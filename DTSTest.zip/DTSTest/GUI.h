//============================================================================
// GUI.h
//
// Header for GUI.cpp, which defines GUI tools for Windows
//
// Copyright (C) 2014 - 2016 Quartzdyne, Inc.  All rights reserved.
//
// No part of this source code may be reproduced or transmitted in any form or
// by any means, electronic or mechanical, including photocopying, recording,
// or any information storage and retrieval system, without express written
// permission from Quartzdyne, Inc.  Further, no use of this source code is
// permitted in any form or means without a valid, written license agreement
// with Quartzdyne, Inc.  While every reasonable precaution has been taken in
// the preparation of this source code, Quartzdyne, Inc., assumes no
// responsibility for errors, omissions, or damages from the use of the source
// code contained herein.
//
// NEITHER QUARTZDYNE, INC., ANY MEMBER OF QUARTZDYNE, INC., NOR ANY PERSON OR
// ORGANIZATION ACTING ON BEHALF OF THEM MAKES ANY WARRANTY OR REPRESENTATION
// WHATSOEVER, EXPRESS OR IMPLIED, INCLUDING ANY WARRANTY OF MERCHANTABILITY
// OR FITNESS FOR ANY PURPOSE WITH RESPECT TO THE SOURCE CODE OR ASSUMES ANY
// LIABILITY WHATSOEVER WITH RESPECT TO ANY USE OF THE SOURCE CODE OR ANY
// PORTION THEREOF OR WITH RESPECT TO ANY DAMAGES THAT MAY RESULT FROM SUCH
// USE.
//
// Noji Ratzlaff
//
// See DTSTest.log for a complete history of all updates, changes, and revisions
// of this source and other files and policies regarding DTSTest software
//
// Updated 01-14-2016
//============================================================================
#pragma once
#ifndef     GUI_H       // provided for legacy compilers, but unnecessary for
#define     GUI_H       // recent compilers, due to the preceding pragma
//----------------------------------------------------------------------------
// Include appropriate headers
//----------------------------------------------------------------------------
#include    "DTSTestDefs.h"
//----------------------------------------------------------------------------
// Specify libraries and namespaces
//----------------------------------------------------------------------------
#using      <mscorlib.dll>
#using      <System.dll>
#using      <System.Data.dll>
#using      <System.Drawing.dll>
#using      <System.Windows.Forms.dll>
#using      <WindowsBase.dll>
//----------------------------------------------------------------------------
// To get WindowsBase.dll, copy it from
// C:\Program Files\Reference Assemblies\Microsoft\Framework\.NETFramework\v4.0
// to C:\WINDOWS\Microsoft.NET\Framework\v4.0.30319
//----------------------------------------------------------------------------
using       namespace System;
using       namespace System::ComponentModel;
using       namespace System::Data;
using       namespace System::Data::Odbc;
using       namespace System::Diagnostics;
using       namespace System::Drawing;
using       namespace System::IO;
using       namespace System::IO::Packaging;
using       namespace System::IO::Ports;
using       namespace System::Net;
using       namespace System::Net::Mail;
using       namespace System::Net::Mime;
using       namespace System::Net::NetworkInformation;
using       namespace System::Security::Permissions;
using       namespace System::Text;
using       namespace System::Threading;
using       namespace System::Windows::Forms;
using       namespace Microsoft::Win32;
//--------------------------------------------------------------------
// Managed structures
//--------------------------------------------------------------------
public value struct EmailInfo
{
    public:
        String                  ^toAddress;
        array <String ^>        ^toAddressArray;
        String                  ^fromAddress;
        array <String ^>        ^fromAddressArray;
        String                  ^ccAddress;
        array <String ^>        ^ccAddressArray;
        String                  ^replyAddress;
        array <String ^>        ^replyAddressArray;
        String                  ^messageString;
        array <String ^>        ^messageStringArray;
        String                  ^subjectString;
        array <String ^>        ^subjectStringArray;
        String                  ^attachment;
        array <String ^>        ^attachmentArray;
};
//----------------------------------------------------------------------------
// CSV Entry Information Structure
//----------------------------------------------------------------------------
public value struct CSVEntryInfo
{
    public:
        int                     scriptLineNumber;
        String                  ^scriptLineNumberString;
        String                  ^loggedCSVEntryString;                      // collection of all these strings
        bool                    logCSVDate;
        String                  ^loggedCSVDateString;
        bool                    logCSVTime;
        String                  ^loggedCSVTimeString;
        bool                    logCSVHardwareID;
        String                  ^loggedCSVHardwareIDString;
        bool                    logCSVState;
        String                  ^loggedCSVStateString;
        bool                    logCSVBaudRateState;
        String                  ^loggedCSVBaudRateStateString;
        bool                    logCSVCRCState;
        String                  ^loggedCSVCRCStateString;
        bool                    logCSVSyncState;
        String                  ^loggedCSVSyncStateString;
        bool                    logCSVFreshState;
        String                  ^loggedCSVFreshStateString;
        bool                    logCSVCableLengthState;
        String                  ^loggedCSVCableLengthStateString;
        bool                    logCSVTempState;
        String                  ^loggedCSVTempStateString;
        bool                    logCSVVoltageState;
        String                  ^loggedCSVVoltageStateString;
        bool                    logCSVInput;
        String                  ^loggedCSVInputString;                      // the entire line entered by the user or script
        bool                    logCSVDelay;
        String                  ^loggedCSVDelayString;
        bool                    logCSVAddress;
        String                  ^loggedCSVAddressString;
        bool                    logCSVCommand;
        String                  ^loggedCSVCommandString;
        bool                    logCSVSent;
        String                  ^loggedCSVSentString;
        bool                    logCSVReply;
        String                  ^loggedCSVReplyString;
        bool                    logCSVExpected;
        String                  ^loggedCSVExpectedString;
        bool                    logCSVPrefix;
        String                  ^loggedCSVPrefixString;
        bool                    logCSVStatus;
        String                  ^loggedCSVStatusString;
        bool                    logCSVChipID;
        String                  ^loggedCSVChipIDString;
        bool                    logCSVOTP;
        String                  ^loggedCSVOTPString;
        bool                    logCSVPressureCount;
        String                  ^loggedCSVPressureCountHexString;
        String                  ^loggedCSVPressureCountDecimalString;
        bool                    logCSVPressureActual;
        String                  ^loggedCSVPressureActualString;
        bool                    logCSVTemperatureCount;
        String                  ^loggedCSVTemperatureCountHexString;
        String                  ^loggedCSVTemperatureCountDecimalString;    
        bool                    logCSVTemperatureActual;
        String                  ^loggedCSVTemperatureActualString;
        bool                    logCSVType;
        String                  ^loggedCSVTypeString;
        bool                    logCSVVersion;
        String                  ^loggedCSVVersionString;
        bool                    logCSVHolding;
        String                  ^loggedCSVHoldingString;
        bool                    logCSVVendor;
        String                  ^loggedCSVVendorString;
        bool                    logCSVRemaining;
        String                  ^loggedCSVRemainingString;
        bool                    logCSVInterpretation;
        String                  ^loggedCSVInterpretationString;
        bool                    logCSVResult;
        String                  ^loggedCSVResultString;
        bool                    logCSVError;
        String                  ^loggedCSVErrorString;
        bool                    logCSVComment;
        String                  ^loggedCSVCommentString;
        bool                    logCSVInstructionalComment;
        String                  ^loggedCSVInstructionalCommentString;
};                                      // end of CSVEntryInfo
//----------------------------------------------------------------------------
// Coefficient Information Structure
//----------------------------------------------------------------------------
public value struct CoefficientInfo
{
    public:
        String                  ^cffFilePath;
        String                  ^cftFilePath;
        String                  ^hexFilePath;
        String                  ^cof2FilePath;
        bool                    coefficientDataLoaded;
        CoefficientDataFormat   *coefficientData;
};                                      // end of CoefficientInfo
//----------------------------------------------------------------------------
// Calibrate Structure
//----------------------------------------------------------------------------
public value struct Calibrate
{
    public:
        BYTE                    nodeAddress;
        String                  ^hybridSerialNumberString;
        bool                    hybridSerialNumberStringIsValid;
        String                  ^jigSerialNumberString;
        bool                    jigSerialNumberStringIsValid;
        int                     pressureAmbientCount;
        int                     temperatureAmbientCount;
        int                     temperature100Count;
        int                     temperature150Count;
        int                     temperature175Count;
        int                     temperature200Count;
        int                     temperature225Count;
        CoefficientDataFormat   *coefficientData;
        String                  ^hexFilePathString;
};                                      // end of Calibrate
//----------------------------------------------------------------------------
// Transducer Information Structure
//----------------------------------------------------------------------------
public value struct TransducerInfo
{
    public:
        String                  ^serialNumber;
        String                  ^partNumber;
        int                     numberOfSamples;
        DWORD                   currentPressureCount;
        float                   currentPressureFrequency;
        double                  currentPressurePSI;
        double                  totalPressurePSI;
        DWORD                   currentTemperatureCount;
        float                   currentTemperatureFrequency;
        double                  currentTemperatureCelsius;
        double                  totalTemperatureCelsius;
        CoefficientInfo         ^coefficientInfo;
};                                      // end of TransducerInfo
//----------------------------------------------------------------------------
// Hybrid Information Structure
//----------------------------------------------------------------------------
public value struct HybridInfo
{
    public:
        int                     hybridNumber;
        String                  ^hybridSerialNumber;
        String                  ^hybridPartNumber;
};                                      // end of HybridInfo
//----------------------------------------------------------------------------
// Test Entry Structure
//----------------------------------------------------------------------------
public value struct TestEntry
{
    public:
        bool                    entrySelectedForTesting;
        BYTE                    placeholder1Value;
        BYTE                    placeholder2Value;
        BYTE                    placeholder3Value;
        String                  ^primaryDeviceTypeString;
        String                  ^entryControlScriptPath;
        String                  ^entryControlScriptFile;
        String                  ^entryCommandString;
        String                  ^entryCommandReplacedString;
        bool                    coefficientDataLoaded;
        bool                    allTestsCompleted;
        bool                    allTestsPassed;
        int                     entryTestResults;
        CheckBox                ^entrySelectedCheck;
        Label                   ^entryStatusLEDLabel;
        TextBox                 ^placeholder1Box;
        TextBox                 ^placeholder2Box;
        TextBox                 ^placeholder3Box;
        Label                   ^primaryDeviceTypeLabel;
        TextBox                 ^entryScriptCommandBox;
        Button                  ^entryScriptPathButton;
        ProgressBar             ^entryProgressBar;
        Graphics                ^percentGraphics;
        Label                   ^entryPressureLabel;
        Label                   ^entryTemperatureLabel;
        Button                  ^entryLoadEraseButton;
//        CSVEntryInfo            ^entryCSVEntry;
};                                      // end of TestEntry
//----------------------------------------------------------------------------
// Script Structure
//----------------------------------------------------------------------------
public value struct Script
{
    public:
        String                  ^controlScriptString;
        bool                    controlScriptIsLoaded;
        String                  ^controlScriptFilePath;
        String                  ^resultsLogFilePath;
        String                  ^placeholder1String;
        BYTE                    placeholder1Value;
        String                  ^placeholder2String;
        BYTE                    placeholder2Value;
        String                  ^placeholder3String;
        BYTE                    placeholder3Value;
        int                     scriptNumberOfFailures;
        int                     scriptNumberOfPasses;
};                                      // end of Script
//----------------------------------------------------------------------------
// SensorInfo structure
//----------------------------------------------------------------------------
public value struct SensorInfo
{
    public:
        BYTE                    nodeAddress;
        int                     sensorNumber;       // the LSB of sensorNumber should be the same as nodeAddress
        bool                    sensorPresent;
        bool                    sensorIdentified;
        DWORD                   sensorType;
        String                  ^hardwareIDString;
        //--------------------------------------------------------------------
        // Baud rate
        //--------------------------------------------------------------------
        int                     currentBaudRateRx;
        int                     currentBaudRateTx;
        //--------------------------------------------------------------------
        // Sensor Position
        //--------------------------------------------------------------------
        int                     gaugePosition;          // 1 or 2
        String                  ^gaugePositionString;
        bool                    fieldGPPopulated;
        //--------------------------------------------------------------------
        // Sensor Address
        //--------------------------------------------------------------------
        unsigned char           gaugeType;
        int                     gaugeTypeNumber;
        WORD                    gaugeAddress;
        String                  ^gaugeAddressString;
        bool                    fieldGAPopulated;
        //--------------------------------------------------------------------
        // QD Serial Number
        //--------------------------------------------------------------------
        String                  ^QDSerialNumber;
        String                  ^calNumber;
        String                  ^QDPartNumber;
        bool                    fieldQDSNPopulated;
        //--------------------------------------------------------------------
        // Hybrid Serial Number
        //--------------------------------------------------------------------
        String                  ^hybridSerialNumber;
        String                  ^hybridPartNumber;
        String                  ^fullDocumentName;
        bool                    fieldHSNPopulated;
        //--------------------------------------------------------------------
        // Versions
        //--------------------------------------------------------------------
        bool                    repairVersion;          // 'RP' version ?
        bool                    L5Transducer;           // 'L5' version ?
        //--------------------------------------------------------------------
        // Measurements
        //--------------------------------------------------------------------
        bool                    addBias;
        bool                    measurementsValid;
        float                   pressurePSI;
        float                   temperatureCelsius;
        float                   pressureFrequency;
        float                   temperatureFrequency;
        int                     numberOfSamples;
        DWORD                   currentPressureCount;
        float                   currentPressureFrequency;
        double                  currentPressurePSI;
        double                  totalPressurePSI;
        double                  pressurePSIBias;
        DWORD                   currentTemperatureCount;
        float                   currentTemperatureFrequency;
        double                  currentTemperatureCelsius;
        double                  totalTemperatureCelsius;
        double                  temperatureCelsiusBias;
        //--------------------------------------------------------------------
        // Structures
        //--------------------------------------------------------------------
        CoefficientInfo         ^coefficientInfo;
        BYTE                    coefficientDataChecksum;
};                                      // end of SensorInfo
//----------------------------------------------------------------------------
// PDGIC Info structure
//----------------------------------------------------------------------------
public value struct PDGICInfo
{
    public:
        bool                    PDGICPresent;
        SerialPort              ^port;
        String                  ^portName;
        int                     portOffset;
        BYTE                    nodeAddress;
        bool                    powerToBargesEnabled;
        int                     baudRate;
        int                     dataBits;
        StopBits                stopBits;
        Parity                  parity;
        Handshake               handShaking;
        int                     timeout;
        WORD                    maximumNumberOfSlots;
        String                  ^modelName;
        WORD                    chipID;
        WORD                    systemStatus;
        WORD                    firmwareVersion;
        WORD                    serialNumber;
        WORD                    devicePowerEnableMask;
        bool                    channelPowerEnabled;
        bool                    ROCXModeEnabled;
        bool                    configuredToRequestTransducerData;
        int                     transducerDataDisplayMode;
        float                   channelVoltageSetPoint;
        float                   currentUnitACCurrent;
        float                   currentUnitTemperature;
        float                   currentUnitDCCurrent;
        float                   currentUnitSupplyVoltage;
        float                   currentUnitOutputVoltage;
        float                   currentUnitInputVoltage;
        WORD                    numberOfRegistersToTransfer;
        WORD                    startingRegisterOffset;
        int                     numberOfBytesRead;
        WORD                    writeData;
        int                     numberOfCommandBytes;
        int                     expectedNumberOfResponseBytes;
        bool                    rawCommand;
        array <unsigned char>   ^commandArray;
        array <unsigned char>   ^responseArray;
        String                  ^responseString;
        bool                    sentCRCIsValid;
        bool                    receivedCRCIsValid;
//        bool                    controlScriptIsLoaded;
//        String                  ^currentControlScriptPathName;
//        String                  ^currentControlScript;
        bool                    atLeastOneBargePresent;
        int                     numberOfBarges;
        bool                    atLeastOneGaugePresent;
        int                     numberOfGauges;
        bool                    atLeastOneSensorPresent;
        int                     numberOfSensors;
        array <SensorInfo ^>    ^sensorInfoArray;
};                                      // end of PDGICInfo
//----------------------------------------------------------------------------
// General Information Structure
//----------------------------------------------------------------------------
public value struct GeneralInfo
{
    public:
        DWORD                   flags;
        DWORD                   persistentFlags;
        String                  ^commandLine;
        String                  ^configFilePath;
        String                  ^generalUsePath;
        String                  ^logDirectory;
        String                  ^errorLogPath;
        String                  ^eventLogPath;
        String                  ^mostRecentEventLogPath;
        String                  ^windowsVersion;
        String                  ^emailAddress;
        String                  ^emailCCAddress;
        String                  ^textMessageToNumber;
        String                  ^textMessageCCNumber;
        String                  ^emailMessageToAddress;
        String                  ^emailMessageCCAddress;
        String                  ^searchString;
        String                  ^operatorName;
        String                  ^dieSerialNumber;
        Script                  ^mainScript;
        CoefficientInfo         ^defaultCoefficientInfo;
        PDGICInfo               ^pgInfo;
        Calibrate               ^calibrate;
        int                     serialPortsSearchedCount;
        array <String ^>        ^serialPortsSearchedArray;
};                                      // end of GeneralInfo
//----------------------------------------------------------------------------
// The main window class
//
// Note:    [SecurityPermissionAttribute(...)] is needed to support the
//          unhandled exception handler DTSTest_DefaultExceptionHandler
//----------------------------------------------------------------------------
    public ref class        // __gc class has been replaced by ref class
DTSTest_GUIClass :
    public Form
{
    public:
        [SecurityPermissionAttribute(SecurityAction::Demand, ControlAppDomain = true)]
        DTSTest_GUIClass();
    private:
        //--------------------------------------------------------------------
        // Single-element variable members
        //--------------------------------------------------------------------
        bool                    DTSTest_PDGICSuccessfulReply;
        int                     pgErrorReply;
        BackgroundWorker        ^samplingEntryBackground;
        BackgroundWorker        ^testingEntryBackground;
        Bitmap                  ^blueDotOffImage;
        Bitmap                  ^blueDotOnImage;
        Bitmap                  ^greenDotOffImage;
        Bitmap                  ^greenDotOnImage;
        Bitmap                  ^redDotOffImage;
        Bitmap                  ^redDotOnImage;
        Bitmap                  ^sandBackground;
        Bitmap                  ^whiteMarbleBackground;
        Bitmap                  ^whiteSandBackground;
        Bitmap                  ^yellowLEDOffImage;
        Bitmap                  ^yellowLEDOnImage;
        Button                  ^advancedExpOneButton;
        Button                  ^experimentalStartStopSamplingGauge3EButton;
        Button                  ^homeAddCommentButton;
        Button                  ^homeClearCommandDialogueButton;
        Button                  ^homeExitButton;
        Button                  ^homeLoadControlScriptButton;
        Button                  ^homeLoopControlScriptButton;
        Button                  ^homeRerunControlScriptButton;
        Button                  ^homeSaveCommandDialogueButton;
        Button                  ^homeSingleCommandSendButton;
        Button                  ^homeSwitchBaudRateButton;
        Button                  ^samplingStartStopAllButton;
        Button                  ^samplingStartStopAllBargesButton;
        Button                  ^samplingStartStopAllGaugesButton;
        Button                  ^sensorGenerateCoefficientsButton;
        Button                  ^sensorSnapshot100TemperatureButton;
        Button                  ^sensorSnapshot150TemperatureButton;
        Button                  ^sensorSnapshot175TemperatureButton;
        Button                  ^sensorSnapshot200TemperatureButton;
        Button                  ^sensorSnapshot225TemperatureButton;
        Button                  ^sensorSnapshotAmbientTemperatureButton;
        Button                  ^testingClearCommandDialogueButton;
        Button                  ^testingLEDButton;
        Button                  ^testingPauseResumeButton;
        Button                  ^testingRunStopButton;
        CheckBox                ^advancedBasicMessagesCheck;
        CheckBox                ^advancedDeleteConfigCheck;
        CheckBox                ^advancedDetailedMessagesCheck;
        CheckBox                ^advancedDontSaveConfigCheck;
        CheckBox                ^advancedEnableExperimentsCheck;
        CheckBox                ^advancedEnableStackTracesCheck;
        CheckBox                ^advancedErrorMessagesCheck;
        CheckBox                ^advancedExpMessagesCheck;
        CheckBox                ^advancedSendEmailErrorMessageCheck;
        CheckBox                ^advancedSendTextErrorMessageCheck;
        CheckBox                ^advancedVerboseMessagesCheck;
        CheckBox                ^homeCalculateCRCsCheck;
        CheckBox                ^homeDemoModeCheck;
        CheckBox                ^homeNormalizeReadingsCheck;
        CheckBox                ^homePrependDateAndTimeCheck;
        CheckBox                ^homeReportCRCErrorsCheck;
        CheckBox                ^homeSaveCSVResultsCheck;
        CheckBox                ^testingDemoModeCheck;
        ComboBox                ^advancedSerialPortCombo;
        ComboBox                ^emailFromCombo;
        ComboBox                ^emailToCombo;
        Drawing::Icon           ^DTSTest_SoftwareIcon;
        Form                    ^aboutHelpWindow;
        Form                    ^advancedControlsWindow;
        Form                    ^emailSupportLogWindow;
        Form                    ^eventLogWindow;
        Form                    ^experimentalControlsWindow;
        Form                    ^fileControlsWindow;
        Form                    ^pInfoWindow;
        Form                    ^pleaseWaitWindow;
        Form                    ^samplingControlsWindow;
        Form                    ^scriptControlsWindow;
        Form                    ^testingControlsWindow;
        GroupBox                ^testingBaudRateGroupBox;
        Label                   ^emailStatusLabel;
        Label                   ^advancedEmailMessageToAddressLabel;
        Label                   ^advancedEmailMessageCCAddressLabel;
        Label                   ^advancedTextMessageCCNumberLabel;
        Label                   ^advancedTextMessageToNumberLabel;
        Label                   ^homeBaudRateLabel;
        Label                   ^homeResultsLogPathLabel;
        Label                   ^homeScriptFilenameLabel;
        Label                   ^pleaseWaitLabel;
        Label                   ^sensor100CountLabel;
        Label                   ^sensor150CountLabel;
        Label                   ^sensor175CountLabel;
        Label                   ^sensor200CountLabel;
        Label                   ^sensor225CountLabel;
        Label                   ^sensorAmbientCountLabel;
        Label                   ^sensorDeviceNodeAddressHexLabel;
        Label                   ^testingCRCLEDLabel;
        Label                   ^testingLoopsCompletedLabel;
        Label                   ^testingNormalizeLEDLabel;
        Label                   ^testingResultsLogPathLabel;
        Label                   ^testingSyncLEDLabel;
        Media::SoundPlayer      ^downSound;
        Media::SoundPlayer      ^errorSound;
        Media::SoundPlayer      ^openSound;
        Media::SoundPlayer      ^tadaSound;
        RadioButton             ^testingBaudRate1200Radio;
        RadioButton             ^testingBaudRate2400Radio;
        RadioButton             ^testingBaudRate4800Radio;
        RadioButton             ^testingBaudRate600Radio;
        StatusStrip             ^homeStatusStrip;
        String                  ^generalCSVFileString;
        String                  ^generalLogFileString;
        TextBox                 ^advancedEmailMessageCCAddressBox;
        TextBox                 ^advancedEmailMessageToAddressBox;
        TextBox                 ^advancedExperimentNumberBox;
        TextBox                 ^advancedTextMessageCCNumberBox;
        TextBox                 ^advancedTextMessageToNumberBox;
        TextBox                 ^emailMessageBox;
        TextBox                 ^emailSubjectBox;
        TextBox                 ^homeAddCommentBox;
        TextBox                 ^homeCommandDialogueBox;
        TextBox                 ^homeDieSerialNumberBox;
        TextBox                 ^homeOperatorNameBox;
        TextBox                 ^homePlaceholder1Box;
        TextBox                 ^homePlaceholder2Box;
        TextBox                 ^homeSingleCommandBox;
        TextBox                 ^testingDelayBox;
        Windows::Forms::Timer   ^oneSecondTimer;
        Windows::Forms::Timer   ^scriptControlLoopTimer;
        ToolStripButton         ^advancedControlsTSButton;
        ToolStripButton         ^configFileSaveDontSaveTSButton;
        ToolStripButton         ^displayEventLogTSButton;
        ToolStripButton         ^eventLogAllTSButton;
        ToolStripButton         ^eventLogBasicTSButton;
        ToolStripButton         ^eventLogDetailedTSButton;
        ToolStripButton         ^eventLogVerboseTSButton;
        ToolStripButton         ^experimentalControlsTSButton;
        ToolStripButton         ^expertFunctionTSButton;
        ToolStripButton         ^programInfoTSButton;
        ToolStripButton         ^samplingControlsTSButton;
//        ToolStripButton         ^scriptControlsTSButton;
        ToolStripButton         ^testingControlsTSButton;
        ToolStripDropDown       ^helpTSDropDown;
        ToolStripDropDownButton ^advancedTSDDButton;
        ToolStripDropDownButton ^controlTSDDButton;
        ToolStripDropDownButton ^eventLogRecordingTSDDButton;
        ToolStripDropDownButton ^fileTSDDButton;
        ToolStripDropDownButton ^helpTSDDButton;
        ToolStripProgressBar    ^homeTSProgressBar;
        ToolStripStatusLabel    ^homeTSStatusLabel;
        ToolStripStatusLabel    ^nowTSStatusLabel;
        CSVEntryInfo            ^generalCSVEntry;
        GeneralInfo             ^DTSTest_GeneralInfo;
        //--------------------------------------------------------------------
        // Array variables
        //--------------------------------------------------------------------
        array <String ^>        ^DTSTest_MonthStringArray;
        array <String ^>        ^DTSTest_SerialPortNameStringArray;
//        array <ScriptPlaceholder ^>
//                                ^DTSTest_ScriptPlaceholderArray;
        array <TestEntry ^>     ^DTSTest_TestEntryArray;
        //--------------------------------------------------------------------
        // Methods
        //--------------------------------------------------------------------
        void    DTSTest_Start(void);
        void    DTSTest_AboutHelp(void);
        void    DTSTest_AdvancedBasicMessagesChecked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    DTSTest_AdvancedCalibrateSensorButtonClicked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    DTSTest_AdvancedControlsCloseWindow(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    DTSTest_AdvancedControlsClosingWindow(
                    Object          ^sender,
                    FormClosingEventArgs
                                    ^evt);
        void    DTSTest_AdvancedControlsSetUpWindow(void);
        void    DTSTest_AdvancedDeleteConfigChecked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    DTSTest_AdvancedDeleteConfigCheckMouseEntered(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    DTSTest_AdvancedDetailedMessagesChecked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    DTSTest_AdvancedDetailedMessagesCheckMouseEntered(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    DTSTest_AdvancedEmailMessageCCAddressBoxMouseEntered(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    DTSTest_AdvancedEmailMessageToAddressBoxMouseEntered(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    DTSTest_AdvancedEnableExperimentsAreaMouseEntered(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    DTSTest_AdvancedEnableExperimentsChecked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    DTSTest_AdvancedEnableStackTracesChecked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    DTSTest_AdvancedEnableStackTracesCheckMouseEntered(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    DTSTest_AdvancedErrorMessagesChecked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    DTSTest_AdvancedErrorMessagesCheckMouseEntered(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    DTSTest_AdvancedExpMessagesChecked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    DTSTest_AdvancedExpMessagesCheckMouseEntered(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    DTSTest_AdvancedExpOneButtonClicked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    DTSTest_AdvancedExpOneButtonMouseEntered(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    DTSTest_AdvancedKeepPortOpenChecked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    DTSTest_AdvancedResetAllMessagesButtonClicked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    DTSTest_AdvancedResetAllUserAddressesButtonClicked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    DTSTest_AdvancedSendEmailErrorMessageChecked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    DTSTest_AdvancedSendEmailErrorMessageCheckMouseEntered(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    DTSTest_AdvancedSendTextErrorMessageChecked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    DTSTest_AdvancedSendTextErrorMessageCheckMouseEntered(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    DTSTest_AdvancedSerialPortAreaMouseEntered(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    DTSTest_AdvancedSerialPortComboProcessEnterKey(
                    Object          ^sender,
                    KeyEventArgs    ^evt);
        void    DTSTest_AdvancedSerialPortComboProcessSelection(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    DTSTest_AdvancedTextMessageCCNumberBoxMouseEntered(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    DTSTest_AdvancedTextMessageToNumberBoxMouseEntered(
                    Object          ^sender,
                    EventArgs       ^evt);
//        void    DTSTest_AdvancedUserBarge1LoadButtonClicked(
//                    Object          ^sender,
//                    EventArgs       ^evt);
//        void    DTSTest_AdvancedUserBarge2LoadButtonClicked(
//                    Object          ^sender,
//                    EventArgs       ^evt);
//        void    DTSTest_AdvancedUserBarge3LoadButtonClicked(
//                    Object          ^sender,
//                    EventArgs       ^evt);
//        void    DTSTest_AdvancedUserBarge4LoadButtonClicked(
//                    Object          ^sender,
//                    EventArgs       ^evt);
//        void    DTSTest_AdvancedUserBarge5LoadButtonClicked(
//                    Object          ^sender,
//                    EventArgs       ^evt);
//        void    DTSTest_AdvancedUserBarge6LoadButtonClicked(
//                    Object          ^sender,
//                    EventArgs       ^evt);
//        void    DTSTest_AdvancedUserGauge1LoadButtonClicked(
//                    Object          ^sender,
//                    EventArgs       ^evt);
//        void    DTSTest_AdvancedUserGauge2LoadButtonClicked(
//                    Object          ^sender,
//                    EventArgs       ^evt);
//        void    DTSTest_AdvancedUserGauge3LoadButtonClicked(
//                    Object          ^sender,
//                    EventArgs       ^evt);
        void    DTSTest_AdvancedVerboseMessagesChecked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    DTSTest_AdvancedVerboseMessagesCheckMouseEntered(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    DTSTest_AdvancedWorkAroundDTSBadCRCErrorChecked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    DTSTest_AffirmStartupConditions(void);
        void    DTSTest_AnyObjectMouseExited(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    DTSTest_AppendLineToCSVLog(
                    String          ^csvLineString);
        void    DTSTest_AppendLineToDataLog(
                    String          ^logLineString);
        double  DTSTest_CalculatePressureBias(
                    double          pressureValuePSI);
        double  DTSTest_CalculateTemperatureBias(
                    double          temperatureValueCelsius);
        void    DTSTest_CaptureCommandLine(void);
        void    DTSTest_CheckForCurrentSoftwareVersion(
                    bool            announceResults);
        String  ^DTSTest_CleanUpTextBoxText(
                    String          ^textBoxText);
        void    DTSTest_ComboBoxAcceptEnterKey(
                    Object          ^sender,
                    PreviewKeyDownEventArgs
                                    ^evt);
        void    DTSTest_CommandDialogueAppendLine(
                    String          ^lineString);
        void    DTSTest_ComputerGoingToHibernation(
                    Object          ^sender,
                    PowerModeChangedEventArgs
                                    ^evt);
        void    DTSTest_ComputerShuttingDown(
                    Object          ^sender,
                    SessionEndedEventArgs
                                    ^evt);
        void    DTSTest_ComputerUserChanging(
                    Object          ^sender,
                    SessionSwitchEventArgs
                                    ^evt);
        void    DTSTest_ConcludeErrorLog(
                    String          ^finalErrorEntry);
        void    DTSTest_ConcludeEventLog(
                    String          ^finalEventEntry);
        void    DTSTest_ConcludeGeneralLogs(
                    String          ^finalEventEntry);
        void    DTSTest_ConfigFileSaveDontSaveAreaClicked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    DTSTest_ConfigFileSaveDontSaveAreaMouseEntered(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    DTSTest_ConstructAndPresentUserInterface(void);
        void    DTSTest_ConstructHomeWindow(void);
        void    DTSTest_DefaultExceptionHandler(
                    Object          ^sender,
                    UnhandledExceptionEventArgs
                                    ^evt);
        void    DTSTest_DetermineResultsLog(void);
        void    DTSTest_DisplayHelpLink(
                    Form            ^helpWindow,
                    String          ^textString,
                    DWORD           yPosition,
                    DWORD           fieldWidth,
                    DWORD           firstLinkCharacterOffset,
                    DWORD           numberOfLinkCharacters);
        void    DTSTest_DisplayHelpTextLine(
                    Form            ^helpWindow,
                    String          ^textString,
                    DWORD           yPosition,
                    DWORD           fieldWidth);
        System::Windows::Forms::DialogResult
                DTSTest_DisplayModalMessage(
                    bool            allow,
                    DWORD           flag,
                    String          ^titleString,
                    String          ^formatString,
                    ...array <Object ^>
                                    ^parameters);
        void    DTSTest_DisplayMostRecentEventLog(void);
        bool    DTSTest_EmailAddressFormatIsValid(
                    String          ^emailAddress);
        void    DTSTest_EmailMessageClearComboBox(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    DTSTest_EmailMessageCloseButtonMouseEntered(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    DTSTest_EmailMessageProcessComboEnterKey(
                    Object          ^sender,
                    KeyEventArgs    ^evt);
        void    DTSTest_EmailMessageSendButtonClicked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    DTSTest_EmailMessageSendButtonMouseEntered(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    DTSTest_EmailSupportLogCloseWindow(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    DTSTest_ErrorAlert(
                    String          ^titleString,
                    DWORD           status,
                    DWORD           messageFlags,
                    String          ^formatString,
                    ...array <Object ^>
                                    ^parameters);
        void    DTSTest_EstablishErrorLog(void);
        void    DTSTest_EstablishEventLog(
                    String          ^initialEventEntry);
        void    DTSTest_EstablishLogDirectory(void);
        void    DTSTest_EventLogCloseWindow(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    DTSTest_ExitProgram(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    DTSTest_ExperimentalChangeHardwareTypeButtonClicked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    DTSTest_ExperimentalControlsCloseWindow(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    DTSTest_ExperimentalControlsClosingWindow(
                    Object          ^sender,
                    FormClosingEventArgs
                                    ^evt);
        void    DTSTest_ExperimentalControlsSetUpWindow(void);
        void    DTSTest_ExperimentalEnableUserInterface(void);
        void    DTSTest_ExperimentalMemoryToolButtonClicked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    DTSTest_ExperimentalScanForDevices(
                    PDGICInfo       ^pgInfo);
        void    DTSTest_ExperimentalScanForDevicesThread(
                    Object          ^pgInfoContext);
        void    DTSTest_ExperimentalSendIdentifyCommandButtonClicked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    DTSTest_ExperimentalSendStatusCommandButtonClicked(
                    Object          ^sender,
                    EventArgs       ^evt);
        DWORD   DTSTest_ExperimentalSetDTSBaudRate(
                    PDGICInfo       ^pgInfo,
                    int             targetBaudRate);
        void    DTSTest_ExperimentalStartStopSamplingGauge3EButtonClicked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    DTSTest_ExperimentalSyncAllButtonClicked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    DTSTest_ExperimentalSyncB4ButtonClicked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    DTSTest_ExperimentalSyncE2ButtonClicked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    DTSTest_ExperimentalSendChipIDCommandButtonClicked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    DTSTest_FileControlsCloseWindow(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    DTSTest_FileControlsClosingWindow(
                    Object          ^sender,
                    FormClosingEventArgs
                                    ^evt);
        void    DTSTest_FileControlsSetUpWindow(void);
        void    DTSTest_FileCreateCSVEntry(
                    CSVEntryInfo    ^entry,
                    bool            isHeaderEntry);
        void    DTSTest_FileInitializeCSVHeader(
                    CSVEntryInfo    ^entry);
        void    DTSTest_Finalize(
                    String          ^finalEventEntry);
        void    DTSTest_FreeGeneralElements(void);
        void    DTSTest_GenerateSupportLog(void);
        void    DTSTest_GetWindowsEnvironment(void);
        void    DTSTest_GetWindowsVersion(void);
        bool    DTSTest_GlobalFileSearch(
                    String          ^fileName,
                    StringBuilder   ^filePath);
        void    DTSTest_HelpAboutQuartzdyneLogoMouseEntered(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    DTSTest_HelpAboutSoftwareLogoMouseEntered(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    DTSTest_HelpCloseWindow(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    DTSTest_HomeAddCommentAreaMouseEntered(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    DTSTest_HomeAddCommentButtonClicked(
                    Object          ^sender,
                    EventArgs       ^evt);
//        void    DTSTest_HomeBargeE2PowerDisableButtonClicked(
//                    Object          ^sender,
//                    EventArgs       ^evt);
//        void    DTSTest_HomeBargeE2PowerDisableButtonMouseEntered(
//                    Object          ^sender,
//                    EventArgs       ^evt);
//        void    DTSTest_HomeBargeE2PowerEnableButtonClicked(
//                    Object          ^sender,
//                    EventArgs       ^evt);
//        void    DTSTest_HomeBargeE2PowerEnableButtonMouseEntered(
//                    Object          ^sender,
//                    EventArgs       ^evt);
        void    DTSTest_HomeBaudRateLabelMouseEntered(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    DTSTest_HomeCalculateCRCsChecked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    DTSTest_HomeCalculateCRCsCheckMouseEntered(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    DTSTest_HomeCommandDialogueBoxMouseEntered(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    DTSTest_HomeClearCommandDialogueButtonClicked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    DTSTest_HomeClearCommandDialogueButtonMouseEntered(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    DTSTest_HomeClosingWindow(
                    Object          ^sender,
                    FormClosingEventArgs
                                    ^evt);
        void    DTSTest_HomeCSVLogChecked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    DTSTest_HomeCSVLogCheckMouseEntered(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    DTSTest_HomeDieSerialNumberAreaMouseEntered(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    DTSTest_HomeDemoModeChecked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    DTSTest_HomeDemoModeCheckMouseEntered(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    DTSTest_HomeExitButtonMouseEntered(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    DTSTest_HomeLoadControlScriptFileButtonClicked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    DTSTest_HomeLoadControlScriptFileButtonMouseEntered(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    DTSTest_HomeLoopControlScriptButtonClicked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    DTSTest_HomeLoopControlScriptButtonMouseEntered(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    DTSTest_HomeNormalizeReadingsChecked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    DTSTest_HomeNormalizeReadingsCheckMouseEntered(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    DTSTest_HomeOperatorNameAreaMouseEntered(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    DTSTest_HomePlaceholderAreaMouseEntered(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    DTSTest_HomePrependDateAndTimeChecked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    DTSTest_HomePrependDateAndTimeCheckMouseEntered(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    DTSTest_HomeProgressBarMouseEntered(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    DTSTest_HomeReportCRCErrorsChecked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    DTSTest_HomeReportCRCErrorsCheckMouseEntered(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    DTSTest_HomeRerunControlScriptButtonClicked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    DTSTest_HomeRerunControlScriptButtonMouseEntered(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    DTSTest_HomeResultsLogPathLabelMouseEntered(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    DTSTest_HomeSaveCommandDialogueButtonClicked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    DTSTest_HomeSaveCommandDialogueButtonMouseEntered(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    DTSTest_HomeSingleCommandAreaMouseEntered(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    DTSTest_HomeSingleCommandSendButtonClicked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    DTSTest_HomeSwitchBaudRateButtonClicked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    DTSTest_HomeSwitchBaudRateButtonMouseEntered(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    DTSTest_HomeTextBoxAcceptEnterKey(
                    Object          ^sender,
                    PreviewKeyDownEventArgs
                                    ^evt);
        void    DTSTest_HomeTextBoxProcessEnterKey(
                    Object          ^sender,
                    KeyEventArgs    ^evt);
        void    DTSTest_HomeVerboseLogMessagesChecked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    DTSTest_HomeVerboseLogMessagesCheckMouseEntered(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    DTSTest_HyperLinkClicked(
                    Object          ^sender,
                    LinkLabelLinkClickedEventArgs
                                    ^evt);
        void    DTSTest_InitializeGUIComponents(void);
        DWORD   DTSTest_InitializeDTSTest(void);
        void    DTSTest_InitializeProgramComponents(void);
        void    DTSTest_InitializeUserInterface(void);
        void    DTSTest_InstallHomeWindowGraphics(void);
        void    DTSTest_InstallStatusStrip(void);
        void    DTSTest_InstallToolStrip(void);
        void    DTSTest_InstallUtilities(void);
        bool    DTSTest_InternetIsAvailable(void);
        String  ^DTSTest_LimitFilePathStringWidth(
                    String          ^filePath,
                    DWORD           maximumWidth);
        String  ^DTSTest_LimitStringWidth(
                    String          ^textString,
                    DWORD           maximumWidth,
                    bool            truncateString);
        void    DTSTest_LoadDefaultCoefficientData(void);
        void    DTSTest_LoadImagesAndSounds(void);
        void    DTSTest_LogTesterInfo(void);
        bool    DTSTest_NetworkIsAvailable(void);
        void    DTSTest_OneSecondTimerElapsed(
                    Object          ^sender,
                    EventArgs       ^evt);
        bool    DTSTest_ParseAndConvertHexStringToByte(
                    String          ^hexString,
                    BYTE            *unsignedEquivalent);
        bool    DTSTest_ParseAndConvertStringToUnsigned(
                    String          ^integerString,
                    DWORD           *unsignedEquivalent);
        bool    DTSTest_ParseAndConvertStringToInteger(
                    String          ^integerString,
                    int             *signedEquivalent);
        DWORD   DTSTest_PDGICAcquireReadings(void);
        DWORD   DTSTest_PDGICClosePersistentPort(
                    PDGICInfo       ^pgInfo);
        void    DTSTest_PDGICDeterminePDGICPresence(
                    PDGICInfo       ^pgInfo);
        DWORD   DTSTest_PDGICDisablePowerToAllGaugeBarges(
                    PDGICInfo       ^pgInfo);
        void    DTSTest_PDGICDummyRead(
                    PDGICInfo       ^pgInfo);
        DWORD   DTSTest_PDGICEnablePowerToAllGaugeBarges(
                    PDGICInfo       ^pgInfo);
        DWORD   DTSTest_PDGICInitializeEnvironment(void);
        void    DTSTest_PDGICLocatePort(
                    PDGICInfo       ^pgInfo);
        DWORD   DTSTest_PDGICOpenPersistentPort(
                    PDGICInfo       ^pgInfo);
        DWORD   DTSTest_PDGICOpenPort(
                    PDGICInfo       ^pgInfo,
                    SerialPort      ^port);
        DWORD   DTSTest_PDGICReadWords(
                    PDGICInfo       ^pgInfo);
        void    DTSTest_PDGICResetErrorCondition(
                    PDGICInfo       ^pgInfo);
        void    DTSTest_PDGICRetrieveCurrentReadings(void);
        void    DTSTest_PDGICRetrieveDTSChipID(
                    PDGICInfo       ^pgInfo);
        void    DTSTest_PDGICRetrieveDTSIdentification(
                    PDGICInfo       ^pgInfo);
        void    DTSTest_PDGICRetrieveDTSInformation(
                    PDGICInfo       ^pgInfo);
        void    DTSTest_PDGICRetrieveDTSStatus(
                    PDGICInfo       ^pgInfo);
        void    DTSTest_PDGICRetrieveNodeAddress(
                    PDGICInfo       ^pgInfo);
        DWORD   DTSTest_PDGICRetrieveResponse(
                    PDGICInfo       ^pgInfo,
                    SerialPort      ^port);
        String  ^DTSTest_PDGICReturnDeviceInformationString(
                    PDGICInfo       ^pgInfo);
        DWORD   DTSTest_PDGICSendCommand(
                    PDGICInfo       ^pgInfo);
        DWORD   DTSTest_PDGICSendRawCommand(
                    PDGICInfo       ^pgInfo);
        DWORD   DTSTest_PDGICSetBaudRateForAllBarges(
                    PDGICInfo       ^pgInfo,
                    int             targetBaudRate);
        DWORD   DTSTest_PDGICSetDTSSystemBaudRate(
                    PDGICInfo       ^pgInfo,
                    int             targetBaudRate);
        void    DTSTest_PDGICShutDownEnvironment(void);
        bool    DTSTest_PDGICTransmitCRCIsValid(
                    PDGICInfo       ^pgInfo);
        void    DTSTest_PerformCommandLineTasks(void);
        void    DTSTest_PerformExperiments(void);
        void    DTSTest_PleaseWait(
                    DWORD           action,
                    String          ^formatString,
                    ...array <Object ^>
                                    ^parameters);
        void    DTSTest_PleaseWaitClosingWindow(
                    Object          ^sender,
                    FormClosingEventArgs
                                    ^evt);
        void    DTSTest_ProcessCommandLine(
                    String          ^commandLineString,
                    bool            testingContext);
        DWORD   DTSTest_ProcessCommandLineParameters(void);
        void    DTSTest_ProgramInfoCloseWindow(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    DTSTest_ProgramInfoDisplayWindow(void);
        bool    DTSTest_PromptForReadFile(
                    String          ^titleString,
                    StringBuilder   ^filePathBuilder,
                    String          ^suggestedFileName,
                    DWORD           fileType);
        bool    DTSTest_PromptForSaveFile(
                    String          ^titleString,
                    StringBuilder   ^filePathBuilder,
                    String          ^suggestedFileName,
                    DWORD           fileType);
        bool    DTSTest_PromptInputModal(
                    String          ^titleString,
                    String          ^suggestedInputString,
                    DWORD           *inputValue,
                    StringBuilder   ^inputStringBuilder,
                    DWORD           maximumInputStringSize,
                    String          ^formatString,
                    ...array <Object ^>
                                    ^parameters);
        void    DTSTest_PromptKeyPressed(
                    Object          ^sender,
                    KeyPressEventArgs
                                    ^evt);
        bool    DTSTest_PromptPulldownModal(
                    String          ^titleString,
                    array <String ^>
                                    ^pulldownList,
                    DWORD           *listOffset,
                    String          ^formatString,
                    ...array <Object ^>
                                    ^parameters);
        bool    DTSTest_PromptYesNoModal(
                    String          ^titleString,
                    String          ^yesText,
                    String          ^noText,
                    String          ^formatString,
                    ...array <Object ^>
                                    ^parameters);
        String  ^DTSTest_ReadFilePathFromLine(
                    String          ^lineString,
                    String          ^parameter);
        BYTE    DTSTest_ReadHexByteFromLine(
                    String          ^lineString,
                    String          ^parameter);
        DWORD   DTSTest_ReadHexValueFromLine(
                    String          ^lineString,
                    String          ^parameter);
        String  ^DTSTest_ReadStringFromLine(
                    String          ^lineString,
                    String          ^parameter);
        bool    DTSTest_ReadYesNoFromLine(
                    String          ^lineString,
                    String          ^parameter);
        void    DTSTest_RecordAndModalErrorEvent(
                    String          ^formatString,
                    ...array <Object ^>
                                    ^parameters);
        void    DTSTest_RecordAndModalEventByFlags(
                    bool            eventFlag,
                    bool            messageFlag,
                    String          ^sourceFunction,
                    String          ^formatString,
                    ...array <Object ^>
                                    ^parameters);
        void    DTSTest_RecordEvent(
                    bool            allow,
                    String          ^formatString,
                    ...array<Object ^>
                                    ^parameters);
        void    DTSTest_RemoveFilesAndSubFolders(
                    String          ^folderString);
        void    DTSTest_RetrieveConfigData(void);
        String  ^DTSTest_ReturnScriptCommandInterpretationString(
                    String          ^scriptCommandString,
                    bool            testingContext);
        void    DTSTest_SamplingBackgroundWorker(
                    Object          ^sender,
                    DoWorkEventArgs ^evt);
        void    DTSTest_SamplingBackgroundWorkerCompleted(
                    Object          ^sender,
                    RunWorkerCompletedEventArgs
                                    ^evt);
        void    DTSTest_SamplingBackgroundWorkerUpdateProgress(
                    Object          ^sender,
                    ProgressChangedEventArgs
                                    ^evt);
        void    DTSTest_SampleDisplayAndRecord(
                    PDGICInfo       ^pgInfo,
                    String          ^titleString,
                    String          ^pressureResultLine,
                    String          ^temperatureResultLine);
        void    DTSTest_SamplingControlsClosingWindow(
                    Object          ^sender,
                    FormClosingEventArgs
                                    ^evt);
        void    DTSTest_SamplingControlsHideWindow(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    DTSTest_SamplingControlsSetUpWindow(void);
        void    DTSTest_SamplingRecordSamplesChecked(
                    Object          ^sender,
                    EventArgs       ^evt);
        DWORD   DTSTest_SamplingRunSamplingTasks(
                    BackgroundWorker
                                    ^workerThread);
        void    DTSTest_SamplingStartStopAllButtonClicked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    DTSTest_SamplingStartStopAllBargesButtonClicked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    DTSTest_SamplingStartStopAllGaugesButtonClicked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    DTSTest_SamplingStopEverythingButtonClicked(
                    Object          ^sender,
                    EventArgs       ^evt);
        DWORD   DTSTest_SamplingRunBackgroundSampleTasks(
                    BackgroundWorker
                                    ^workerThread,
                    DoWorkEventArgs ^evt);
        void    DTSTest_SaveBinaryData(
                    array <Byte>    ^binaryData,
                    String          ^binaryFileName);
        void    DTSTest_SaveConfigData(void);
        void    DTSTest_ScanForDevices(void);
//        void    DTSTest_ScriptAutoLoadCFDataChecked(
//                    Object          ^sender,
//                    EventArgs       ^evt);
        String  ^DTSTest_ScriptCalculateAndAppendCRC(
                    String          ^commandString);
//        void    DTSTest_ScriptClearAllPlaceholdersButtonClicked(
//                    Object          ^sender,
//                    EventArgs       ^evt);
        void    DTSTest_ScriptControlLoopTimerElapsed(
                    Object          ^sender,
                    EventArgs       ^evt);
//        void    DTSTest_ScriptControlsCloseWindow(
//                    Object          ^sender,
//                    EventArgs       ^evt);
//        void    DTSTest_ScriptControlsClosingWindow(
//                    Object          ^sender,
//                    FormClosingEventArgs
//                                    ^evt);
//        void    DTSTest_ScriptControlsSetUpWindow(void);
        String  ^DTSTest_ScriptLoadControlScriptFile(
                    String          ^scriptFilePathString);
        String  ^DTSTest_ScriptParseLineForCommandString(
                    String          ^scriptCommandString,
                    int             defaultDelay,
                    bool            testingContext);
//        void    DTSTest_ScriptPlaceholderLoadEraseButtonClicked(
//                    Object          ^sender,
//                    EventArgs       ^evt);
        void    DTSTest_ScriptProcessAddComment(
                    String          ^commentString);
        String  ^DTSTest_ScriptProcessBaudRateChangeString(
                    String          ^scriptCommandString);
        void    DTSTest_ScriptProcessMainControlScript(
                    String          ^controlScriptString);
        void    DTSTest_ScriptProcessLine(
                    String          ^scriptLineString,
                    bool            testingContext);
        void    DTSTest_ScriptPromptForMainControlScriptFile(void);
        void    DTSTest_ScriptRunMainControlScriptThread(
                    Object          ^controlScriptContext);
        String  ^DTSTest_ScriptTranslateCommandString(
                    String          ^commandString,
                    bool            testingContext);
//        bool    DTSTest_SearchForCoefficientFile(
//                    String          ^serialNumberString,
//                    StringBuilder   ^filePathBuilder);
        String  ^DTSTest_SendCommandArray(
                    array <unsigned char>
                                    ^commandArray,
                    int             numberOfBytesToSend,
                    bool            testingContext);
        DWORD   DTSTest_SendEmailMessage(
                    String          ^emailSubjectString,
                    String          ^emailMessageString);
        DWORD   DTSTest_SendEmailStructure(
                    EmailInfo       ^emailInfo);
        void    DTSTest_SendSync(
                    bool            testingContext);
        DWORD   DTSTest_SendSMTPMail(
                    MailMessage     ^mailPackage);
        DWORD   DTSTest_SendTextMessage(
                    String          ^textSubjectString,
                    String          ^textMessageString);
        DWORD   DTSTest_SensorCalibrateReadings(
                    SensorInfo      ^sensor);
        DWORD   DTSTest_SensorEnableGaugeToolhead(
                    SensorInfo      ^sensor);
        bool    DTSTest_SensorPresent(
                    SensorInfo      ^sensor);
        void    DTSTest_SensorPromptAndCalibrate(void);
        DWORD   DTSTest_SensorRetrieveBargeInformation(
                    SensorInfo      ^sensor);
        DWORD   DTSTest_SensorRetrieveCounts(
                    SensorInfo      ^sensor);
        DWORD   DTSTest_SensorRetrieveGaugeInformation(
                    SensorInfo      ^sensor);
        DWORD   DTSTest_SensorRetrieveMeasurements(
                    SensorInfo      ^sensor);
        DWORD   DTSTest_SensorRetrieveType(
                    SensorInfo      ^sensor);
        String  ^DTSTest_SensorReturnMeasurementsString(
                    SensorInfo      ^sensor);
        DWORD   DTSTest_SensorSetGaugeRxBaudRate(
                    SensorInfo      ^sensor,
                    int             targetBaudRate);
        DWORD   DTSTest_SensorSetGaugeTxBaudRate(
                    SensorInfo      ^sensor,
                    int             targetBaudRate);
        void    DTSTest_SensorSnapshotAmbientTemperatureClicked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    DTSTest_SensorSnapshot100TemperatureClicked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    DTSTest_SensorSnapshot150TemperatureClicked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    DTSTest_SensorSnapshot175TemperatureClicked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    DTSTest_SensorSnapshot200TemperatureClicked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    DTSTest_SensorSnapshot225TemperatureClicked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    DTSTest_SetBuildNumber(void);
        void    DTSTest_SetCalculateCRCs(
                    bool            enableCRCCalculation);
        void    DTSTest_SetDisplayBaudRate(
                    int             targetBaudRate);
        void    DTSTest_SetNormalizeMeasurements(
                    bool            enableNormalizeMeasurements);
        void    DTSTest_SetSync(
                    bool            enableSync,
                    bool            testingContext);
        void    DTSTest_SetHostBaudRate(
                    int             baudRate);
        void    DTSTest_ShutDownSoftware(void);
        DWORD   DTSTest_StringWidth(
                    String          ^textString);
        void    DTSTest_SwitchBaudRate(void);
        void    DTSTest_Sync(void);
        void    DTSTest_TestingAutoLoadCFDataChecked(
                    Object          ^sender,
                    EventArgs       ^evt);
        DWORD   DTSTest_TestingBackgroundRunTestEntry(
                    BackgroundWorker
                                    ^workerThread,
                    DoWorkEventArgs ^evt);
        void    DTSTest_TestingBackgroundWorker(
                    Object          ^sender,
                    DoWorkEventArgs ^evt);
        void    DTSTest_TestingBackgroundWorkerCompleted(
                    Object          ^sender,
                    RunWorkerCompletedEventArgs
                                    ^evt);
        void    DTSTest_TestingBackgroundWorkerUpdateProgress(
                    Object          ^sender,
                    ProgressChangedEventArgs
                                    ^evt);
        void    DTSTest_TestingBaudRate1200RadioSelected(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    DTSTest_TestingBaudRate2400RadioSelected(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    DTSTest_TestingBaudRate4800RadioSelected(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    DTSTest_TestingBaudRate600RadioSelected(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    DTSTest_TestingCalculateCRCsClicked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    DTSTest_TestingCheckForAsynchronousPause(void);
        void    DTSTest_TestingControlsClosingWindow(
                    Object          ^sender,
                    FormClosingEventArgs
                                    ^evt);
        void    DTSTest_TestingControlsHideWindow(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    DTSTest_TestingControlsSetUpWindow(void);
        void    DTSTest_TestingDisplayDialogueChecked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    DTSTest_TestingEntryLoadEraseButtonClicked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    DTSTest_TestingEntryProcessControlScriptFile(
                    BackgroundWorker
                                    ^workerThread,
                    int             testEntryNumber);
        void    DTSTest_TestingEntryScriptCommandClicked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    DTSTest_TestingEntryScriptPathButtonClicked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    DTSTest_TestingEntrySelectedChecked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    DTSTest_TestingNormalizeClicked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    DTSTest_TestingPauseResumeButtonClicked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    DTSTest_TestingProcessTestEntry(
                    BackgroundWorker
                                    ^workerThread,
                    int             testEntryNumber);
        void    DTSTest_TestingRunControlScript(
                    BackgroundWorker
                                    ^workerThread,
                    int             testEntryNumber,
                    String          ^controlScriptString);
        DWORD   DTSTest_TestingRunTestEntries(
                    BackgroundWorker
                                    ^workerThread);
        void    DTSTest_TestingRunStopButtonClicked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    DTSTest_TestingSetResetLoopChecked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    DTSTest_TestingStartLogging(void);
        void    DTSTest_TestingStartRunActivities(void);
        void    DTSTest_TestingStopActivities(
                    bool            runCanceled);
        void    DTSTest_TestingStopLogging(void);
        void    DTSTest_TestingSyncClicked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    DTSTest_TextChangedAddComment(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    DTSTest_TextChangedSingleCommand(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    DTSTest_ToggleCalculateCRCs(void);
        void    DTSTest_ToggleNormalizeMeasurements(void);
        void    DTSTest_ToggleSync(void);
        void    DTSTest_ToggleExpertMode(void);
        void    DTSTest_ToolStripAboutDropDownClicked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    DTSTest_ToolStripAboutDropDownMouseEntered(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    DTSTest_ToolStripAdvancedButtonMouseEntered(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    DTSTest_ToolStripAdvancedButtonMouseMoved(
                    Object          ^sender,
                    MouseEventArgs  ^evt);
        void    DTSTest_ToolStripAdvancedControlsDropDownClicked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    DTSTest_ToolStripAdvancedControlsDropDownMouseEntered(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    DTSTest_ToolStripButtonsMouseExited(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    DTSTest_ToolStripCheckForUpdateDropDownClicked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    DTSTest_ToolStripCheckForUpdateDropDownMouseEntered(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    DTSTest_ToolStripControlButtonMouseEntered(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    DTSTest_ToolStripControlButtonMouseMoved(
                    Object          ^sender,
                    MouseEventArgs  ^evt);
        void    DTSTest_ToolStripCSVControlsDropDownClicked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    DTSTest_ToolStripCSVControlsDropDownMouseEntered(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    DTSTest_ToolStripDisplayEventLogDropDownClicked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    DTSTest_ToolStripDisplayEventLogDropDownMouseEntered(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    DTSTest_ToolStripDropDownsMouseExited(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    DTSTest_ToolStripExperimentalControlsDropDownClicked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    DTSTest_ToolStripExperimentalControlsDropDownMouseEntered(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    DTSTest_ToolStripEventLogAllDropDownClicked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    DTSTest_ToolStripEventLogAllDropDownMouseEntered(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    DTSTest_ToolStripEventLogBasicDropDownClicked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    DTSTest_ToolStripEventLogBasicDropDownMouseEntered(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    DTSTest_ToolStripEventLogDetailedDropDownClicked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    DTSTest_ToolStripEventLogDetailedDropDownMouseEntered(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    DTSTest_ToolStripEventLogDropDownMouseEntered(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    DTSTest_ToolStripEventLogDropDownMouseExited(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    DTSTest_ToolStripEventLogVerboseDropDownClicked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    DTSTest_ToolStripEventLogVerboseDropDownMouseEntered(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    DTSTest_ToolStripExpertModeDropDownClicked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    DTSTest_ToolStripExpertModeDropDownMouseEntered(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    DTSTest_ToolStripFileButtonMouseEntered(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    DTSTest_ToolStripFileButtonMouseMoved(
                    Object          ^sender,
                    MouseEventArgs  ^evt);
        void    DTSTest_ToolStripHelpButtonMouseEntered(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    DTSTest_ToolStripHelpButtonMouseMoved(
                    Object          ^sender,
                    MouseEventArgs  ^evt);
        void    DTSTest_ToolStripOnlineHelpDropDownClicked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    DTSTest_ToolStripOnlineHelpDropDownMouseEntered(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    DTSTest_ToolStripProgInfoDropDownClicked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    DTSTest_ToolStripProgInfoDropDownMouseEntered(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    DTSTest_ToolStripSamplingControlsDropDownClicked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    DTSTest_ToolStripSamplingControlsDropDownMouseEntered(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    DTSTest_ToolStripScriptControlsDropDownClicked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    DTSTest_ToolStripScriptControlsDropDownMouseEntered(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    DTSTest_ToolStripSupportLogDropDownClicked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    DTSTest_ToolStripSupportLogDropDownMouseEntered(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    DTSTest_ToolStripTestingControlsDropDownClicked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    DTSTest_ToolStripTestingControlsDropDownMouseEntered(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    DTSTest_UpdateErrorLog(
                    String          ^descriptionString);
        void    DTSTest_UpdateEventLog(
                    String          ^descriptionString);
        void    DTSTest_UpdateHomeFields(void);
        void    DTSTest_UpdateHomeProgressBar(
                    DWORD           itemsCompleted,
                    DWORD           itemsToComplete);
        void    DTSTest_UpdateHomeStatusLine(
                    String          ^statusString);
        void    DTSTest_UpdateMessageChecks(void);
        void    DTSTest_UpdateStatusLine(
                    String          ^statusString);
        bool    DTSTest_URLExists(
                    String          ^URL);
        void    DTSTest_ValidateAndSendEmail(
                    EmailInfo       ^emailInfo);
        void    DTSTest_ValidateEmailMessageAddresses(
                    Object          ^sender,
                    CancelEventArgs ^evt);
        void    DTSTest_ValidateExperimentNumberValue(
                    Object          ^sender,
                    CancelEventArgs ^evt);
        void    DTSTest_ValidateHomeDieSerialNumberAddress(
                    Object          ^sender,
                    CancelEventArgs ^evt);
        void    DTSTest_ValidateHomeOperatorNameAddress(
                    Object          ^sender,
                    CancelEventArgs ^evt);
        void    DTSTest_ValidateHomePlaceholderValue(
                    Object          ^sender,
                    CancelEventArgs ^evt);
//        void    DTSTest_ValidateScriptPlaceholderValue(
//                    Object          ^sender,
//                    CancelEventArgs ^evt);
        void    DTSTest_ValidateSensorHybridSerialNumber(
                    Object          ^sender,
                    CancelEventArgs ^evt);
        void    DTSTest_ValidateSensorJigSerialNumber(
                    Object          ^sender,
                    CancelEventArgs ^evt);
        void    DTSTest_ValidateTestingDelayValue(
                    Object          ^sender,
                    CancelEventArgs ^evt);
        void    DTSTest_ValidateTestingEntryPlaceholderValue(
                    Object          ^sender,
                    CancelEventArgs ^evt);
        void    DTSTest_ValidateTestingEntryScriptCommand(
                    Object          ^sender,
                    CancelEventArgs ^evt);
        void    DTSTest_ValidateTextMessageNumbers(
                    Object          ^sender,
                    CancelEventArgs ^evt);
        void    DTSTest_ZipFiles(
                    array <String ^>
                                    ^filesToZip,
                    String          ^zipFileName);
};                                      // end of DTSTest_GUIClass
//----------------------------------------------------------------------------
// Type definitions
//----------------------------------------------------------------------------
//----------------------------------------------------------------------------
// Boolean definitions
//----------------------------------------------------------------------------
#define     GUI_YES                                             true
#define     GUI_NO                                              false
#define     GUI_MAIN_LOG                                        GUI_YES
#define     GUI_SNAPSHOT_LOG                                    GUI_NO
#define     GUI_ACCEPT                                          GUI_YES
#define     GUI_CANCEL                                          GUI_NO
#define     GUI_DETAILED_LOG                                    GUI_YES
#define     GUI_SIMPLE_LOG                                      GUI_NO
#define     GUI_TRUNCATE_STRING                                 GUI_YES
#define     GUI_LOP_STRING                                      GUI_NO
#define     GUI_CLEAR_LOG_WITH_SAVE                             GUI_YES
#define     GUI_CLEAR_LOG_WITHOUT_SAVE                          GUI_NO
#define     GUI_CSV_HEADER_ENTRY                                GUI_YES
#define     GUI_CSV_REGULAR_ENTRY                               GUI_NO
//----------------------------------------------------------------------------
// Program limits
//----------------------------------------------------------------------------
#define     GUI_ONE_SECOND_INTERVAL                             1000
#define     GUI_MAXIMUM_PROMPT_STRING_SIZE                      180
#define     GUI_MAXIMUM_DISPLAY_STRING_SIZE                     512
#define     GUI_MAXIMUM_MODAL_TITLE_SIZE                        256
#define     GUI_MAXIMUM_STATUS_LINE_SIZE                        110
#define     GUI_MAXIMUM_VERSION_STRING_SIZE                     80
#define     GUI_MAXIMUM_STATUS_LINE_PIXEL_SIZE                  400
#define     GUI_MAXIMUM_EXPERIMENT_NUMBER                       99
#define     GUI_MINIMUM_EXPERIMENT_NUMBER                       1
#define     GUI_DEFAULT_EXPERIMENT_NUMBER                       1
//----------------------------------------------------------------------------
// General and default window component dimensions
//----------------------------------------------------------------------------
#define     GUI_REGULAR_LABEL_HEIGHT                            14
#define     GUI_INFO_LABEL_HEIGHT                               16
#define     GUI_PROMPT_LABEL_HEIGHT                             17
#define     GUI_HELP_LABEL_HEIGHT                               22
#define     GUI_CLOSE_BUTTON_WIDTH                              75
#define     GUI_YES_NO_BUTTON_WIDTH                             40
#define     GUI_REGULAR_BUTTON_HEIGHT                           25
#define     GUI_NARROW_BUTTON_HEIGHT                            21
#define     GUI_REGULAR_RADIO_BUTTON_HEIGHT                     16
#define     GUI_REGULAR_TEXT_BOX_HEIGHT                         20
#define     GUI_REGULAR_COMBO_BOX_HEIGHT                        GUI_REGULAR_TEXT_BOX_HEIGHT
#define     GUI_REGULAR_CHECK_BOX_HEIGHT                        16
#define     GUI_DEFAULT_GROUP_BOX_WIDTH                         850
//----------------------------------------------------------------------------
// Specific window component dimensions
//----------------------------------------------------------------------------
#define     GUI_HOME_WINDOW_MIN_WIDTH                           820
#define     GUI_HOME_WINDOW_MIN_HEIGHT                          635
#define     GUI_PROGRAM_INFO_GROUP_BOX_WIDTH                    GUI_DEFAULT_GROUP_BOX_WIDTH
#define     GUI_ADVANCED_CONTROLS_WINDOW_WIDTH                  820
#define     GUI_ADVANCED_CONTROLS_WINDOW_HEIGHT                 400
#define     GUI_EXPERIMENTAL_CONTROLS_WINDOW_WIDTH              820
#define     GUI_EXPERIMENTAL_CONTROLS_WINDOW_HEIGHT             604
#define     GUI_SAMPLING_CONTROLS_WINDOW_WIDTH                  820
#define     GUI_SAMPLING_CONTROLS_WINDOW_HEIGHT                 604
#define     GUI_SCRIPT_CONTROLS_WINDOW_WIDTH                    520
#define     GUI_SCRIPT_CONTROLS_WINDOW_HEIGHT                   600
#define     GUI_FILE_CONTROLS_WINDOW_WIDTH                      720
#define     GUI_FILE_CONTROLS_WINDOW_HEIGHT                     600
#define     GUI_TESTING_CONTROLS_WINDOW_WIDTH                   1020
#define     GUI_TESTING_CONTROLS_WINDOW_HEIGHT                  790
#define     GUI_HOME_COMMAND_DIALOGUE_TOP                       140
//----------------------------------------------------------------------------
// Error message flags
//----------------------------------------------------------------------------
#define     GUI_EMSG_INTERPRET_STATUS                           0x00000001
#define     GUI_EMSG_MUST_DISPLAY                               0x00000010
#define     GUI_EMSG_PLAY_SOUND                                 0x00000100
//----------------------------------------------------------------------------
// Please Wait values and actions
//----------------------------------------------------------------------------
#define     GUI_PLEASE_WAIT_STATE_HIDDEN                        1
#define     GUI_PLEASE_WAIT_STATE_VISIBLE                       2
#define     GUI_PLEASE_WAIT_INSTALL                             1
#define     GUI_PLEASE_WAIT_DISPLAY_NEW_TITLE                   2
#define     GUI_PLEASE_WAIT_DISPLAY_CURRENT_TITLE               3
#define     GUI_PLEASE_WAIT_HIDE                                4
#define     GUI_PLEASE_WAIT_REMOVE                              5
#define     GUI_PLEASE_WAIT_DISPOSE                             7
//----------------------------------------------------------------------------
// Modal icon types
//----------------------------------------------------------------------------
#define     GUI_MODAL_ICON_NONE                                 0x00000000
#define     GUI_MODAL_ICON_INFORMATION                          0x00000001
#define     GUI_MODAL_ICON_WARNING                              0x00000002
#define     GUI_MODAL_ICON_ERROR                                0x00000003
#define     GUI_MODAL_ICON_CRITICAL                             0x00000004
//----------------------------------------------------------------------------
// Modal message levels
//----------------------------------------------------------------------------
#define     GUI_MODAL_BASIC                                     0x00000001
#define     GUI_MODAL_ERROR                                     0x00000002
#define     GUI_MODAL_VERBOSE                                   0x00000004
#define     GUI_MODAL_DETAILED                                  0x00000008
#define     GUI_MODAL_EXP                                       0x00000010
#define     GUI_MODAL_STACK                                     0x00000020
#define     GUI_MODAL_TEXT                                      0x00000040
#define     GUI_MODAL_EMAIL                                     0x00000080
//----------------------------------------------------------------------------
// Event log recording levels
//----------------------------------------------------------------------------
#define     GUI_ELOG_BASIC                                      0x00001000
#define     GUI_ELOG_VERBOSE                                    0x00002000
#define     GUI_ELOG_DETAILED                                   0x00004000
#define     GUI_ELOG_TEST                                       0x00008000
//----------------------------------------------------------------------------
// Software states
//----------------------------------------------------------------------------
#define     GUI_EXPERIMENTS_BASIC                               0x10000000
#define     GUI_SOFTWARE_UPDATE                                 0x80000000
//----------------------------------------------------------------------------
// Testing flags
//----------------------------------------------------------------------------
#define     GUI_TESTING_FLAG_DISPLAY_IN_MAIN_DIALOGUE           0x00000001
#define     GUI_TESTING_FLAG_AUTO_LOAD_COEFFICIENT_DATA         0x00000002
//----------------------------------------------------------------------------
// File type enumerations
//----------------------------------------------------------------------------
#define     GUI_FILE_TYPE_UNKNOWN                               0
#define     GUI_FILE_TYPE_TEXT                                  1
#define     GUI_FILE_TYPE_HEX                                   2
#define     GUI_FILE_TYPE_LOG                                   3
#define     GUI_FILE_TYPE_DAT                                   4
#define     GUI_FILE_TYPE_CSV                                   7
#define     GUI_FILE_TYPE_CONFIG                                8
#define     GUI_FILE_TYPE_BIN                                   9
#define     GUI_FILE_TYPE_EXE                                   10
#define     GUI_FILE_TYPE_ZIP                                   11
#define     GUI_FILE_TYPE_DLL                                   12
//----------------------------------------------------------------------------
// File type specifications
//----------------------------------------------------------------------------
#define     GUI_FILE_SPEC_ALL                   _T("All files (*.*)|*.*|All files (*.*)|*.*")
#define     GUI_FILE_SPEC_TEXT                  _T("Text files (*.txt)|*.txt|All files (*.*)|*.*")
#define     GUI_FILE_SPEC_HEX                   _T("Hex files (*.hex)|*.hex|All files (*.*)|*.*")
#define     GUI_FILE_SPEC_LOG                   _T("Log files (*.log)|*.log|Text files (*.txt)|*.txt|")         \
                                                    _T("All files (*.*)|*.*")
#define     GUI_FILE_SPEC_DAT                   _T("Data files (*.dat)|*.dat|All files (*.*)|*.*")
#define     GUI_FILE_SPEC_CSV                   _T("Log files (*.log)|*.log|Text files (*.txt)|*.txt|")         \
                                                    _T("Excel-ready text files (*.csv)|*.csv|")                 \
                                                    _T("All files (*.*)|*.*")
#define     GUI_FILE_SPEC_CONFIG                _T("Config files (*.config)|*.config|All files (*.*)|*.*")
#define     GUI_FILE_SPEC_BIN                   _T("Binary files (*.bin)|*.bin|All files (*.*)|*.*")
#define     GUI_FILE_SPEC_EXE                   _T("Executable files (*.exe)|*.exe|All files (*.*)|*.*")
#define     GUI_FILE_SPEC_ZIP                   _T("Compressed files (*.zip)|*.zip|All files (*.*)|*.*")
#define     GUI_FILE_SPEC_DLL                   _T("Dynamic-link library files (*.dll)|*.dll|All files (*.*)|*.*")
//----------------------------------------------------------------------------
// Drop-down button states and masks
//----------------------------------------------------------------------------
#define     GUI_DROP_DOWN_CLOSED                                0x00010000
#define     GUI_DROP_DOWN_OPENED                                0x00020000
#define     GUI_DROP_DOWN_DISPLAY_MASK                          0xFFFF0000
#define     GUI_DROP_DOWN_VERTICAL_POSITION_MASK                0x0000FFFF
//----------------------------------------------------------------------------
// Key values
//----------------------------------------------------------------------------
#define     GUI_KEY_ESC                                         27
//----------------------------------------------------------------------------
// External function prototypes
//----------------------------------------------------------------------------
extern int      DTSTest_CalculatePercentage(
                    DWORD           dividend,
                    DWORD           divisor);
extern char     *DTSTest_ConvertString(
                    String          ^managedString,
                    char            *unmanagedString,
                    size_t          unmanagedBufferSize);
extern System::Windows::Forms::DialogResult
                DTSTest_ModalMessage(
                    bool            allow,
                    DWORD           flag,
                    String          ^titleString,
                    String          ^formatString,
                    ...array <Object ^>
                                    ^parameters);
extern void     DTSTest_DisplayStackTrace(
                    String          ^messageString);
extern char     *DTSTest_ItoA(
                    DWORD           value,
                    char            *valueString);
extern char     *DTSTest_ItoX(
                    DWORD           value,
                    char            *valueString);
extern bool     DTSTest_PromptYesNoModal(
                    String          ^titleString,
                    String          ^formatString,
                    ...array <Object ^>
                                    ^parameters);
extern bool     DTSTest_StringContains(
                    char            *sourceString,
                    char            *testString);
extern void     DTSTest_TimeElapsed(
                    DWORD           lapsedTime,
                    int             *lapsedDays,
                    int             *lapsedHours,
                    int             *lapsedMinutes,
                    int             *lapsedSeconds,
                    int             *lapsedMilliseconds);
extern WORD     PDGIC_CalculateWordCRC(
                    array <unsigned char>
                                    ^dataBuffer,
                    int             dataLength);
//----------------------------------------------------------------------------
// Graphic file names
//----------------------------------------------------------------------------
#define     GUI_PROGRAM_ICON                    String::Concat(Application::StartupPath, _T("\\DTSTest.ico"))
#define     GUI_PROGRAM_LOGO                    String::Concat(Application::StartupPath, _T("\\DTSTest.png"))
#define     GUI_BG_SAND                         String::Concat(Application::StartupPath, _T("\\DTSTest-BG-Sand.jpg"))
#define     GUI_BG_TOOLSTRIP                    String::Concat(Application::StartupPath, _T("\\DTSTest-BG-OrangeGradient.png"))
#define     GUI_BG_WHITE_MARBLE                 String::Concat(Application::StartupPath, _T("\\DTSTest-BG-WhiteMarble.gif"))
#define     GUI_BG_WHITE_SAND                   String::Concat(Application::StartupPath, _T("\\DTSTest-BG-WhiteSand.jpg"))
#define     GUI_IMAGE_BLUE_DOT_OFF              String::Concat(Application::StartupPath, _T("\\DTSTest-IMG-Dot-Off.gif"))
#define     GUI_IMAGE_BLUE_DOT_ON               String::Concat(Application::StartupPath, _T("\\DTSTest-IMG-Blue-Dot-On.gif"))
#define     GUI_IMAGE_GREEN_DOT_OFF             String::Concat(Application::StartupPath, _T("\\DTSTest-IMG-Dot-Off.gif"))
#define     GUI_IMAGE_GREEN_DOT_ON              String::Concat(Application::StartupPath, _T("\\DTSTest-IMG-Green-Dot-On.gif"))
#define     GUI_IMAGE_RED_DOT_OFF               String::Concat(Application::StartupPath, _T("\\DTSTest-IMG-Dot-Off.gif"))
#define     GUI_IMAGE_RED_DOT_ON                String::Concat(Application::StartupPath, _T("\\DTSTest-IMG-Red-Dot-On.gif"))
#define     GUI_IMAGE_YELLOW_LED_OFF            String::Concat(Application::StartupPath, _T("\\DTSTest-IMG-Yellow-LED-Off.gif"))
#define     GUI_IMAGE_YELLOW_LED_ON             String::Concat(Application::StartupPath, _T("\\DTSTest-IMG-Yellow-LED-On.gif"))
//----------------------------------------------------------------------------
// Sound file names
//----------------------------------------------------------------------------
#define     GUI_SOUND_DOWN                      String::Concat(Application::StartupPath, _T("\\DTSTest-Down.wav"))
#define     GUI_SOUND_ERROR                     String::Concat(Application::StartupPath, _T("\\DTSTest-Error.wav"))
#define     GUI_SOUND_OPEN                      String::Concat(Application::StartupPath, _T("\\DTSTest-Open.wav"))
#define     GUI_SOUND_TADA                      String::Concat(Application::StartupPath, _T("\\DTSTest-Tada.wav"))
//----------------------------------------------------------------------------
// Other file names
//----------------------------------------------------------------------------
#define     GUI_DEFAULT_COEFFICIENT_HEX_FILE    String::Concat(Application::StartupPath, _T("\\100001.hex"))
//----------------------------------------------------------------------------
// ToolStrip and Button titles
//----------------------------------------------------------------------------
#define     GUI_ENABLE_EXPERT_MODE_STRING               _T("Enable Expert Mode")
#define     GUI_DISABLE_EXPERT_MODE_STRING              _T("Disable Expert Mode")
#define     GUI_ELOG_ALL_START_STRING                   _T("Start Recording All Events")
#define     GUI_ELOG_ALL_STOP_STRING                    _T("Stop Recording All Events")
#define     GUI_ELOG_BASIC_START_STRING                 _T("Start Recording Basic Events")
#define     GUI_ELOG_BASIC_STOP_STRING                  _T("Stop Recording Basic Events")
#define     GUI_ELOG_DETAILED_START_STRING              _T("Start Recording Detailed Events")
#define     GUI_ELOG_DETAILED_STOP_STRING               _T("Stop Recording Detailed Events")
#define     GUI_ELOG_VERBOSE_START_STRING               _T("Start Recording Verbose Events")
#define     GUI_ELOG_VERBOSE_STOP_STRING                _T("Stop Recording Verbose Events")
#define     GUI_ENABLE_CONFIG_SAVE_STRING               _T("Save config file on exit")
#define     GUI_DISABLE_CONFIG_SAVE_STRING              _T("Don't save config file on exit")
//----------------------------------------------------------------------------
// Other string definitions
//----------------------------------------------------------------------------
#define     GUI_HOME_WINDOW_TITLE               "DTSTest (Quartzdyne eDTS Test Software)"
#define     GUI_MUTEX_STRING                    _T("DTSTestModal")
#define     GUI_PLEASE_WAIT_STRING              _T("Please wait . . .")
#define     GUI_TEXT_FILE_BORDER                String::Concat("#", gcnew String('=', 77))
#define     GUI_TEXT_FILE_HALF_BORDER           String::Concat("#", gcnew String('-', 77))
//----------------------------------------------------------------------------
// Modal macros
//----------------------------------------------------------------------------
#define     AnyMessageEnabled                   (DTSTest_BasicMessagesEnabled || DTSTest_ErrorMessagesEnabled || DTSTest_VerboseMessagesEnabled || DTSTest_DetailedMessagesEnabled)
#define     AnyNonErrorMessageEnabled           (DTSTest_BasicMessagesEnabled || DTSTest_VerboseMessagesEnabled || DTSTest_DetailedMessagesEnabled)
#define     Modal(M,...)                        DTSTest_DisplayModalMessage(true, MB_ICONINFORMATION, FunctionName(), (M), __VA_ARGS__)
#define     ModalB(M,...)                       DTSTest_DisplayModalMessage(DTSTest_BasicMessagesEnabled, MB_ICONASTERISK, FunctionName(), (M), __VA_ARGS__)
#define     ModalD(M,...)                       DTSTest_DisplayModalMessage(DTSTest_DetailedMessagesEnabled, MB_ICONINFORMATION, FunctionName(), (M), __VA_ARGS__)
#define     ModalE(M,...)                       DTSTest_DisplayModalMessage(DTSTest_ErrorMessagesEnabled, MB_ICONWARNING, FunctionName(), (M), __VA_ARGS__)
#define     ModalT(T,M,...)                     DTSTest_DisplayModalMessage(true, MB_ICONINFORMATION, (T), (M), __VA_ARGS__)
#define     ModalV(M,...)                       DTSTest_DisplayModalMessage(DTSTest_VerboseMessagesEnabled, MB_ICONINFORMATION, FunctionName(), (M), __VA_ARGS__)
#define     ModalX(M,...)                       DTSTest_DisplayModalMessage(DTSTest_ExpMessagesEnabled, MB_ICONINFORMATION, FunctionName(), (M), __VA_ARGS__)
//----------------------------------------------------------------------------
// Shortcut Macros
//----------------------------------------------------------------------------
#define     GUI_DisplayHandCursorOnHover(X)     (X)->Cursor = Cursors::Hand
#define     GUI_PlaySound(S)                    ((DTSTest_GeneralInfo->flags & DTSTEST_GENERAL_SOUNDS_ENABLED) ? (S)->Play() : (S)->Stop())
#define     DTSTest_PromptModal(T,P,...)        DTSTest_PromptYesNoModal((T), String::Empty, String::Empty, (P), __VA_ARGS__)
#define     DTSTest_PromptOKFunction(P,...)     DTSTest_PromptYesNoModal(__FUNCTION__, nullptr, nullptr, (P), __VA_ARGS__)
#define     DTSTest_PromptOKModal(T,P,...)      DTSTest_PromptYesNoModal((T), nullptr, nullptr, (P), __VA_ARGS__)
//----------------------------------------------------------------------------
// Shortcut Error Message Macros
//----------------------------------------------------------------------------
#define     GUI_DisplayGeneralErrorWithStatus(T,M,S)                                    \
                                                DTSTest_ErrorAlert(                     \
                                                    (T), (S),                           \
                                                    (GUI_EMSG_INTERPRET_STATUS |        \
                                                    GUI_EMSG_PLAY_SOUND), (M))
#define     GUI_DisplayMandatoryError(T,M,...)  DTSTest_ErrorAlert(                     \
                                                    (T), DTSTEST_SUCCESS,               \
                                                    (GUI_EMSG_MUST_DISPLAY |            \
                                                    GUI_EMSG_PLAY_SOUND),               \
                                                    (M), __VA_ARGS__)
#define     GUI_DisplaySimpleError(T,M,...)     DTSTest_ErrorAlert(                     \
                                                    (T), DTSTEST_SUCCESS,               \
                                                    GUI_EMSG_PLAY_SOUND,                \
                                                    (M), __VA_ARGS__)
//----------------------------------------------------------------------------
// Compound macros
//----------------------------------------------------------------------------
#define     GUI_PositionBelow(thisObject,aboveObject,N)                                 \
                {                                                                       \
                    if ((thisObject) && (aboveObject))                                  \
                    {                                                                   \
                        (thisObject)->Location = Point(                                 \
                            (aboveObject)->Left, (aboveObject)->Bottom + (N));          \
                        (thisObject)->BackColor = Color::Transparent;                   \
                    }                                                                   \
                }
#define     GUI_PositionAndSizeBelow(thisObject,aboveObject,N)                          \
                {                                                                       \
                    if ((thisObject) && (aboveObject))                                  \
                    {                                                                   \
                        GUI_PositionBelow((thisObject), (aboveObject), (N));            \
                        (thisObject)->Size = (aboveObject)->Size;                       \
                    }                                                                   \
                }
#define     GUI_SetButtonInterfaceProperties(X)                                         \
                {                                                                       \
                    if (X)                                                              \
                    {                                                                   \
                        (X)->BackgroundImage = sandBackground;                          \
                        (X)->BackColor = Color::Transparent;                            \
                        GUI_DisplayHandCursorOnHover(X);                                \
                    }                                                                   \
                }
#define     GUI_SetObjectInterfaceProperties(X)                                         \
                {                                                                       \
                    if (X)                                                              \
                    {                                                                   \
                        (X)->BackColor = Color::Transparent;                            \
                        GUI_DisplayHandCursorOnHover(X);                                \
                    }                                                                   \
                }
#define     GUI_SetTagButtonInterfaceProperties(X,T)                                    \
                {                                                                       \
                    if (X)                                                              \
                    {                                                                   \
                        (X)->Tag = dynamic_cast <Object ^> (T);                         \
                        GUI_SetButtonInterfaceProperties(X);                            \
                    }                                                                   \
                }
#define     GUI_SetTagObjectInterfaceProperties(X,T)                                    \
                {                                                                       \
                    if (X)                                                              \
                    {                                                                   \
                        (X)->Tag = dynamic_cast <Object ^> (T);                         \
                        GUI_SetObjectInterfaceProperties(X);                            \
                    }                                                                   \
                }
#define     GUI_StringToBuilder(S,B)                                                    \
                {                                                                       \
                    if ((S) && (B))                                                     \
                    {                                                                   \
                        (B)->Clear();                                                   \
                        (B)->Insert(0, (S));                                            \
                    }                                                                   \
                }
//----------------------------------------------------------------------------
// Structures
//----------------------------------------------------------------------------
//----------------------------------------------------------------------------
// External global variables
//----------------------------------------------------------------------------
extern bool     DTSTest_BasicMessagesEnabled;
extern bool     DTSTest_BaudRateSetTo2400;
extern DWORD    DTSTest_BuildNumber;
extern bool     DTSTest_CalculateCRCs;
extern bool     DTSTest_CommandLineOnly;
extern bool     DTSTest_ControlScriptLooping;
extern bool     DTSTest_ControlScriptPaused;
extern bool     DTSTest_ControlScriptRunning;
extern int      DTSTest_CurrentEntryNumber;
extern DWORD    DTSTest_CurrentExperimentNumber;
extern bool     DTSTest_CurrentlyEventLogging;
extern bool     DTSTest_CurrentlySamplingAll;
extern bool     DTSTest_CurrentlySamplingAllBarges;
extern bool     DTSTest_CurrentlySamplingAllGauges;
extern bool     DTSTest_DemoModeEnabled;
extern bool     DTSTest_DetailedMessagesEnabled;
extern bool     DTSTest_DisplayInCommandDialogue;
extern bool     DTSTest_KeepPortOpen;
extern bool     DTSTest_ReportCRCErrors;
extern bool     DTSTest_ErrorMessagesEnabled;
extern bool     DTSTest_EventLogBasicEnabled;
extern bool     DTSTest_EventLogDetailedEnabled;
extern bool     DTSTest_EventLogVerboseEnabled;
extern bool     DTSTest_ExperimentsEnabled;
extern bool     DTSTest_ExpMessagesEnabled;
extern DWORD    DTSTest_ModalKeyStroke;
extern bool     DTSTest_NormalizeReadings;
extern bool     DTSTest_PortIsOpen;
extern bool     DTSTest_PrependDateAndTime;
extern bool     DTSTest_RecordSamples;
extern bool     DTSTest_RetrieveResponseContext;
extern bool     DTSTest_SendEmailErrorMessagesEnabled;
extern bool     DTSTest_SendTextErrorMessagesEnabled;
extern bool     DTSTest_SoftwareUpdateInProgress;
extern bool     DTSTest_StackTracesEnabled;
extern DWORD    DTSTest_StartTime;
extern bool     DTSTest_SyncEnabled;
extern bool     DTSTest_TestingAutoLoadCoefficientData;
extern int      DTSTest_TestingDelay;
extern bool     DTSTest_TestingDisplayInCommandDialogue;
extern bool     DTSTest_TestingRunning;
extern bool     DTSTest_VerboseMessagesEnabled;
extern DWORD    DTSTest_WindowsVersion;
extern bool     DTSTest_WorkAroundDTSBadCRCError;
//----------------------------------------------------------------------------
// The following lines are only seen by GUI.cpp
//----------------------------------------------------------------------------
#ifdef      GUI_CPP
//----------------------------------------------------------------------------
// Internal global variables
//----------------------------------------------------------------------------
bool            DTSTest_BaudRateSetTo2400 = GUI_NO;
bool            DTSTest_CalculateCRCs = GUI_NO;
bool            DTSTest_ControlScriptLooping = GUI_NO;
bool            DTSTest_ControlScriptPaused = GUI_NO;
bool            DTSTest_ControlScriptRunning = GUI_NO;
int             DTSTest_CurrentEntryNumber = 0;
DWORD           DTSTest_CurrentExperimentNumber = GUI_DEFAULT_EXPERIMENT_NUMBER;
bool            DTSTest_CurrentlyEventLogging = GUI_NO;
bool            DTSTest_CurrentlySamplingAll = GUI_NO;
bool            DTSTest_CurrentlySamplingAllBarges = GUI_NO;
bool            DTSTest_CurrentlySamplingAllGauges = GUI_NO;
bool            DTSTest_DemoModeEnabled = GUI_NO;
bool            DTSTest_DisplayInCommandDialogue = GUI_YES;
bool            DTSTest_KeepPortOpen = GUI_NO;
DWORD           DTSTest_ModalKeyStroke = 0;
bool            DTSTest_NormalizeReadings = GUI_YES;
bool            DTSTest_PrependDateAndTime = GUI_YES;
bool            DTSTest_PortIsOpen = GUI_NO;
bool            DTSTest_RecordSamples = GUI_NO;
bool            DTSTest_ReportCRCErrors = GUI_YES;
bool            DTSTest_RetrieveResponseContext = GUI_NO;
bool            DTSTest_SyncEnabled = GUI_NO;
bool            DTSTest_WorkAroundDTSBadCRCError = GUI_NO;
//----------------------------------------------------------------------------
// End of the lines that are only seen by GUI.cpp
//----------------------------------------------------------------------------
#endif      // GUI_CPP
#endif      // GUI_H
//============================================================================
// End of GUI.h
//============================================================================
