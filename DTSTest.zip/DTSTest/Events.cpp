//============================================================================
// Events.cpp
//
// The event methods registered by the source methods
//
// Copyright (C) 2014 - 2016 Quartzdyne, Inc.  All rights reserved.
//
// No part of this source code may be reproduced or transmitted in any form or
// by any means, electronic or mechanical, including photocopying, recording,
// or any information storage and retrieval system, without express written
// permission from Quartzdyne, Inc.  Further, no use of this source code is
// permitted in any form or means without a valid, written license agreement
// with Quartzdyne, Inc.  While every reasonable precaution has been taken in
// the preparation of this source code, Quartzdyne, Inc., assumes no
// responsibility for errors, omissions, or damages from the use of the source
// code contained herein.
//
// NEITHER QUARTZDYNE, INC., ANY MEMBER OF QUARTZDYNE, INC., NOR ANY PERSON OR
// ORGANIZATION ACTING ON BEHALF OF THEM MAKES ANY WARRANTY OR REPRESENTATION
// WHATSOEVER, EXPRESS OR IMPLIED, INCLUDING ANY WARRANTY OF MERCHANTABILITY
// OR FITNESS FOR ANY PURPOSE WITH RESPECT TO THE SOURCE CODE OR ASSUMES ANY
// LIABILITY WHATSOEVER WITH RESPECT TO ANY USE OF THE SOURCE CODE OR ANY
// PORTION THEREOF OR WITH RESPECT TO ANY DAMAGES THAT MAY RESULT FROM SUCH
// USE.
//
// Noji Ratzlaff
//
// See DTSTest.log for a complete history of all updates, changes, and revisions
// of this source and other files and policies regarding DTSTest software
//
// Updated 01-14-2016
//============================================================================
#include    "stdafx.h"
#ifndef     EVENTS_CPP
#define     EVENTS_CPP
#include    "Events.h"
//----------------------------------------------------------------------------
// DTSTest_ComboBoxAcceptEnterKey
//
// Handles the acceptance of the Enter key in the Send Email combo box
//
// Called by:   DTSTest_GenerateSupportLog
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_ComboBoxAcceptEnterKey(
    Object          ^sender,
    PreviewKeyDownEventArgs
                    ^evt)
{
    //------------------------------------------------------------------------
    if (evt->KeyCode == Keys::Enter)
    {
        evt->IsInputKey = GUI_YES;
    }
}                                       // end of DTSTest_ComboBoxAcceptEnterKey()
//----------------------------------------------------------------------------
// DTSTest_ComputerGoingToHibernation
//
// Handles the computer going into hibernation event
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_ComputerGoingToHibernation(
    Object          ^sender,
    PowerModeChangedEventArgs
                    ^evt)
{
    //------------------------------------------------------------------------
    if (evt->Mode == PowerModes::Suspend)
    {
        RecordBasicEvent("Computer {0} is going into hibernation", Environment::MachineName);
        //--------------------------------------------------------------------
        // Clean up
        //--------------------------------------------------------------------
        DTSTest_ShutDownSoftware();
        //--------------------------------------------------------------------
        // TODO: The permanent solution would be to prevent going into
        // hibernation altogether, but in the mean time, just bail
        //--------------------------------------------------------------------
        Environment::Exit(0);
    }
}                                       // end of DTSTest_ComputerGoingToHibernation()
//----------------------------------------------------------------------------
// DTSTest_ComputerShuttingDown
//
// Handles the computer shutdown event
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_ComputerShuttingDown(
    Object          ^sender,
    SessionEndedEventArgs
                    ^evt)
{
    //------------------------------------------------------------------------
    if (evt->Reason == SessionEndReasons::SystemShutdown)
    {
        RecordBasicEvent("Computer {0} is shutting down", Environment::MachineName);
        //--------------------------------------------------------------------
        // Clean up, then bail
        //--------------------------------------------------------------------
        DTSTest_ShutDownSoftware();
        Environment::Exit(0);
    }
}                                       // end of DTSTest_ComputerShuttingDown()
//----------------------------------------------------------------------------
// DTSTest_ComputerUserChanging
//
// Handles the computer user changing
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_ComputerUserChanging(
    Object          ^sender,
    SessionSwitchEventArgs
                    ^evt)
{
    //------------------------------------------------------------------------
    if (evt->Reason == SessionSwitchReason::SessionLogon)
    {
        RecordBasicEvent("Computer {0} is switching users", Environment::MachineName);
        //--------------------------------------------------------------------
        // Retrieve the login (AD) name
        //--------------------------------------------------------------------
        DTSTest_GeneralInfo->operatorName = Environment::UserName;
    }
}                                       // end of DTSTest_ComputerUserChanging()
//----------------------------------------------------------------------------
// DTSTest_ConfigFileSaveDontSaveAreaClicked
//
// Handles the click of the Save / Don't Save Config File area
//
// Called by:   DTSTest_AdvancedControlsSetUpWindow
//              DTSTest_InstallToolStrip
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_ConfigFileSaveDontSaveAreaClicked(
    Object          ^sender,
    EventArgs       ^evt)
{
    //------------------------------------------------------------------------
    if (DTSTest_GeneralInfo->flags & DTSTEST_GENERAL_CONFIG_DONT_SAVE)
        DTSTest_GeneralInfo->flags &= ~DTSTEST_GENERAL_CONFIG_DONT_SAVE;
    else
        DTSTest_GeneralInfo->flags |= DTSTEST_GENERAL_CONFIG_DONT_SAVE;
    if (configFileSaveDontSaveTSButton)
    {
        configFileSaveDontSaveTSButton->Text =
            (DTSTest_GeneralInfo->flags & DTSTEST_GENERAL_CONFIG_DONT_SAVE) ?
                GUI_ENABLE_CONFIG_SAVE_STRING : GUI_DISABLE_CONFIG_SAVE_STRING;
    }
    RecordBasicEvent(
        "{0}Save Config File selected",
        ((DTSTest_GeneralInfo->flags & DTSTEST_GENERAL_CONFIG_DONT_SAVE) ? "Don't " : ""));
    DTSTest_UpdateMessageChecks();
}                                       // end of DTSTest_ConfigFileSaveDontSaveAreaClicked()
//----------------------------------------------------------------------------
// DTSTest_DefaultExceptionHandler
//
// Handles any exception not already handled elsewhere in the program
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_DefaultExceptionHandler(
    Object          ^sender,
    UnhandledExceptionEventArgs
                    ^evt)
{
    Exception       ^defaultException = dynamic_cast <Exception ^> (evt->ExceptionObject);
    //------------------------------------------------------------------------
    GUI_DisplayMandatoryError("DTSTest Exception",
        String::Concat(
            "Function ", __FUNCTION__, "\n\n",
            "Line ", __LINE__, "\n\n",
            defaultException->Message,
            "\n\nTerminating:\n",
            evt->ExceptionObject));
    //------------------------------------------------------------------------
    // Clean up, then bail
    //------------------------------------------------------------------------
    DTSTest_ShutDownSoftware();
}                                       // end of DTSTest_DefaultExceptionHandler()
//----------------------------------------------------------------------------
// DTSTest_EmailMessageClearComboBox
//
// Clears the Email combo box
//
// Called by:   DTSTest_GenerateSupportLog
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_EmailMessageClearComboBox(
    Object          ^sender,
    EventArgs       ^evt)
{
    EmailInfo       ^emailInfo =
        dynamic_cast <EmailInfo ^> ((dynamic_cast <ComboBox ^> (sender))->Tag);
    //------------------------------------------------------------------------
}                                       // end of DTSTest_EmailMessageClearComboBox()
//----------------------------------------------------------------------------
// DTSTest_EmailMessageProcessComboEnterKey
//
// Processes the result of accepting the Enter key in the Email Support Log
// combo box
//
// Called by:   DTSTest_GenerateSupportLog
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_EmailMessageProcessComboEnterKey(
    Object          ^sender,
    KeyEventArgs    ^evt)
{
    EmailInfo       ^emailInfo =
        dynamic_cast <EmailInfo ^> ((dynamic_cast <ComboBox ^> (sender))->Tag);
    //------------------------------------------------------------------------
    if (evt->KeyCode == Keys::Enter)
    {
        if (emailInfo)
        {
            RecordBasicEvent(
                "Email Support Log Box Enter Key pressed for email address\n{0}",
                emailInfo->toAddress);
            emailInfo->toAddress = emailToCombo->Text;
            emailInfo->fromAddress = emailFromCombo->Text;
            emailInfo->subjectString = emailSubjectBox->Text;
            emailInfo->messageString = emailMessageBox->Text;
            DTSTest_ValidateAndSendEmail(emailInfo);
        }
        else
        {
            RecordBasicEvent(
                "Email Support Log Box Enter Key pressed with an invalid email structure");
        }
        evt->SuppressKeyPress = GUI_YES;
    }
}                                       // end of DTSTest_EmailMessageProcessComboEnterKey()
//----------------------------------------------------------------------------
// DTSTest_EmailMessageSendButtonClicked
//
// Event that handles the click of the Send Email button
//
// Called by:   DTSTest_GenerateSupportLog
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_EmailMessageSendButtonClicked(
    Object          ^sender,
    EventArgs       ^evt)
{
    EmailInfo       ^emailInfo =
        dynamic_cast <EmailInfo ^> ((dynamic_cast <Button ^> (sender))->Tag);
    //------------------------------------------------------------------------
    RecordBasicEvent("Send Email button clicked");
    if (emailInfo)
    {
        emailInfo->toAddress = emailToCombo->Text;
        emailInfo->fromAddress = emailFromCombo->Text;
        emailInfo->subjectString = emailSubjectBox->Text;
        emailInfo->messageString = emailMessageBox->Text;
        DTSTest_ValidateAndSendEmail(emailInfo);
    }
}                                       // end of DTSTest_EmailMessageSendButtonClicked()
//----------------------------------------------------------------------------
// DTSTest_EmailSupportLogCloseWindow
//
// Event that closes the Email Support Log window
//
// Called by:   DTSTest_GenerateSupportLog
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_EmailSupportLogCloseWindow(
    Object          ^sender,
    EventArgs       ^evt)
{
    RecordBasicEvent("Email Support Log window closed");
    if (emailSupportLogWindow)
    {
        emailSupportLogWindow->Close();
    }
}                                       // end of DTSTest_EmailSupportLogCloseWindow()
//----------------------------------------------------------------------------
// DTSTest_EventLogCloseWindow
//
// Event that closes the Display Event Log window
//
// Called by:   DTSTest_DisplayMostRecentEventLog
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_EventLogCloseWindow(
    Object          ^sender,
    EventArgs       ^evt)
{
    String          ^functionName = _T("DTSTest_EventLogCloseWindow");
    //------------------------------------------------------------------------
    RecordBasicEvent("Close Event Log button clicked");
    eventLogWindow->Close();
}                                       // end of DTSTest_EventLogCloseWindow()
//----------------------------------------------------------------------------
// DTSTest_ExitProgram
//
// Event that closes the home window, effectively exiting the program, if no
// other windows are opened in DTSTest_Main
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_ExitProgram(
    Object          ^sender,
    EventArgs       ^evt)
{
    //------------------------------------------------------------------------
    // Exit the home window (this actually forces a call to
    // DTSTest_HomeClosingWindow, which presents the user with a modal choice
    // whether to remain running or proceed to exit the program)
    //------------------------------------------------------------------------
    this->Close();
}                                       // end of DTSTest_ExitProgram()
//----------------------------------------------------------------------------
// DTSTest_HomeAddCommentButtonClicked
//
// Event that handles the click of the Add Comment button
//
// Called by:   DTSTest_InstallHomeWindowGraphics
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_HomeAddCommentButtonClicked(
    Object          ^sender,
    EventArgs       ^evt)
{
    String          ^functionName = _T("DTSTest_HomeAddCommentButtonClicked");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0} called", functionName);
    DTSTest_ScriptProcessAddComment(homeAddCommentBox->Text);
    RecordBasicEvent("{0} concluded", functionName);
}                                       // end of DTSTest_HomeAddCommentButtonClicked()
//----------------------------------------------------------------------------
// DTSTest_HomeCalculateCRCsChecked
//
// Event that handles the check of the CRCs Included checkbox
//
// Called by:   DTSTest_InstallHomeWindowGraphics
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_HomeCalculateCRCsChecked(
    Object          ^sender,
    EventArgs       ^evt)
{
    String          ^functionName = _T("DTSTest_HomeCalculateCRCsChecked");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0} called", functionName);
    DTSTest_ToggleCalculateCRCs();
    RecordBasicEvent("{0} concluded", functionName);
}                                       // end of DTSTest_HomeCalculateCRCsChecked()
//----------------------------------------------------------------------------
// DTSTest_HelpCloseWindow
//
// Event that closes the help window
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_HelpCloseWindow(
    Object          ^sender,
    EventArgs       ^evt)
{
    RecordBasicEvent("About window closed");
    if (aboutHelpWindow)
    {
        aboutHelpWindow->Close();
    }
}                                       // end of DTSTest_HelpCloseWindow()
//----------------------------------------------------------------------------
// DTSTest_HomeClearCommandDialogueButtonClicked
//
// Event that handles the click of the Clear Command Dialogue button
//
// Called by:   DTSTest_InstallHomeWindowGraphics
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_HomeClearCommandDialogueButtonClicked(
    Object          ^sender,
    EventArgs       ^evt)
{
    String          ^functionName = _T("DTSTest_HomeClearCommandDialogueButtonClicked");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0} called", functionName);
    homeCommandDialogueBox->Clear();
    generalLogFileString = String::Empty;
    generalCSVFileString = String::Empty;
    homeSingleCommandSendButton->Enabled = GUI_NO;
    homeSingleCommandBox->Clear();
    RecordBasicEvent("{0} concluded", functionName);
}                                       // end of DTSTest_HomeClearCommandDialogueButtonClicked()
//----------------------------------------------------------------------------
// DTSTest_HomeClosingWindow
//
// Handles the closing of the home window
//
// Called by:   DTSTest_InitializeGUIComponents
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_HomeClosingWindow(
    Object          ^sender,
    FormClosingEventArgs
                    ^evt)
{
    bool            proceedWithExit = GUI_YES;
    //------------------------------------------------------------------------
    if (DTSTest_GeneralInfo->flags & DTSTEST_GENERAL_SCAN_COMPLETED)
    {
        if (!(DTSTest_GeneralInfo->flags & DTSTEST_GENERAL_EXPERT_MODE))
        {
            proceedWithExit = DTSTest_PromptYesNoModal(
                "Exit DTSTest",
                "Exit", "Cancel",
                "Proceed to Exit or Cancel ?");
        }
        if (proceedWithExit)
        {
            evt->Cancel = GUI_NO;       // proceed to close the window (don't cancel)
        }
        else
        {
            evt->Cancel = GUI_YES;      // cancel the closing of the window
        }
        //--------------------------------------------------------------------
        // The user has selected to exit the program, so shut down everything
        //--------------------------------------------------------------------
        if (proceedWithExit)
        {
            DTSTest_GeneralInfo->flags |= DTSTEST_GENERAL_PROGRAM_EXITING;
            //----------------------------------------------------------------
            // Shut down the software by releasing resources
            //----------------------------------------------------------------
            DTSTest_ShutDownSoftware();
        }
    }
    else
    {
        evt->Cancel = GUI_YES;          // cancel the closing of the window
    }
}                                       // end of DTSTest_HomeClosingWindow()
//----------------------------------------------------------------------------
// DTSTest_HomeCSVLogChecked
//
// Event that handles the check of the CSV Log files checkbox
//
// Called by:   DTSTest_InstallHomeWindowGraphics
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_HomeCSVLogChecked(
    Object          ^sender,
    EventArgs       ^evt)
{
    String          ^functionName = _T("DTSTest_HomeCSVLogChecked");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0} called", functionName);
    if (DTSTest_GeneralInfo->flags & DTSTEST_GENERAL_CREATE_CSV_LOG_FILE)
        DTSTest_GeneralInfo->flags &= ~DTSTEST_GENERAL_CREATE_CSV_LOG_FILE;
    else
        DTSTest_GeneralInfo->flags |= DTSTEST_GENERAL_CREATE_CSV_LOG_FILE;
    RecordBasicEvent("{0} concluded", functionName);
}                                       // end of DTSTest_HomeCSVLogChecked()
//----------------------------------------------------------------------------
// DTSTest_HomeDemoModeChecked
//
// Event that handles the check of the Demo Mode checkbox
//
// Called by:   DTSTest_InstallHomeWindowGraphics
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_HomeDemoModeChecked(
    Object          ^sender,
    EventArgs       ^evt)
{
    String          ^functionName = _T("DTSTest_HomeDemoModeChecked");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0} called", functionName);
    DTSTest_DemoModeEnabled = DTSTest_DemoModeEnabled ? GUI_NO : GUI_YES;
    if (DTSTest_DemoModeEnabled)
    {
        homeDemoModeCheck->Checked = GUI_YES;
        testingDemoModeCheck->Checked = GUI_YES;
        if (StringSet(homeSingleCommandBox->Text))
            homeSingleCommandSendButton->Enabled = GUI_YES;
    }
    else
    {
        homeDemoModeCheck->Checked = GUI_NO;
        testingDemoModeCheck->Checked = GUI_NO;
    }
    RecordBasicEvent("{0} concluded", functionName);
}                                       // end of DTSTest_HomeDemoModeChecked()
//----------------------------------------------------------------------------
// DTSTest_HomeLoadControlScriptFileButtonClicked
//
// Event that handles the click of the Load Control Script File button
//
// Called by:   DTSTest_InstallHomeWindowGraphics
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_HomeLoadControlScriptFileButtonClicked(
    Object          ^sender,
    EventArgs       ^evt)
{
    String          ^functionName = _T("DTSTest_HomeLoadControlScriptFileButtonClicked");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0} called", functionName);
    if (DTSTest_ControlScriptRunning)
    {
        DTSTest_ControlScriptRunning = GUI_NO;
    }
    else
    {
        DTSTest_ScriptPromptForMainControlScriptFile();
    }
    RecordBasicEvent("{0} concluded", functionName);
}                                       // end of DTSTest_HomeLoadControlScriptFileButtonClicked()
//----------------------------------------------------------------------------
// DTSTest_HomeLoopControlScriptButtonClicked
//
// Event that handles the click of the Loop Control Script button
//
// Called by:   DTSTest_InstallHomeWindowGraphics
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_HomeLoopControlScriptButtonClicked(
    Object          ^sender,
    EventArgs       ^evt)
{
    String          ^functionName = _T("DTSTest_HomeLoopControlScriptButtonClicked");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0} called", functionName);
    DTSTest_ControlScriptLooping = DTSTest_ControlScriptLooping ? GUI_NO : GUI_YES;
    if (DTSTest_ControlScriptLooping)
    {
        if (DTSTest_ControlScriptRunning)
        {
            homeLoopControlScriptButton->Text = _T("Stop Looping");
        }
        else
        {
            DTSTest_ControlScriptRunning = GUI_YES;
//            PDGICInfo ^pgInfo = DTSTest_GeneralInfo->pgInfo;
            if (StringSet(DTSTest_GeneralInfo->mainScript->controlScriptString))
            {
                homeLoopControlScriptButton->Text = _T("Stop Looping");
                DTSTest_ScriptProcessMainControlScript(DTSTest_GeneralInfo->mainScript->controlScriptString);
            }
            else
            {
                Modal("!!! No control script has been specified");
            }
        }
    }
    else
    {
        homeLoopControlScriptButton->Text = _T("Loop Control Script");
//        DTSTest_ControlScriptRunning = GUI_NO;
    }
    RecordBasicEvent("{0} concluded", functionName);
}                                       // end of DTSTest_HomeLoopControlScriptButtonClicked()
//----------------------------------------------------------------------------
// DTSTest_HomeNormalizeReadingsChecked
//
// Event that handles the check of the Normalize Readings checkbox
//
// Called by:   DTSTest_InstallHomeWindowGraphics
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_HomeNormalizeReadingsChecked(
    Object          ^sender,
    EventArgs       ^evt)
{
    String          ^functionName = _T("DTSTest_HomeNormalizeReadingsChecked");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0} called", functionName);
    DTSTest_ToggleNormalizeMeasurements();
    RecordBasicEvent("{0} concluded", functionName);
}                                       // end of DTSTest_HomeNormalizeReadingsChecked()
//----------------------------------------------------------------------------
// DTSTest_HomePrependDateAndTimeChecked
//
// Event that handles the check of the Prepend Date and Time checkbox
//
// Called by:   DTSTest_InstallHomeWindowGraphics
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_HomePrependDateAndTimeChecked(
    Object          ^sender,
    EventArgs       ^evt)
{
    String          ^functionName = _T("DTSTest_HomePrependDateAndTimeChecked");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0} called", functionName);
    DTSTest_PrependDateAndTime = DTSTest_PrependDateAndTime ? GUI_NO : GUI_YES;
    RecordBasicEvent("{0} concluded", functionName);
}                                       // end of DTSTest_HomePrependDateAndTimeChecked()
//----------------------------------------------------------------------------
// DTSTest_HomeReportCRCErrorsChecked
//
// Event that handles the check of the Report CRC Errors checkbox
//
// Called by:   DTSTest_InstallHomeWindowGraphics
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_HomeReportCRCErrorsChecked(
    Object          ^sender,
    EventArgs       ^evt)
{
    String          ^functionName = _T("DTSTest_HomeReportCRCErrorsCheck");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0} called", functionName);
    DTSTest_ReportCRCErrors = DTSTest_ReportCRCErrors ? GUI_NO : GUI_YES;
    RecordBasicEvent("{0} concluded", functionName);
}                                       // end of DTSTest_HomeReportCRCErrorsChecked()
//----------------------------------------------------------------------------
// DTSTest_HomeRerunControlScriptButtonClicked
//
// Event that handles the click of the Rerun Control Script button
//
// Called by:   DTSTest_InstallHomeWindowGraphics
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_HomeRerunControlScriptButtonClicked(
    Object          ^sender,
    EventArgs       ^evt)
{
    String          ^functionName = _T("DTSTest_HomeRerunControlScriptButtonClicked");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0} called", functionName);
    if (DTSTest_ControlScriptPaused)
    {
        DTSTest_ControlScriptPaused = GUI_NO;
        homeRerunControlScriptButton->Text = _T("Pause Control Script");
    }
    else
    {
        if (DTSTest_ControlScriptRunning)
        {
            DTSTest_ControlScriptPaused = GUI_YES;
            homeRerunControlScriptButton->Text = _T("Resume Control Script");
        }
        else
        {
//            PDGICInfo ^pgInfo = DTSTest_GeneralInfo->pgInfo;
            if (StringSet(DTSTest_GeneralInfo->mainScript->controlScriptString))
            {
                DTSTest_ScriptProcessMainControlScript(DTSTest_GeneralInfo->mainScript->controlScriptString);
            }
        }
    }
    RecordBasicEvent("{0} concluded", functionName);
}                                       // end of DTSTest_HomeRerunControlScriptButtonClicked()
//----------------------------------------------------------------------------
// DTSTest_HomeSaveCommandDialogueButtonClicked
//
// Event that handles the click of the Save Command Dialogue button
//
// Called by:   DTSTest_InstallHomeWindowGraphics
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_HomeSaveCommandDialogueButtonClicked(
    Object          ^sender,
    EventArgs       ^evt)
{
    String          ^filePathString;
    String          ^functionName = _T("DTSTest_HomeSaveCommandDialogueButtonClicked");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0} called", functionName);
    if (StringSet(DTSTest_GeneralInfo->mainScript->resultsLogFilePath))
    {
        filePathString = DTSTest_GeneralInfo->mainScript->resultsLogFilePath;
    }
    else
    {
        DateTime dateTime = DateTime::Now;
        String ^dateStamp = String::Format(
            "{0:D2}{1:D2}{2:D2}",
            (dateTime.Year % 100),
            dateTime.Month,
            dateTime.Day);
        filePathString = String::Concat(
            DTSTest_GeneralInfo->logDirectory,
            "\\DTSTest-Results-",
            String::Format(
                "{0:D2}{1:D2}{2:D2}",
                (dateTime.Year % 100),
                dateTime.Month,
                dateTime.Day),
            "-001.log");
    }
    StringBuilder ^pathNameBuilder = gcnew StringBuilder(
        DTSTEST_MAXIMUM_FILE_PATH_LENGTH);                                      // 512
    GUI_StringToBuilder(
        filePathString,
        pathNameBuilder);
    bool proceedToSave = DTSTest_PromptForSaveFile(
        _T("Save Results Log"),
        pathNameBuilder,
        String::Empty,
        ((DTSTest_GeneralInfo->flags & DTSTEST_GENERAL_CREATE_CSV_LOG_FILE) ? GUI_FILE_TYPE_CSV : GUI_FILE_TYPE_LOG));
    String ^pathString = pathNameBuilder->ToString();
    delete pathNameBuilder;
    if (proceedToSave)
    {
        //--------------------------------------------------------------------
        // Always save a .log type file
        //--------------------------------------------------------------------
        String ^logPathString = pathString->Replace(Path::GetExtension(pathString), ".log");
        DTSTest_GeneralInfo->mainScript->resultsLogFilePath = logPathString;
        homeResultsLogPathLabel->Text = String::Concat(
            _T("Results log: "),
            DTSTest_GeneralInfo->mainScript->resultsLogFilePath);
        testingResultsLogPathLabel->Text = String::Concat(
            _T("Test results: "),
            DTSTest_GeneralInfo->mainScript->resultsLogFilePath);
        DTSTest_AppendLineToDataLog(homeCommandDialogueBox->Text);
        if ((DTSTest_GeneralInfo->flags & DTSTEST_GENERAL_CREATE_CSV_LOG_FILE) ||
            (pathString->EndsWith(".csv", StringComparison::OrdinalIgnoreCase)))
        {
            DTSTest_AppendLineToCSVLog(generalCSVFileString);
        }
    }                                   // end of if (proceedToSave)
    RecordBasicEvent("{0} concluded", functionName);
}                                       // end of DTSTest_HomeSaveCommandDialogueButtonClicked()
//----------------------------------------------------------------------------
// DTSTest_HomeSingleCommandSendButtonClicked
//
// Event that handles the click of the Single Command Send button
//
// Called by:   DTSTest_InstallHomeWindowGraphics
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_HomeSingleCommandSendButtonClicked(
    Object          ^sender,
    EventArgs       ^evt)
{
    String          ^functionName = _T("DTSTest_HomeSingleCommandSendButtonClicked");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0} called", functionName);
    DTSTest_ProcessCommandLine(
        homeSingleCommandBox->Text,
        GUI_NO);
    RecordBasicEvent("{0} concluded", functionName);
}                                       // end of DTSTest_HomeSingleCommandSendButtonClicked()
//----------------------------------------------------------------------------
// DTSTest_HomeSwitchBaudRateButtonClicked
//
// Event that handles the click of the Switch Baud Rate button
//
// Called by:   DTSTest_InstallHomeWindowGraphics
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_HomeSwitchBaudRateButtonClicked(
    Object          ^sender,
    EventArgs       ^evt)
{
    String          ^functionName = _T("DTSTest_HomeSwitchBaudRateButtonClicked");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0} called", functionName);
    DTSTest_SwitchBaudRate();
    RecordBasicEvent("{0} concluded", functionName);
}                                       // end of DTSTest_HomeSwitchBaudRateButtonClicked()
//----------------------------------------------------------------------------
// DTSTest_HomeTextBoxAcceptEnterKey
//
// Handles the acceptance of the Enter key in any of the main page text boxes
//
// Called by:   DTSTest_InstallHomeWindowGraphics
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_HomeTextBoxAcceptEnterKey(
    Object          ^sender,
    PreviewKeyDownEventArgs
                    ^evt)
{
    //------------------------------------------------------------------------
    if (evt->KeyCode == Keys::Enter)
    {
        evt->IsInputKey = GUI_YES;
        if (StringSet(homeAddCommentBox->Text))
            DTSTest_ScriptProcessAddComment(homeAddCommentBox->Text);
        else
            DTSTest_ProcessCommandLine(homeSingleCommandBox->Text, GUI_NO);
    }
}                                       // end of DTSTest_HomeTextBoxAcceptEnterKey()
//----------------------------------------------------------------------------
// DTSTest_HomeTextBoxProcessEnterKey
//
// Processes the result of accepting the Enter key in the text boxes
// box by suppressing the 'bell' as a result of the keypress
//
// Called by:   DTSTest_InstallHomeWindowGraphics
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_HomeTextBoxProcessEnterKey(
    Object          ^sender,
    KeyEventArgs    ^evt)
{
    //------------------------------------------------------------------------
    if (evt->KeyCode == Keys::Enter)
    {
        evt->SuppressKeyPress = GUI_YES;
    }
}                                       // end of DTSTest_HomeTextBoxProcessEnterKey()
//----------------------------------------------------------------------------
// DTSTest_HomeVerboseLogMessagesChecked
//
// Event that handles the check of the Verbose Log Messages checkbox
//
// Called by:   DTSTest_InstallHomeWindowGraphics
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_HomeVerboseLogMessagesChecked(
    Object          ^sender,
    EventArgs       ^evt)
{
    String          ^functionName = _T("DTSTest_HomeVerboseLogMessagesChecked");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0} called", functionName);
    if (DTSTest_GeneralInfo->flags & DTSTEST_GENERAL_VERBOSE_LOG_MESSAGES)
        DTSTest_GeneralInfo->flags &= ~DTSTEST_GENERAL_VERBOSE_LOG_MESSAGES;
    else
        DTSTest_GeneralInfo->flags |= DTSTEST_GENERAL_VERBOSE_LOG_MESSAGES;
    RecordBasicEvent("{0} concluded", functionName);
}                                       // end of DTSTest_HomeVerboseLogMessagesChecked()
//----------------------------------------------------------------------------
// DTSTest_HyperLinkClicked
//
// Event that handles the click of a hyperlink
//
// Called by:   DTSTest_DisplayHelpLink
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_HyperLinkClicked(
    Object          ^sender,
    LinkLabelLinkClickedEventArgs
                    ^evt)
{
    int             timeout = 10;
    LinkLabel       ^hyperLink = dynamic_cast <LinkLabel ^> (sender);
    String          ^target = dynamic_cast <String ^> (evt->Link->LinkData);
    //------------------------------------------------------------------------
    RecordBasicEvent("Hyperlink clicked");
    if (target && hyperLink)
    {
        while (!(DTSTest_GeneralInfo->flags & DTSTEST_GENERAL_INTERNET_AVAILABLE) && timeout)
        {
            DTSTest_InternetIsAvailable();
            if (!(DTSTest_GeneralInfo->flags & DTSTEST_GENERAL_INTERNET_AVAILABLE))
            {
                Thread::Sleep(100);
                timeout--;
            }
        }
        if (DTSTest_GeneralInfo->flags & DTSTEST_GENERAL_INTERNET_AVAILABLE)
        {
            System::Diagnostics::Process::Start(target);
            hyperLink->Links[hyperLink->Links->IndexOf(evt->Link)]->Visited = GUI_YES;
        }
        else
        {
            GUI_DisplaySimpleError(
                "Internet Access",
                "The web is unavailable at this time");
        }
    }
}                                       // end of DTSTest_HyperLinkClicked()
//----------------------------------------------------------------------------
// DTSTest_OneSecondTimerElapsed
//
// Handles the lapsing of the one-second timer
//
// Called by:   DTSTest_InitializeGUIComponents
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_OneSecondTimerElapsed(
    Object          ^sender,
    EventArgs       ^evt)
{
    DateTime        dateTime = DateTime::Now;
//    String          ^functionName = _T("DTSTest_OneSecondTimerElapsed");
    //------------------------------------------------------------------------
    nowTSStatusLabel->Text = String::Format(
        "{0,9} {1:D2} {2} {3:D4} {4:D2}:{5:D2}:{6:D2}",
        dateTime.DayOfWeek,
        dateTime.Day,
        DTSTest_MonthStringArray[dateTime.Month],
        dateTime.Year,
        dateTime.Hour,
        dateTime.Minute,
        dateTime.Second);
    //------------------------------------------------------------------------
    // Relieve the display windows of being forced to the top of the display
    //------------------------------------------------------------------------
//    this->TopMost = GUI_NO;
//    if (emailSupportLogWindow)
//        emailSupportLogWindow->TopMost = GUI_NO;
//    if (pInfoWindow)
//        pInfoWindow->TopMost = GUI_NO;
}                                       // end of DTSTest_OneSecondTimerElapsed()
//----------------------------------------------------------------------------
// DTSTest_PleaseWaitClosingWindow
//
// Handles the closing of the Please wait window by the red X
//
// Called by:   DTSTest_PleaseWait
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_PleaseWaitClosingWindow(
    Object          ^sender,
    FormClosingEventArgs
                    ^evt)
{
    //------------------------------------------------------------------------
    evt->Cancel = GUI_YES;              // cancel the closing of the window
    if (pleaseWaitWindow)
    {
        pleaseWaitWindow->Tag = GUI_PLEASE_WAIT_STATE_HIDDEN;
        pleaseWaitWindow->Hide();
        pleaseWaitWindow->Update();
    }
}                                       // end of DTSTest_PleaseWaitClosingWindow()
//----------------------------------------------------------------------------
// DTSTest_ProgramInfoCloseWindow
//
// Event that closes the program infomation display window
//
// Called by:   DTSTest_ProgramInfoDisplayWindow
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_ProgramInfoCloseWindow(
    Object          ^sender,
    EventArgs       ^evt)
{
    RecordBasicEvent("Program Info window closed");
    if (pInfoWindow)
    {
        pInfoWindow->Close();
    }
}                                       // end of DTSTest_ProgramInfoCloseWindow()
//----------------------------------------------------------------------------
// DTSTest_PromptKeyPressed
//
// Handles the press of a keystroke in the PromptYesNoModal or PromptInput
// window
//
// Called by:   DTSTest_PromptYesNoModal
//
// Note:        Accepts only the upper- and lower-case characters B, K, N, S,
//              X, and Y.
//              Enter, Esc, and Space are already handled by ShowDialog, which
//              will leave DTSTest_ModalKeyStroke at 0.
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_PromptKeyPressed(
    Object          ^sender,
    KeyPressEventArgs
                    ^evt)
{
    //------------------------------------------------------------------------
    DTSTest_ModalKeyStroke = 0;
    if ((evt->KeyChar == (int) 'b') || (evt->KeyChar == (int) 'B') ||           // browse
        (evt->KeyChar == (int) 'd') || (evt->KeyChar == (int) 'D') ||           // delete
        (evt->KeyChar == (int) 'k') || (evt->KeyChar == (int) 'K') ||
        (evt->KeyChar == (int) 'n') || (evt->KeyChar == (int) 'N') ||           // no
        (evt->KeyChar == (int) 's') || (evt->KeyChar == (int) 'S') ||           // search / save
        (evt->KeyChar == (int) 'x') || (evt->KeyChar == (int) 'X') ||
        (evt->KeyChar == (int) 'y') || (evt->KeyChar == (int) 'Y'))             // yes
    {
        if ((evt->KeyChar == (int) 'b') || (evt->KeyChar == (int) 'B') ||
            (evt->KeyChar == (int) 'd') || (evt->KeyChar == (int) 'D') ||
            (evt->KeyChar == (int) 'n') || (evt->KeyChar == (int) 'N'))
            DTSTest_ModalKeyStroke = (DWORD) 'N';
        else
            DTSTest_ModalKeyStroke = (DWORD) 'Y';
        evt->Handled = GUI_YES;
        (dynamic_cast <Button ^>(sender))->PerformClick();
    }
}                                       // end of DTSTest_PromptKeyPressed()
//----------------------------------------------------------------------------
// DTSTest_TextChangedAddComment
//
// Handles changes of the Add Comment field by enabling the Add button if
// text is present in the box
//
// Called by:   DTSTest_InstallHomeWindowGraphics
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_TextChangedAddComment(
    Object          ^sender,
    EventArgs       ^evt)
{
    //------------------------------------------------------------------------
    if (StringSet(homeAddCommentBox->Text))
        homeAddCommentButton->Enabled = GUI_YES;
    else
        homeAddCommentButton->Enabled = GUI_NO;
}                                       // end of DTSTest_TextChangedAddComment()
//----------------------------------------------------------------------------
// DTSTest_TextChangedSingleCommand
//
// Handles changes of the Single Command field by enabling the Send button if
// text is present in the box
//
// Called by:   DTSTest_InstallHomeWindowGraphics
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_TextChangedSingleCommand(
    Object          ^sender,
    EventArgs       ^evt)
{
    //------------------------------------------------------------------------
    if (StringSet(homeSingleCommandBox->Text))
    {
        if (DTSTest_GeneralInfo->pgInfo->PDGICPresent || DTSTest_DemoModeEnabled)
            homeSingleCommandSendButton->Enabled = GUI_YES;
        else
            homeSingleCommandSendButton->Enabled = GUI_NO;
    }
    else
        homeSingleCommandSendButton->Enabled = GUI_NO;
}                                       // end of DTSTest_TextChangedSingleCommand()
//----------------------------------------------------------------------------
// DTSTest_ToolStripAboutDropDownClicked
//
// Handles the click of the About drop down button
//
// Called by:   DTSTest_InstallToolStrip
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_ToolStripAboutDropDownClicked(
    Object          ^sender,
    EventArgs       ^evt)
{
    RecordBasicEvent("About drop-down button clicked");
    DTSTest_AboutHelp();
}                                       // end of DTSTest_ToolStripAboutDropDownClicked()
//----------------------------------------------------------------------------
// DTSTest_ToolStripAdvancedControlsDropDownClicked
//
// Handles the click of the Advanced Controls drop down button
//
// Called by:   DTSTest_InstallToolStrip
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_ToolStripAdvancedControlsDropDownClicked(
    Object          ^sender,
    EventArgs       ^evt)
{
    //------------------------------------------------------------------------
    RecordBasicEvent("Advanced Controls drop-down button clicked");
    if (advancedControlsWindow->WindowState == FormWindowState::Minimized)
        advancedControlsWindow->WindowState = FormWindowState::Normal;
    else
        advancedControlsWindow->Show();
    advancedControlsWindow->BringToFront();
    if (advancedControlsWindow->CanFocus)
        advancedControlsWindow->Focus();
    if (advancedControlsWindow->CanSelect)
        advancedControlsWindow->Select();
}                                       // end of DTSTest_ToolStripAdvancedControlsDropDownClicked()
//----------------------------------------------------------------------------
// DTSTest_ToolStripCheckForUpdateDropDownClicked
//
// Handles the click of the Check for Update drop down button
//
// Called by:   DTSTest_InstallToolStrip
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_ToolStripCheckForUpdateDropDownClicked(
    Object          ^sender,
    EventArgs       ^evt)
{
    bool            proceedToCheck = GUI_NO;
    //------------------------------------------------------------------------
    RecordBasicEvent("Check for Update drop-down button clicked");
    proceedToCheck = DTSTest_PromptModal(
        "Check for Update",
        "You are running DTSTest software version {0}\n"
        "Check online for an updated version?",
        DTSTEST_PROGRAM_VERSION_STRING);
    if (proceedToCheck)
        DTSTest_CheckForCurrentSoftwareVersion(GUI_YES);
}                                       // end of DTSTest_ToolStripCheckForUpdateDropDownClicked()
//----------------------------------------------------------------------------
// DTSTest_ToolStripCSVControlsDropDownClicked
//
// Handles the click of the CSV File Controls drop down button
//
// Called by:   DTSTest_InstallToolStrip
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_ToolStripCSVControlsDropDownClicked(
    Object          ^sender,
    EventArgs       ^evt)
{
    //------------------------------------------------------------------------
    RecordBasicEvent("CSV File Controls drop-down button clicked");
    if (fileControlsWindow->WindowState == FormWindowState::Minimized)
        fileControlsWindow->WindowState = FormWindowState::Normal;
    else
        fileControlsWindow->Show();
    fileControlsWindow->BringToFront();
    if (fileControlsWindow->CanFocus)
        fileControlsWindow->Focus();
    if (fileControlsWindow->CanSelect)
        fileControlsWindow->Select();
}                                       // end of DTSTest_ToolStripCSVControlsDropDownClicked()
//----------------------------------------------------------------------------
// DTSTest_ToolStripDisplayEventLogDropDownClicked
//
// Handles the click of the Display Event Log drop down
//
// Called by:   DTSTest_InstallToolStrip
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_ToolStripDisplayEventLogDropDownClicked(
    Object          ^sender,
    EventArgs       ^evt)
{
    String          ^functionName = _T("DTSTest_ToolStripDisplayEventLogDropDownClicked");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0} called", functionName);
    DTSTest_DisplayMostRecentEventLog();
    RecordBasicEvent("{0} concluded", functionName);
}                                       // end of DTSTest_ToolStripDisplayEventLogDropDownClicked()
//----------------------------------------------------------------------------
// DTSTest_ToolStripEventLogAllDropDownClicked
//
// Handles the click of the All Events Log drop down
//
// Called by:   DTSTest_InstallToolStrip
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_ToolStripEventLogAllDropDownClicked(
    Object          ^sender,
    EventArgs       ^evt)
{
    String          ^functionName = _T("DTSTest_ToolStripEventLogAllDropDownClicked");
    //------------------------------------------------------------------------
    DTSTest_EventLogBasicEnabled = (DTSTest_EventLogBasicEnabled ? GUI_NO : GUI_YES);
    if (DTSTest_EventLogBasicEnabled)
    {
        DTSTest_EventLogVerboseEnabled = GUI_YES;
        DTSTest_EventLogDetailedEnabled = GUI_YES;
        DTSTest_EstablishEventLog(String::Concat(functionName, " called"));
    }
    else
    {
        DTSTest_UpdateEventLog(String::Concat(functionName, " called"));
        DTSTest_EventLogVerboseEnabled = GUI_NO;
        DTSTest_EventLogDetailedEnabled = GUI_NO;
        DTSTest_ConcludeEventLog(String::Concat(functionName, " concluded"));
    }
    DTSTest_UpdateMessageChecks();
}                                       // end of DTSTest_ToolStripEventLogAllDropDownClicked()
//----------------------------------------------------------------------------
// DTSTest_ToolStripEventLogBasicDropDownClicked
//
// Handles the click of the Log Basic Events drop down
//
// Called by:   DTSTest_InstallToolStrip
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_ToolStripEventLogBasicDropDownClicked(
    Object          ^sender,
    EventArgs       ^evt)
{
    String          ^functionName = _T("DTSTest_ToolStripEventLogBasicDropDownClicked");
    //------------------------------------------------------------------------
    DTSTest_EventLogBasicEnabled = (DTSTest_EventLogBasicEnabled ? GUI_NO : GUI_YES);
    if (DTSTest_EventLogVerboseEnabled && !DTSTest_EventLogBasicEnabled)
        DTSTest_EventLogVerboseEnabled = GUI_NO;
    if (DTSTest_EventLogDetailedEnabled && !DTSTest_EventLogBasicEnabled)
        DTSTest_EventLogDetailedEnabled = GUI_NO;
    DTSTest_EstablishEventLog(String::Format("{0} called", functionName));
    RecordBasicEvent(
        "Basic Event Log {0}",
        (DTSTest_EventLogBasicEnabled ? "started" : "stopped"));
    if (eventLogBasicTSButton)
    {
        eventLogBasicTSButton->Text =
            DTSTest_EventLogBasicEnabled ?
                GUI_ELOG_BASIC_STOP_STRING : GUI_ELOG_BASIC_START_STRING;
    }
    if (eventLogVerboseTSButton)
    {
        eventLogVerboseTSButton->Text =
            DTSTest_EventLogVerboseEnabled ?
                GUI_ELOG_VERBOSE_STOP_STRING : GUI_ELOG_VERBOSE_START_STRING;
    }
    if (eventLogDetailedTSButton)
    {
        eventLogDetailedTSButton->Text =
            DTSTest_EventLogDetailedEnabled ?
                GUI_ELOG_DETAILED_STOP_STRING : GUI_ELOG_DETAILED_START_STRING;
    }
    RecordVerboseEvent("{0} concluded", functionName);
}                                       // end of DTSTest_ToolStripEventLogBasicDropDownClicked()
//----------------------------------------------------------------------------
// DTSTest_ToolStripEventLogDetailedDropDownClicked
//
// Handles the check of the Log Detailed Events drop down
//
// Called by:   DTSTest_InstallToolStrip
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_ToolStripEventLogDetailedDropDownClicked(
    Object          ^sender,
    EventArgs       ^evt)
{
    String          ^functionName = _T("DTSTest_ToolStripEventLogDetailedDropDownClicked");
    //------------------------------------------------------------------------
    DTSTest_EventLogDetailedEnabled = (DTSTest_EventLogDetailedEnabled ? GUI_NO : GUI_YES);
    if (DTSTest_EventLogDetailedEnabled && !DTSTest_EventLogBasicEnabled)
        DTSTest_EventLogBasicEnabled = GUI_YES;
    DTSTest_EstablishEventLog(String::Format("{0} called", functionName));
    RecordBasicEvent(
        "Detailed Event Log {0}",
        (DTSTest_EventLogDetailedEnabled ? "started" : "stopped"));
    if (eventLogBasicTSButton)
    {
        eventLogBasicTSButton->Text =
            DTSTest_EventLogBasicEnabled ?
                GUI_ELOG_BASIC_STOP_STRING : GUI_ELOG_BASIC_START_STRING;
    }
    if (eventLogVerboseTSButton)
    {
        eventLogVerboseTSButton->Text =
            DTSTest_EventLogVerboseEnabled ?
                GUI_ELOG_VERBOSE_STOP_STRING : GUI_ELOG_VERBOSE_START_STRING;
    }
    if (eventLogDetailedTSButton)
    {
        eventLogDetailedTSButton->Text =
            DTSTest_EventLogDetailedEnabled ?
                GUI_ELOG_DETAILED_STOP_STRING : GUI_ELOG_DETAILED_START_STRING;
    }
    RecordVerboseEvent("{0} concluded", functionName);
}                                       // end of DTSTest_ToolStripEventLogDetailedDropDownClicked()
//----------------------------------------------------------------------------
// DTSTest_ToolStripEventLogVerboseDropDownClicked
//
// Handles the check of the Log Verbose Events drop down
//
// Called by:   DTSTest_InstallToolStrip
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_ToolStripEventLogVerboseDropDownClicked(
    Object          ^sender,
    EventArgs       ^evt)
{
    String          ^functionName = _T("DTSTest_ToolStripEventLogVerboseDropDownClicked");
    //------------------------------------------------------------------------
    DTSTest_EventLogVerboseEnabled = (DTSTest_EventLogVerboseEnabled ? GUI_NO : GUI_YES);
    if (DTSTest_EventLogVerboseEnabled && !DTSTest_EventLogBasicEnabled)
        DTSTest_EventLogBasicEnabled = GUI_YES;
    DTSTest_EstablishEventLog(String::Format("{0} called", functionName));
    RecordBasicEvent(
        "Verbose Event Log {0}",
        (DTSTest_EventLogVerboseEnabled ? "started" : "stopped"));
    if (eventLogBasicTSButton)
    {
        eventLogBasicTSButton->Text =
            DTSTest_EventLogBasicEnabled ?
                GUI_ELOG_BASIC_STOP_STRING : GUI_ELOG_BASIC_START_STRING;
    }
    if (eventLogVerboseTSButton)
    {
        eventLogVerboseTSButton->Text =
            DTSTest_EventLogVerboseEnabled ?
                GUI_ELOG_VERBOSE_STOP_STRING : GUI_ELOG_VERBOSE_START_STRING;
    }
    if (eventLogDetailedTSButton)
    {
        eventLogDetailedTSButton->Text =
            DTSTest_EventLogDetailedEnabled ?
                GUI_ELOG_DETAILED_STOP_STRING : GUI_ELOG_DETAILED_START_STRING;
    }
    RecordVerboseEvent("{0} concluded", functionName);
}                                       // end of DTSTest_ToolStripEventLogVerboseDropDownClicked()
//----------------------------------------------------------------------------
// DTSTest_ToolStripExpertModeDropDownClicked
//
// Handles the click of the Expert Mode button by adding the Expert tab to the
//      set of tabs already present as the third tab, or removes it if the tab
//      is present
//
// Called by:   DTSTest_InstallToolStrip
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_ToolStripExpertModeDropDownClicked(
    Object          ^sender,
    EventArgs       ^evt)
{
    RecordBasicEvent("Expert Mode drop-down button clicked");
    DTSTest_ToggleExpertMode();
}                                       // end of DTSTest_ToolStripExpertModeDropDownClicked()
//----------------------------------------------------------------------------
// DTSTest_ToolStripOnlineHelpDropDownClicked
//
// Event that invokes the default browser to display the DTSTest online help
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_ToolStripOnlineHelpDropDownClicked(
    Object          ^sender,
    EventArgs       ^evt)
{
    RecordBasicEvent("Online Help URL drop-down button clicked");
    if (DTSTest_InternetIsAvailable())
        System::Diagnostics::Process::Start(DTSTEST_HELP_URL);
    else
        GUI_DisplaySimpleError(
            "Online Help",
            "The web is unavailable at this time");
}                                       // end of DTSTest_ToolStripOnlineHelpDropDownClicked()
//----------------------------------------------------------------------------
// DTSTest_ToolStripProgInfoDropDownClicked
//
// Handles the click of the Program Info button
//
// Called by:   DTSTest_InstallToolStrip
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_ToolStripProgInfoDropDownClicked(
    Object          ^sender,
    EventArgs       ^evt)
{
    RecordBasicEvent("Program Info drop-down button clicked");
    DTSTest_ProgramInfoDisplayWindow();
}                                       // end of DTSTest_ToolStripProgInfoDropDownClicked()
//----------------------------------------------------------------------------
// DTSTest_ToolStripSamplingControlsDropDownClicked
//
// Handles the click of the Sampling Controls drop down button
//
// Called by:   DTSTest_InstallToolStrip
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_ToolStripSamplingControlsDropDownClicked(
    Object          ^sender,
    EventArgs       ^evt)
{
    //------------------------------------------------------------------------
    RecordBasicEvent("Sampling Controls drop-down button clicked");
    if (samplingControlsWindow->WindowState == FormWindowState::Minimized)
        samplingControlsWindow->WindowState = FormWindowState::Normal;
    else
        samplingControlsWindow->Show();
    samplingControlsWindow->BringToFront();
    if (samplingControlsWindow->CanFocus)
        samplingControlsWindow->Focus();
    if (samplingControlsWindow->CanSelect)
        samplingControlsWindow->Select();
}                                       // end of DTSTest_ToolStripSamplingControlsDropDownClicked()
//----------------------------------------------------------------------------
// DTSTest_ToolStripScriptControlsDropDownClicked
//
// Handles the click of the Script Controls drop down button
//
// Called by:   DTSTest_InstallToolStrip
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_ToolStripScriptControlsDropDownClicked(
    Object          ^sender,
    EventArgs       ^evt)
{
    //------------------------------------------------------------------------
    RecordBasicEvent("Script Controls drop-down button clicked");
    if (scriptControlsWindow->WindowState == FormWindowState::Minimized)
        scriptControlsWindow->WindowState = FormWindowState::Normal;
    else
        scriptControlsWindow->Show();
    scriptControlsWindow->BringToFront();
    if (scriptControlsWindow->CanFocus)
        scriptControlsWindow->Focus();
    if (scriptControlsWindow->CanSelect)
        scriptControlsWindow->Select();
}                                       // end of DTSTest_ToolStripScriptControlsDropDownClicked()
//----------------------------------------------------------------------------
// DTSTest_ToolStripSupportLogDropDownClicked
//
// Handles the click of the Support Log button
//
// Called by:   DTSTest_InstallToolStrip
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_ToolStripSupportLogDropDownClicked(
    Object          ^sender,
    EventArgs       ^evt)
{
    RecordBasicEvent("Support Log drop-down button clicked");
    DTSTest_GenerateSupportLog();
}                                       // end of DTSTest_ToolStripSupportLogDropDownClicked()
//----------------------------------------------------------------------------
// DTSTest_ToolStripTestingControlsDropDownClicked
//
// Handles the click of the Sandbox Controls drop down button
//
// Called by:   DTSTest_InstallToolStrip
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_ToolStripTestingControlsDropDownClicked(
    Object          ^sender,
    EventArgs       ^evt)
{
    //------------------------------------------------------------------------
    RecordBasicEvent("Testing Controls drop-down button clicked");
    if (testingControlsWindow->WindowState == FormWindowState::Minimized)
        testingControlsWindow->WindowState = FormWindowState::Normal;
    else
        testingControlsWindow->Show();
    testingControlsWindow->BringToFront();
    if (testingControlsWindow->CanFocus)
        testingControlsWindow->Focus();
    if (testingControlsWindow->CanSelect)
        testingControlsWindow->Select();
}                                       // end of DTSTest_ToolStripTestingControlsDropDownClicked()
//----------------------------------------------------------------------------
// DTSTest_ValidateEmailMessageAddresses
//
// Handles changes of the Send Email Message To and CC fields; ensures that the
// field format meets the criteria for a proper email address
//
// Called by:   DTSTest_AdvancedControlsSetUpWindow
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_ValidateEmailMessageAddresses(
    Object          ^sender,
    CancelEventArgs ^evt)
{
    String          ^functionName = _T("DTSTest_ValidateEmailMessageAddresses");
    //------------------------------------------------------------------------
    if (StringSet(advancedEmailMessageToAddressBox->Text))
    {
        if (DTSTest_EmailAddressFormatIsValid(advancedEmailMessageToAddressBox->Text))
        {
            DTSTest_GeneralInfo->emailMessageToAddress =
                advancedEmailMessageToAddressBox->Text;
            RecordBasicEvent(
                "Email Message To address set as {0}",
                advancedEmailMessageToAddressBox->Text);
        }
        else
        {
            DTSTest_PromptOKModal(
                "Invalid Email Address",
                "Attempt to set Email Message To address as {0}",
                advancedEmailMessageToAddressBox->Text);
        }
    }
    else
    {
        DTSTest_GeneralInfo->emailMessageToAddress = String::Empty;
    }
    if (StringSet(advancedEmailMessageCCAddressBox->Text))
    {
        if (DTSTest_EmailAddressFormatIsValid(advancedEmailMessageCCAddressBox->Text))
        {
            DTSTest_GeneralInfo->emailMessageCCAddress =
                advancedEmailMessageCCAddressBox->Text;
            RecordBasicEvent(
                "Email Message CC address set as {0}",
                advancedEmailMessageCCAddressBox->Text);
        }
        else
        {
            DTSTest_PromptOKModal(
                "Invalid Email Address",
                "Attempt to set Email Message To address as {0}",
                advancedEmailMessageCCAddressBox->Text);
        }
    }
    else
    {
        DTSTest_GeneralInfo->emailMessageCCAddress = String::Empty;
    }
    DTSTest_UpdateMessageChecks();
    evt->Cancel = GUI_NO;
}                                       // end of DTSTest_ValidateEmailMessageAddresses()
//----------------------------------------------------------------------------
// DTSTest_ValidateExperimentNumberValue
//
// Handles changes of the experiment number field; ensures that the
// integer value of the field falls within the appropriate limits
//
// Called by:   DTSTest_AdvancedControlsSetUpWindow
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_ValidateExperimentNumberValue(
    Object          ^sender,
    CancelEventArgs ^evt)
{
    bool            revertToOriginalValue = GUI_NO;
    DWORD           newValue;
    String          ^functionName = _T("DTSTest_ValidateExperimentNumberValue");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0} called", functionName);
    if (StringSet(advancedExperimentNumberBox->Text))
    {
        bool isCorrectFormat = DTSTest_ParseAndConvertStringToUnsigned(
            advancedExperimentNumberBox->Text,
            &newValue);
        if (isCorrectFormat)
        {
            if ((newValue < GUI_MINIMUM_EXPERIMENT_NUMBER) ||
                (newValue > GUI_MAXIMUM_EXPERIMENT_NUMBER))
            {
                DTSTest_PromptOKModal(
                    "Invalid Experiment Number",
                    "Valid values are {0:D} through {1:D}, inclusive",
                    GUI_MINIMUM_EXPERIMENT_NUMBER,
                    GUI_MAXIMUM_EXPERIMENT_NUMBER);
                RecordErrorEvent(
                    "    Attempted to set experiment number to '{0:D}'",
                    newValue);
                revertToOriginalValue = GUI_YES;
            }
            else
            {
                if (newValue != DTSTest_CurrentExperimentNumber)
                {
                    RecordBasicEvent(
                        "    The Experiment Number changed from {0:D} to {1:D} ms",
                        DTSTest_CurrentExperimentNumber,
                        newValue);
                    DTSTest_CurrentExperimentNumber = newValue;
                }
                evt->Cancel = GUI_NO;
                RecordBasicEvent("{0} concluded: Accept {1:X2}",
                    functionName, DTSTest_CurrentExperimentNumber);
                return;
            }
        }                               // end of if (isCorrectFormat)
        else
        {
            DTSTest_PromptOKModal(
                "Invalid Characters",
                "The entry contains invalid characters;\n"
                "enter only decimal digits");
            RecordErrorEvent(
                "    Attempted setting the experimental value to '{0}'",
                advancedExperimentNumberBox->Text);
            revertToOriginalValue = GUI_YES;
        }
    }                                   // end of if (StringSet(advancedExperimentNumberBox->Text))
    else
    {
        revertToOriginalValue = GUI_YES;
    }
    if (revertToOriginalValue)
    {
        advancedExperimentNumberBox->Text = String::Concat(DTSTest_CurrentExperimentNumber);
    }
    evt->Cancel = GUI_YES;
    RecordBasicEvent("{0} concluded: Cancel", functionName);
}                                       // end of DTSTest_ValidateExperimentNumberValue()
//----------------------------------------------------------------------------
// DTSTest_ValidateHomeDieSerialNumberAddress
//
// Handles changes of the home Die Serial Number box
//
// Called by:   DTSTest_InstallHomeWindowGraphics
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_ValidateHomeDieSerialNumberAddress(
    Object          ^sender,
    CancelEventArgs ^evt)
{
    String          ^functionName = _T("DTSTest_ValidateHomeDieSerialNumberAddress");
    //------------------------------------------------------------------------
    if (StringSet(homeDieSerialNumberBox->Text))
    {
        DTSTest_GeneralInfo->dieSerialNumber =
            homeDieSerialNumberBox->Text;
        RecordBasicEvent(
            "Die Serial Number set as {0}",
            DTSTest_GeneralInfo->dieSerialNumber);
    }
    else
    {
        DTSTest_GeneralInfo->dieSerialNumber = String::Empty;
        homeDieSerialNumberBox->Text = DTSTest_GeneralInfo->dieSerialNumber;
    }
    evt->Cancel = GUI_NO;
}                                       // end of DTSTest_ValidateHomeDieSerialNumberAddress()
//----------------------------------------------------------------------------
// DTSTest_ValidateHomeOperatorNameAddress
//
// Handles changes of the home Operator Name box
//
// Called by:   DTSTest_InstallHomeWindowGraphics
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_ValidateHomeOperatorNameAddress(
    Object          ^sender,
    CancelEventArgs ^evt)
{
    String          ^functionName = _T("DTSTest_ValidateHomeOperatorNameAddress");
    //------------------------------------------------------------------------
    if (StringSet(homeOperatorNameBox->Text))
    {
        DTSTest_GeneralInfo->operatorName =
            homeOperatorNameBox->Text;
        RecordBasicEvent(
            "Operator Name set as {0}",
            DTSTest_GeneralInfo->operatorName);
    }
    else
    {
        DTSTest_GeneralInfo->operatorName = Environment::UserName;
        homeOperatorNameBox->Text = DTSTest_GeneralInfo->operatorName;
    }
    evt->Cancel = GUI_NO;
}                                       // end of DTSTest_ValidateHomeOperatorNameAddress()
//----------------------------------------------------------------------------
// DTSTest_ValidateHomePlaceholderValue
//
// Handles changes of the home Placeholder Value boxes
//
// Called by:   DTSTest_InstallHomeWindowGraphics
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_ValidateHomePlaceholderValue(
    Object          ^sender,
    CancelEventArgs ^evt)
{
    bool            revertToOriginalValue = GUI_NO;
    int             index = (int) (dynamic_cast <TextBox ^> (sender))->Tag;
    BYTE            newValue = 0;
    String          ^placeholderString = String::Empty;
    BYTE            placeholderValue = 0;
    String          ^valueString = String::Empty;
    String          ^functionName = _T("DTSTest_ValidateHomePlaceholderValue");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0} called", functionName);
    if ((index == 1) || (index == 2))
    {
        if (index == 1)
        {
            valueString = homePlaceholder1Box->Text;
            placeholderString = DTSTest_GeneralInfo->mainScript->placeholder1String;
            placeholderValue = DTSTest_GeneralInfo->mainScript->placeholder1Value;
        }
        else
        {
            valueString = homePlaceholder2Box->Text;
            placeholderString = DTSTest_GeneralInfo->mainScript->placeholder2String;
            placeholderValue = DTSTest_GeneralInfo->mainScript->placeholder2Value;
        }
        if (StringSet(valueString) && (valueString->Length < 3))
        {
            bool isCorrectFormat = DTSTest_ParseAndConvertHexStringToByte(
                valueString,
                &newValue);
            if (isCorrectFormat)
            {
                valueString = String::Format("{0:X2}", newValue);
                if (newValue > 254)
                {
                    DTSTest_PromptOKModal(
                        "Invalid MODBUS Address",
                        "Valid values are 01 through FE, inclusive");
                    RecordErrorEvent(
                        "    Attempted to set script placeholder ${0:D} MODBUS address to '{1:X2}'",
                        index, newValue);
                    revertToOriginalValue = GUI_YES;
                }
                else
                {
                    if (newValue != placeholderValue)
                    {
                        RecordBasicEvent(
                            "    The script placeholder ${0:D} MODBUS address changed from {1:X2} to {2:X2}",
                            index, placeholderValue, newValue);
                        placeholderValue = newValue;
                        if (index == 1)
                        {
                            DTSTest_GeneralInfo->mainScript->placeholder1Value = newValue;
                            DTSTest_GeneralInfo->mainScript->placeholder1String = valueString;
                        }
                        else
                        {
                            DTSTest_GeneralInfo->mainScript->placeholder2Value = newValue;
                            DTSTest_GeneralInfo->mainScript->placeholder2String = valueString;
                        }
                        if (placeholderValue)
                        {
                            if (index == 1)
                                homePlaceholder1Box->Text = String::Format(
                                    "{0:X2}", placeholderValue);
                            else
                                homePlaceholder2Box->Text = String::Format(
                                    "{0:X2}", placeholderValue);
                            PDGICInfo ^pgInfo = DTSTest_GeneralInfo->pgInfo;
                            SensorInfo ^sensor = pgInfo->sensorInfoArray[newValue];
                            DWORD status = DTSTest_SensorRetrieveBargeInformation(sensor);
                            if (status == DTSTEST_SUCCESS)
                            {
    //                            if (DTSTest_ScriptAutoLoadCoefficientData)
                                {
    ///                                BYTE *coefficientData = (LPBYTE) sensor->coefficientInfo->coefficientData;
    //                                memcpy_s(
    //                                    (void *) coefficientData,
    //                                    sizeof(CoefficientDataFormat),
    //                                    (void *) DTSTest_GeneralInfo->defaultCoefficientInfo->coefficientData,
    //                                    sizeof(CoefficientDataFormat));
    //                                sensor->coefficientInfo->coefficientDataLoaded = GUI_YES;
    //                                RecordBasicEvent("    Coefficient data for user sensor {0:X2} loaded",
    //                                    sensor->nodeAddress);
                                    status = DTSTest_SensorCalibrateReadings(sensor);
                                    if (status == DTSTEST_SUCCESS)
                                    {
    //                                    placeholder->coefficientDataLoaded = GUI_YES;
    //                                    sensor->pressurePSIBias = DTSTest_CalculatePressureBias(sensor->currentPressurePSI);
    //                                    sensor->currentPressurePSI = sensor->pressurePSIBias + sensor->pressurePSIBias;
    //                                    sensor->temperatureCelsiusBias = DTSTest_CalculateTemperatureBias(sensor->currentTemperatureCelsius);
    //                                    sensor->currentTemperatureCelsius = sensor->temperatureCelsiusBias + sensor->temperatureCelsiusBias;
    //                                    RecordVerboseEvent("    Sensor {0:X2} returned {1:F3} psi / {2:F3} �C",
    //                                        sensor->nodeAddress,
    //                                        sensor->currentPressurePSI,
    //                                        sensor->currentTemperatureCelsius);
                                    }
    //                                placeholder->placeholderButton->Text = _T("Erase Coefficient Data");
                                }       // end of if (DTSTest_ScriptAutoLoadCoefficientData)
    //                            placeholder->placeholderButton->Enabled = GUI_YES;
                            }           // end of if (status == DTSTEST_SUCCESS)
                        }               // end of if (placeholder->placeholderValue)
                    }                   // end of if (newValue != placeholder->placeholderValue)
                    evt->Cancel = GUI_NO;
                    RecordBasicEvent("{0} concluded: Accept {1:X2}",
                        functionName, newValue);
                    return;
                }                       // end of else of if (newValue > 254)
            }                           // end of if (isCorrectFormat)
            else
            {
                DTSTest_PromptOKModal(
                    "Invalid Characters",
                    "The entry contains invalid characters;\n"
                    "enter only hex digits");
                RecordErrorEvent(
                    "    Attempted to set script placeholder ${0:D} MODBUS address to '{1}'",
                    index, valueString);
                revertToOriginalValue = GUI_YES;
            }
        }                               // end of if (StringSet(valueString) && (valueString->Length < 3))
        else
        {
            revertToOriginalValue = GUI_YES;
        }
        if (revertToOriginalValue)
        {
            if (index == 1)
                homePlaceholder1Box->Text = String::Format(
                    "{0:X2}", placeholderValue);
            else
                homePlaceholder2Box->Text = String::Format(
                    "{0:X2}", placeholderValue);
        }
    }                                   // end of if ((index == 1) || (index == 2))
    evt->Cancel = GUI_YES;
    RecordBasicEvent("{0} concluded: Cancel", functionName);
}                                       // end of DTSTest_ValidateHomePlaceholderValue()
//----------------------------------------------------------------------------
// DTSTest_ValidateTextMessageNumbers
//
// Handles changes of the Send Text Message To and CC fields; ensures that the
// field format meets the criteria for a proper phone number
//
// Called by:   DTSTest_AdvancedControlsSetUpWindow
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_ValidateTextMessageNumbers(
    Object          ^sender,
    CancelEventArgs ^evt)
{
    String          ^functionName = _T("DTSTest_ValidateTextMessageNumbers");
    //------------------------------------------------------------------------
    if (StringSet(advancedTextMessageToNumberBox->Text))
    {
        advancedTextMessageToNumberBox->Text = DTSTest_CleanUpTextBoxText(
            advancedTextMessageToNumberBox->Text);
        DTSTest_GeneralInfo->textMessageToNumber =
            advancedTextMessageToNumberBox->Text;
        RecordBasicEvent(
            "Text Message To number set as {0}",
            advancedTextMessageToNumberBox->Text);
    }
    else
    {
        DTSTest_GeneralInfo->textMessageToNumber = String::Empty;
    }
    if (StringSet(advancedTextMessageCCNumberBox->Text))
    {
        advancedTextMessageCCNumberBox->Text = DTSTest_CleanUpTextBoxText(
            advancedTextMessageCCNumberBox->Text);
        DTSTest_GeneralInfo->textMessageCCNumber =
            advancedTextMessageCCNumberBox->Text;
        RecordBasicEvent(
            "Text Message CC number set as {0}",
            advancedTextMessageCCNumberBox->Text);
    }
    else
    {
        DTSTest_GeneralInfo->textMessageCCNumber = String::Empty;
    }
    DTSTest_UpdateMessageChecks();
    evt->Cancel = GUI_NO;
}                                       // end of DTSTest_ValidateTextMessageNumbers()
//----------------------------------------------------------------------------
#endif      // EVENTS_CPP
//============================================================================
// End of Events.cpp
//============================================================================
