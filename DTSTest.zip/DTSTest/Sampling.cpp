//============================================================================
// Sampling.cpp
//
// The methods provided for sampling control
//
// Copyright (C) 2014 - 2016 Quartzdyne, Inc.  All rights reserved.
//
// No part of this source code may be reproduced or transmitted in any form or
// by any means, electronic or mechanical, including photocopying, recording,
// or any information storage and retrieval system, without express written
// permission from Quartzdyne, Inc.  Further, no use of this source code is
// permitted in any form or means without a valid, written license agreement
// with Quartzdyne, Inc.  While every reasonable precaution has been taken in
// the preparation of this source code, Quartzdyne, Inc., assumes no
// responsibility for errors, omissions, or damages from the use of the source
// code contained herein.
//
// NEITHER QUARTZDYNE, INC., ANY MEMBER OF QUARTZDYNE, INC., NOR ANY PERSON OR
// ORGANIZATION ACTING ON BEHALF OF THEM MAKES ANY WARRANTY OR REPRESENTATION
// WHATSOEVER, EXPRESS OR IMPLIED, INCLUDING ANY WARRANTY OF MERCHANTABILITY
// OR FITNESS FOR ANY PURPOSE WITH RESPECT TO THE SOURCE CODE OR ASSUMES ANY
// LIABILITY WHATSOEVER WITH RESPECT TO ANY USE OF THE SOURCE CODE OR ANY
// PORTION THEREOF OR WITH RESPECT TO ANY DAMAGES THAT MAY RESULT FROM SUCH
// USE.
//
// Noji Ratzlaff
//
// See DTSTest.log for a complete history of all updates, changes, and revisions
// of this source and other files and policies regarding DTSTest software
//
// Updated 01-14-2016
//============================================================================
#include    "stdafx.h"
#ifndef     SAMPLING_CPP
#define     SAMPLING_CPP
#include    "Sampling.h"
//----------------------------------------------------------------------------
// DTSTest_SamplingBackgroundWorker
//
// Handles the sampling background worker process
//
// Called by:   DTSTest_InitializeGUIComponents
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_SamplingBackgroundWorker(
    Object          ^sender,
    DoWorkEventArgs ^evt)
{
    String          ^functionName = _T("DTSTest_SamplingBackgroundWorker");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0} called", functionName);
    BackgroundWorker ^workerThread = dynamic_cast <BackgroundWorker ^> (sender);
    evt->Result = DTSTest_SamplingRunBackgroundSampleTasks(
        workerThread,
        evt);
    RecordBasicEvent("{0} concluded", functionName);
}                                       // end of DTSTest_SamplingBackgroundWorker()
//----------------------------------------------------------------------------
// DTSTest_SamplingBackgroundWorkerCompleted
//
// Handles the sampling background worker completion process
//
// Called by:   DTSTest_InitializeGUIComponents
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_SamplingBackgroundWorkerCompleted(
    Object          ^sender,
    RunWorkerCompletedEventArgs
                    ^evt)
{
    String          ^functionName = _T("DTSTest_SamplingBackgroundWorkerCompleted");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0} called", functionName);
//    DTSTest_SamplingStopActivities(evt->Cancelled);
    RecordBasicEvent("{0} concluded", functionName);
}                                       // end of DTSTest_SamplingBackgroundWorkerCompleted()
//----------------------------------------------------------------------------
// DTSTest_SamplingBackgroundWorkerUpdateProgress
//
// Handles the sampling background worker update progress process
//
// Called by:   DTSTest_InitializeGUIComponents
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_SamplingBackgroundWorkerUpdateProgress(
    Object          ^sender,
    ProgressChangedEventArgs
                    ^evt)
{
    String          ^functionName = _T("DTSTest_SamplingBackgroundWorkerUpdateProgress");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0} called", functionName);
    RecordBasicEvent("{0} concluded", functionName);
}                                       // end of DTSTest_SamplingBackgroundWorkerUpdateProgress()
//----------------------------------------------------------------------------
// DTSTest_SamplingRunBackgroundSampleTasks
//
// Handles the sampling background worker main tasks
//
// Called by:   DTSTest_SamplingBackgroundWorker
//----------------------------------------------------------------------------
    DWORD DTSTest_GUIClass::
DTSTest_SamplingRunBackgroundSampleTasks(
    BackgroundWorker
                    ^workerThread,
    DoWorkEventArgs ^evt)
{
    DWORD           status = DTSTEST_SUCCESS;
    String          ^functionName = _T("DTSTest_SamplingRunBackgroundSampleTasks");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0} called", functionName);
    if (workerThread->CancellationPending)
    {
        evt->Cancel = GUI_YES;
    }
    else
    {
        DTSTest_SamplingRunning = GUI_YES;
        status = DTSTest_SamplingRunSamplingTasks(workerThread);
        if (status == DTSTEST_ERROR_TEST_CANCELED)                              // 0x000000F8
            evt->Cancel = GUI_YES;
        else
            evt->Cancel = GUI_NO;
    }
    RecordBasicEvent("{0} concluded, returning 0x{1:X8}", functionName, status);
    return status;
}                                       // end of DTSTest_SamplingRunBackgroundSampleTasks()
//----------------------------------------------------------------------------
// DTSTest_SamplingRunSamplingTasks
//
// Samples forever, until flagged to stop
//
// Returns: 0       = Success
//          nonzero = Test Canceled or Failure
//
// Called by:   DTSTest_SamplingRunBackgroundSampleTasks
//----------------------------------------------------------------------------
    DWORD DTSTest_GUIClass::
DTSTest_SamplingRunSamplingTasks(
    BackgroundWorker
                    ^workerThread)
{
//    bool            atLeastOneIsSampling = GUI_NO;
    DWORD           status = DTSTEST_SUCCESS;
//    double          pressureValuePSI = 0.0;
//    double          temperatureValueCelsius = 0.0;
//    SensorInfo      ^sensor = nullptr;
    PDGICInfo       ^pgInfo = DTSTest_GeneralInfo->pgInfo;
    String          ^functionName = _T("DTSTest_SamplingRunSamplingTasks");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0} called", functionName);
    if (pgInfo)
    {
//        while (DTSTest_SamplingRunning)
//        {
//            //----------------------------------------------------------------
//            // Sample gauge 2D
//            //----------------------------------------------------------------
//            if (DTSTest_CurrentlySamplingGauge2D)
//            {
//                atLeastOneIsSampling = GUI_YES;
//                sensor = pgInfo->sensorInfoArray[DTSTEST_EXPERIMENTAL_GAUGE_2D_VALUE];
//                if (sensor->sensorPresent)
//                {
//                    if (sensor->coefficientInfo->coefficientDataLoaded)
//                    {
//                        status = DTSTest_SensorRetrieveMeasurements(sensor);
//                        if (status == DTSTEST_SUCCESS)
//                        {
//                            samplingGauge2DPressureLabel->Text = String::Format(
//                                "{0:F3} psi", sensor->currentPressurePSI);
//                            samplingGauge2DTemperatureLabel->Text = String::Format(
//                                "{0:F3} �C", sensor->currentTemperatureCelsius);
//                        }
//                        else
//                        {
//                            samplingGauge2DPressureLabel->Text = String::Format(
//                                "Error 0x{0:X8}", status);
//                            samplingGauge2DTemperatureLabel->Text = String::Format(
//                                "Error 0x{0:X8}", status);
//                        }
//                        if (DTSTest_RecordSamples)
//                        {
//                            DTSTest_SampleDisplayAndRecord(
//                                pgInfo,
//                                _T("Gauge 2D"),
//                                samplingGauge2DPressureLabel->Text,
//                                samplingGauge2DTemperatureLabel->Text);
//                        }
//                    }                   // end of if (sensor->coefficientInfo->coefficientDataLoaded) [2D]
//                    else
//                    {
//                        samplingGauge2DPressureLabel->Text = _T("Coeff not loaded");
//                        samplingGauge2DTemperatureLabel->Text = _T("Coeff not loaded");
//                    }
//                }                       // end of if (sensor->sensorPresent) [2D]
//            }                           // end of if (DTSTest_CurrentlySamplingGauge2D)
//            //----------------------------------------------------------------
//            // Sample gauge 3E
//            //----------------------------------------------------------------
//            if (DTSTest_CurrentlySamplingGauge3E)
//            {
//                atLeastOneIsSampling = GUI_YES;
//                sensor = pgInfo->sensorInfoArray[DTSTEST_EXPERIMENTAL_GAUGE_3E_VALUE];
//                if (sensor->sensorPresent)
//                {
//                    if (sensor->coefficientInfo->coefficientDataLoaded)
//                    {
//                        status = DTSTest_SensorRetrieveMeasurements(sensor);
//                        if (status == DTSTEST_SUCCESS)
//                        {
//                            samplingGauge3EPressureLabel->Text = String::Format(
//                                "{0:F3} psi", sensor->currentPressurePSI);
//                            samplingGauge3ETemperatureLabel->Text = String::Format(
//                                "{0:F3} �C", sensor->currentTemperatureCelsius);
//                        }
//                        else
//                        {
//                            samplingGauge3EPressureLabel->Text = String::Format(
//                                "Error 0x{0:X8}", status);
//                            samplingGauge3ETemperatureLabel->Text = String::Format(
//                                "Error 0x{0:X8}", status);
//                        }
//                        if (DTSTest_RecordSamples)
//                        {
//                            DTSTest_SampleDisplayAndRecord(
//                                pgInfo,
//                                _T("Gauge 3E"),
//                                samplingGauge3EPressureLabel->Text,
//                                samplingGauge3ETemperatureLabel->Text);
//                        }
//                    }                   // end of if (sensor->coefficientInfo->coefficientDataLoaded) [3E]
//                    else
//                    {
//                        samplingGauge3EPressureLabel->Text = _T("Coeff not loaded");
//                        samplingGauge3ETemperatureLabel->Text = _T("Coeff not loaded");
//                    }
//                }                       // end of if (sensor->sensorPresent) [3E]
//            }                           // end of if (DTSTest_CurrentlySamplingGauge3E)
//            //----------------------------------------------------------------
//            // Sample barge B4
//            //----------------------------------------------------------------
//            if (DTSTest_CurrentlySamplingBargeB4)
//            {
//                atLeastOneIsSampling = GUI_YES;
//                sensor = pgInfo->sensorInfoArray[DTSTEST_EXPERIMENTAL_BARGE_B4_VALUE];
//                if (sensor->sensorPresent)
//                {
//                    if (sensor->coefficientInfo->coefficientDataLoaded)
//                    {
//                        status = DTSTest_SensorRetrieveMeasurements(sensor);
//                        if (status == DTSTEST_SUCCESS)
//                        {
//                            samplingBargeB4PressureLabel->Text = String::Format(
//                                "{0:F3} psi", sensor->currentPressurePSI);
//                            samplingBargeB4TemperatureLabel->Text = String::Format(
//                                "{0:F3} �C", sensor->currentTemperatureCelsius);
//                        }
//                        else
//                        {
//                            samplingBargeB4PressureLabel->Text = String::Format(
//                                "Error 0x{0:X8}", status);
//                            samplingBargeB4TemperatureLabel->Text = String::Format(
//                                "Error 0x{0:X8}", status);
//                        }
//                        if (DTSTest_RecordSamples)
//                        {
//                            DTSTest_SampleDisplayAndRecord(
//                                pgInfo,
//                                _T("Barge B4"),
//                                samplingBargeB4PressureLabel->Text,
//                                samplingBargeB4TemperatureLabel->Text);
//                        }
//                    }                   // end of if (sensor->coefficientInfo->coefficientDataLoaded) [B4]
//                    else
//                    {
//                        samplingBargeB4PressureLabel->Text = _T("Coeff not loaded");
//                        samplingBargeB4TemperatureLabel->Text = _T("Coeff not loaded");
//                    }
//                }                       // end of if (sensor->sensorPresent) [B4]
//            }                           // end of if (DTSTest_CurrentlySamplingBargeB4)
//            //----------------------------------------------------------------
//            // Sample barge C9
//            //----------------------------------------------------------------
//            if (DTSTest_CurrentlySamplingBargeC9)
//            {
//                atLeastOneIsSampling = GUI_YES;
//                sensor = pgInfo->sensorInfoArray[DTSTEST_EXPERIMENTAL_BARGE_C9_VALUE];
//                if (sensor->sensorPresent)
//                {
//                    if (sensor->coefficientInfo->coefficientDataLoaded)
//                    {
//                        status = DTSTest_SensorRetrieveMeasurements(sensor);
//                        if (status == DTSTEST_SUCCESS)
//                        {
//                            samplingBargeC9PressureLabel->Text = String::Format(
//                                "{0:F3} psi", sensor->currentPressurePSI);
//                            samplingBargeC9TemperatureLabel->Text = String::Format(
//                                "{0:F3} �C", sensor->currentTemperatureCelsius);
//                        }
//                        else
//                        {
//                            samplingBargeC9PressureLabel->Text = String::Format(
//                                "Error 0x{0:X8}", status);
//                            samplingBargeC9TemperatureLabel->Text = String::Format(
//                                "Error 0x{0:X8}", status);
//                        }
//                        if (DTSTest_RecordSamples)
//                        {
//                            DTSTest_SampleDisplayAndRecord(
//                                pgInfo,
//                                _T("Barge C9"),
//                                samplingBargeC9PressureLabel->Text,
//                                samplingBargeC9TemperatureLabel->Text);
//                        }
//                    }                   // end of if (sensor->coefficientInfo->coefficientDataLoaded) [C9]
//                    else
//                    {
//                        samplingBargeC9PressureLabel->Text = _T("Coeff not loaded");
//                        samplingBargeC9TemperatureLabel->Text = _T("Coeff not loaded");
//                    }
//                }                       // end of if (sensor->sensorPresent) [C9]
//            }                           // end of if (DTSTest_CurrentlySamplingBargeC9)
//            //----------------------------------------------------------------
//            // Sample barge E2
//            //----------------------------------------------------------------
//            if (DTSTest_CurrentlySamplingBargeE2)
//            {
//                atLeastOneIsSampling = GUI_YES;
//                sensor = pgInfo->sensorInfoArray[DTSTEST_EXPERIMENTAL_BARGE_E2_VALUE];
//                if (sensor->sensorPresent)
//                {
//                    if (sensor->coefficientInfo->coefficientDataLoaded)
//                    {
//                        status = DTSTest_SensorRetrieveMeasurements(sensor);
//                        if (status == DTSTEST_SUCCESS)
//                        {
//                            samplingBargeE2PressureLabel->Text = String::Format(
//                                "{0:F3} psi", sensor->currentPressurePSI);
//                            samplingBargeE2TemperatureLabel->Text = String::Format(
//                                "{0:F3} �C", sensor->currentTemperatureCelsius);
//                        }
//                        else
//                        {
//                            samplingBargeE2PressureLabel->Text = String::Format(
//                                "Error 0x{0:X8}", status);
//                            samplingBargeE2TemperatureLabel->Text = String::Format(
//                                "Error 0x{0:X8}", status);
//                        }
//                        if (DTSTest_RecordSamples)
//                        {
//                            DTSTest_SampleDisplayAndRecord(
//                                pgInfo,
//                                _T("Barge E2"),
//                                samplingBargeE2PressureLabel->Text,
//                                samplingBargeE2TemperatureLabel->Text);
//                        }
//                    }                   // end of if (sensor->coefficientInfo->coefficientDataLoaded) [E2]
//                    else
//                    {
//                        samplingBargeE2PressureLabel->Text = _T("Coeff not loaded");
//                        samplingBargeE2TemperatureLabel->Text = _T("Coeff not loaded");
//                    }
//                }                       // end of if (sensor->sensorPresent) [E2]
//            }                           // end of if (DTSTest_CurrentlySamplingBargeE2)
//            //----------------------------------------------------------------
//            // Sample barge 02
//            //----------------------------------------------------------------
//            if (DTSTest_CurrentlySamplingBarge02)
//            {
//                atLeastOneIsSampling = GUI_YES;
//                sensor = pgInfo->sensorInfoArray[DTSTEST_EXPERIMENTAL_BARGE_02_VALUE];
//                if (sensor->sensorPresent)
//                {
//                    if (sensor->coefficientInfo->coefficientDataLoaded)
//                    {
//                        status = DTSTest_SensorRetrieveMeasurements(sensor);
//                        if (status == DTSTEST_SUCCESS)
//                        {
//                            samplingBarge02PressureLabel->Text = String::Format(
//                                "{0:F3} psi", sensor->currentPressurePSI);
//                            samplingBarge02TemperatureLabel->Text = String::Format(
//                                "{0:F3} �C", sensor->currentTemperatureCelsius);
//                        }
//                        else
//                        {
//                            samplingBarge02PressureLabel->Text = String::Format(
//                                "Error 0x{0:X8}", status);
//                            samplingBarge02TemperatureLabel->Text = String::Format(
//                                "Error 0x{0:X8}", status);
//                        }
//                        if (DTSTest_RecordSamples)
//                        {
//                            DTSTest_SampleDisplayAndRecord(
//                                pgInfo,
//                                _T("Barge 02"),
//                                samplingBarge02PressureLabel->Text,
//                                samplingBarge02TemperatureLabel->Text);
//                        }
//                    }                   // end of if (sensor->coefficientInfo->coefficientDataLoaded) [02]
//                    else
//                    {
//                        samplingBarge02PressureLabel->Text = _T("Coeff not loaded");
//                        samplingBarge02TemperatureLabel->Text = _T("Coeff not loaded");
//                    }
//                }                       // end of if (sensor->sensorPresent) [02]
//            }                           // end of if (DTSTest_CurrentlySamplingBarge02)
//            //----------------------------------------------------------------
//            // Sample user gauge 1
//            //----------------------------------------------------------------
//            if (DTSTest_CurrentlySamplingUserGauge1)
//            {
//                atLeastOneIsSampling = GUI_YES;
//                sensor = pgInfo->sensorInfoArray[pgInfo->userGaugeNodeAddress1];
//                if (sensor->sensorPresent)
//                {
//                    if (sensor->coefficientInfo->coefficientDataLoaded)
//                    {
//                        status = DTSTest_SensorRetrieveMeasurements(sensor);
//                        if (status == DTSTEST_SUCCESS)
//                        {
//                            samplingUserGauge1PressureLabel->Text = String::Format(
//                                "{0:F3} psi", sensor->currentPressurePSI);
//                            samplingUserGauge1TemperatureLabel->Text = String::Format(
//                                "{0:F3} �C", sensor->currentTemperatureCelsius);
//                        }
//                        else
//                        {
//                            samplingUserGauge1PressureLabel->Text = String::Format(
//                                "Error 0x{0:X8}", status);
//                            samplingUserGauge1TemperatureLabel->Text = String::Format(
//                                "Error 0x{0:X8}", status);
//                        }
//                        if (DTSTest_RecordSamples)
//                        {
//                            DTSTest_SampleDisplayAndRecord(
//                                pgInfo,
//                                _T("User Gauge 1"),
//                                samplingUserGauge1PressureLabel->Text,
//                                samplingUserGauge1TemperatureLabel->Text);
//                        }
//                    }                   // end of if (sensor->coefficientInfo->coefficientDataLoaded) [UG1]
//                    else
//                    {
//                        samplingUserGauge1PressureLabel->Text = _T("Coeff not loaded");
//                        samplingUserGauge1TemperatureLabel->Text = _T("Coeff not loaded");
//                    }
//                }                       // end of if (sensor->sensorPresent) [UG1]
//            }                           // end of if (DTSTest_CurrentlySamplingUserGauge1)
//            //----------------------------------------------------------------
//            // Sample user gauge 2
//            //----------------------------------------------------------------
//            if (DTSTest_CurrentlySamplingUserGauge2)
//            {
//                atLeastOneIsSampling = GUI_YES;
//                sensor = pgInfo->sensorInfoArray[pgInfo->userGaugeNodeAddress2];
//                if (sensor->sensorPresent)
//                {
//                    if (sensor->coefficientInfo->coefficientDataLoaded)
//                    {
//                        status = DTSTest_SensorRetrieveMeasurements(sensor);
//                        if (status == DTSTEST_SUCCESS)
//                        {
//                            samplingUserGauge2PressureLabel->Text = String::Format(
//                                "{0:F3} psi", sensor->currentPressurePSI);
//                            samplingUserGauge2TemperatureLabel->Text = String::Format(
//                                "{0:F3} �C", sensor->currentTemperatureCelsius);
//                        }
//                        else
//                        {
//                            samplingUserGauge2PressureLabel->Text = String::Format(
//                                "Error 0x{0:X8}", status);
//                            samplingUserGauge2TemperatureLabel->Text = String::Format(
//                                "Error 0x{0:X8}", status);
//                        }
//                        if (DTSTest_RecordSamples)
//                        {
//                            DTSTest_SampleDisplayAndRecord(
//                                pgInfo,
//                                _T("User Gauge 2"),
//                                samplingUserGauge2PressureLabel->Text,
//                                samplingUserGauge2TemperatureLabel->Text);
//                        }
//                    }                   // end of if (sensor->coefficientInfo->coefficientDataLoaded) [UG2]
//                    else
//                    {
//                        samplingUserGauge2PressureLabel->Text = _T("Coeff not loaded");
//                        samplingUserGauge2TemperatureLabel->Text = _T("Coeff not loaded");
//                    }
//                }                       // end of if (sensor->sensorPresent) [UG2]
//            }                           // end of if (DTSTest_CurrentlySamplingUserGauge2)
//            //----------------------------------------------------------------
//            // Sample user gauge 3
//            //----------------------------------------------------------------
//            if (DTSTest_CurrentlySamplingUserGauge3)
//            {
//                atLeastOneIsSampling = GUI_YES;
//                sensor = pgInfo->sensorInfoArray[pgInfo->userGaugeNodeAddress3];
//                if (sensor->sensorPresent)
//                {
//                    if (sensor->coefficientInfo->coefficientDataLoaded)
//                    {
//                        status = DTSTest_SensorRetrieveMeasurements(sensor);
//                        if (status == DTSTEST_SUCCESS)
//                        {
//                            samplingUserGauge3PressureLabel->Text = String::Format(
//                                "{0:F3} psi", sensor->currentPressurePSI);
//                            samplingUserGauge3TemperatureLabel->Text = String::Format(
//                                "{0:F3} �C", sensor->currentTemperatureCelsius);
//                        }
//                        else
//                        {
//                            samplingUserGauge3PressureLabel->Text = String::Format(
//                                "Error 0x{0:X8}", status);
//                            samplingUserGauge3TemperatureLabel->Text = String::Format(
//                                "Error 0x{0:X8}", status);
//                        }
//                        if (DTSTest_RecordSamples)
//                        {
//                            DTSTest_SampleDisplayAndRecord(
//                                pgInfo,
//                                _T("User Gauge 3"),
//                                samplingUserGauge3PressureLabel->Text,
//                                samplingUserGauge3TemperatureLabel->Text);
//                        }
//                    }                   // end of if (sensor->coefficientInfo->coefficientDataLoaded) [UG3]
//                    else
//                    {
//                        samplingUserGauge3PressureLabel->Text = _T("Coeff not loaded");
//                        samplingUserGauge3TemperatureLabel->Text = _T("Coeff not loaded");
//                    }
//                }                       // end of if (sensor->sensorPresent) [UG3]
//            }                           // end of if (DTSTest_CurrentlySamplingUserGauge3)
//            //----------------------------------------------------------------
//            // Sample user barge 1
//            //----------------------------------------------------------------
//            if (DTSTest_CurrentlySamplingUserBarge1)
//            {
//                atLeastOneIsSampling = GUI_YES;
//                sensor = pgInfo->sensorInfoArray[pgInfo->userBargeNodeAddress1];
//                if (sensor->sensorPresent)
//                {
//                    if (sensor->coefficientInfo->coefficientDataLoaded)
//                    {
//                        status = DTSTest_SensorRetrieveMeasurements(sensor);
//                        if (status == DTSTEST_SUCCESS)
//                        {
//                            samplingUserBarge1PressureLabel->Text = String::Format(
//                                "{0:F3} psi", sensor->currentPressurePSI);
//                            samplingUserBarge1TemperatureLabel->Text = String::Format(
//                                "{0:F3} �C", sensor->currentTemperatureCelsius);
//                        }
//                        else
//                        {
//                            samplingUserBarge1PressureLabel->Text = String::Format(
//                                "Error 0x{0:X8}", status);
//                            samplingUserBarge1TemperatureLabel->Text = String::Format(
//                                "Error 0x{0:X8}", status);
//                        }
//                        if (DTSTest_RecordSamples)
//                        {
//                            DTSTest_SampleDisplayAndRecord(
//                                pgInfo,
//                                _T("User Barge 1"),
//                                samplingUserBarge1PressureLabel->Text,
//                                samplingUserBarge1TemperatureLabel->Text);
//                        }
//                    }                   // end of if (sensor->coefficientInfo->coefficientDataLoaded) [UB1]
//                    else
//                    {
//                        samplingUserBarge1PressureLabel->Text = _T("Coeff not loaded");
//                        samplingUserBarge1TemperatureLabel->Text = _T("Coeff not loaded");
//                    }
//                }                       // end of if (sensor->sensorPresent) [UB1]
//            }                           // end of if (DTSTest_CurrentlySamplingUserBarge1)
//            //----------------------------------------------------------------
//            // Sample user barge 2
//            //----------------------------------------------------------------
//            if (DTSTest_CurrentlySamplingUserBarge2)
//            {
//                atLeastOneIsSampling = GUI_YES;
//                sensor = pgInfo->sensorInfoArray[pgInfo->userBargeNodeAddress2];
//                if (sensor->sensorPresent)
//                {
//                    if (sensor->coefficientInfo->coefficientDataLoaded)
//                    {
//                        status = DTSTest_SensorRetrieveMeasurements(sensor);
//                        if (status == DTSTEST_SUCCESS)
//                        {
//                            samplingUserBarge2PressureLabel->Text = String::Format(
//                                "{0:F3} psi", sensor->currentPressurePSI);
//                            samplingUserBarge2TemperatureLabel->Text = String::Format(
//                                "{0:F3} �C", sensor->currentTemperatureCelsius);
//                        }
//                        else
//                        {
//                            samplingUserBarge2PressureLabel->Text = String::Format(
//                                "Error 0x{0:X8}", status);
//                            samplingUserBarge2TemperatureLabel->Text = String::Format(
//                                "Error 0x{0:X8}", status);
//                        }
//                        if (DTSTest_RecordSamples)
//                        {
//                            DTSTest_SampleDisplayAndRecord(
//                                pgInfo,
//                                _T("User Barge 2"),
//                                samplingUserBarge2PressureLabel->Text,
//                                samplingUserBarge2TemperatureLabel->Text);
//                        }
//                    }                   // end of if (sensor->coefficientInfo->coefficientDataLoaded) [UB2]
//                    else
//                    {
//                        samplingUserBarge2PressureLabel->Text = _T("Coeff not loaded");
//                        samplingUserBarge2TemperatureLabel->Text = _T("Coeff not loaded");
//                    }
//                }                       // end of if (sensor->sensorPresent) [UB2]
//            }                           // end of if (DTSTest_CurrentlySamplingUserBarge2)
//            //----------------------------------------------------------------
//            // Sample user barge 3
//            //----------------------------------------------------------------
//            if (DTSTest_CurrentlySamplingUserBarge3)
//            {
//                atLeastOneIsSampling = GUI_YES;
//                sensor = pgInfo->sensorInfoArray[pgInfo->userBargeNodeAddress3];
//                if (sensor->sensorPresent)
//                {
//                    if (sensor->coefficientInfo->coefficientDataLoaded)
//                    {
//                        status = DTSTest_SensorRetrieveMeasurements(sensor);
//                        if (status == DTSTEST_SUCCESS)
//                        {
//                            samplingUserBarge3PressureLabel->Text = String::Format(
//                                "{0:F3} psi", sensor->currentPressurePSI);
//                            samplingUserBarge3TemperatureLabel->Text = String::Format(
//                                "{0:F3} �C", sensor->currentTemperatureCelsius);
//                        }
//                        else
//                        {
//                            samplingUserBarge3PressureLabel->Text = String::Format(
//                                "Error 0x{0:X8}", status);
//                            samplingUserBarge3TemperatureLabel->Text = String::Format(
//                                "Error 0x{0:X8}", status);
//                        }
//                        if (DTSTest_RecordSamples)
//                        {
//                            DTSTest_SampleDisplayAndRecord(
//                                pgInfo,
//                                _T("User Barge 3"),
//                                samplingUserBarge3PressureLabel->Text,
//                                samplingUserBarge3TemperatureLabel->Text);
//                        }
//                    }                   // end of if (sensor->coefficientInfo->coefficientDataLoaded) [UB3]
//                    else
//                    {
//                        samplingUserBarge3PressureLabel->Text = _T("Coeff not loaded");
//                        samplingUserBarge3TemperatureLabel->Text = _T("Coeff not loaded");
//                    }
//                }                       // end of if (sensor->sensorPresent) [UB3]
//            }                           // end of if (DTSTest_CurrentlySamplingUserBarge3)
//            //----------------------------------------------------------------
//            // Sample user barge 4
//            //----------------------------------------------------------------
//            if (DTSTest_CurrentlySamplingUserBarge4)
//            {
//                atLeastOneIsSampling = GUI_YES;
//                sensor = pgInfo->sensorInfoArray[pgInfo->userBargeNodeAddress4];
//                if (sensor->sensorPresent)
//                {
//                    if (sensor->coefficientInfo->coefficientDataLoaded)
//                    {
//                        status = DTSTest_SensorRetrieveMeasurements(sensor);
//                        if (status == DTSTEST_SUCCESS)
//                        {
//                            samplingUserBarge4PressureLabel->Text = String::Format(
//                                "{0:F3} psi", sensor->currentPressurePSI);
//                            samplingUserBarge4TemperatureLabel->Text = String::Format(
//                                "{0:F3} �C", sensor->currentTemperatureCelsius);
//                        }
//                        else
//                        {
//                            samplingUserBarge4PressureLabel->Text = String::Format(
//                                "Error 0x{0:X8}", status);
//                            samplingUserBarge4TemperatureLabel->Text = String::Format(
//                                "Error 0x{0:X8}", status);
//                        }
//                        if (DTSTest_RecordSamples)
//                        {
//                            DTSTest_SampleDisplayAndRecord(
//                                pgInfo,
//                                _T("User Barge 4"),
//                                samplingUserBarge4PressureLabel->Text,
//                                samplingUserBarge4TemperatureLabel->Text);
//                        }
//                    }                   // end of if (sensor->coefficientInfo->coefficientDataLoaded) [UB4]
//                    else
//                    {
//                        samplingUserBarge4PressureLabel->Text = _T("Coeff not loaded");
//                        samplingUserBarge4TemperatureLabel->Text = _T("Coeff not loaded");
//                    }
//                }                       // end of if (sensor->sensorPresent) [UB4]
//            }                           // end of if (DTSTest_CurrentlySamplingUserBarge4)
//            //----------------------------------------------------------------
//            // Sample user barge 5
//            //----------------------------------------------------------------
//            if (DTSTest_CurrentlySamplingUserBarge5)
//            {
//                atLeastOneIsSampling = GUI_YES;
//                sensor = pgInfo->sensorInfoArray[pgInfo->userBargeNodeAddress5];
//                if (sensor->sensorPresent)
//                {
//                    if (sensor->coefficientInfo->coefficientDataLoaded)
//                    {
//                        status = DTSTest_SensorRetrieveMeasurements(sensor);
//                        if (status == DTSTEST_SUCCESS)
//                        {
//                            samplingUserBarge5PressureLabel->Text = String::Format(
//                                "{0:F3} psi", sensor->currentPressurePSI);
//                            samplingUserBarge5TemperatureLabel->Text = String::Format(
//                                "{0:F3} �C", sensor->currentTemperatureCelsius);
//                        }
//                        else
//                        {
//                            samplingUserBarge5PressureLabel->Text = String::Format(
//                                "Error 0x{0:X8}", status);
//                            samplingUserBarge5TemperatureLabel->Text = String::Format(
//                                "Error 0x{0:X8}", status);
//                        }
//                        if (DTSTest_RecordSamples)
//                        {
//                            DTSTest_SampleDisplayAndRecord(
//                                pgInfo,
//                                _T("User Barge 5"),
//                                samplingUserBarge5PressureLabel->Text,
//                                samplingUserBarge5TemperatureLabel->Text);
//                        }
//                    }                   // end of if (sensor->coefficientInfo->coefficientDataLoaded) [UB5]
//                    else
//                    {
//                        samplingUserBarge5PressureLabel->Text = _T("Coeff not loaded");
//                        samplingUserBarge5TemperatureLabel->Text = _T("Coeff not loaded");
//                    }
//                }                       // end of if (sensor->sensorPresent) [UB5]
//            }                           // end of if (DTSTest_CurrentlySamplingUserBarge5)
//            //----------------------------------------------------------------
//            // Sample user barge 6
//            //----------------------------------------------------------------
//            if (DTSTest_CurrentlySamplingUserBarge6)
//            {
//                atLeastOneIsSampling = GUI_YES;
//                sensor = pgInfo->sensorInfoArray[pgInfo->userBargeNodeAddress6];
//                if (sensor->sensorPresent)
//                {
//                    if (sensor->coefficientInfo->coefficientDataLoaded)
//                    {
//                        status = DTSTest_SensorRetrieveMeasurements(sensor);
//                        if (status == DTSTEST_SUCCESS)
//                        {
//                            samplingUserBarge6PressureLabel->Text = String::Format(
//                                "{0:F3} psi", sensor->currentPressurePSI);
//                            samplingUserBarge6TemperatureLabel->Text = String::Format(
//                                "{0:F3} �C", sensor->currentTemperatureCelsius);
//                        }
//                        else
//                        {
//                            samplingUserBarge6PressureLabel->Text = String::Format(
//                                "Error 0x{0:X8}", status);
//                            samplingUserBarge6TemperatureLabel->Text = String::Format(
//                                "Error 0x{0:X8}", status);
//                        }
//                        if (DTSTest_RecordSamples)
//                        {
//                            DTSTest_SampleDisplayAndRecord(
//                                pgInfo,
//                                _T("User Barge 6"),
//                                samplingUserBarge6PressureLabel->Text,
//                                samplingUserBarge6TemperatureLabel->Text);
//                        }
//                    }                   // end of if (sensor->coefficientInfo->coefficientDataLoaded) [UB6]
//                    else
//                    {
//                        samplingUserBarge1PressureLabel->Text = _T("Coeff not loaded");
//                        samplingUserBarge6TemperatureLabel->Text = _T("Coeff not loaded");
//                    }
//                }                       // end of if (sensor->sensorPresent) [UB6]
//            }                           // end of if (DTSTest_CurrentlySamplingUserBarge6)
//        }                               // end of while (DTSTest_SamplingRunning)
    }                                   // end of if (pgInfo)
    RecordBasicEvent("{0} concluded, returning 0x{1:X8}", functionName, status);
    return status;
}                                       // end of DTSTest_SamplingRunSamplingTasks()
//----------------------------------------------------------------------------
// DTSTest_SampleDisplayAndRecord
//
// Displays the specified result line, along with other pertinent data, then
// stores the same line in the main log file and CSV file entry
//
// Called by:   DTSTest_SamplingTimerElapsed
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_SampleDisplayAndRecord(
    PDGICInfo       ^pgInfo,
    String          ^titleString,
    String          ^pressureResultLine,
    String          ^temperatureResultLine)
{
    DateTime        dateTime = DateTime::Now;
    String          ^functionName = _T("DTSTest_SampleDisplayAndRecord");
    //------------------------------------------------------------------------
    RecordBasicEvent("    {0} called", functionName);
    if (pgInfo)
    {
        static int sampleNumber = 0;
        String ^firstLineString = String::Empty;
        if (DTSTest_PrependDateAndTime)
        {
            firstLineString = String::Concat(
                String::Format("[ {0:D2}-{1:D2}-{2:D4} {3:D2}:{4:D2}:{5:D2}.{6:D3} ] ",
                    dateTime.Month,
                    dateTime.Day,
                    dateTime.Year,
                    dateTime.Hour,
                    dateTime.Minute,
                    dateTime.Second,
                    dateTime.Millisecond),
                titleString);
        }
        else
        {
            firstLineString = String::Concat(
                ++sampleNumber,
                _T("  "),
                titleString);
        }
        String ^sendingString = _T("    => sending ");
        String ^commandString = String::Empty;
        for (int index = 0; index < pgInfo->numberOfCommandBytes; index++)
            commandString += String::Format(" {0:X2}", pgInfo->commandArray[index]);
        sendingString += commandString;
        String ^pathString = DTSTest_GeneralInfo->mainScript->resultsLogFilePath;
        try
        {
            String ^logLine = String::Concat(
                firstLineString,
                Environment::NewLine,
                sendingString,
                Environment::NewLine,
                _T("    => pressure = "),
                pressureResultLine,
                Environment::NewLine,
                _T("    => temperature = "),
                temperatureResultLine);
            DTSTest_AppendLineToDataLog(logLine);
        }
        catch (Exception ^ex)
        {
            RecordErrorEvent("        {0}\n{1}",
                functionName,
                ex->Message);
        }
        if ((DTSTest_GeneralInfo->flags & DTSTEST_GENERAL_CREATE_CSV_LOG_FILE) ||
            (pathString->EndsWith(".csv", StringComparison::OrdinalIgnoreCase)))
        {
            array <Char> ^lineDelimiters = gcnew array <Char> {DTSTEST_CHAR_SPACE};
            array <String ^> ^pressureStrings = pressureResultLine->Split(
                lineDelimiters,
                StringSplitOptions::RemoveEmptyEntries);
            array <String ^> ^temperatureStrings = temperatureResultLine->Split(
                lineDelimiters,
                StringSplitOptions::RemoveEmptyEntries);
            generalCSVEntry->loggedCSVSentString = commandString;
            generalCSVEntry->loggedCSVPressureActualString = pressureStrings[0];
            generalCSVEntry->loggedCSVTemperatureActualString = temperatureStrings[0];
            DTSTest_FileCreateCSVEntry(generalCSVEntry, GUI_CSV_REGULAR_ENTRY);
            DTSTest_AppendLineToCSVLog(generalCSVEntry->loggedCSVEntryString);
            delete [] temperatureStrings;
            delete [] pressureStrings;
            delete [] lineDelimiters;
        }
    }                                   // end of if (pgInfo)
    RecordBasicEvent("    {0} concluded", functionName);
}                                       // end of DTSTest_SampleDisplayAndRecord()
//----------------------------------------------------------------------------
// DTSTest_SamplingControlsClosingWindow
//
// Handles the closing of the Sampling Controls window by the red X
//
// Called by:   DTSTest_SamplingControlsSetUpWindow
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_SamplingControlsClosingWindow(
    Object          ^sender,
    FormClosingEventArgs
                    ^evt)
{
    //------------------------------------------------------------------------
    evt->Cancel = GUI_YES;              // cancel the closing of the window
    RecordBasicEvent("Sampling Controls window closing");
    if (samplingControlsWindow)
    {
        samplingControlsWindow->Hide();
    }
}                                       // end of DTSTest_SamplingControlsClosingWindow()
//----------------------------------------------------------------------------
// DTSTest_SamplingControlsHideWindow
//
// Event that hides the Sampling Controls display window
//
// Called by:   DTSTest_SamplingControlsSetUpWindow
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_SamplingControlsHideWindow(
    Object          ^sender,
    EventArgs       ^evt)
{
    //------------------------------------------------------------------------
    RecordBasicEvent("Sampling Controls window hidden");
    if (samplingControlsWindow)
    {
        samplingControlsWindow->Hide();
    }
}                                       // end of DTSTest_SamplingControlsHideWindow()
//----------------------------------------------------------------------------
// DTSTest_SamplingControlsSetUpWindow
//
// Displays sampling controls in a new window
//
// Called by:   DTSTest_InstallUtilities
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_SamplingControlsSetUpWindow(void)
{
    SensorInfo      ^sensor = nullptr;
    PDGICInfo       ^pgInfo = DTSTest_GeneralInfo->pgInfo;
    String          ^functionName = _T("DTSTest_SamplingControlsSetUpWindow");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0} called", functionName);
    if (DTSTest_GeneralInfo)
    {
        //--------------------------------------------------------------------
        // Create a new window form each time this is called, due to the
        // dynamic nature of the program values
        //--------------------------------------------------------------------
        samplingControlsWindow = gcnew Form;
        samplingControlsWindow->SuspendLayout();
        //--------------------------------------------------------------------
        // Set its properties
        //--------------------------------------------------------------------
        samplingControlsWindow->MaximizeBox = GUI_NO;
        samplingControlsWindow->HelpButton = GUI_NO;
        //--------------------------------------------------------------------
        // Set its icon
        //--------------------------------------------------------------------
        samplingControlsWindow->Icon = DTSTest_SoftwareIcon;
        //--------------------------------------------------------------------
        // Set the background image
        //--------------------------------------------------------------------
    //        samplingControlsWindow->BackgroundImage = whiteSandBackground;
        //--------------------------------------------------------------------
        // Set the title and border style
        //--------------------------------------------------------------------
        samplingControlsWindow->Text = _T("DTSTest Sampling Controls");
        samplingControlsWindow->FormBorderStyle = ::FormBorderStyle::Fixed3D;
        //--------------------------------------------------------------------
        // Set the dimensions of the Experimental Controls window
        //--------------------------------------------------------------------
        samplingControlsWindow->Size = Drawing::Size(
            GUI_SAMPLING_CONTROLS_WINDOW_WIDTH,
            GUI_SAMPLING_CONTROLS_WINDOW_HEIGHT);
        //--------------------------------------------------------------------
        // Start / Stop Sampling All button
        //--------------------------------------------------------------------
        samplingStartStopAllButton = gcnew Button;
        samplingStartStopAllButton->Text = _T("Start Sampling All");
        samplingStartStopAllButton->Location = Point(10, 10);
        samplingStartStopAllButton->Size = Drawing::Size(150, GUI_REGULAR_BUTTON_HEIGHT);
        GUI_SetButtonInterfaceProperties(samplingStartStopAllButton);
        samplingStartStopAllButton->Click +=
            gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_SamplingStartStopAllButtonClicked);
        samplingStartStopAllButton->Enabled = GUI_NO;
        samplingControlsWindow->Controls->Add(samplingStartStopAllButton);
        //--------------------------------------------------------------------
        // Start / Stop Sampling All Gauges button
        //--------------------------------------------------------------------
        samplingStartStopAllGaugesButton = gcnew Button;
        samplingStartStopAllGaugesButton->Text = _T("Start Sampling All Gauges");
        samplingStartStopAllGaugesButton->Location = Point(
            samplingStartStopAllButton->Right + 25,
            samplingStartStopAllButton->Top);
        samplingStartStopAllGaugesButton->Size = samplingStartStopAllButton->Size;
        GUI_SetButtonInterfaceProperties(samplingStartStopAllGaugesButton);
        samplingStartStopAllGaugesButton->Click +=
            gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_SamplingStartStopAllGaugesButtonClicked);
        samplingStartStopAllGaugesButton->Enabled = GUI_NO;
        samplingControlsWindow->Controls->Add(samplingStartStopAllGaugesButton);
        //--------------------------------------------------------------------
        // Start / Stop Sampling All Barges button
        //--------------------------------------------------------------------
        samplingStartStopAllBargesButton = gcnew Button;
        samplingStartStopAllBargesButton->Text = _T("Start Sampling All Barges");
        samplingStartStopAllBargesButton->Location = Point(
            samplingStartStopAllGaugesButton->Right + 25,
            samplingStartStopAllGaugesButton->Top);
        samplingStartStopAllBargesButton->Size = samplingStartStopAllButton->Size;
        GUI_SetButtonInterfaceProperties(samplingStartStopAllBargesButton);
        samplingStartStopAllBargesButton->Click +=
            gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_SamplingStartStopAllBargesButtonClicked);
        samplingStartStopAllBargesButton->Enabled = GUI_NO;
        samplingControlsWindow->Controls->Add(samplingStartStopAllBargesButton);
        //--------------------------------------------------------------------
        // Stop Everything button
        //--------------------------------------------------------------------
        Button ^samplingStopEverythingButton = gcnew Button;
        samplingStopEverythingButton->Text = _T("Stop Everything");
        samplingStopEverythingButton->Location = Point(
            samplingStartStopAllBargesButton->Right + 25,
            samplingStartStopAllBargesButton->Top);
        samplingStopEverythingButton->Size = samplingStartStopAllBargesButton->Size;
        GUI_SetButtonInterfaceProperties(samplingStopEverythingButton);
        samplingStopEverythingButton->Click +=
            gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_SamplingStopEverythingButtonClicked);
        samplingControlsWindow->Controls->Add(samplingStopEverythingButton);
///        //--------------------------------------------------------------------
//        // Start / Stop Sampling Gauge 2D button
//        //--------------------------------------------------------------------
//        samplingStartStopGauge2DButton = gcnew Button;
//        samplingStartStopGauge2DButton->Text = _T("Start Sampling Gauge 2D");
//        GUI_PositionAndSizeBelow(samplingStartStopGauge2DButton, samplingStartStopAllButton, 10);
//        GUI_SetButtonInterfaceProperties(samplingStartStopGauge2DButton);
//        samplingStartStopGauge2DButton->Click +=
//            gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_SamplingStartStopGauge2DButtonClicked);
//        samplingStartStopGauge2DButton->Enabled = GUI_NO;
//        samplingControlsWindow->Controls->Add(samplingStartStopGauge2DButton);
//        //--------------------------------------------------------------------
//        // Gauge 2D Pressure label
//        //--------------------------------------------------------------------
//        samplingGauge2DPressureLabel = gcnew Label;
//        samplingGauge2DPressureLabel->Text = _T("--  --  --  --");
//        samplingGauge2DPressureLabel->Font = gcnew Drawing::Font(
//            FontFamily::GenericSansSerif,
//            12.0F,
//            FontStyle::Bold);
//        GUI_PositionAndSizeBelow(samplingGauge2DPressureLabel, samplingStartStopAllGaugesButton, 10);
//        samplingGauge2DPressureLabel->BackColor = Color::Transparent;
//        samplingGauge2DPressureLabel->TextAlign = Drawing::ContentAlignment::MiddleCenter;
//        samplingControlsWindow->Controls->Add(samplingGauge2DPressureLabel);
//        //--------------------------------------------------------------------
//        // Gauge 2D Temperature label
//        //--------------------------------------------------------------------
//        samplingGauge2DTemperatureLabel = gcnew Label;
//        samplingGauge2DTemperatureLabel->Text = _T("--  --  --  --");
//        samplingGauge2DTemperatureLabel->Font = gcnew Drawing::Font(
//            FontFamily::GenericSansSerif,
//            12.0F,
//            FontStyle::Bold);
//        GUI_PositionAndSizeBelow(samplingGauge2DTemperatureLabel, samplingStartStopAllBargesButton, 10);
//        samplingGauge2DTemperatureLabel->BackColor = Color::Transparent;
//        samplingGauge2DTemperatureLabel->TextAlign = Drawing::ContentAlignment::MiddleCenter;
//        samplingControlsWindow->Controls->Add(samplingGauge2DTemperatureLabel);
//        //--------------------------------------------------------------------
//        // Gauge 2D LED
//        //--------------------------------------------------------------------
//        samplingGauge2DLEDButton = gcnew Button;
//        samplingGauge2DLEDButton->Location = Point(
//            samplingStopEverythingButton->Left + (samplingStopEverythingButton->Width / 2) - 15,
//            samplingStartStopGauge2DButton->Top - 2);
//        samplingGauge2DLEDButton->Size = Drawing::Size(30, 30);
//        samplingGauge2DLEDButton->BackgroundImage = yellowLEDOffImage;
//        samplingGauge2DLEDButton->BackgroundImageLayout = ImageLayout::Center;
//        GUI_SetObjectInterfaceProperties(samplingGauge2DLEDButton);
//        samplingGauge2DLEDButton->Click +=
//            gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_SamplingStartStopGauge2DButtonClicked);
//        samplingControlsWindow->Controls->Add(samplingGauge2DLEDButton);
//        //--------------------------------------------------------------------
//        // Start / Stop Sampling Gauge 3E button
//        //--------------------------------------------------------------------
//        samplingStartStopGauge3EButton = gcnew Button;
//        samplingStartStopGauge3EButton->Text = _T("Start Sampling Gauge 3E");
//        GUI_PositionAndSizeBelow(samplingStartStopGauge3EButton, samplingStartStopGauge2DButton, 10);
//        GUI_SetButtonInterfaceProperties(samplingStartStopGauge3EButton);
//        samplingStartStopGauge3EButton->Click +=
//            gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_SamplingStartStopGauge3EButtonClicked);
//        samplingStartStopGauge3EButton->Enabled = GUI_NO;
//        samplingControlsWindow->Controls->Add(samplingStartStopGauge3EButton);
//        //--------------------------------------------------------------------
//        // Gauge 3E Pressure label
//        //--------------------------------------------------------------------
//        samplingGauge3EPressureLabel = gcnew Label;
//        samplingGauge3EPressureLabel->Text = _T("--  --  --  --");
//        samplingGauge3EPressureLabel->Font = gcnew Drawing::Font(
//            FontFamily::GenericSansSerif,
//            12.0F,
//            FontStyle::Bold);
//        GUI_PositionAndSizeBelow(samplingGauge3EPressureLabel, samplingGauge2DPressureLabel, 10);
//        samplingGauge3EPressureLabel->BackColor = Color::Transparent;
//        samplingGauge3EPressureLabel->TextAlign = Drawing::ContentAlignment::MiddleCenter;
//        samplingControlsWindow->Controls->Add(samplingGauge3EPressureLabel);
//        //--------------------------------------------------------------------
//        // Gauge 3E Temperature label
//        //--------------------------------------------------------------------
//        samplingGauge3ETemperatureLabel = gcnew Label;
//        samplingGauge3ETemperatureLabel->Text = _T("--  --  --  --");
//        samplingGauge3ETemperatureLabel->Font = gcnew Drawing::Font(
//            FontFamily::GenericSansSerif,
//            12.0F,
//            FontStyle::Bold);
//        GUI_PositionAndSizeBelow(samplingGauge3ETemperatureLabel, samplingGauge2DTemperatureLabel, 10);
//        samplingGauge3ETemperatureLabel->BackColor = Color::Transparent;
//        samplingGauge3ETemperatureLabel->TextAlign = Drawing::ContentAlignment::MiddleCenter;
//        samplingControlsWindow->Controls->Add(samplingGauge3ETemperatureLabel);
//        //--------------------------------------------------------------------
//        // Gauge 3E LED
//        //--------------------------------------------------------------------
//        samplingGauge3ELEDButton = gcnew Button;
//        samplingGauge3ELEDButton->Location = Point(
//            samplingGauge2DLEDButton->Left,
//            samplingStartStopGauge3EButton->Top - 2);
//        samplingGauge3ELEDButton->Size = samplingGauge2DLEDButton->Size;
//        samplingGauge3ELEDButton->BackgroundImage = yellowLEDOffImage;
//        samplingGauge3ELEDButton->BackgroundImageLayout = ImageLayout::Center;
//        GUI_SetObjectInterfaceProperties(samplingGauge3ELEDButton);
//        samplingGauge3ELEDButton->Click +=
//            gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_SamplingStartStopGauge3EButtonClicked);
//        samplingControlsWindow->Controls->Add(samplingGauge3ELEDButton);
//        //--------------------------------------------------------------------
//        // Start / Stop Sampling Barge B4 button
//        //--------------------------------------------------------------------
//        samplingStartStopBargeB4Button = gcnew Button;
//        samplingStartStopBargeB4Button->Text = _T("Start Sampling Barge B4");
//        GUI_PositionAndSizeBelow(samplingStartStopBargeB4Button, samplingStartStopGauge3EButton, 10);
//        GUI_SetButtonInterfaceProperties(samplingStartStopBargeB4Button);
//        samplingStartStopBargeB4Button->Click +=
//            gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_SamplingStartStopBargeB4ButtonClicked);
//        samplingStartStopBargeB4Button->Enabled = GUI_NO;
//        samplingControlsWindow->Controls->Add(samplingStartStopBargeB4Button);
//        //--------------------------------------------------------------------
//        // Barge B4 Pressure label
//        //--------------------------------------------------------------------
//        samplingBargeB4PressureLabel = gcnew Label;
//        samplingBargeB4PressureLabel->Text = _T("--  --  --  --");
//        samplingBargeB4PressureLabel->Font = gcnew Drawing::Font(
//            FontFamily::GenericSansSerif,
//            12.0F,
//            FontStyle::Bold);
//        GUI_PositionAndSizeBelow(samplingBargeB4PressureLabel, samplingGauge3EPressureLabel, 10);
//        samplingBargeB4PressureLabel->BackColor = Color::Transparent;
//        samplingBargeB4PressureLabel->TextAlign = Drawing::ContentAlignment::MiddleCenter;
//        samplingControlsWindow->Controls->Add(samplingBargeB4PressureLabel);
//        //--------------------------------------------------------------------
//        // Barge B4 Temperature label
//        //--------------------------------------------------------------------
//        samplingBargeB4TemperatureLabel = gcnew Label;
//        samplingBargeB4TemperatureLabel->Text = _T("--  --  --  --");
//        samplingBargeB4TemperatureLabel->Font = gcnew Drawing::Font(
//            FontFamily::GenericSansSerif,
//            12.0F,
//            FontStyle::Bold);
//        GUI_PositionAndSizeBelow(samplingBargeB4TemperatureLabel, samplingGauge3ETemperatureLabel, 10);
//        samplingBargeB4TemperatureLabel->BackColor = Color::Transparent;
//        samplingBargeB4TemperatureLabel->TextAlign = Drawing::ContentAlignment::MiddleCenter;
//        samplingControlsWindow->Controls->Add(samplingBargeB4TemperatureLabel);
//        //--------------------------------------------------------------------
//        // Barge B4 LED
//        //--------------------------------------------------------------------
//        samplingBargeB4LEDButton = gcnew Button;
//        samplingBargeB4LEDButton->Location = Point(
//            samplingGauge3ELEDButton->Left,
//            samplingStartStopBargeB4Button->Top - 2);
//        samplingBargeB4LEDButton->Size = samplingGauge3ELEDButton->Size;
//        samplingBargeB4LEDButton->BackgroundImage = yellowLEDOffImage;
//        samplingBargeB4LEDButton->BackgroundImageLayout = ImageLayout::Center;
//        GUI_SetObjectInterfaceProperties(samplingBargeB4LEDButton);
//        samplingBargeB4LEDButton->Click +=
//            gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_SamplingStartStopBargeB4ButtonClicked);
//        samplingControlsWindow->Controls->Add(samplingBargeB4LEDButton);
//        //--------------------------------------------------------------------
//        // Start / Stop Sampling Barge C9 button
//        //--------------------------------------------------------------------
//        samplingStartStopBargeC9Button = gcnew Button;
//        samplingStartStopBargeC9Button->Text = _T("Start Sampling Barge C9");
//        GUI_PositionAndSizeBelow(samplingStartStopBargeC9Button, samplingStartStopBargeB4Button, 10);
//        GUI_SetButtonInterfaceProperties(samplingStartStopBargeC9Button);
//        samplingStartStopBargeC9Button->Click +=
//            gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_SamplingStartStopBargeC9ButtonClicked);
//        samplingStartStopBargeC9Button->Enabled = GUI_NO;
//        samplingControlsWindow->Controls->Add(samplingStartStopBargeC9Button);
//        //--------------------------------------------------------------------
//        // Barge C9 Pressure label
//        //--------------------------------------------------------------------
//        samplingBargeC9PressureLabel = gcnew Label;
//        samplingBargeC9PressureLabel->Text = _T("--  --  --  --");
//        samplingBargeC9PressureLabel->Font = gcnew Drawing::Font(
//            FontFamily::GenericSansSerif,
//            12.0F,
//            FontStyle::Bold);
//        GUI_PositionAndSizeBelow(samplingBargeC9PressureLabel, samplingBargeB4PressureLabel, 10);
//        samplingBargeC9PressureLabel->BackColor = Color::Transparent;
//        samplingBargeC9PressureLabel->TextAlign = Drawing::ContentAlignment::MiddleCenter;
//        samplingControlsWindow->Controls->Add(samplingBargeC9PressureLabel);
//        //--------------------------------------------------------------------
//        // Barge C9 Temperature label
//        //--------------------------------------------------------------------
//        samplingBargeC9TemperatureLabel = gcnew Label;
//        samplingBargeC9TemperatureLabel->Text = _T("--  --  --  --");
//        samplingBargeC9TemperatureLabel->Font = gcnew Drawing::Font(
//            FontFamily::GenericSansSerif,
//            12.0F,
//            FontStyle::Bold);
//        GUI_PositionAndSizeBelow(samplingBargeC9TemperatureLabel, samplingBargeB4TemperatureLabel, 10);
//        samplingBargeC9TemperatureLabel->BackColor = Color::Transparent;
//        samplingBargeC9TemperatureLabel->TextAlign = Drawing::ContentAlignment::MiddleCenter;
//        samplingControlsWindow->Controls->Add(samplingBargeC9TemperatureLabel);
//        //--------------------------------------------------------------------
//        // Barge C9 LED
//        //--------------------------------------------------------------------
//        samplingBargeC9LEDButton = gcnew Button;
//        samplingBargeC9LEDButton->Location = Point(
//            samplingBargeB4LEDButton->Left,
//            samplingStartStopBargeC9Button->Top - 2);
//        samplingBargeC9LEDButton->Size = samplingBargeB4LEDButton->Size;
//        samplingBargeC9LEDButton->BackgroundImage = yellowLEDOffImage;
//        samplingBargeC9LEDButton->BackgroundImageLayout = ImageLayout::Center;
//        GUI_SetObjectInterfaceProperties(samplingBargeC9LEDButton);
//        samplingBargeC9LEDButton->Click +=
//            gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_SamplingStartStopBargeC9ButtonClicked);
//        samplingControlsWindow->Controls->Add(samplingBargeC9LEDButton);
//        //--------------------------------------------------------------------
//        // Start / Stop Sampling Barge E2 button
//        //--------------------------------------------------------------------
//        samplingStartStopBargeE2Button = gcnew Button;
//        samplingStartStopBargeE2Button->Text = _T("Start Sampling Barge E2");
//        GUI_PositionAndSizeBelow(samplingStartStopBargeE2Button, samplingStartStopBargeC9Button, 10);
//        GUI_SetButtonInterfaceProperties(samplingStartStopBargeE2Button);
//        samplingStartStopBargeE2Button->Click +=
//            gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_SamplingStartStopBargeE2ButtonClicked);
//        samplingStartStopBargeE2Button->Enabled = GUI_NO;
//        samplingControlsWindow->Controls->Add(samplingStartStopBargeE2Button);
//        //--------------------------------------------------------------------
//        // Barge E2 Pressure label
//        //--------------------------------------------------------------------
//        samplingBargeE2PressureLabel = gcnew Label;
//        samplingBargeE2PressureLabel->Text = _T("--  --  --  --");
//        samplingBargeE2PressureLabel->Font = gcnew Drawing::Font(
//            FontFamily::GenericSansSerif,
//            12.0F,
//            FontStyle::Bold);
//        GUI_PositionAndSizeBelow(samplingBargeE2PressureLabel, samplingBargeC9PressureLabel, 10);
//        samplingBargeE2PressureLabel->BackColor = Color::Transparent;
//        samplingBargeE2PressureLabel->TextAlign = Drawing::ContentAlignment::MiddleCenter;
//        samplingControlsWindow->Controls->Add(samplingBargeE2PressureLabel);
//        //--------------------------------------------------------------------
//        // Barge E2 Temperature label
//        //--------------------------------------------------------------------
//        samplingBargeE2TemperatureLabel = gcnew Label;
//        samplingBargeE2TemperatureLabel->Text = _T("--  --  --  --");
//        samplingBargeE2TemperatureLabel->Font = gcnew Drawing::Font(
//            FontFamily::GenericSansSerif,
//            12.0F,
//            FontStyle::Bold);
//        GUI_PositionAndSizeBelow(samplingBargeE2TemperatureLabel, samplingBargeC9TemperatureLabel, 10);
//        samplingBargeE2TemperatureLabel->BackColor = Color::Transparent;
//        samplingBargeE2TemperatureLabel->TextAlign = Drawing::ContentAlignment::MiddleCenter;
//        samplingControlsWindow->Controls->Add(samplingBargeE2TemperatureLabel);
//        //--------------------------------------------------------------------
//        // Barge E2 LED
//        //--------------------------------------------------------------------
//        samplingBargeE2LEDButton = gcnew Button;
//        samplingBargeE2LEDButton->Location = Point(
//            samplingBargeC9LEDButton->Left,
//            samplingStartStopBargeE2Button->Top - 2);
//        samplingBargeE2LEDButton->Size = samplingBargeC9LEDButton->Size;
//        samplingBargeE2LEDButton->BackgroundImage = yellowLEDOffImage;
//        samplingBargeE2LEDButton->BackgroundImageLayout = ImageLayout::Center;
//        GUI_SetObjectInterfaceProperties(samplingBargeE2LEDButton);
//        samplingBargeE2LEDButton->Click +=
//            gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_SamplingStartStopBargeE2ButtonClicked);
//        samplingControlsWindow->Controls->Add(samplingBargeE2LEDButton);
//        //--------------------------------------------------------------------
//        // Start / Stop Sampling Barge 02 button
//        //--------------------------------------------------------------------
//        samplingStartStopBarge02Button = gcnew Button;
//        samplingStartStopBarge02Button->Text = _T("Start Sampling Barge 02");
//        GUI_PositionAndSizeBelow(samplingStartStopBarge02Button, samplingStartStopBargeE2Button, 10);
//        GUI_SetButtonInterfaceProperties(samplingStartStopBarge02Button);
//        samplingStartStopBarge02Button->Click +=
//            gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_SamplingStartStopBarge02ButtonClicked);
//        samplingStartStopBarge02Button->Enabled = GUI_NO;
//        samplingControlsWindow->Controls->Add(samplingStartStopBarge02Button);
//        //--------------------------------------------------------------------
//        // Barge 02 Pressure label
//        //--------------------------------------------------------------------
//        samplingBarge02PressureLabel = gcnew Label;
//        samplingBarge02PressureLabel->Text = _T("--  --  --  --");
//        samplingBarge02PressureLabel->Font = gcnew Drawing::Font(
//            FontFamily::GenericSansSerif,
//            12.0F,
//            FontStyle::Bold);
//        GUI_PositionAndSizeBelow(samplingBarge02PressureLabel, samplingBargeE2PressureLabel, 10);
//        samplingBarge02PressureLabel->BackColor = Color::Transparent;
//        samplingBarge02PressureLabel->TextAlign = Drawing::ContentAlignment::MiddleCenter;
//        samplingControlsWindow->Controls->Add(samplingBarge02PressureLabel);
//        //--------------------------------------------------------------------
//        // Barge 02 Temperature label
//        //--------------------------------------------------------------------
//        samplingBarge02TemperatureLabel = gcnew Label;
//        samplingBarge02TemperatureLabel->Text = _T("--  --  --  --");
//        samplingBarge02TemperatureLabel->Font = gcnew Drawing::Font(
//            FontFamily::GenericSansSerif,
//            12.0F,
//            FontStyle::Bold);
//        GUI_PositionAndSizeBelow(samplingBarge02TemperatureLabel, samplingBargeE2TemperatureLabel, 10);
//        samplingBarge02TemperatureLabel->BackColor = Color::Transparent;
//        samplingBarge02TemperatureLabel->TextAlign = Drawing::ContentAlignment::MiddleCenter;
//        samplingControlsWindow->Controls->Add(samplingBarge02TemperatureLabel);
//        //--------------------------------------------------------------------
//        // Barge 02 LED
//        //--------------------------------------------------------------------
//        samplingBarge02LEDButton = gcnew Button;
//        samplingBarge02LEDButton->Location = Point(
//            samplingBargeE2LEDButton->Left,
//            samplingStartStopBarge02Button->Top - 2);
//        samplingBarge02LEDButton->Size = samplingBargeE2LEDButton->Size;
//        samplingBarge02LEDButton->BackgroundImage = yellowLEDOffImage;
//        samplingBarge02LEDButton->BackgroundImageLayout = ImageLayout::Center;
//        GUI_SetObjectInterfaceProperties(samplingBarge02LEDButton);
//        samplingBarge02LEDButton->Click +=
//            gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_SamplingStartStopBarge02ButtonClicked);
//        samplingControlsWindow->Controls->Add(samplingBarge02LEDButton);
//        //--------------------------------------------------------------------
//        // Start / Stop Sampling User Gauge 1 button
//        //--------------------------------------------------------------------
//        samplingStartStopUserGauge1Button = gcnew Button;
//        samplingStartStopUserGauge1Button->Text = String::Concat(
//            _T("Start Sampling Gauge "),
//            (pgInfo->userGaugeNodeAddress1 ? String::Format("{0:X2}", pgInfo->userGaugeNodeAddress1) : _T("XX")));
//        GUI_PositionAndSizeBelow(samplingStartStopUserGauge1Button, samplingStartStopBarge02Button, 10);
//        GUI_SetButtonInterfaceProperties(samplingStartStopUserGauge1Button);
//        samplingStartStopUserGauge1Button->Click +=
//            gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_SamplingStartStopUserGauge1ButtonClicked);
//        samplingStartStopUserGauge1Button->Enabled = GUI_NO;
//        samplingControlsWindow->Controls->Add(samplingStartStopUserGauge1Button);
//        //--------------------------------------------------------------------
//        // User Gauge 1 Pressure label
//        //--------------------------------------------------------------------
//        samplingUserGauge1PressureLabel = gcnew Label;
//        samplingUserGauge1PressureLabel->Text = _T("--  --  --  --");
//        samplingUserGauge1PressureLabel->Font = gcnew Drawing::Font(
//            FontFamily::GenericSansSerif,
//            12.0F,
//            FontStyle::Bold);
//        GUI_PositionAndSizeBelow(samplingUserGauge1PressureLabel, samplingBarge02PressureLabel, 10);
//        samplingUserGauge1PressureLabel->BackColor = Color::Transparent;
//        samplingUserGauge1PressureLabel->TextAlign = Drawing::ContentAlignment::MiddleCenter;
//        samplingControlsWindow->Controls->Add(samplingUserGauge1PressureLabel);
//        //--------------------------------------------------------------------
//        // User Gauge 1 Temperature label
//        //--------------------------------------------------------------------
//        samplingUserGauge1TemperatureLabel = gcnew Label;
//        samplingUserGauge1TemperatureLabel->Text = _T("--  --  --  --");
//        samplingUserGauge1TemperatureLabel->Font = gcnew Drawing::Font(
//            FontFamily::GenericSansSerif,
//            12.0F,
//            FontStyle::Bold);
//        GUI_PositionAndSizeBelow(samplingUserGauge1TemperatureLabel, samplingBarge02TemperatureLabel, 10);
//        samplingUserGauge1TemperatureLabel->BackColor = Color::Transparent;
//        samplingUserGauge1TemperatureLabel->TextAlign = Drawing::ContentAlignment::MiddleCenter;
//        samplingControlsWindow->Controls->Add(samplingUserGauge1TemperatureLabel);
//        //--------------------------------------------------------------------
//        // User Gauge 1 LED
//        //--------------------------------------------------------------------
//        samplingUserGauge1LEDButton = gcnew Button;
//        samplingUserGauge1LEDButton->Location = Point(
//            samplingBarge02LEDButton->Left,
//            samplingStartStopUserGauge1Button->Top - 2);
//        samplingUserGauge1LEDButton->Size = samplingBarge02LEDButton->Size;
//        samplingUserGauge1LEDButton->BackgroundImage = yellowLEDOffImage;
//        samplingUserGauge1LEDButton->BackgroundImageLayout = ImageLayout::Center;
//        GUI_SetObjectInterfaceProperties(samplingUserGauge1LEDButton);
//        samplingUserGauge1LEDButton->Click +=
//            gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_SamplingStartStopUserGauge1ButtonClicked);
//        samplingControlsWindow->Controls->Add(samplingUserGauge1LEDButton);
//        //--------------------------------------------------------------------
//        // Start / Stop Sampling User Gauge 2 button
//        //--------------------------------------------------------------------
//        samplingStartStopUserGauge2Button = gcnew Button;
//        samplingStartStopUserGauge2Button->Text = String::Concat(
//            _T("Start Sampling Gauge "),
//            (pgInfo->userGaugeNodeAddress2 ? String::Format("{0:X2}", pgInfo->userGaugeNodeAddress2) : _T("XX")));
//        GUI_PositionAndSizeBelow(samplingStartStopUserGauge2Button, samplingStartStopUserGauge1Button, 10);
//        GUI_SetButtonInterfaceProperties(samplingStartStopUserGauge2Button);
//        samplingStartStopUserGauge2Button->Click +=
//            gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_SamplingStartStopUserGauge2ButtonClicked);
//        samplingStartStopUserGauge2Button->Enabled = GUI_NO;
//        samplingControlsWindow->Controls->Add(samplingStartStopUserGauge2Button);
//        //--------------------------------------------------------------------
//        // User Gauge 2 Pressure label
//        //--------------------------------------------------------------------
//        samplingUserGauge2PressureLabel = gcnew Label;
//        samplingUserGauge2PressureLabel->Text = _T("--  --  --  --");
//        samplingUserGauge2PressureLabel->Font = gcnew Drawing::Font(
//            FontFamily::GenericSansSerif,
//            12.0F,
//            FontStyle::Bold);
//        GUI_PositionAndSizeBelow(samplingUserGauge2PressureLabel, samplingUserGauge1PressureLabel, 10);
//        samplingUserGauge2PressureLabel->BackColor = Color::Transparent;
//        samplingUserGauge2PressureLabel->TextAlign = Drawing::ContentAlignment::MiddleCenter;
//        samplingControlsWindow->Controls->Add(samplingUserGauge2PressureLabel);
//        //--------------------------------------------------------------------
//        // User Gauge 2 Temperature label
//        //--------------------------------------------------------------------
//        samplingUserGauge2TemperatureLabel = gcnew Label;
//        samplingUserGauge2TemperatureLabel->Text = _T("--  --  --  --");
//        samplingUserGauge2TemperatureLabel->Font = gcnew Drawing::Font(
//            FontFamily::GenericSansSerif,
//            12.0F,
//            FontStyle::Bold);
//        GUI_PositionAndSizeBelow(samplingUserGauge2TemperatureLabel, samplingUserGauge1TemperatureLabel, 10);
//        samplingUserGauge2TemperatureLabel->BackColor = Color::Transparent;
//        samplingUserGauge2TemperatureLabel->TextAlign = Drawing::ContentAlignment::MiddleCenter;
//        samplingControlsWindow->Controls->Add(samplingUserGauge2TemperatureLabel);
//        //--------------------------------------------------------------------
//        // User Gauge 2 LED
//        //--------------------------------------------------------------------
//        samplingUserGauge2LEDButton = gcnew Button;
//        samplingUserGauge2LEDButton->Location = Point(
//            samplingUserGauge1LEDButton->Left,
//            samplingStartStopUserGauge2Button->Top - 2);
//        samplingUserGauge2LEDButton->Size = samplingUserGauge1LEDButton->Size;
//        samplingUserGauge2LEDButton->BackgroundImage = yellowLEDOffImage;
//        samplingUserGauge2LEDButton->BackgroundImageLayout = ImageLayout::Center;
//        GUI_SetObjectInterfaceProperties(samplingUserGauge2LEDButton);
//        samplingUserGauge2LEDButton->Click +=
//            gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_SamplingStartStopUserGauge2ButtonClicked);
//        samplingControlsWindow->Controls->Add(samplingUserGauge2LEDButton);
//        //--------------------------------------------------------------------
//        // Start / Stop Sampling User Gauge 3 button
//        //--------------------------------------------------------------------
//        samplingStartStopUserGauge3Button = gcnew Button;
//        samplingStartStopUserGauge3Button->Text = String::Concat(
//            _T("Start Sampling Gauge "),
//            (pgInfo->userGaugeNodeAddress3 ? String::Format("{0:X2}", pgInfo->userGaugeNodeAddress3) : _T("XX")));
//        GUI_PositionAndSizeBelow(samplingStartStopUserGauge3Button, samplingStartStopUserGauge2Button, 10);
//        GUI_SetButtonInterfaceProperties(samplingStartStopUserGauge3Button);
//        samplingStartStopUserGauge3Button->Click +=
//            gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_SamplingStartStopUserGauge3ButtonClicked);
//        samplingStartStopUserGauge3Button->Enabled = GUI_NO;
//        samplingControlsWindow->Controls->Add(samplingStartStopUserGauge3Button);
//        //--------------------------------------------------------------------
//        // User Gauge 3 Pressure label
//        //--------------------------------------------------------------------
//        samplingUserGauge3PressureLabel = gcnew Label;
//        samplingUserGauge3PressureLabel->Text = _T("--  --  --  --");
//        samplingUserGauge3PressureLabel->Font = gcnew Drawing::Font(
//            FontFamily::GenericSansSerif,
//            12.0F,
//            FontStyle::Bold);
//        GUI_PositionAndSizeBelow(samplingUserGauge3PressureLabel, samplingUserGauge2PressureLabel, 10);
//        samplingUserGauge3PressureLabel->BackColor = Color::Transparent;
//        samplingUserGauge3PressureLabel->TextAlign = Drawing::ContentAlignment::MiddleCenter;
//        samplingControlsWindow->Controls->Add(samplingUserGauge3PressureLabel);
//        //--------------------------------------------------------------------
//        // User Gauge 3 Temperature label
//        //--------------------------------------------------------------------
//        samplingUserGauge3TemperatureLabel = gcnew Label;
//        samplingUserGauge3TemperatureLabel->Text = _T("--  --  --  --");
//        samplingUserGauge3TemperatureLabel->Font = gcnew Drawing::Font(
//            FontFamily::GenericSansSerif,
//            12.0F,
//            FontStyle::Bold);
//        GUI_PositionAndSizeBelow(samplingUserGauge3TemperatureLabel, samplingUserGauge2TemperatureLabel, 10);
//        samplingUserGauge3TemperatureLabel->BackColor = Color::Transparent;
//        samplingUserGauge3TemperatureLabel->TextAlign = Drawing::ContentAlignment::MiddleCenter;
//        samplingControlsWindow->Controls->Add(samplingUserGauge3TemperatureLabel);
//        //--------------------------------------------------------------------
//        // User Gauge 3 LED
//        //--------------------------------------------------------------------
//        samplingUserGauge3LEDButton = gcnew Button;
//        samplingUserGauge3LEDButton->Location = Point(
//            samplingUserGauge2LEDButton->Left,
//            samplingStartStopUserGauge3Button->Top - 2);
//        samplingUserGauge3LEDButton->Size = samplingUserGauge2LEDButton->Size;
//        samplingUserGauge3LEDButton->BackgroundImage = yellowLEDOffImage;
//        samplingUserGauge3LEDButton->BackgroundImageLayout = ImageLayout::Center;
//        GUI_SetObjectInterfaceProperties(samplingUserGauge3LEDButton);
//        samplingUserGauge3LEDButton->Click +=
//            gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_SamplingStartStopUserGauge3ButtonClicked);
//        samplingControlsWindow->Controls->Add(samplingUserGauge3LEDButton);
//        //--------------------------------------------------------------------
//        // Start / Stop Sampling User Barge 1 button
//        //--------------------------------------------------------------------
//        samplingStartStopUserBarge1Button = gcnew Button;
//        samplingStartStopUserBarge1Button->Text = String::Concat(
//            _T("Start Sampling Barge "),
//            (pgInfo->userBargeNodeAddress1 ? String::Format("{0:X2}", pgInfo->userBargeNodeAddress1) : _T("XX")));
//        GUI_PositionAndSizeBelow(samplingStartStopUserBarge1Button, samplingStartStopUserGauge3Button, 10);
//        GUI_SetButtonInterfaceProperties(samplingStartStopUserBarge1Button);
//        samplingStartStopUserBarge1Button->Click +=
//            gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_SamplingStartStopUserBarge1ButtonClicked);
//        samplingStartStopUserBarge1Button->Enabled = GUI_NO;
//        samplingControlsWindow->Controls->Add(samplingStartStopUserBarge1Button);
//        //--------------------------------------------------------------------
//        // User Barge 1 Pressure label
//        //--------------------------------------------------------------------
//        samplingUserBarge1PressureLabel = gcnew Label;
//        samplingUserBarge1PressureLabel->Text = _T("--  --  --  --");
//        samplingUserBarge1PressureLabel->Font = gcnew Drawing::Font(
//            FontFamily::GenericSansSerif,
//            12.0F,
//            FontStyle::Bold);
//        GUI_PositionAndSizeBelow(samplingUserBarge1PressureLabel, samplingUserGauge3PressureLabel, 10);
//        samplingUserBarge1PressureLabel->BackColor = Color::Transparent;
//        samplingUserBarge1PressureLabel->TextAlign = Drawing::ContentAlignment::MiddleCenter;
//        samplingControlsWindow->Controls->Add(samplingUserBarge1PressureLabel);
//        //--------------------------------------------------------------------
//        // User Barge 1 Temperature label
//        //--------------------------------------------------------------------
//        samplingUserBarge1TemperatureLabel = gcnew Label;
//        samplingUserBarge1TemperatureLabel->Text = _T("--  --  --  --");
//        samplingUserBarge1TemperatureLabel->Font = gcnew Drawing::Font(
//            FontFamily::GenericSansSerif,
//            12.0F,
//            FontStyle::Bold);
//        GUI_PositionAndSizeBelow(samplingUserBarge1TemperatureLabel, samplingUserGauge3TemperatureLabel, 10);
//        samplingUserBarge1TemperatureLabel->BackColor = Color::Transparent;
//        samplingUserBarge1TemperatureLabel->TextAlign = Drawing::ContentAlignment::MiddleCenter;
//        samplingControlsWindow->Controls->Add(samplingUserBarge1TemperatureLabel);
//        //--------------------------------------------------------------------
//        // User Barge 1 LED
//        //--------------------------------------------------------------------
//        samplingUserBarge1LEDButton = gcnew Button;
//        samplingUserBarge1LEDButton->Location = Point(
//            samplingUserGauge3LEDButton->Left,
//            samplingStartStopUserBarge1Button->Top - 2);
//        samplingUserBarge1LEDButton->Size = samplingUserGauge3LEDButton->Size;
//        samplingUserBarge1LEDButton->BackgroundImage = yellowLEDOffImage;
//        samplingUserBarge1LEDButton->BackgroundImageLayout = ImageLayout::Center;
//        GUI_SetObjectInterfaceProperties(samplingUserBarge1LEDButton);
//        samplingUserBarge1LEDButton->Click +=
//            gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_SamplingStartStopUserBarge1ButtonClicked);
//        samplingControlsWindow->Controls->Add(samplingUserBarge1LEDButton);
//        //--------------------------------------------------------------------
//        // Start / Stop Sampling User Barge 2 button
//        //--------------------------------------------------------------------
//        samplingStartStopUserBarge2Button = gcnew Button;
//        samplingStartStopUserBarge2Button->Text = String::Concat(
//            _T("Start Sampling Barge "),
//            (pgInfo->userBargeNodeAddress2 ? String::Format("{0:X2}", pgInfo->userBargeNodeAddress2) : _T("XX")));
//        GUI_PositionAndSizeBelow(samplingStartStopUserBarge2Button, samplingStartStopUserBarge1Button, 10);
//        GUI_SetButtonInterfaceProperties(samplingStartStopUserBarge2Button);
//        samplingStartStopUserBarge2Button->Click +=
//            gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_SamplingStartStopUserBarge2ButtonClicked);
//        samplingStartStopUserBarge2Button->Enabled = GUI_NO;
//        samplingControlsWindow->Controls->Add(samplingStartStopUserBarge2Button);
//        //--------------------------------------------------------------------
//        // User Barge 2 Pressure label
//        //--------------------------------------------------------------------
//        samplingUserBarge2PressureLabel = gcnew Label;
//        samplingUserBarge2PressureLabel->Text = _T("--  --  --  --");
//        samplingUserBarge2PressureLabel->Font = gcnew Drawing::Font(
//            FontFamily::GenericSansSerif,
//            12.0F,
//            FontStyle::Bold);
//        GUI_PositionAndSizeBelow(samplingUserBarge2PressureLabel, samplingUserBarge1PressureLabel, 10);
//        samplingUserBarge2PressureLabel->BackColor = Color::Transparent;
//        samplingUserBarge2PressureLabel->TextAlign = Drawing::ContentAlignment::MiddleCenter;
//        samplingControlsWindow->Controls->Add(samplingUserBarge2PressureLabel);
//        //--------------------------------------------------------------------
//        // User Barge 2 Temperature label
//        //--------------------------------------------------------------------
//        samplingUserBarge2TemperatureLabel = gcnew Label;
//        samplingUserBarge2TemperatureLabel->Text = _T("--  --  --  --");
//        samplingUserBarge2TemperatureLabel->Font = gcnew Drawing::Font(
//            FontFamily::GenericSansSerif,
//            12.0F,
//            FontStyle::Bold);
//        GUI_PositionAndSizeBelow(samplingUserBarge2TemperatureLabel, samplingUserBarge1TemperatureLabel, 10);
//        samplingUserBarge2TemperatureLabel->BackColor = Color::Transparent;
//        samplingUserBarge2TemperatureLabel->TextAlign = Drawing::ContentAlignment::MiddleCenter;
//        samplingControlsWindow->Controls->Add(samplingUserBarge2TemperatureLabel);
//        //--------------------------------------------------------------------
//        // User Barge 2 LED
//        //--------------------------------------------------------------------
//        samplingUserBarge2LEDButton = gcnew Button;
//        samplingUserBarge2LEDButton->Location = Point(
//            samplingUserBarge1LEDButton->Left,
//            samplingStartStopUserBarge2Button->Top - 2);
//        samplingUserBarge2LEDButton->Size = samplingUserBarge1LEDButton->Size;
//        samplingUserBarge2LEDButton->BackgroundImage = yellowLEDOffImage;
//        samplingUserBarge2LEDButton->BackgroundImageLayout = ImageLayout::Center;
//        GUI_SetObjectInterfaceProperties(samplingUserBarge2LEDButton);
//        samplingUserBarge2LEDButton->Click +=
//            gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_SamplingStartStopUserBarge2ButtonClicked);
//        samplingControlsWindow->Controls->Add(samplingUserBarge2LEDButton);
//        //--------------------------------------------------------------------
//        // Start / Stop Sampling User Barge 3 button
//        //--------------------------------------------------------------------
//        samplingStartStopUserBarge3Button = gcnew Button;
//        samplingStartStopUserBarge3Button->Text = String::Concat(
//            _T("Start Sampling Barge "),
//            (pgInfo->userBargeNodeAddress3 ? String::Format("{0:X2}", pgInfo->userBargeNodeAddress3) : _T("XX")));
//        GUI_PositionAndSizeBelow(samplingStartStopUserBarge3Button, samplingStartStopUserBarge2Button, 10);
//        GUI_SetButtonInterfaceProperties(samplingStartStopUserBarge3Button);
//        samplingStartStopUserBarge3Button->Click +=
//            gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_SamplingStartStopUserBarge3ButtonClicked);
//        samplingStartStopUserBarge3Button->Enabled = GUI_NO;
//        samplingControlsWindow->Controls->Add(samplingStartStopUserBarge3Button);
//        //--------------------------------------------------------------------
//        // User Barge 3 Pressure label
//        //--------------------------------------------------------------------
//        samplingUserBarge3PressureLabel = gcnew Label;
//        samplingUserBarge3PressureLabel->Text = _T("--  --  --  --");
//        samplingUserBarge3PressureLabel->Font = gcnew Drawing::Font(
//            FontFamily::GenericSansSerif,
//            12.0F,
//            FontStyle::Bold);
//        GUI_PositionAndSizeBelow(samplingUserBarge3PressureLabel, samplingUserBarge2PressureLabel, 10);
//        samplingUserBarge3PressureLabel->BackColor = Color::Transparent;
//        samplingUserBarge3PressureLabel->TextAlign = Drawing::ContentAlignment::MiddleCenter;
//        samplingControlsWindow->Controls->Add(samplingUserBarge3PressureLabel);
//        //--------------------------------------------------------------------
//        // User Barge 3 Temperature label
//        //--------------------------------------------------------------------
//        samplingUserBarge3TemperatureLabel = gcnew Label;
//        samplingUserBarge3TemperatureLabel->Text = _T("--  --  --  --");
//        samplingUserBarge3TemperatureLabel->Font = gcnew Drawing::Font(
//            FontFamily::GenericSansSerif,
//            12.0F,
//            FontStyle::Bold);
//        GUI_PositionAndSizeBelow(samplingUserBarge3TemperatureLabel, samplingUserBarge2TemperatureLabel, 10);
//        samplingUserBarge3TemperatureLabel->BackColor = Color::Transparent;
//        samplingUserBarge3TemperatureLabel->TextAlign = Drawing::ContentAlignment::MiddleCenter;
//        samplingControlsWindow->Controls->Add(samplingUserBarge3TemperatureLabel);
//        //--------------------------------------------------------------------
//        // User Barge 3 LED
//        //--------------------------------------------------------------------
//        samplingUserBarge3LEDButton = gcnew Button;
//        samplingUserBarge3LEDButton->Location = Point(
//            samplingUserBarge2LEDButton->Left,
//            samplingStartStopUserBarge3Button->Top - 2);
//        samplingUserBarge3LEDButton->Size = samplingUserBarge2LEDButton->Size;
//        samplingUserBarge3LEDButton->BackgroundImage = yellowLEDOffImage;
//        samplingUserBarge3LEDButton->BackgroundImageLayout = ImageLayout::Center;
//        GUI_SetObjectInterfaceProperties(samplingUserBarge3LEDButton);
//        samplingUserBarge3LEDButton->Click +=
//            gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_SamplingStartStopUserBarge3ButtonClicked);
//        samplingControlsWindow->Controls->Add(samplingUserBarge3LEDButton);
//        //--------------------------------------------------------------------
//        // Start / Stop Sampling User Barge 4 button
//        //--------------------------------------------------------------------
//        samplingStartStopUserBarge4Button = gcnew Button;
//        samplingStartStopUserBarge4Button->Text = String::Concat(
//            _T("Start Sampling Barge "),
//            (pgInfo->userBargeNodeAddress4 ? String::Format("{0:X2}", pgInfo->userBargeNodeAddress4) : _T("XX")));
//        GUI_PositionAndSizeBelow(samplingStartStopUserBarge4Button, samplingStartStopUserBarge3Button, 10);
//        GUI_SetButtonInterfaceProperties(samplingStartStopUserBarge4Button);
//        samplingStartStopUserBarge4Button->Click +=
//            gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_SamplingStartStopUserBarge4ButtonClicked);
//        samplingStartStopUserBarge4Button->Enabled = GUI_NO;
//        samplingControlsWindow->Controls->Add(samplingStartStopUserBarge4Button);
//        //--------------------------------------------------------------------
//        // User Barge 4 Pressure label
//        //--------------------------------------------------------------------
//        samplingUserBarge4PressureLabel = gcnew Label;
//        samplingUserBarge4PressureLabel->Text = _T("--  --  --  --");
//        samplingUserBarge4PressureLabel->Font = gcnew Drawing::Font(
//            FontFamily::GenericSansSerif,
//            12.0F,
//            FontStyle::Bold);
//        GUI_PositionAndSizeBelow(samplingUserBarge4PressureLabel, samplingUserBarge3PressureLabel, 10);
//        samplingUserBarge4PressureLabel->BackColor = Color::Transparent;
//        samplingUserBarge4PressureLabel->TextAlign = Drawing::ContentAlignment::MiddleCenter;
//        samplingControlsWindow->Controls->Add(samplingUserBarge4PressureLabel);
//        //--------------------------------------------------------------------
//        // User Barge 4 Temperature label
//        //--------------------------------------------------------------------
//        samplingUserBarge4TemperatureLabel = gcnew Label;
//        samplingUserBarge4TemperatureLabel->Text = _T("--  --  --  --");
//        samplingUserBarge4TemperatureLabel->Font = gcnew Drawing::Font(
//            FontFamily::GenericSansSerif,
//            12.0F,
//            FontStyle::Bold);
//        GUI_PositionAndSizeBelow(samplingUserBarge4TemperatureLabel, samplingUserBarge3TemperatureLabel, 10);
//        samplingUserBarge4TemperatureLabel->BackColor = Color::Transparent;
//        samplingUserBarge4TemperatureLabel->TextAlign = Drawing::ContentAlignment::MiddleCenter;
//        samplingControlsWindow->Controls->Add(samplingUserBarge4TemperatureLabel);
//        //--------------------------------------------------------------------
//        // User Barge 4 LED
//        //--------------------------------------------------------------------
//        samplingUserBarge4LEDButton = gcnew Button;
//        samplingUserBarge4LEDButton->Location = Point(
//            samplingUserBarge3LEDButton->Left,
//            samplingStartStopUserBarge4Button->Top - 2);
//        samplingUserBarge4LEDButton->Size = samplingUserBarge3LEDButton->Size;
//        samplingUserBarge4LEDButton->BackgroundImage = yellowLEDOffImage;
//        samplingUserBarge4LEDButton->BackgroundImageLayout = ImageLayout::Center;
//        GUI_SetObjectInterfaceProperties(samplingUserBarge4LEDButton);
//        samplingUserBarge4LEDButton->Click +=
//            gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_SamplingStartStopUserBarge4ButtonClicked);
//        samplingControlsWindow->Controls->Add(samplingUserBarge4LEDButton);
//        //--------------------------------------------------------------------
//        // Start / Stop Sampling User Barge 5 button
//        //--------------------------------------------------------------------
//        samplingStartStopUserBarge5Button = gcnew Button;
//        samplingStartStopUserBarge5Button->Text = String::Concat(
//            _T("Start Sampling Barge "),
//            (pgInfo->userBargeNodeAddress5 ? String::Format("{0:X2}", pgInfo->userBargeNodeAddress5) : _T("XX")));
//        GUI_PositionAndSizeBelow(samplingStartStopUserBarge5Button, samplingStartStopUserBarge4Button, 10);
//        GUI_SetButtonInterfaceProperties(samplingStartStopUserBarge5Button);
//        samplingStartStopUserBarge5Button->Click +=
//            gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_SamplingStartStopUserBarge5ButtonClicked);
//        samplingStartStopUserBarge5Button->Enabled = GUI_NO;
//        samplingControlsWindow->Controls->Add(samplingStartStopUserBarge5Button);
//        //--------------------------------------------------------------------
//        // User Barge 5 Pressure label
//        //--------------------------------------------------------------------
//        samplingUserBarge5PressureLabel = gcnew Label;
//        samplingUserBarge5PressureLabel->Text = _T("--  --  --  --");
//        samplingUserBarge5PressureLabel->Font = gcnew Drawing::Font(
//            FontFamily::GenericSansSerif,
//            12.0F,
//            FontStyle::Bold);
//        GUI_PositionAndSizeBelow(samplingUserBarge5PressureLabel, samplingUserBarge4PressureLabel, 10);
//        samplingUserBarge5PressureLabel->BackColor = Color::Transparent;
//        samplingUserBarge5PressureLabel->TextAlign = Drawing::ContentAlignment::MiddleCenter;
//        samplingControlsWindow->Controls->Add(samplingUserBarge5PressureLabel);
//        //--------------------------------------------------------------------
//        // User Barge 5 Temperature label
//        //--------------------------------------------------------------------
//        samplingUserBarge5TemperatureLabel = gcnew Label;
//        samplingUserBarge5TemperatureLabel->Text = _T("--  --  --  --");
//        samplingUserBarge5TemperatureLabel->Font = gcnew Drawing::Font(
//            FontFamily::GenericSansSerif,
//            12.0F,
//            FontStyle::Bold);
//        GUI_PositionAndSizeBelow(samplingUserBarge5TemperatureLabel, samplingUserBarge4TemperatureLabel, 10);
//        samplingUserBarge5TemperatureLabel->BackColor = Color::Transparent;
//        samplingUserBarge5TemperatureLabel->TextAlign = Drawing::ContentAlignment::MiddleCenter;
//        samplingControlsWindow->Controls->Add(samplingUserBarge5TemperatureLabel);
//        //--------------------------------------------------------------------
//        // User Barge 5 LED
//        //--------------------------------------------------------------------
//        samplingUserBarge5LEDButton = gcnew Button;
//        samplingUserBarge5LEDButton->Location = Point(
//            samplingUserBarge4LEDButton->Left,
//            samplingStartStopUserBarge5Button->Top - 2);
//        samplingUserBarge5LEDButton->Size = samplingUserBarge4LEDButton->Size;
//        samplingUserBarge5LEDButton->BackgroundImage = yellowLEDOffImage;
//        samplingUserBarge5LEDButton->BackgroundImageLayout = ImageLayout::Center;
//        GUI_SetObjectInterfaceProperties(samplingUserBarge5LEDButton);
//        samplingUserBarge5LEDButton->Click +=
//            gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_SamplingStartStopUserBarge5ButtonClicked);
//        samplingControlsWindow->Controls->Add(samplingUserBarge5LEDButton);
//        //--------------------------------------------------------------------
//        // Start / Stop Sampling User Barge 6 button
//        //--------------------------------------------------------------------
//        samplingStartStopUserBarge6Button = gcnew Button;
//        samplingStartStopUserBarge6Button->Text = String::Concat(
//            _T("Start Sampling Barge "),
//            (pgInfo->userBargeNodeAddress6 ? String::Format("{0:X2}", pgInfo->userBargeNodeAddress6) : _T("XX")));
//        GUI_PositionAndSizeBelow(samplingStartStopUserBarge6Button, samplingStartStopUserBarge5Button, 10);
//        GUI_SetButtonInterfaceProperties(samplingStartStopUserBarge6Button);
//        samplingStartStopUserBarge6Button->Click +=
//            gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_SamplingStartStopUserBarge6ButtonClicked);
//        samplingStartStopUserBarge6Button->Enabled = GUI_NO;
//        samplingControlsWindow->Controls->Add(samplingStartStopUserBarge6Button);
//        //--------------------------------------------------------------------
//        // User Barge 6 Pressure label
//        //--------------------------------------------------------------------
//        samplingUserBarge6PressureLabel = gcnew Label;
//        samplingUserBarge6PressureLabel->Text = _T("--  --  --  --");
//        samplingUserBarge6PressureLabel->Font = gcnew Drawing::Font(
//            FontFamily::GenericSansSerif,
//            12.0F,
//            FontStyle::Bold);
//        GUI_PositionAndSizeBelow(samplingUserBarge6PressureLabel, samplingUserBarge5PressureLabel, 10);
//        samplingUserBarge6PressureLabel->BackColor = Color::Transparent;
//        samplingUserBarge6PressureLabel->TextAlign = Drawing::ContentAlignment::MiddleCenter;
//        samplingControlsWindow->Controls->Add(samplingUserBarge6PressureLabel);
//        //--------------------------------------------------------------------
//        // User Barge 6 Temperature label
//        //--------------------------------------------------------------------
//        samplingUserBarge6TemperatureLabel = gcnew Label;
//        samplingUserBarge6TemperatureLabel->Text = _T("--  --  --  --");
//        samplingUserBarge6TemperatureLabel->Font = gcnew Drawing::Font(
//            FontFamily::GenericSansSerif,
//            12.0F,
//            FontStyle::Bold);
//        GUI_PositionAndSizeBelow(samplingUserBarge6TemperatureLabel, samplingUserBarge5TemperatureLabel, 10);
//        samplingUserBarge6TemperatureLabel->BackColor = Color::Transparent;
//        samplingUserBarge6TemperatureLabel->TextAlign = Drawing::ContentAlignment::MiddleCenter;
//        samplingControlsWindow->Controls->Add(samplingUserBarge6TemperatureLabel);
//        //--------------------------------------------------------------------
//        // User Barge 6 LED
//        //--------------------------------------------------------------------
//        samplingUserBarge6LEDButton = gcnew Button;
//        samplingUserBarge6LEDButton->Location = Point(
//            samplingUserBarge5LEDButton->Left,
//            samplingStartStopUserBarge6Button->Top - 2);
//        samplingUserBarge6LEDButton->Size = samplingUserBarge5LEDButton->Size;
//        samplingUserBarge6LEDButton->BackgroundImage = yellowLEDOffImage;
//        samplingUserBarge6LEDButton->BackgroundImageLayout = ImageLayout::Center;
//        GUI_SetObjectInterfaceProperties(samplingUserBarge6LEDButton);
//        samplingUserBarge6LEDButton->Click +=
//            gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_SamplingStartStopUserBarge6ButtonClicked);
//        samplingControlsWindow->Controls->Add(samplingUserBarge6LEDButton);
        //--------------------------------------------------------------------
        // Record samples check box
        //--------------------------------------------------------------------
        CheckBox ^samplingRecordSamplesCheck = gcnew CheckBox;
        samplingRecordSamplesCheck->Text = _T("Record samples");
        samplingRecordSamplesCheck->Location = Point(
            samplingStopEverythingButton->Right + 12,
            samplingStopEverythingButton->Top + 5);
        samplingRecordSamplesCheck->Size = Drawing::Size(106, GUI_REGULAR_CHECK_BOX_HEIGHT);
        GUI_SetObjectInterfaceProperties(samplingRecordSamplesCheck);
        samplingRecordSamplesCheck->Click +=
            gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_SamplingRecordSamplesChecked);
        samplingControlsWindow->Controls->Add(samplingRecordSamplesCheck);
        //--------------------------------------------------------------------
        // Record samples check box tool tip
        //--------------------------------------------------------------------
        ToolTip ^samplingRecordSamplesCheckToolTip = gcnew ToolTip;
        samplingRecordSamplesCheckToolTip->ShowAlways = GUI_YES;
        samplingRecordSamplesCheckToolTip->AutoPopDelay = 10000;     // let stand for ten seconds
        samplingRecordSamplesCheckToolTip->ToolTipTitle =
            _T("Record Samples");
        String ^samplingRecordSamplesCheckToolTipText = String::Concat(
            "If checked, the software will record", Environment::NewLine,
            "the samples taken from the controls", Environment::NewLine,
            "on this window.");
        samplingRecordSamplesCheckToolTip->SetToolTip(samplingRecordSamplesCheck, samplingRecordSamplesCheckToolTipText);
        delete samplingRecordSamplesCheckToolTipText;
        //--------------------------------------------------------------------
        // Add a Hide button
        //--------------------------------------------------------------------
        Button ^samplingHideButton = gcnew Button;
        samplingHideButton->Font = gcnew Drawing::Font(
            FontFamily::GenericSansSerif,
            10.0F,
            FontStyle::Bold);
        samplingHideButton->Text = _T("Hide");
        samplingHideButton->Location = Point(
            samplingControlsWindow->Right - 100,
            samplingControlsWindow->Bottom - 70);
        samplingHideButton->Size = Drawing::Size(
            GUI_CLOSE_BUTTON_WIDTH,
            GUI_REGULAR_BUTTON_HEIGHT);
        GUI_SetButtonInterfaceProperties(samplingHideButton);
        samplingHideButton->DialogResult = System::Windows::Forms::DialogResult::OK;
        samplingHideButton->Click +=
            gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_SamplingControlsHideWindow);
        samplingControlsWindow->Controls->Add(samplingHideButton);
        //--------------------------------------------------------------------
        // Hide button tool tip
        //--------------------------------------------------------------------
        ToolTip ^samplingHideButtonToolTip = gcnew ToolTip;
        samplingHideButtonToolTip->ShowAlways = GUI_YES;
        samplingHideButtonToolTip->AutoPopDelay = 10000;   // let stand for ten seconds
        samplingHideButtonToolTip->ToolTipTitle =
            _T("Hide");
        String ^samplingHideButtonToolTipText = String::Concat(
            "Hides (not minimizes) the Sampling window,", Environment::NewLine,
            "which preserves the settings and allows the", Environment::NewLine,
            "sampling to continue running");
        samplingHideButtonToolTip->SetToolTip(samplingHideButton, samplingHideButtonToolTipText);
        delete samplingHideButtonToolTipText;
        //------------------------------------------------------------------------
        // Handle the closing of the window by any other way
        //------------------------------------------------------------------------
        samplingControlsWindow->FormClosing +=
            gcnew FormClosingEventHandler(this, &DTSTest_GUIClass::DTSTest_SamplingControlsClosingWindow);
        //--------------------------------------------------------------------
        // Set the remaining window properties
        //--------------------------------------------------------------------
        samplingControlsWindow->AcceptButton = samplingHideButton;
        samplingControlsWindow->CancelButton = samplingHideButton;
        //--------------------------------------------------------------------
        // Finally, hide the new window
        //--------------------------------------------------------------------
        samplingControlsWindow->ResumeLayout();
        samplingControlsWindow->Hide();
    }                                   // end of if (DTSTest_GeneralInfo)
    RecordBasicEvent("{0} concluded", functionName);
}                                       // end of DTSTest_SamplingControlsSetUpWindow()
//----------------------------------------------------------------------------
// DTSTest_SamplingRecordSamplesChecked
//
// Handles the check of the Record Samples box
//
// Called by:   DTSTest_SamplingControlsSetUpWindow
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_SamplingRecordSamplesChecked(
    Object          ^sender,
    EventArgs       ^evt)
{
    //------------------------------------------------------------------------
    DTSTest_RecordSamples = (DTSTest_RecordSamples ? GUI_NO : GUI_YES);
    RecordBasicEvent(
        "Record Samples {0}",
        (DTSTest_RecordSamples ? "checked" : "un-checked"));
}                                       // end of DTSTest_SamplingRecordSamplesChecked()
//----------------------------------------------------------------------------
// DTSTest_SamplingStartStopAllButtonClicked
//
// Handles the click of the Start / Stop Sampling All button
//
// Called by:   DTSTest_SamplingControlsSetUpWindow
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_SamplingStartStopAllButtonClicked(
    Object          ^sender,
    EventArgs       ^evt)
{
    PDGICInfo       ^pgInfo = DTSTest_GeneralInfo->pgInfo;
    //------------------------------------------------------------------------
    RecordBasicEvent("Start / Stop Sampling All button clicked");
    if (DTSTest_CurrentlySamplingAll)
    {
        while (DTSTest_RetrieveResponseContext)
            Thread::Sleep(10);
        DTSTest_SamplingRunning = GUI_NO;
        DTSTest_CurrentlySamplingAll = GUI_NO;
        samplingStartStopAllButton->Text = _T("Start Sampling All");
        DTSTest_CurrentlySamplingAllGauges = GUI_NO;
        samplingStartStopAllGaugesButton->Text = _T("Start Sampling All Gauges");
//        DTSTest_CurrentlySamplingGauge2D = GUI_NO;
//        samplingStartStopGauge2DButton->Text = _T("Start Sampling Gauge 2D");
//        samplingGauge2DLEDButton->BackgroundImage = yellowLEDOffImage;
//        DTSTest_CurrentlySamplingGauge3E = GUI_NO;
//        samplingStartStopGauge3EButton->Text = _T("Start Sampling Gauge 3E");
//        samplingGauge3ELEDButton->BackgroundImage = yellowLEDOffImage;
//        DTSTest_CurrentlySamplingAllBarges = GUI_NO;
//        samplingStartStopAllBargesButton->Text = _T("Start Sampling All Barges");
//        DTSTest_CurrentlySamplingBargeB4 = GUI_NO;
//        samplingStartStopBargeB4Button->Text = _T("Start Sampling Barge B4");
//        samplingBargeB4LEDButton->BackgroundImage = yellowLEDOffImage;
//        DTSTest_CurrentlySamplingBargeC9 = GUI_NO;
//        samplingStartStopBargeC9Button->Text = _T("Start Sampling Barge C9");
//        samplingBargeC9LEDButton->BackgroundImage = yellowLEDOffImage;
//        DTSTest_CurrentlySamplingBargeE2 = GUI_NO;
//        samplingStartStopBargeE2Button->Text = _T("Start Sampling Barge E2");
//        samplingBargeE2LEDButton->BackgroundImage = yellowLEDOffImage;
//        DTSTest_CurrentlySamplingBarge02 = GUI_NO;
//        samplingStartStopBarge02Button->Text = _T("Start Sampling Barge 02");
//        samplingBarge02LEDButton->BackgroundImage = yellowLEDOffImage;
//        DTSTest_CurrentlySamplingUserGauge1 = GUI_NO;
//        samplingStartStopUserGauge1Button->Text = String::Concat(
//            _T("Start Sampling Gauge "),
//            (pgInfo->userGaugeNodeAddress1 ? String::Format("{0:X2}", pgInfo->userGaugeNodeAddress1) : _T("XX")));
//        samplingUserGauge1LEDButton->BackgroundImage = yellowLEDOffImage;
//        DTSTest_CurrentlySamplingUserGauge2 = GUI_NO;
//        samplingStartStopUserGauge2Button->Text = String::Concat(
//            _T("Start Sampling Gauge "),
//            (pgInfo->userGaugeNodeAddress2 ? String::Format("{0:X2}", pgInfo->userGaugeNodeAddress2) : _T("XX")));
//        samplingUserGauge2LEDButton->BackgroundImage = yellowLEDOffImage;
//        DTSTest_CurrentlySamplingUserGauge3 = GUI_NO;
//        samplingStartStopUserGauge3Button->Text = String::Concat(
//            _T("Start Sampling Gauge "),
//            (pgInfo->userGaugeNodeAddress3 ? String::Format("{0:X2}", pgInfo->userGaugeNodeAddress3) : _T("XX")));
//        samplingUserGauge3LEDButton->BackgroundImage = yellowLEDOffImage;
//        DTSTest_CurrentlySamplingUserBarge1 = GUI_NO;
//        samplingStartStopUserBarge1Button->Text = String::Concat(
//            _T("Start Sampling Barge "),
//            (pgInfo->userBargeNodeAddress1 ? String::Format("{0:X2}", pgInfo->userBargeNodeAddress1) : _T("XX")));
//        samplingUserBarge1LEDButton->BackgroundImage = yellowLEDOffImage;
//        DTSTest_CurrentlySamplingUserBarge2 = GUI_NO;
//        samplingStartStopUserBarge2Button->Text = String::Concat(
//            _T("Start Sampling Barge "),
//            (pgInfo->userBargeNodeAddress2 ? String::Format("{0:X2}", pgInfo->userBargeNodeAddress2) : _T("XX")));
//        samplingUserBarge2LEDButton->BackgroundImage = yellowLEDOffImage;
//        DTSTest_CurrentlySamplingUserBarge3 = GUI_NO;
//        samplingStartStopUserBarge3Button->Text = String::Concat(
//            _T("Start Sampling Barge "),
//            (pgInfo->userBargeNodeAddress3 ? String::Format("{0:X2}", pgInfo->userBargeNodeAddress3) : _T("XX")));
//        samplingUserBarge3LEDButton->BackgroundImage = yellowLEDOffImage;
//        DTSTest_CurrentlySamplingUserBarge4 = GUI_NO;
//        samplingStartStopUserBarge4Button->Text = String::Concat(
//            _T("Start Sampling Barge "),
//            (pgInfo->userBargeNodeAddress4 ? String::Format("{0:X2}", pgInfo->userBargeNodeAddress4) : _T("XX")));
//        samplingUserBarge4LEDButton->BackgroundImage = yellowLEDOffImage;
//        DTSTest_CurrentlySamplingUserBarge5 = GUI_NO;
//        samplingStartStopUserBarge5Button->Text = String::Concat(
//            _T("Start Sampling Barge "),
//            (pgInfo->userBargeNodeAddress5 ? String::Format("{0:X2}", pgInfo->userBargeNodeAddress5) : _T("XX")));
//        samplingUserBarge5LEDButton->BackgroundImage = yellowLEDOffImage;
//        DTSTest_CurrentlySamplingUserBarge6 = GUI_NO;
//        samplingStartStopUserBarge6Button->Text = String::Concat(
//            _T("Start Sampling Barge "),
//            (pgInfo->userBargeNodeAddress6 ? String::Format("{0:X2}", pgInfo->userBargeNodeAddress6) : _T("XX")));
//        samplingUserBarge6LEDButton->BackgroundImage = yellowLEDOffImage;
        DTSTest_PDGICClosePersistentPort(pgInfo);
    }
    else
    {
        DTSTest_CurrentlySamplingAll = GUI_YES;
        samplingStartStopAllButton->Text = _T("Stop Sampling All");
        DTSTest_CurrentlySamplingAllGauges = GUI_YES;
        samplingStartStopAllGaugesButton->Text = _T("Stop Sampling All Gauges");
//        if (pgInfo->sensorInfoArray[DTSTEST_EXPERIMENTAL_GAUGE_2D_VALUE]->sensorPresent)
//        {
//            DTSTest_CurrentlySamplingGauge2D = GUI_YES;
//            samplingStartStopGauge2DButton->Text = _T("Stop Sampling Gauge 2D");
//            samplingGauge2DLEDButton->BackgroundImage = yellowLEDOnImage;
//        }
//        else
//        {
//            samplingGauge2DPressureLabel->Text = _T("Absent");
//            samplingGauge2DTemperatureLabel->Text = _T("Absent");
//        }
//        if (pgInfo->sensorInfoArray[DTSTEST_EXPERIMENTAL_GAUGE_3E_VALUE]->sensorPresent)
//        {
//            DTSTest_CurrentlySamplingGauge3E = GUI_YES;
//            samplingStartStopGauge3EButton->Text = _T("Stop Sampling Gauge 3E");
//            samplingGauge3ELEDButton->BackgroundImage = yellowLEDOnImage;
//        }
//        else
//        {
//            samplingGauge3EPressureLabel->Text = _T("Absent");
//            samplingGauge3ETemperatureLabel->Text = _T("Absent");
//        }
        DTSTest_CurrentlySamplingAllBarges = GUI_YES;
        samplingStartStopAllBargesButton->Text = _T("Stop Sampling All Barges");
//        if (pgInfo->sensorInfoArray[DTSTEST_EXPERIMENTAL_BARGE_B4_VALUE]->sensorPresent)
//        {
//            DTSTest_CurrentlySamplingBargeB4 = GUI_YES;
//            samplingStartStopBargeB4Button->Text = _T("Stop Sampling Barge B4");
//            samplingBargeB4LEDButton->BackgroundImage = yellowLEDOnImage;
//        }
//        else
//        {
//            samplingBargeB4PressureLabel->Text = _T("Absent");
//            samplingBargeB4TemperatureLabel->Text = _T("Absent");
//        }
//        if (pgInfo->sensorInfoArray[DTSTEST_EXPERIMENTAL_BARGE_C9_VALUE]->sensorPresent)
//        {
//            DTSTest_CurrentlySamplingBargeC9 = GUI_YES;
//            samplingStartStopBargeC9Button->Text = _T("Stop Sampling Barge C9");
//            samplingBargeC9LEDButton->BackgroundImage = yellowLEDOnImage;
//        }
//        else
//        {
//            samplingBargeC9PressureLabel->Text = _T("Absent");
//            samplingBargeC9TemperatureLabel->Text = _T("Absent");
//        }
//        if (pgInfo->sensorInfoArray[DTSTEST_EXPERIMENTAL_BARGE_E2_VALUE]->sensorPresent)
//        {
//            DTSTest_CurrentlySamplingBargeE2 = GUI_YES;
//            samplingStartStopBargeE2Button->Text = _T("Stop Sampling Barge E2");
//            samplingBargeE2LEDButton->BackgroundImage = yellowLEDOnImage;
//        }
//        else
//        {
//            samplingBargeE2PressureLabel->Text = _T("Absent");
//            samplingBargeE2TemperatureLabel->Text = _T("Absent");
//        }
//        if (pgInfo->sensorInfoArray[DTSTEST_EXPERIMENTAL_BARGE_02_VALUE]->sensorPresent)
//        {
//            DTSTest_CurrentlySamplingBarge02 = GUI_YES;
//            samplingStartStopBarge02Button->Text = _T("Stop Sampling Barge 02");
//            samplingBarge02LEDButton->BackgroundImage = yellowLEDOnImage;
//        }
//        else
//        {
//            samplingBarge02PressureLabel->Text = _T("Absent");
//            samplingBarge02TemperatureLabel->Text = _T("Absent");
//        }
//        if (pgInfo->sensorInfoArray[pgInfo->userGaugeNodeAddress1]->sensorPresent)
//        {
//            DTSTest_CurrentlySamplingUserGauge1 = GUI_YES;
//            samplingStartStopUserGauge1Button->Text = String::Concat(
//                _T("Stop Sampling Gauge "),
//                (pgInfo->userGaugeNodeAddress1 ? String::Format("{0:X2}", pgInfo->userGaugeNodeAddress1) : _T("XX")));
//            samplingUserGauge1LEDButton->BackgroundImage = yellowLEDOnImage;
//        }
//        else
//        {
//            samplingUserGauge1PressureLabel->Text = _T("Absent");
//            samplingUserGauge1TemperatureLabel->Text = _T("Absent");
//        }
//        if (pgInfo->sensorInfoArray[pgInfo->userGaugeNodeAddress2]->sensorPresent)
//        {
//            DTSTest_CurrentlySamplingUserGauge2 = GUI_YES;
//            samplingStartStopUserGauge2Button->Text = String::Concat(
//                _T("Stop Sampling Gauge "),
//                (pgInfo->userGaugeNodeAddress2 ? String::Format("{0:X2}", pgInfo->userGaugeNodeAddress2) : _T("XX")));
//            samplingUserGauge2LEDButton->BackgroundImage = yellowLEDOnImage;
//        }
//        else
//        {
//            samplingUserGauge2PressureLabel->Text = _T("Absent");
//            samplingUserGauge2TemperatureLabel->Text = _T("Absent");
//        }
//        if (pgInfo->sensorInfoArray[pgInfo->userGaugeNodeAddress3]->sensorPresent)
//        {
//            DTSTest_CurrentlySamplingUserGauge3 = GUI_YES;
//            samplingStartStopUserGauge3Button->Text = String::Concat(
//                _T("Stop Sampling Gauge "),
//                (pgInfo->userGaugeNodeAddress3 ? String::Format("{0:X2}", pgInfo->userGaugeNodeAddress3) : _T("XX")));
//            samplingUserGauge3LEDButton->BackgroundImage = yellowLEDOnImage;
//        }
//        else
//        {
//            samplingUserGauge3PressureLabel->Text = _T("Absent");
//            samplingUserGauge3TemperatureLabel->Text = _T("Absent");
//        }
//        if (pgInfo->sensorInfoArray[pgInfo->userBargeNodeAddress1]->sensorPresent)
//        {
//            DTSTest_CurrentlySamplingUserBarge1 = GUI_YES;
//            samplingStartStopUserBarge1Button->Text = String::Concat(
//                _T("Stop Sampling Barge "),
//                (pgInfo->userBargeNodeAddress1 ? String::Format("{0:X2}", pgInfo->userBargeNodeAddress1) : _T("XX")));
//            samplingUserBarge1LEDButton->BackgroundImage = yellowLEDOnImage;
//        }
//        else
//        {
//            samplingUserBarge1PressureLabel->Text = _T("Absent");
//            samplingUserBarge1TemperatureLabel->Text = _T("Absent");
//        }
//        if (pgInfo->sensorInfoArray[pgInfo->userBargeNodeAddress2]->sensorPresent)
//        {
//            DTSTest_CurrentlySamplingUserBarge2 = GUI_YES;
//            samplingStartStopUserBarge2Button->Text = String::Concat(
//                _T("Stop Sampling Barge "),
//                (pgInfo->userBargeNodeAddress2 ? String::Format("{0:X2}", pgInfo->userBargeNodeAddress2) : _T("XX")));
//            samplingUserBarge2LEDButton->BackgroundImage = yellowLEDOnImage;
//        }
//        else
//        {
//            samplingUserBarge2PressureLabel->Text = _T("Absent");
//            samplingUserBarge2TemperatureLabel->Text = _T("Absent");
//        }
//        if (pgInfo->sensorInfoArray[pgInfo->userBargeNodeAddress3]->sensorPresent)
//        {
//            DTSTest_CurrentlySamplingUserBarge3 = GUI_YES;
//            samplingStartStopUserBarge3Button->Text = String::Concat(
//                _T("Stop Sampling Barge "),
//                (pgInfo->userBargeNodeAddress3 ? String::Format("{0:X2}", pgInfo->userBargeNodeAddress3) : _T("XX")));
//            samplingUserBarge3LEDButton->BackgroundImage = yellowLEDOnImage;
//        }
//        else
//        {
//            samplingUserBarge3PressureLabel->Text = _T("Absent");
//            samplingUserBarge3TemperatureLabel->Text = _T("Absent");
//        }
//        if (pgInfo->sensorInfoArray[pgInfo->userBargeNodeAddress4]->sensorPresent)
//        {
//            DTSTest_CurrentlySamplingUserBarge4 = GUI_YES;
//            samplingStartStopUserBarge4Button->Text = String::Concat(
//                _T("Stop Sampling Barge "),
//                (pgInfo->userBargeNodeAddress4 ? String::Format("{0:X2}", pgInfo->userBargeNodeAddress4) : _T("XX")));
//            samplingUserBarge4LEDButton->BackgroundImage = yellowLEDOnImage;
//        }
//        else
//        {
//            samplingUserBarge4PressureLabel->Text = _T("Absent");
//            samplingUserBarge4TemperatureLabel->Text = _T("Absent");
//        }
//        if (pgInfo->sensorInfoArray[pgInfo->userBargeNodeAddress5]->sensorPresent)
//        {
//            DTSTest_CurrentlySamplingUserBarge5 = GUI_YES;
//            samplingStartStopUserBarge5Button->Text = String::Concat(
//                _T("Stop Sampling Barge "),
//                (pgInfo->userBargeNodeAddress5 ? String::Format("{0:X2}", pgInfo->userBargeNodeAddress5) : _T("XX")));
//            samplingUserBarge5LEDButton->BackgroundImage = yellowLEDOnImage;
//        }
//        else
//        {
//            samplingUserBarge5PressureLabel->Text = _T("Absent");
//            samplingUserBarge5TemperatureLabel->Text = _T("Absent");
//        }
//        if (pgInfo->sensorInfoArray[pgInfo->userBargeNodeAddress6]->sensorPresent)
//        {
//            DTSTest_CurrentlySamplingUserBarge6 = GUI_YES;
//            samplingStartStopUserBarge6Button->Text = String::Concat(
//                _T("Stop Sampling Barge "),
//                (pgInfo->userBargeNodeAddress6 ? String::Format("{0:X2}", pgInfo->userBargeNodeAddress6) : _T("XX")));
//            samplingUserBarge6LEDButton->BackgroundImage = yellowLEDOnImage;
//        }
//        else
//        {
//            samplingUserBarge6PressureLabel->Text = _T("Absent");
//            samplingUserBarge6TemperatureLabel->Text = _T("Absent");
//        }
        DTSTest_PDGICOpenPersistentPort(pgInfo);
        //--------------------------------------------------------------------
        // Start the background process that samples forever
        //--------------------------------------------------------------------
        samplingEntryBackground->RunWorkerAsync();
    }
}                                       // end of DTSTest_SamplingStartStopAllButtonClicked()
//----------------------------------------------------------------------------
// DTSTest_SamplingStartStopAllBargesButtonClicked
//
// Handles the click of the Start / Stop Sampling All Barges button
//
// Called by:   DTSTest_SamplingControlsSetUpWindow
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_SamplingStartStopAllBargesButtonClicked(
    Object          ^sender,
    EventArgs       ^evt)
{
    PDGICInfo       ^pgInfo = DTSTest_GeneralInfo->pgInfo;
    //------------------------------------------------------------------------
    RecordBasicEvent("Start / Stop Sampling All Barges button clicked");
    if (DTSTest_CurrentlySamplingAllBarges)
    {
        while (DTSTest_RetrieveResponseContext)
            Thread::Sleep(10);
        DTSTest_SamplingRunning = GUI_NO;
        DTSTest_CurrentlySamplingAllBarges = GUI_NO;
        samplingStartStopAllBargesButton->Text = _T("Start Sampling All Barges");
//        DTSTest_CurrentlySamplingBargeB4 = GUI_NO;
//        samplingStartStopBargeB4Button->Text = _T("Start Sampling Barge B4");
//        samplingBargeB4LEDButton->BackgroundImage = yellowLEDOffImage;
//        DTSTest_CurrentlySamplingBargeC9 = GUI_NO;
//        samplingStartStopBargeC9Button->Text = _T("Start Sampling Barge C9");
//        samplingBargeC9LEDButton->BackgroundImage = yellowLEDOffImage;
//        DTSTest_CurrentlySamplingBargeE2 = GUI_NO;
//        samplingStartStopBargeE2Button->Text = _T("Start Sampling Barge E2");
//        samplingBargeE2LEDButton->BackgroundImage = yellowLEDOffImage;
//        DTSTest_CurrentlySamplingBarge02 = GUI_NO;
//        samplingStartStopBarge02Button->Text = _T("Start Sampling Barge 02");
//        samplingBarge02LEDButton->BackgroundImage = yellowLEDOffImage;
//        DTSTest_CurrentlySamplingUserGauge1 = GUI_NO;
//        DTSTest_CurrentlySamplingUserBarge1 = GUI_NO;
//        samplingStartStopUserBarge1Button->Text = String::Concat(
//            _T("Start Sampling Barge "),
//            (pgInfo->userBargeNodeAddress1 ? String::Format("{0:X2}", pgInfo->userBargeNodeAddress1) : _T("XX")));
//        samplingUserBarge1LEDButton->BackgroundImage = yellowLEDOffImage;
//        DTSTest_CurrentlySamplingUserBarge2 = GUI_NO;
//        samplingStartStopUserBarge2Button->Text = String::Concat(
//            _T("Start Sampling Barge "),
//            (pgInfo->userBargeNodeAddress2 ? String::Format("{0:X2}", pgInfo->userBargeNodeAddress2) : _T("XX")));
//        samplingUserBarge2LEDButton->BackgroundImage = yellowLEDOffImage;
//        DTSTest_CurrentlySamplingUserBarge3 = GUI_NO;
//        samplingStartStopUserBarge3Button->Text = String::Concat(
//            _T("Start Sampling Barge "),
//            (pgInfo->userBargeNodeAddress3 ? String::Format("{0:X2}", pgInfo->userBargeNodeAddress3) : _T("XX")));
//        samplingUserBarge3LEDButton->BackgroundImage = yellowLEDOffImage;
//        DTSTest_CurrentlySamplingUserBarge4 = GUI_NO;
//        samplingStartStopUserBarge4Button->Text = String::Concat(
//            _T("Start Sampling Barge "),
//            (pgInfo->userBargeNodeAddress4 ? String::Format("{0:X2}", pgInfo->userBargeNodeAddress4) : _T("XX")));
//        samplingUserBarge4LEDButton->BackgroundImage = yellowLEDOffImage;
//        DTSTest_CurrentlySamplingUserBarge5 = GUI_NO;
//        samplingStartStopUserBarge5Button->Text = String::Concat(
//            _T("Start Sampling Barge "),
//            (pgInfo->userBargeNodeAddress5 ? String::Format("{0:X2}", pgInfo->userBargeNodeAddress5) : _T("XX")));
//        samplingUserBarge5LEDButton->BackgroundImage = yellowLEDOffImage;
//        DTSTest_CurrentlySamplingUserBarge6 = GUI_NO;
//        samplingStartStopUserBarge6Button->Text = String::Concat(
//            _T("Start Sampling Barge "),
//            (pgInfo->userBargeNodeAddress6 ? String::Format("{0:X2}", pgInfo->userBargeNodeAddress6) : _T("XX")));
//        samplingUserBarge6LEDButton->BackgroundImage = yellowLEDOffImage;
        DTSTest_PDGICClosePersistentPort(pgInfo);
    }
    else
    {
        DTSTest_CurrentlySamplingAllBarges = GUI_YES;
        samplingStartStopAllBargesButton->Text = _T("Stop Sampling All Barges");
//        if (pgInfo->sensorInfoArray[DTSTEST_EXPERIMENTAL_BARGE_B4_VALUE]->sensorPresent)
//        {
//            DTSTest_CurrentlySamplingBargeB4 = GUI_YES;
//            samplingStartStopBargeB4Button->Text = _T("Stop Sampling Barge B4");
//            samplingBargeB4LEDButton->BackgroundImage = yellowLEDOnImage;
//        }
//        else
//        {
//            samplingBargeB4PressureLabel->Text = _T("Absent");
//            samplingBargeB4TemperatureLabel->Text = _T("Absent");
//        }
//        if (pgInfo->sensorInfoArray[DTSTEST_EXPERIMENTAL_BARGE_C9_VALUE]->sensorPresent)
//        {
//            DTSTest_CurrentlySamplingBargeC9 = GUI_YES;
//            samplingStartStopBargeC9Button->Text = _T("Stop Sampling Barge C9");
//            samplingBargeC9LEDButton->BackgroundImage = yellowLEDOnImage;
//        }
//        else
//        {
//            samplingBargeC9PressureLabel->Text = _T("Absent");
//            samplingBargeC9TemperatureLabel->Text = _T("Absent");
//        }
//        if (pgInfo->sensorInfoArray[DTSTEST_EXPERIMENTAL_BARGE_E2_VALUE]->sensorPresent)
//        {
//            DTSTest_CurrentlySamplingBargeE2 = GUI_YES;
//            samplingStartStopBargeE2Button->Text = _T("Stop Sampling Barge E2");
//            samplingBargeE2LEDButton->BackgroundImage = yellowLEDOnImage;
//        }
//        else
//        {
//            samplingBargeE2PressureLabel->Text = _T("Absent");
//            samplingBargeE2TemperatureLabel->Text = _T("Absent");
//        }
//        if (pgInfo->sensorInfoArray[DTSTEST_EXPERIMENTAL_BARGE_02_VALUE]->sensorPresent)
//        {
//            DTSTest_CurrentlySamplingBarge02 = GUI_YES;
//            samplingStartStopBarge02Button->Text = _T("Stop Sampling Barge 02");
//            samplingBarge02LEDButton->BackgroundImage = yellowLEDOnImage;
//        }
//        else
//        {
//            samplingBarge02PressureLabel->Text = _T("Absent");
//            samplingBarge02TemperatureLabel->Text = _T("Absent");
//        }
//        if (pgInfo->sensorInfoArray[pgInfo->userBargeNodeAddress1]->sensorPresent)
//        {
//            DTSTest_CurrentlySamplingUserBarge1 = GUI_YES;
//            samplingStartStopUserBarge1Button->Text = String::Concat(
//                _T("Stop Sampling Barge "),
//                (pgInfo->userBargeNodeAddress1 ? String::Format("{0:X2}", pgInfo->userBargeNodeAddress1) : _T("XX")));
//            samplingUserBarge1LEDButton->BackgroundImage = yellowLEDOnImage;
//        }
//        else
//        {
//            samplingUserBarge1PressureLabel->Text = _T("Absent");
//            samplingUserBarge1TemperatureLabel->Text = _T("Absent");
//        }
//        if (pgInfo->sensorInfoArray[pgInfo->userBargeNodeAddress2]->sensorPresent)
//        {
//            DTSTest_CurrentlySamplingUserBarge2 = GUI_YES;
//            samplingStartStopUserBarge2Button->Text = String::Concat(
//                _T("Stop Sampling Barge "),
//                (pgInfo->userBargeNodeAddress2 ? String::Format("{0:X2}", pgInfo->userBargeNodeAddress2) : _T("XX")));
//            samplingUserBarge2LEDButton->BackgroundImage = yellowLEDOnImage;
//        }
//        else
//        {
//            samplingUserBarge2PressureLabel->Text = _T("Absent");
//            samplingUserBarge2TemperatureLabel->Text = _T("Absent");
//        }
//        if (pgInfo->sensorInfoArray[pgInfo->userBargeNodeAddress3]->sensorPresent)
//        {
//            DTSTest_CurrentlySamplingUserBarge3 = GUI_YES;
//            samplingStartStopUserBarge3Button->Text = String::Concat(
//                _T("Stop Sampling Barge "),
//                (pgInfo->userBargeNodeAddress3 ? String::Format("{0:X2}", pgInfo->userBargeNodeAddress3) : _T("XX")));
//            samplingUserBarge3LEDButton->BackgroundImage = yellowLEDOnImage;
//        }
//        else
//        {
//            samplingUserBarge3PressureLabel->Text = _T("Absent");
//            samplingUserBarge3TemperatureLabel->Text = _T("Absent");
//        }
//        if (pgInfo->sensorInfoArray[pgInfo->userBargeNodeAddress4]->sensorPresent)
//        {
//            DTSTest_CurrentlySamplingUserBarge4 = GUI_YES;
//            samplingStartStopUserBarge4Button->Text = String::Concat(
//                _T("Stop Sampling Barge "),
//                (pgInfo->userBargeNodeAddress4 ? String::Format("{0:X2}", pgInfo->userBargeNodeAddress4) : _T("XX")));
//            samplingUserBarge4LEDButton->BackgroundImage = yellowLEDOnImage;
//        }
//        else
//        {
//            samplingUserBarge4PressureLabel->Text = _T("Absent");
//            samplingUserBarge4TemperatureLabel->Text = _T("Absent");
//        }
//        if (pgInfo->sensorInfoArray[pgInfo->userBargeNodeAddress5]->sensorPresent)
//        {
//            DTSTest_CurrentlySamplingUserBarge5 = GUI_YES;
//            samplingStartStopUserBarge5Button->Text = String::Concat(
//                _T("Stop Sampling Barge "),
//                (pgInfo->userBargeNodeAddress5 ? String::Format("{0:X2}", pgInfo->userBargeNodeAddress5) : _T("XX")));
//            samplingUserBarge5LEDButton->BackgroundImage = yellowLEDOnImage;
//        }
//        else
//        {
//            samplingUserBarge5PressureLabel->Text = _T("Absent");
//            samplingUserBarge5TemperatureLabel->Text = _T("Absent");
//        }
//        if (pgInfo->sensorInfoArray[pgInfo->userBargeNodeAddress6]->sensorPresent)
//        {
//            DTSTest_CurrentlySamplingUserBarge6 = GUI_YES;
//            samplingStartStopUserBarge6Button->Text = String::Concat(
//                _T("Stop Sampling Barge "),
//                (pgInfo->userBargeNodeAddress6 ? String::Format("{0:X2}", pgInfo->userBargeNodeAddress6) : _T("XX")));
//            samplingUserBarge6LEDButton->BackgroundImage = yellowLEDOnImage;
//        }
//        else
//        {
//            samplingUserBarge6PressureLabel->Text = _T("Absent");
//            samplingUserBarge6TemperatureLabel->Text = _T("Absent");
//        }
        DTSTest_PDGICOpenPersistentPort(pgInfo);
        //--------------------------------------------------------------------
        // Start the background process that samples forever
        //--------------------------------------------------------------------
        samplingEntryBackground->RunWorkerAsync();
    }
}                                       // end of DTSTest_SamplingStartStopAllBargesButtonClicked()
//----------------------------------------------------------------------------
// DTSTest_SamplingStartStopAllGaugesButtonClicked
//
// Handles the click of the Start / Stop Sampling All Gauges button
//
// Called by:   DTSTest_SamplingControlsSetUpWindow
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_SamplingStartStopAllGaugesButtonClicked(
    Object          ^sender,
    EventArgs       ^evt)
{
    PDGICInfo       ^pgInfo = DTSTest_GeneralInfo->pgInfo;
    //------------------------------------------------------------------------
    RecordBasicEvent("Start / Stop Sampling All Gauges button clicked");
    if (DTSTest_CurrentlySamplingAllGauges)
    {
        while (DTSTest_RetrieveResponseContext)
            Thread::Sleep(10);
        DTSTest_SamplingRunning = GUI_NO;
        DTSTest_CurrentlySamplingAllGauges = GUI_NO;
        samplingStartStopAllGaugesButton->Text = _T("Start Sampling All Gauges");
//        DTSTest_CurrentlySamplingGauge2D = GUI_NO;
//        samplingStartStopGauge2DButton->Text = _T("Start Sampling Gauge 2D");
//        samplingGauge2DLEDButton->BackgroundImage = yellowLEDOffImage;
//        DTSTest_CurrentlySamplingGauge3E = GUI_NO;
//        samplingStartStopGauge3EButton->Text = _T("Start Sampling Gauge 3E");
//        samplingGauge3ELEDButton->BackgroundImage = yellowLEDOffImage;
//        DTSTest_CurrentlySamplingUserGauge1 = GUI_NO;
//        samplingStartStopUserGauge1Button->Text = String::Concat(
//            _T("Start Sampling Gauge "),
//            (pgInfo->userGaugeNodeAddress1 ? String::Format("{0:X2}", pgInfo->userGaugeNodeAddress1) : _T("XX")));
//        samplingUserGauge1LEDButton->BackgroundImage = yellowLEDOffImage;
//        DTSTest_CurrentlySamplingUserGauge2 = GUI_NO;
//        samplingStartStopUserGauge2Button->Text = String::Concat(
//            _T("Start Sampling Gauge "),
//            (pgInfo->userGaugeNodeAddress2 ? String::Format("{0:X2}", pgInfo->userGaugeNodeAddress2) : _T("XX")));
//        samplingUserGauge2LEDButton->BackgroundImage = yellowLEDOffImage;
//        DTSTest_CurrentlySamplingUserGauge3 = GUI_NO;
//        samplingStartStopUserGauge3Button->Text = String::Concat(
//            _T("Start Sampling Gauge "),
//            (pgInfo->userGaugeNodeAddress3 ? String::Format("{0:X2}", pgInfo->userGaugeNodeAddress3) : _T("XX")));
//        samplingUserGauge3LEDButton->BackgroundImage = yellowLEDOffImage;
        DTSTest_PDGICClosePersistentPort(pgInfo);
    }
    else
    {
        DTSTest_CurrentlySamplingAllGauges = GUI_YES;
        samplingStartStopAllGaugesButton->Text = _T("Stop Sampling All Gauges");
//        if (pgInfo->sensorInfoArray[DTSTEST_EXPERIMENTAL_GAUGE_2D_VALUE]->sensorPresent)
//        {
//            DTSTest_CurrentlySamplingGauge2D = GUI_YES;
//            samplingStartStopGauge2DButton->Text = _T("Stop Sampling Gauge 2D");
//            samplingGauge2DLEDButton->BackgroundImage = yellowLEDOnImage;
//        }
//        else
//        {
//            samplingGauge2DPressureLabel->Text = _T("Absent");
//            samplingGauge2DTemperatureLabel->Text = _T("Absent");
//        }
//        if (pgInfo->sensorInfoArray[DTSTEST_EXPERIMENTAL_GAUGE_3E_VALUE]->sensorPresent)
//        {
//            DTSTest_CurrentlySamplingGauge3E = GUI_YES;
//            samplingStartStopGauge3EButton->Text = _T("Stop Sampling Gauge 3E");
//            samplingGauge3ELEDButton->BackgroundImage = yellowLEDOnImage;
////            samplingGauge3ETimer->Start();
//        }
//        else
//        {
//            samplingGauge3EPressureLabel->Text = _T("Absent");
//            samplingGauge3ETemperatureLabel->Text = _T("Absent");
//        }
//        if (pgInfo->sensorInfoArray[pgInfo->userGaugeNodeAddress1]->sensorPresent)
//        {
//            DTSTest_CurrentlySamplingUserGauge1 = GUI_YES;
//            samplingStartStopUserGauge1Button->Text = String::Concat(
//                _T("Stop Sampling Gauge "),
//                (pgInfo->userGaugeNodeAddress1 ? String::Format("{0:X2}", pgInfo->userGaugeNodeAddress1) : _T("XX")));
//            samplingUserGauge1LEDButton->BackgroundImage = yellowLEDOnImage;
//        }
//        else
//        {
//            samplingUserGauge1PressureLabel->Text = _T("Absent");
//            samplingUserGauge1TemperatureLabel->Text = _T("Absent");
//        }
//        if (pgInfo->sensorInfoArray[pgInfo->userGaugeNodeAddress2]->sensorPresent)
//        {
//            DTSTest_CurrentlySamplingUserGauge2 = GUI_YES;
//            samplingStartStopUserGauge2Button->Text = String::Concat(
//                _T("Stop Sampling Gauge "),
//                (pgInfo->userGaugeNodeAddress2 ? String::Format("{0:X2}", pgInfo->userGaugeNodeAddress2) : _T("XX")));
//            samplingUserGauge2LEDButton->BackgroundImage = yellowLEDOnImage;
//        }
//        else
//        {
//            samplingUserGauge2PressureLabel->Text = _T("Absent");
//            samplingUserGauge2TemperatureLabel->Text = _T("Absent");
//        }
//        if (pgInfo->sensorInfoArray[pgInfo->userGaugeNodeAddress3]->sensorPresent)
//        {
//            DTSTest_CurrentlySamplingUserGauge3 = GUI_YES;
//            samplingStartStopUserGauge3Button->Text = String::Concat(
//                _T("Stop Sampling Gauge "),
//                (pgInfo->userGaugeNodeAddress3 ? String::Format("{0:X2}", pgInfo->userGaugeNodeAddress3) : _T("XX")));
//            samplingUserGauge3LEDButton->BackgroundImage = yellowLEDOnImage;
//        }
//        else
//        {
//            samplingUserGauge3PressureLabel->Text = _T("Absent");
//            samplingUserGauge3TemperatureLabel->Text = _T("Absent");
//        }
        DTSTest_PDGICOpenPersistentPort(pgInfo);
        //--------------------------------------------------------------------
        // Start the background process that samples forever
        //--------------------------------------------------------------------
        samplingEntryBackground->RunWorkerAsync();
    }
}                                       // end of DTSTest_SamplingStartStopAllGaugesButtonClicked()
////----------------------------------------------------------------------------
//// DTSTest_SamplingStartStopGauge2DButtonClicked
////
//// Handles the click of the Start / Stop Sampling Gauge 2D button
////
//// Called by:   DTSTest_SamplingControlsSetUpWindow
////----------------------------------------------------------------------------
//    void DTSTest_GUIClass::
//DTSTest_SamplingStartStopGauge2DButtonClicked(
//    Object          ^sender,
//    EventArgs       ^evt)
//{
//    PDGICInfo       ^pgInfo = DTSTest_GeneralInfo->pgInfo;
//    //------------------------------------------------------------------------
//    RecordBasicEvent("Start / Stop Sampling Gauge 2D button clicked");
//    if (DTSTest_CurrentlySamplingGauge2D)
//    {
//        while (DTSTest_RetrieveResponseContext)
//            Thread::Sleep(10);
//        DTSTest_SamplingRunning = GUI_NO;
//        DTSTest_CurrentlySamplingGauge2D = GUI_NO;
//        samplingStartStopGauge2DButton->Text = _T("Start Sampling Gauge 2D");
//        samplingGauge2DLEDButton->BackgroundImage = yellowLEDOffImage;
//        DTSTest_PDGICClosePersistentPort(pgInfo);
//    }
//    else
//    {
//        DTSTest_CurrentlySamplingGauge2D = GUI_YES;
//        samplingStartStopGauge2DButton->Text = _T("Stop Sampling Gauge 2D");
//        samplingGauge2DLEDButton->BackgroundImage = yellowLEDOnImage;
//        DTSTest_PDGICOpenPersistentPort(pgInfo);
//        //--------------------------------------------------------------------
//        // Start the background process that samples forever
//        //--------------------------------------------------------------------
//        samplingEntryBackground->RunWorkerAsync();
//    }
//}                                       // end of DTSTest_SamplingStartStopGauge2DButtonClicked()
////----------------------------------------------------------------------------
//// DTSTest_SamplingStartStopGauge3EButtonClicked
////
//// Handles the click of the Start / Stop Sampling Gauge 3E button
////
//// Called by:   DTSTest_SamplingControlsSetUpWindow
////----------------------------------------------------------------------------
//    void DTSTest_GUIClass::
//DTSTest_SamplingStartStopGauge3EButtonClicked(
//    Object          ^sender,
//    EventArgs       ^evt)
//{
//    PDGICInfo       ^pgInfo = DTSTest_GeneralInfo->pgInfo;
//    //------------------------------------------------------------------------
//    RecordBasicEvent("Start / Stop Sampling Gauge 3E button clicked");
//    if (DTSTest_CurrentlySamplingGauge3E)
//    {
//        while (DTSTest_RetrieveResponseContext)
//            Thread::Sleep(10);
//        DTSTest_SamplingRunning = GUI_NO;
//        DTSTest_CurrentlySamplingGauge3E = GUI_NO;
//        samplingStartStopGauge3EButton->Text = _T("Start Sampling Gauge 3E");
//        samplingGauge3ELEDButton->BackgroundImage = yellowLEDOffImage;
//        DTSTest_PDGICClosePersistentPort(pgInfo);
//    }
//    else
//    {
//        DTSTest_CurrentlySamplingGauge3E = GUI_YES;
//        samplingStartStopGauge3EButton->Text = _T("Stop Sampling Gauge 3E");
//        samplingGauge3ELEDButton->BackgroundImage = yellowLEDOnImage;
//        DTSTest_PDGICOpenPersistentPort(pgInfo);
//    }
//}                                       // end of DTSTest_SamplingStartStopGauge3EButtonClicked()
////----------------------------------------------------------------------------
//// DTSTest_SamplingStartStopBarge02ButtonClicked
////
//// Handles the click of the Start / Stop Sampling Barge 02 button
////
//// Called by:   DTSTest_SamplingControlsSetUpWindow
////----------------------------------------------------------------------------
//    void DTSTest_GUIClass::
//DTSTest_SamplingStartStopBarge02ButtonClicked(
//    Object          ^sender,
//    EventArgs       ^evt)
//{
//    PDGICInfo       ^pgInfo = DTSTest_GeneralInfo->pgInfo;
//    //------------------------------------------------------------------------
//    RecordBasicEvent("Start / Stop Sampling Gauge 02 button clicked");
//    if (DTSTest_CurrentlySamplingBarge02)
//    {
//        while (DTSTest_RetrieveResponseContext)
//            Thread::Sleep(10);
//        DTSTest_SamplingRunning = GUI_NO;
//        DTSTest_CurrentlySamplingBarge02 = GUI_NO;
//        samplingStartStopBarge02Button->Text = _T("Start Sampling Barge 02");
//        samplingBarge02LEDButton->BackgroundImage = yellowLEDOffImage;
//        DTSTest_PDGICClosePersistentPort(pgInfo);
//    }
//    else
//    {
//        DTSTest_CurrentlySamplingBarge02 = GUI_YES;
//        samplingStartStopBarge02Button->Text = _T("Stop Sampling Barge 02");
//        samplingBarge02LEDButton->BackgroundImage = yellowLEDOnImage;
//        DTSTest_PDGICOpenPersistentPort(pgInfo);
//        //--------------------------------------------------------------------
//        // Start the background process that samples forever
//        //--------------------------------------------------------------------
//        samplingEntryBackground->RunWorkerAsync();
//    }
//}                                       // end of DTSTest_SamplingStartStopBarge02ButtonClicked()
////----------------------------------------------------------------------------
//// DTSTest_SamplingStartStopBargeB4ButtonClicked
////
//// Handles the click of the Start / Stop Sampling Barge B4 button
////
//// Called by:   DTSTest_SamplingControlsSetUpWindow
////----------------------------------------------------------------------------
//    void DTSTest_GUIClass::
//DTSTest_SamplingStartStopBargeB4ButtonClicked(
//    Object          ^sender,
//    EventArgs       ^evt)
//{
//    PDGICInfo       ^pgInfo = DTSTest_GeneralInfo->pgInfo;
//    //------------------------------------------------------------------------
//    RecordBasicEvent("Start / Stop Sampling Gauge B4 button clicked");
//    if (DTSTest_CurrentlySamplingBargeB4)
//    {
//        while (DTSTest_RetrieveResponseContext)
//            Thread::Sleep(10);
//        DTSTest_SamplingRunning = GUI_NO;
//        DTSTest_CurrentlySamplingBargeB4 = GUI_NO;
//        samplingStartStopBargeB4Button->Text = _T("Start Sampling Barge B4");
//        samplingBargeB4LEDButton->BackgroundImage = yellowLEDOffImage;
//        DTSTest_PDGICClosePersistentPort(pgInfo);
//    }
//    else
//    {
//        DTSTest_CurrentlySamplingBargeB4 = GUI_YES;
//        samplingStartStopBargeB4Button->Text = _T("Stop Sampling Barge B4");
//        samplingBargeB4LEDButton->BackgroundImage = yellowLEDOnImage;
//        DTSTest_PDGICOpenPersistentPort(pgInfo);
//        //--------------------------------------------------------------------
//        // Start the background process that samples forever
//        //--------------------------------------------------------------------
//        samplingEntryBackground->RunWorkerAsync();
//    }
//}                                       // end of DTSTest_SamplingStartStopBargeB4ButtonClicked()
////----------------------------------------------------------------------------
//// DTSTest_SamplingStartStopBargeC9ButtonClicked
////
//// Handles the click of the Start / Stop Sampling Barge C9 button
////
//// Called by:   DTSTest_SamplingControlsSetUpWindow
////----------------------------------------------------------------------------
//    void DTSTest_GUIClass::
//DTSTest_SamplingStartStopBargeC9ButtonClicked(
//    Object          ^sender,
//    EventArgs       ^evt)
//{
//    PDGICInfo       ^pgInfo = DTSTest_GeneralInfo->pgInfo;
//    //------------------------------------------------------------------------
//    RecordBasicEvent("Start / Stop Sampling Gauge C9 button clicked");
//    if (DTSTest_CurrentlySamplingBargeC9)
//    {
//        while (DTSTest_RetrieveResponseContext)
//            Thread::Sleep(10);
//        DTSTest_SamplingRunning = GUI_NO;
//        DTSTest_CurrentlySamplingBargeC9 = GUI_NO;
//        samplingStartStopBargeC9Button->Text = _T("Start Sampling Barge C9");
//        samplingBargeC9LEDButton->BackgroundImage = yellowLEDOffImage;
//        DTSTest_PDGICClosePersistentPort(pgInfo);
//    }
//    else
//    {
//        DTSTest_CurrentlySamplingBargeC9 = GUI_YES;
//        samplingStartStopBargeC9Button->Text = _T("Stop Sampling Barge C9");
//        samplingBargeC9LEDButton->BackgroundImage = yellowLEDOnImage;
//        DTSTest_PDGICOpenPersistentPort(pgInfo);
//        //--------------------------------------------------------------------
//        // Start the background process that samples forever
//        //--------------------------------------------------------------------
//        samplingEntryBackground->RunWorkerAsync();
//    }
//}                                       // end of DTSTest_SamplingStartStopBargeC9ButtonClicked()
////----------------------------------------------------------------------------
//// DTSTest_SamplingStartStopBargeE2ButtonClicked
////
//// Handles the click of the Start / Stop Sampling Barge E2 button
////
//// Called by:   DTSTest_SamplingControlsSetUpWindow
////----------------------------------------------------------------------------
//    void DTSTest_GUIClass::
//DTSTest_SamplingStartStopBargeE2ButtonClicked(
//    Object          ^sender,
//    EventArgs       ^evt)
//{
//    PDGICInfo       ^pgInfo = DTSTest_GeneralInfo->pgInfo;
//    //------------------------------------------------------------------------
//    RecordBasicEvent("Start / Stop Sampling Gauge E2 button clicked");
//    if (DTSTest_CurrentlySamplingBargeE2)
//    {
//        while (DTSTest_RetrieveResponseContext)
//            Thread::Sleep(10);
//        DTSTest_SamplingRunning = GUI_NO;
//        DTSTest_CurrentlySamplingBargeE2 = GUI_NO;
//        samplingStartStopBargeE2Button->Text = _T("Start Sampling Barge E2");
//        samplingBargeE2LEDButton->BackgroundImage = yellowLEDOffImage;
//        DTSTest_PDGICClosePersistentPort(pgInfo);
//    }
//    else
//    {
//        DTSTest_CurrentlySamplingBargeE2 = GUI_YES;
//        samplingStartStopBargeE2Button->Text = _T("Stop Sampling Barge E2");
//        samplingBargeE2LEDButton->BackgroundImage = yellowLEDOnImage;
//        DTSTest_PDGICOpenPersistentPort(pgInfo);
//        //--------------------------------------------------------------------
//        // Start the background process that samples forever
//        //--------------------------------------------------------------------
//        samplingEntryBackground->RunWorkerAsync();
//    }
//}                                       // end of DTSTest_SamplingStartStopBargeE2ButtonClicked()
////----------------------------------------------------------------------------
//// DTSTest_SamplingStartStopUserBarge1ButtonClicked
////
//// Handles the click of the Start / Stop Sampling User Barge 1 button
////
//// Called by:   DTSTest_SamplingControlsSetUpWindow
////----------------------------------------------------------------------------
//    void DTSTest_GUIClass::
//DTSTest_SamplingStartStopUserBarge1ButtonClicked(
//    Object          ^sender,
//    EventArgs       ^evt)
//{
//    PDGICInfo       ^pgInfo = DTSTest_GeneralInfo->pgInfo;
//    //------------------------------------------------------------------------
//    RecordBasicEvent("Start / Stop Sampling User Barge 1 button clicked");
//    if (DTSTest_CurrentlySamplingUserBarge1)
//    {
//        while (DTSTest_RetrieveResponseContext)
//            Thread::Sleep(10);
//        DTSTest_SamplingRunning = GUI_NO;
//        DTSTest_CurrentlySamplingUserBarge1 = GUI_NO;
//        samplingStartStopUserBarge1Button->Text = String::Concat(
//            _T("Start Sampling Barge "),
//            (pgInfo->userBargeNodeAddress1 ? String::Format("{0:X2}", pgInfo->userBargeNodeAddress1) : _T("XX")));
//        samplingUserBarge1LEDButton->BackgroundImage = yellowLEDOffImage;
//        DTSTest_PDGICClosePersistentPort(pgInfo);
//    }
//    else
//    {
//        DTSTest_CurrentlySamplingUserBarge1 = GUI_YES;
//        samplingStartStopUserBarge1Button->Text = String::Concat(
//            _T("Stop Sampling Barge "),
//            (pgInfo->userBargeNodeAddress1 ? String::Format("{0:X2}", pgInfo->userBargeNodeAddress1) : _T("XX")));
//        samplingUserBarge1LEDButton->BackgroundImage = yellowLEDOnImage;
//        DTSTest_PDGICOpenPersistentPort(pgInfo);
//    }
//}                                       // end of DTSTest_SamplingStartStopUserBarge1ButtonClicked()
////----------------------------------------------------------------------------
//// DTSTest_SamplingStartStopUserBarge2ButtonClicked
////
//// Handles the click of the Start / Stop Sampling User Barge 2 button
////
//// Called by:   DTSTest_SamplingControlsSetUpWindow
////----------------------------------------------------------------------------
//    void DTSTest_GUIClass::
//DTSTest_SamplingStartStopUserBarge2ButtonClicked(
//    Object          ^sender,
//    EventArgs       ^evt)
//{
//    PDGICInfo       ^pgInfo = DTSTest_GeneralInfo->pgInfo;
//    //------------------------------------------------------------------------
//    RecordBasicEvent("Start / Stop Sampling User Barge 2 button clicked");
//    if (DTSTest_CurrentlySamplingUserBarge2)
//    {
//        while (DTSTest_RetrieveResponseContext)
//            Thread::Sleep(10);
//        DTSTest_SamplingRunning = GUI_NO;
//        DTSTest_CurrentlySamplingUserBarge2 = GUI_NO;
//        samplingStartStopUserBarge2Button->Text = String::Concat(
//            _T("Start Sampling Barge "),
//            (pgInfo->userBargeNodeAddress2 ? String::Format("{0:X2}", pgInfo->userBargeNodeAddress2) : _T("XX")));
//        samplingUserBarge2LEDButton->BackgroundImage = yellowLEDOffImage;
//        DTSTest_PDGICClosePersistentPort(pgInfo);
//    }
//    else
//    {
//        DTSTest_CurrentlySamplingUserBarge2 = GUI_YES;
//        samplingStartStopUserBarge2Button->Text = String::Concat(
//            _T("Stop Sampling Barge "),
//            (pgInfo->userBargeNodeAddress2 ? String::Format("{0:X2}", pgInfo->userBargeNodeAddress2) : _T("XX")));
//        samplingUserBarge2LEDButton->BackgroundImage = yellowLEDOnImage;
//        DTSTest_PDGICOpenPersistentPort(pgInfo);
//        //--------------------------------------------------------------------
//        // Start the background process that samples forever
//        //--------------------------------------------------------------------
//        samplingEntryBackground->RunWorkerAsync();
//    }
//}                                       // end of DTSTest_SamplingStartStopUserBarge2ButtonClicked()
////----------------------------------------------------------------------------
//// DTSTest_SamplingStartStopUserBarge3ButtonClicked
////
//// Handles the click of the Start / Stop Sampling User Barge 3 button
////
//// Called by:   DTSTest_SamplingControlsSetUpWindow
////----------------------------------------------------------------------------
//    void DTSTest_GUIClass::
//DTSTest_SamplingStartStopUserBarge3ButtonClicked(
//    Object          ^sender,
//    EventArgs       ^evt)
//{
//    PDGICInfo       ^pgInfo = DTSTest_GeneralInfo->pgInfo;
//    //------------------------------------------------------------------------
//    RecordBasicEvent("Start / Stop Sampling User Barge 3 button clicked");
//    if (DTSTest_CurrentlySamplingUserBarge3)
//    {
//        while (DTSTest_RetrieveResponseContext)
//            Thread::Sleep(10);
//        DTSTest_SamplingRunning = GUI_NO;
//        DTSTest_CurrentlySamplingUserBarge3 = GUI_NO;
//        samplingStartStopUserBarge3Button->Text = String::Concat(
//            _T("Start Sampling Barge "),
//            (pgInfo->userBargeNodeAddress3 ? String::Format("{0:X2}", pgInfo->userBargeNodeAddress3) : _T("XX")));
//        samplingUserBarge3LEDButton->BackgroundImage = yellowLEDOffImage;
//        DTSTest_PDGICClosePersistentPort(pgInfo);
//    }
//    else
//    {
//        DTSTest_CurrentlySamplingUserBarge3 = GUI_YES;
//        samplingStartStopUserBarge3Button->Text = String::Concat(
//            _T("Stop Sampling Barge "),
//            (pgInfo->userBargeNodeAddress3 ? String::Format("{0:X2}", pgInfo->userBargeNodeAddress3) : _T("XX")));
//        samplingUserBarge3LEDButton->BackgroundImage = yellowLEDOnImage;
//        DTSTest_PDGICOpenPersistentPort(pgInfo);
//        //--------------------------------------------------------------------
//        // Start the background process that samples forever
//        //--------------------------------------------------------------------
//        samplingEntryBackground->RunWorkerAsync();
//    }
//}                                       // end of DTSTest_SamplingStartStopUserBarge3ButtonClicked()
////----------------------------------------------------------------------------
//// DTSTest_SamplingStartStopUserBarge4ButtonClicked
////
//// Handles the click of the Start / Stop Sampling User Barge 4 button
////
//// Called by:   DTSTest_SamplingControlsSetUpWindow
////----------------------------------------------------------------------------
//    void DTSTest_GUIClass::
//DTSTest_SamplingStartStopUserBarge4ButtonClicked(
//    Object          ^sender,
//    EventArgs       ^evt)
//{
//    PDGICInfo       ^pgInfo = DTSTest_GeneralInfo->pgInfo;
//    //------------------------------------------------------------------------
//    RecordBasicEvent("Start / Stop Sampling User Barge 4 button clicked");
//    if (DTSTest_CurrentlySamplingUserBarge4)
//    {
//        while (DTSTest_RetrieveResponseContext)
//            Thread::Sleep(10);
//        DTSTest_SamplingRunning = GUI_NO;
//        DTSTest_CurrentlySamplingUserBarge4 = GUI_NO;
//        samplingStartStopUserBarge4Button->Text = String::Concat(
//            _T("Start Sampling Barge "),
//            (pgInfo->userBargeNodeAddress4 ? String::Format("{0:X2}", pgInfo->userBargeNodeAddress4) : _T("XX")));
//        samplingUserBarge4LEDButton->BackgroundImage = yellowLEDOffImage;
//        DTSTest_PDGICClosePersistentPort(pgInfo);
//    }
//    else
//    {
//        DTSTest_CurrentlySamplingUserBarge4 = GUI_YES;
//        samplingStartStopUserBarge4Button->Text = String::Concat(
//            _T("Stop Sampling Barge "),
//            (pgInfo->userBargeNodeAddress4 ? String::Format("{0:X2}", pgInfo->userBargeNodeAddress4) : _T("XX")));
//        samplingUserBarge4LEDButton->BackgroundImage = yellowLEDOnImage;
//        DTSTest_PDGICOpenPersistentPort(pgInfo);
//        //--------------------------------------------------------------------
//        // Start the background process that samples forever
//        //--------------------------------------------------------------------
//        samplingEntryBackground->RunWorkerAsync();
//    }
//}                                       // end of DTSTest_SamplingStartStopUserBarge4ButtonClicked()
////----------------------------------------------------------------------------
//// DTSTest_SamplingStartStopUserBarge5ButtonClicked
////
//// Handles the click of the Start / Stop Sampling User Barge 5 button
////
//// Called by:   DTSTest_SamplingControlsSetUpWindow
////----------------------------------------------------------------------------
//    void DTSTest_GUIClass::
//DTSTest_SamplingStartStopUserBarge5ButtonClicked(
//    Object          ^sender,
//    EventArgs       ^evt)
//{
//    PDGICInfo       ^pgInfo = DTSTest_GeneralInfo->pgInfo;
//    //------------------------------------------------------------------------
//    RecordBasicEvent("Start / Stop Sampling User Barge 5 button clicked");
//    if (DTSTest_CurrentlySamplingUserBarge5)
//    {
//        while (DTSTest_RetrieveResponseContext)
//            Thread::Sleep(10);
//        DTSTest_SamplingRunning = GUI_NO;
//        DTSTest_CurrentlySamplingUserBarge5 = GUI_NO;
//        samplingStartStopUserBarge5Button->Text = String::Concat(
//            _T("Start Sampling Barge "),
//            (pgInfo->userBargeNodeAddress5 ? String::Format("{0:X2}", pgInfo->userBargeNodeAddress5) : _T("XX")));
//        samplingUserBarge5LEDButton->BackgroundImage = yellowLEDOffImage;
//        DTSTest_PDGICClosePersistentPort(pgInfo);
//    }
//    else
//    {
//        DTSTest_CurrentlySamplingUserBarge5 = GUI_YES;
//        samplingStartStopUserBarge5Button->Text = String::Concat(
//            _T("Stop Sampling Barge "),
//            (pgInfo->userBargeNodeAddress5 ? String::Format("{0:X2}", pgInfo->userBargeNodeAddress5) : _T("XX")));
//        samplingUserBarge5LEDButton->BackgroundImage = yellowLEDOnImage;
//        DTSTest_PDGICOpenPersistentPort(pgInfo);
//        //--------------------------------------------------------------------
//        // Start the background process that samples forever
//        //--------------------------------------------------------------------
//        samplingEntryBackground->RunWorkerAsync();
//    }
//}                                       // end of DTSTest_SamplingStartStopUserBarge5ButtonClicked()
////----------------------------------------------------------------------------
//// DTSTest_SamplingStartStopUserBarge6ButtonClicked
////
//// Handles the click of the Start / Stop Sampling User Barge 6 button
////
//// Called by:   DTSTest_SamplingControlsSetUpWindow
////----------------------------------------------------------------------------
//    void DTSTest_GUIClass::
//DTSTest_SamplingStartStopUserBarge6ButtonClicked(
//    Object          ^sender,
//    EventArgs       ^evt)
//{
//    PDGICInfo       ^pgInfo = DTSTest_GeneralInfo->pgInfo;
//    //------------------------------------------------------------------------
//    RecordBasicEvent("Start / Stop Sampling User Barge 6 button clicked");
//    if (DTSTest_CurrentlySamplingUserBarge6)
//    {
//        while (DTSTest_RetrieveResponseContext)
//            Thread::Sleep(10);
//        DTSTest_SamplingRunning = GUI_NO;
//        DTSTest_CurrentlySamplingUserBarge6 = GUI_NO;
//        samplingStartStopUserBarge6Button->Text = String::Concat(
//            _T("Start Sampling Barge "),
//            (pgInfo->userBargeNodeAddress6 ? String::Format("{0:X2}", pgInfo->userBargeNodeAddress6) : _T("XX")));
//        samplingUserBarge6LEDButton->BackgroundImage = yellowLEDOffImage;
//        DTSTest_PDGICClosePersistentPort(pgInfo);
//    }
//    else
//    {
//        DTSTest_CurrentlySamplingUserBarge6 = GUI_YES;
//        samplingStartStopUserBarge6Button->Text = String::Concat(
//            _T("Stop Sampling Barge "),
//            (pgInfo->userBargeNodeAddress6 ? String::Format("{0:X2}", pgInfo->userBargeNodeAddress6) : _T("XX")));
//        samplingUserBarge6LEDButton->BackgroundImage = yellowLEDOnImage;
//        DTSTest_PDGICOpenPersistentPort(pgInfo);
//        //--------------------------------------------------------------------
//        // Start the background process that samples forever
//        //--------------------------------------------------------------------
//        samplingEntryBackground->RunWorkerAsync();
//    }
//}                                       // end of DTSTest_SamplingStartStopUserBarge6ButtonClicked()
////----------------------------------------------------------------------------
//// DTSTest_SamplingStartStopUserGauge1ButtonClicked
////
//// Handles the click of the Start / Stop Sampling User Gauge 1 button
////
//// Called by:   DTSTest_SamplingControlsSetUpWindow
////----------------------------------------------------------------------------
//    void DTSTest_GUIClass::
//DTSTest_SamplingStartStopUserGauge1ButtonClicked(
//    Object          ^sender,
//    EventArgs       ^evt)
//{
//    PDGICInfo       ^pgInfo = DTSTest_GeneralInfo->pgInfo;
//    //------------------------------------------------------------------------
//    RecordBasicEvent("Start / Stop Sampling User Gauge 1 button clicked");
//    if (DTSTest_CurrentlySamplingUserGauge1)
//    {
//        while (DTSTest_RetrieveResponseContext)
//            Thread::Sleep(10);
//        DTSTest_SamplingRunning = GUI_NO;
//        DTSTest_CurrentlySamplingUserGauge1 = GUI_NO;
//        samplingStartStopUserGauge1Button->Text = String::Concat(
//            _T("Start Sampling Gauge "),
//            (pgInfo->userGaugeNodeAddress1 ? String::Format("{0:X2}", pgInfo->userGaugeNodeAddress1) : _T("XX")));
//        samplingUserGauge1LEDButton->BackgroundImage = yellowLEDOffImage;
//        DTSTest_PDGICClosePersistentPort(pgInfo);
//    }
//    else
//    {
//        DTSTest_CurrentlySamplingUserGauge1 = GUI_YES;
//        samplingStartStopUserGauge1Button->Text = String::Concat(
//            _T("Stop Sampling Gauge "),
//            (pgInfo->userGaugeNodeAddress1 ? String::Format("{0:X2}", pgInfo->userGaugeNodeAddress1) : _T("XX")));
//        samplingUserGauge1LEDButton->BackgroundImage = yellowLEDOnImage;
//        DTSTest_PDGICOpenPersistentPort(pgInfo);
//        //--------------------------------------------------------------------
//        // Start the background process that samples forever
//        //--------------------------------------------------------------------
//        samplingEntryBackground->RunWorkerAsync();
//    }
//}                                       // end of DTSTest_SamplingStartStopUserGauge1ButtonClicked()
////----------------------------------------------------------------------------
//// DTSTest_SamplingStartStopUserGauge2ButtonClicked
////
//// Handles the click of the Start / Stop Sampling User Gauge 2 button
////
//// Called by:   DTSTest_SamplingControlsSetUpWindow
////----------------------------------------------------------------------------
//    void DTSTest_GUIClass::
//DTSTest_SamplingStartStopUserGauge2ButtonClicked(
//    Object          ^sender,
//    EventArgs       ^evt)
//{
//    PDGICInfo       ^pgInfo = DTSTest_GeneralInfo->pgInfo;
//    //------------------------------------------------------------------------
//    RecordBasicEvent("Start / Stop Sampling User Gauge 2 button clicked");
//    if (DTSTest_CurrentlySamplingUserGauge2)
//    {
//        while (DTSTest_RetrieveResponseContext)
//            Thread::Sleep(10);
//        DTSTest_SamplingRunning = GUI_NO;
//        DTSTest_CurrentlySamplingUserGauge2 = GUI_NO;
//        samplingStartStopUserGauge2Button->Text = String::Concat(
//            _T("Start Sampling Gauge "),
//            (pgInfo->userGaugeNodeAddress2 ? String::Format("{0:X2}", pgInfo->userGaugeNodeAddress2) : _T("XX")));
//        samplingUserGauge2LEDButton->BackgroundImage = yellowLEDOffImage;
//        DTSTest_PDGICClosePersistentPort(pgInfo);
//    }
//    else
//    {
//        DTSTest_CurrentlySamplingUserGauge2 = GUI_YES;
//        samplingStartStopUserGauge2Button->Text = String::Concat(
//            _T("Stop Sampling Gauge "),
//            (pgInfo->userGaugeNodeAddress2 ? String::Format("{0:X2}", pgInfo->userGaugeNodeAddress2) : _T("XX")));
//        samplingUserGauge2LEDButton->BackgroundImage = yellowLEDOnImage;
//        DTSTest_PDGICOpenPersistentPort(pgInfo);
//        //--------------------------------------------------------------------
//        // Start the background process that samples forever
//        //--------------------------------------------------------------------
//        samplingEntryBackground->RunWorkerAsync();
//    }
//}                                       // end of DTSTest_SamplingStartStopUserGauge2ButtonClicked()
////----------------------------------------------------------------------------
//// DTSTest_SamplingStartStopUserGauge3ButtonClicked
////
//// Handles the click of the Start / Stop Sampling User Gauge 3 button
////
//// Called by:   DTSTest_SamplingControlsSetUpWindow
////----------------------------------------------------------------------------
//    void DTSTest_GUIClass::
//DTSTest_SamplingStartStopUserGauge3ButtonClicked(
//    Object          ^sender,
//    EventArgs       ^evt)
//{
//    PDGICInfo       ^pgInfo = DTSTest_GeneralInfo->pgInfo;
//    //------------------------------------------------------------------------
//    RecordBasicEvent("Start / Stop Sampling User Gauge 3 button clicked");
//    if (DTSTest_CurrentlySamplingUserGauge3)
//    {
//        while (DTSTest_RetrieveResponseContext)
//            Thread::Sleep(10);
//        DTSTest_SamplingRunning = GUI_NO;
//        DTSTest_CurrentlySamplingUserGauge3 = GUI_NO;
//        samplingStartStopUserGauge3Button->Text = String::Concat(
//            _T("Start Sampling Gauge "),
//            (pgInfo->userGaugeNodeAddress3 ? String::Format("{0:X2}", pgInfo->userGaugeNodeAddress3) : _T("XX")));
//        samplingUserGauge3LEDButton->BackgroundImage = yellowLEDOffImage;
//        DTSTest_PDGICClosePersistentPort(pgInfo);
//    }
//    else
//    {
//        DTSTest_CurrentlySamplingUserGauge3 = GUI_YES;
//        samplingStartStopUserGauge3Button->Text = String::Concat(
//            _T("Stop Sampling Gauge "),
//            (pgInfo->userGaugeNodeAddress3 ? String::Format("{0:X2}", pgInfo->userGaugeNodeAddress3) : _T("XX")));
//        samplingUserGauge3LEDButton->BackgroundImage = yellowLEDOnImage;
//        DTSTest_PDGICOpenPersistentPort(pgInfo);
//        //--------------------------------------------------------------------
//        // Start the background process that samples forever
//        //--------------------------------------------------------------------
//        samplingEntryBackground->RunWorkerAsync();
//    }
//}                                       // end of DTSTest_SamplingStartStopUserGauge3ButtonClicked()
//----------------------------------------------------------------------------
// DTSTest_SamplingStopEverythingButtonClicked
//
// Handles the click of the Stop Everything button
//
// Called by:   DTSTest_SamplingControlsSetUpWindow
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_SamplingStopEverythingButtonClicked(
    Object          ^sender,
    EventArgs       ^evt)
{
    PDGICInfo       ^pgInfo = DTSTest_GeneralInfo->pgInfo;
    //------------------------------------------------------------------------
    RecordBasicEvent("Stop Everything button clicked");
    while (DTSTest_RetrieveResponseContext)
        Thread::Sleep(10);
    DTSTest_SamplingRunning = GUI_NO;
    DTSTest_CurrentlySamplingAll = GUI_NO;
    samplingStartStopAllButton->Text = _T("Start Sampling All");
    DTSTest_CurrentlySamplingAllGauges = GUI_NO;
    samplingStartStopAllGaugesButton->Text = _T("Start Sampling All Gauges");
//    DTSTest_CurrentlySamplingGauge2D = GUI_NO;
//    samplingStartStopGauge2DButton->Text = _T("Start Sampling Gauge 2D");
//    samplingGauge2DLEDButton->BackgroundImage = yellowLEDOffImage;
//    DTSTest_CurrentlySamplingGauge3E = GUI_NO;
//    samplingStartStopGauge3EButton->Text = _T("Start Sampling Gauge 3E");
//    samplingGauge3ELEDButton->BackgroundImage = yellowLEDOffImage;
//    DTSTest_CurrentlySamplingAllBarges = GUI_NO;
//    samplingStartStopAllBargesButton->Text = _T("Start Sampling All Barges");
//    DTSTest_CurrentlySamplingBargeB4 = GUI_NO;
//    samplingStartStopBargeB4Button->Text = _T("Start Sampling Barge B4");
//    samplingBargeB4LEDButton->BackgroundImage = yellowLEDOffImage;
//    DTSTest_CurrentlySamplingBargeC9 = GUI_NO;
//    samplingStartStopBargeC9Button->Text = _T("Start Sampling Barge C9");
//    samplingBargeC9LEDButton->BackgroundImage = yellowLEDOffImage;
//    DTSTest_CurrentlySamplingBargeE2 = GUI_NO;
//    samplingStartStopBargeE2Button->Text = _T("Start Sampling Barge E2");
//    samplingBargeE2LEDButton->BackgroundImage = yellowLEDOffImage;
//    DTSTest_CurrentlySamplingBarge02 = GUI_NO;
//    samplingStartStopBarge02Button->Text = _T("Start Sampling Barge 02");
//    samplingBarge02LEDButton->BackgroundImage = yellowLEDOffImage;
//    DTSTest_CurrentlySamplingUserGauge1 = GUI_NO;
//    samplingStartStopUserGauge1Button->Text = String::Concat(
//        _T("Start Sampling Gauge "),
//        (pgInfo->userGaugeNodeAddress1 ? String::Format("{0:X2}", pgInfo->userGaugeNodeAddress1) : _T("XX")));
//    samplingUserGauge1LEDButton->BackgroundImage = yellowLEDOffImage;
//    DTSTest_CurrentlySamplingUserGauge2 = GUI_NO;
//    samplingStartStopUserGauge2Button->Text = String::Concat(
//        _T("Start Sampling Gauge "),
//        (pgInfo->userGaugeNodeAddress2 ? String::Format("{0:X2}", pgInfo->userGaugeNodeAddress2) : _T("XX")));
//    samplingUserGauge2LEDButton->BackgroundImage = yellowLEDOffImage;
//    DTSTest_CurrentlySamplingUserGauge3 = GUI_NO;
//    samplingStartStopUserGauge3Button->Text = String::Concat(
//        _T("Start Sampling Gauge "),
//        (pgInfo->userGaugeNodeAddress3 ? String::Format("{0:X2}", pgInfo->userGaugeNodeAddress3) : _T("XX")));
//    samplingUserGauge3LEDButton->BackgroundImage = yellowLEDOffImage;
//    DTSTest_CurrentlySamplingUserBarge1 = GUI_NO;
//    samplingStartStopUserBarge1Button->Text = String::Concat(
//        _T("Start Sampling Barge "),
//        (pgInfo->userBargeNodeAddress1 ? String::Format("{0:X2}", pgInfo->userBargeNodeAddress1) : _T("XX")));
//    samplingUserBarge1LEDButton->BackgroundImage = yellowLEDOffImage;
//    DTSTest_CurrentlySamplingUserBarge2 = GUI_NO;
//    samplingStartStopUserBarge2Button->Text = String::Concat(
//        _T("Start Sampling Barge "),
//        (pgInfo->userBargeNodeAddress2 ? String::Format("{0:X2}", pgInfo->userBargeNodeAddress2) : _T("XX")));
//    samplingUserBarge2LEDButton->BackgroundImage = yellowLEDOffImage;
//    DTSTest_CurrentlySamplingUserBarge3 = GUI_NO;
//    samplingStartStopUserBarge3Button->Text = String::Concat(
//        _T("Start Sampling Barge "),
//        (pgInfo->userBargeNodeAddress3 ? String::Format("{0:X2}", pgInfo->userBargeNodeAddress3) : _T("XX")));
//    samplingUserBarge3LEDButton->BackgroundImage = yellowLEDOffImage;
//    DTSTest_CurrentlySamplingUserBarge4 = GUI_NO;
//    samplingStartStopUserBarge4Button->Text = String::Concat(
//        _T("Start Sampling Barge "),
//        (pgInfo->userBargeNodeAddress4 ? String::Format("{0:X2}", pgInfo->userBargeNodeAddress4) : _T("XX")));
//    samplingUserBarge4LEDButton->BackgroundImage = yellowLEDOffImage;
//    DTSTest_CurrentlySamplingUserBarge5 = GUI_NO;
//    samplingStartStopUserBarge5Button->Text = String::Concat(
//        _T("Start Sampling Barge "),
//        (pgInfo->userBargeNodeAddress5 ? String::Format("{0:X2}", pgInfo->userBargeNodeAddress5) : _T("XX")));
//    samplingUserBarge5LEDButton->BackgroundImage = yellowLEDOffImage;
//    DTSTest_CurrentlySamplingUserBarge6 = GUI_NO;
//    samplingStartStopUserBarge6Button->Text = String::Concat(
//        _T("Start Sampling Barge "),
//        (pgInfo->userBargeNodeAddress6 ? String::Format("{0:X2}", pgInfo->userBargeNodeAddress6) : _T("XX")));
//    samplingUserBarge6LEDButton->BackgroundImage = yellowLEDOffImage;
    DTSTest_PDGICClosePersistentPort(pgInfo);
}                                       // end of DTSTest_SamplingStopEverythingButtonClicked()
//----------------------------------------------------------------------------
#endif      // SAMPLING_CPP
//============================================================================
// End of Sampling.cpp
//============================================================================
