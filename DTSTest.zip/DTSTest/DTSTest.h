//============================================================================
// DTSTest.h
//
// Header for DTSTest.cpp
//
// Copyright (C) 2014 - 2016 Quartzdyne, Inc.  All rights reserved.
//
// No part of this source code may be reproduced or transmitted in any form or
// by any means, electronic or mechanical, including photocopying, recording,
// or any information storage and retrieval system, without express written
// permission from Quartzdyne, Inc.  Further, no use of this source code is
// permitted in any form or means without a valid, written license agreement
// with Quartzdyne, Inc.  While every reasonable precaution has been taken in
// the preparation of this source code, Quartzdyne, Inc., assumes no
// responsibility for errors, omissions, or damages from the use of the source
// code contained herein.
//
// NEITHER QUARTZDYNE, INC., ANY MEMBER OF QUARTZDYNE, INC., NOR ANY PERSON OR
// ORGANIZATION ACTING ON BEHALF OF THEM MAKES ANY WARRANTY OR REPRESENTATION
// WHATSOEVER, EXPRESS OR IMPLIED, INCLUDING ANY WARRANTY OF MERCHANTABILITY
// OR FITNESS FOR ANY PURPOSE WITH RESPECT TO THE SOURCE CODE OR ASSUMES ANY
// LIABILITY WHATSOEVER WITH RESPECT TO ANY USE OF THE SOURCE CODE OR ANY
// PORTION THEREOF OR WITH RESPECT TO ANY DAMAGES THAT MAY RESULT FROM SUCH
// USE.
//
// Noji Ratzlaff
//
// See DTSTest.log for a complete history of all updates, changes, and revisions
// of this source and other files and policies regarding DTSTest software
//
// Updated 01-14-2016
//============================================================================
#pragma once
#ifndef     DTSTEST_H   // provided for legacy compilers, but unnecessary for
#define     DTSTEST_H   // recent compilers, due to the preceding pragma
//----------------------------------------------------------------------------
// Include appropriate headers
//----------------------------------------------------------------------------
#include    "GUI.h"
#include    "QDPDGIC.h"
//----------------------------------------------------------------------------
// The following lines are only seen by DTSTest.cpp
//----------------------------------------------------------------------------
#ifdef      DTSTEST_CPP
//----------------------------------------------------------------------------
// Substitutions
//----------------------------------------------------------------------------
#define     DTSTest_Main    wWinMain
#define     DTSTEST_YES     true
#define     DTSTEST_NO      false
//----------------------------------------------------------------------------
// Global variables
//----------------------------------------------------------------------------
bool            DTSTest_BasicMessagesEnabled = DTSTEST_NO;                      // 0x00000001
bool            DTSTest_ErrorMessagesEnabled = DTSTEST_NO;                      // 0x00000002
bool            DTSTest_VerboseMessagesEnabled = DTSTEST_NO;                    // 0x00000004
bool            DTSTest_DetailedMessagesEnabled = DTSTEST_NO;                   // 0x00000008
bool            DTSTest_ExpMessagesEnabled = DTSTEST_NO;                        // 0x00000010
bool            DTSTest_StackTracesEnabled = DTSTEST_NO;                        // 0x00000020
bool            DTSTest_SendTextErrorMessagesEnabled = DTSTEST_NO;              // 0x00000040
bool            DTSTest_SendEmailErrorMessagesEnabled = DTSTEST_NO;             // 0x00000080
bool            DTSTest_EventLogBasicEnabled = DTSTEST_NO;                      // 0x00001000
bool            DTSTest_EventLogVerboseEnabled = DTSTEST_NO;                    // 0x00002000
bool            DTSTest_EventLogDetailedEnabled = DTSTEST_NO;                   // 0x00004000
bool            DTSTest_ExperimentsEnabled = DTSTEST_NO;                        // 0x10000000
bool            DTSTest_CommandLineOnly = DTSTEST_NO;                           // 0x40000000
bool            DTSTest_SoftwareUpdateInProgress = DTSTEST_NO;                  // 0x80000000
DWORD           DTSTest_BuildNumber = 0;
DWORD           DTSTest_StartTime;
DWORD           DTSTest_WindowsVersion = DTSTEST_WIN_VER_UNKNOWN;
//----------------------------------------------------------------------------
// External global variables
//----------------------------------------------------------------------------
//----------------------------------------------------------------------------
// Function prototypes
//----------------------------------------------------------------------------
int             DTSTest_CalculatePercentage(
                    DWORD           dividend,
                    DWORD           divisor);
char            *DTSTest_ConvertString(
                    String          ^managedString,
                    char            *unmanagedString,
                    size_t          unmanagedBufferSize);
System::Windows::Forms::DialogResult
                DTSTest_ModalMessage(
                    bool            allow,
                    DWORD           flag,
                    String          ^titleString,
                    String          ^formatString,
                    ...array <Object ^>
                                    ^parameters);
void            DTSTest_DisplayStackTrace(
                    String          ^messageString);
char            *DTSTest_ItoA(
                    DWORD           value,
                    char            *valueString);
char            *DTSTest_ItoX(
                    DWORD           value,
                    char            *valueString);
bool            DTSTest_PromptYesNoModal(
                    String          ^titleString,
                    String          ^formatString,
                    ...array <Object ^>
                                    ^parameters);
void            DTSTest_SetCommandLineFlags(
                    LPTSTR          commandLine);
bool            DTSTest_StringContains(
                    char            *sourceString,
                    char            *testString);
void            DTSTest_TimeElapsed(
                    DWORD           lapsedTime,
                    int             *lapsedDays,
                    int             *lapsedHours,
                    int             *lapsedMinutes,
                    int             *lapsedSeconds,
                    int             *lapsedMilliseconds);
//----------------------------------------------------------------------------
// External function prototypes
//----------------------------------------------------------------------------
//----------------------------------------------------------------------------
// String definitions
//----------------------------------------------------------------------------
#define     DTSTEST_MUTEX_STRING                _T("DTSTestClass")
//----------------------------------------------------------------------------
// Macros
//----------------------------------------------------------------------------
//----------------------------------------------------------------------------
// End of the lines that are only seen by DTSTest.cpp
//----------------------------------------------------------------------------
#endif      // DTSTEST_CPP
#endif      // DTSTEST_H
//============================================================================
// End of DTSTest.h
//============================================================================
