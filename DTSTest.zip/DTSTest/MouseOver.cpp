//============================================================================
// MouseOver.cpp
//
// The registered mouse-over and mouse-exit event methods
//
// Copyright (C) 2014 - 2016 Quartzdyne, Inc.  All rights reserved.
//
// No part of this source code may be reproduced or transmitted in any form or
// by any means, electronic or mechanical, including photocopying, recording,
// or any information storage and retrieval system, without express written
// permission from Quartzdyne, Inc.  Further, no use of this source code is
// permitted in any form or means without a valid, written license agreement
// with Quartzdyne, Inc.  While every reasonable precaution has been taken in
// the preparation of this source code, Quartzdyne, Inc., assumes no
// responsibility for errors, omissions, or damages from the use of the source
// code contained herein.
//
// NEITHER QUARTZDYNE, INC., ANY MEMBER OF QUARTZDYNE, INC., NOR ANY PERSON OR
// ORGANIZATION ACTING ON BEHALF OF THEM MAKES ANY WARRANTY OR REPRESENTATION
// WHATSOEVER, EXPRESS OR IMPLIED, INCLUDING ANY WARRANTY OF MERCHANTABILITY
// OR FITNESS FOR ANY PURPOSE WITH RESPECT TO THE SOURCE CODE OR ASSUMES ANY
// LIABILITY WHATSOEVER WITH RESPECT TO ANY USE OF THE SOURCE CODE OR ANY
// PORTION THEREOF OR WITH RESPECT TO ANY DAMAGES THAT MAY RESULT FROM SUCH
// USE.
//
// Noji Ratzlaff
//
// See DTSTest.log for a complete history of all updates, changes, and revisions
// of this source and other files and policies regarding DTSTest software
//
// Updated 01-14-2016
//============================================================================
#include    "stdafx.h"
#ifndef     MOUSEOVER_CPP
#define     MOUSEOVER_CPP
#include    "MouseOver.h"
//----------------------------------------------------------------------------
// DTSTest_AnyObjectMouseExited
//
// Handles mousing away from any object
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_AnyObjectMouseExited(
    Object          ^sender,
    EventArgs       ^evt)
{
    DTSTest_UpdateStatusLine("DTSTest Ready");
}                                       // end of DTSTest_AnyObjectMouseExited()
//----------------------------------------------------------------------------
// DTSTest_AdvancedDeleteConfigCheckMouseEntered
//
// Handles the mouse entering the Delete Config File On Exit checkbox
//
// Called by:   DTSTest_AdvancedControlsSetUpWindow
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_AdvancedDeleteConfigCheckMouseEntered(
    Object          ^sender,
    EventArgs       ^evt)
{
    DTSTest_UpdateStatusLine("Deletes the config file when the program exits");
}                                       // end of DTSTest_AdvancedDeleteConfigCheckMouseEntered()
//----------------------------------------------------------------------------
// DTSTest_AdvancedDetailedMessagesCheckMouseEntered
//
// Handles the mouse entering the Enable Detailed Messages check
//
// Called by:   DTSTest_AdvancedControlsSetUpWindow
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_AdvancedDetailedMessagesCheckMouseEntered(
    Object          ^sender,
    EventArgs       ^evt)
{
    DTSTest_UpdateStatusLine("Enables all types of modal messages");
}                                       // end of DTSTest_AdvancedDetailedMessagesCheckMouseEntered()
//----------------------------------------------------------------------------
// DTSTest_AdvancedEmailMessageCCAddressBoxMouseEntered
//
// Handles the mouse entering the Send Text CC Number text box
//
// Called by:   DTSTest_AdvancedControlsSetUpWindow
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_AdvancedEmailMessageCCAddressBoxMouseEntered(
    Object          ^sender,
    EventArgs       ^evt)
{
    DTSTest_UpdateStatusLine("Email address to CC a message when an event requires it");
}                                       // end of DTSTest_AdvancedEmailMessageCCAddressBoxMouseEntered()
//----------------------------------------------------------------------------
// DTSTest_AdvancedEmailMessageToAddressBoxMouseEntered
//
// Handles the mouse entering the Send Text To Address text box
//
// Called by:   DTSTest_AdvancedControlsSetUpWindow
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_AdvancedEmailMessageToAddressBoxMouseEntered(
    Object          ^sender,
    EventArgs       ^evt)
{
    DTSTest_UpdateStatusLine("Email address to send a message when an event requires it");
}                                       // end of DTSTest_AdvancedEmailMessageToAddressBoxMouseEntered()
//----------------------------------------------------------------------------
// DTSTest_AdvancedEnableExperimentsAreaMouseEntered
//
// Handles the mouse entering the Enable Experiments check
//
// Called by:   DTSTest_AdvancedControlsSetUpWindow
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_AdvancedEnableExperimentsAreaMouseEntered(
    Object          ^sender,
    EventArgs       ^evt)
{
    DTSTest_UpdateStatusLine("Enables and displays the experiments button");
}                                       // end of DTSTest_AdvancedEnableExperimentsAreaMouseEntered()
//----------------------------------------------------------------------------
// DTSTest_AdvancedEnableStackTracesCheckMouseEntered
//
// Handles the mouse entering the Enable Stack Traces check
//
// Called by:   DTSTest_AdvancedControlsSetUpWindow
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_AdvancedEnableStackTracesCheckMouseEntered(
    Object          ^sender,
    EventArgs       ^evt)
{
    DTSTest_UpdateStatusLine("Displays stack traces when displaying errors");
}                                       // end of DTSTest_AdvancedEnableStackTracesCheckMouseEntered()
//----------------------------------------------------------------------------
// DTSTest_AdvancedErrorMessagesCheckMouseEntered
//
// Handles the mouse entering the Enable Error Messages check
//
// Called by:   DTSTest_AdvancedControlsSetUpWindow
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_AdvancedErrorMessagesCheckMouseEntered(
    Object          ^sender,
    EventArgs       ^evt)
{
    DTSTest_UpdateStatusLine("Enables error modal messages");
}                                       // end of DTSTest_AdvancedErrorMessagesCheckMouseEntered()
//----------------------------------------------------------------------------
// DTSTest_AdvancedExpMessagesCheckMouseEntered
//
// Handles the mouse entering the Enable Experimental Messages check
//
// Called by:   DTSTest_AdvancedControlsSetUpWindow
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_AdvancedExpMessagesCheckMouseEntered(
    Object          ^sender,
    EventArgs       ^evt)
{
    DTSTest_UpdateStatusLine("Enables experimental modal messages");
}                                       // end of DTSTest_AdvancedExpMessagesCheckMouseEntered()
//----------------------------------------------------------------------------
// DTSTest_AdvancedExpOneButtonMouseEntered
//
// Handles the mouse entering the Perform Experiments button
//
// Called by:   DTSTest_AdvancedControlsSetUpWindow
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_AdvancedExpOneButtonMouseEntered(
    Object          ^sender,
    EventArgs       ^evt)
{
    DTSTest_UpdateStatusLine("Performs one or more predetermined experiments");
}                                       // end of DTSTest_AdvancedExpOneButtonMouseEntered()
//----------------------------------------------------------------------------
// DTSTest_AdvancedSendEmailErrorMessageCheckMouseEntered
//
// Handles the mouse entering the Send Email Message on Errors button
//
// Called by:   DTSTest_AdvancedControlsSetUpWindow
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_AdvancedSendEmailErrorMessageCheckMouseEntered(
    Object          ^sender,
    EventArgs       ^evt)
{
    DTSTest_UpdateStatusLine("Sends email messages upon encountering errors");
}                                       // end of DTSTest_AdvancedSendEmailErrorMessageCheckMouseEntered()
//----------------------------------------------------------------------------
// DTSTest_AdvancedSendTextErrorMessageCheckMouseEntered
//
// Handles the mouse entering the Send Text Message on Errors button
//
// Called by:   DTSTest_AdvancedControlsSetUpWindow
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_AdvancedSendTextErrorMessageCheckMouseEntered(
    Object          ^sender,
    EventArgs       ^evt)
{
    DTSTest_UpdateStatusLine("Sends text messages upon encountering errors");
}                                       // end of DTSTest_AdvancedSendTextErrorMessageCheckMouseEntered()
//----------------------------------------------------------------------------
// DTSTest_AdvancedSerialPortAreaMouseEntered
//
// Handles the mouse entering the Serial Port area
//
// Called by:   DTSTest_AdvancedControlsSetUpWindow
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_AdvancedSerialPortAreaMouseEntered(
    Object          ^sender,
    EventArgs       ^evt)
{
    DTSTest_UpdateStatusLine("Force a serial port to be recognized for PDGIC communications");
}                                       // end of DTSTest_AdvancedSerialPortAreaMouseEntered()
//----------------------------------------------------------------------------
// DTSTest_AdvancedTextMessageCCNumberBoxMouseEntered
//
// Handles the mouse entering the Send Text CC Number text box
//
// Called by:   DTSTest_AdvancedControlsSetUpWindow
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_AdvancedTextMessageCCNumberBoxMouseEntered(
    Object          ^sender,
    EventArgs       ^evt)
{
    DTSTest_UpdateStatusLine("Phone number to CC a text message when an event requires it");
}                                       // end of DTSTest_AdvancedTextMessageCCNumberBoxMouseEntered()
//----------------------------------------------------------------------------
// DTSTest_AdvancedTextMessageToNumberBoxMouseEntered
//
// Handles the mouse entering the Send Text To Number text box
//
// Called by:   DTSTest_AdvancedControlsSetUpWindow
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_AdvancedTextMessageToNumberBoxMouseEntered(
    Object          ^sender,
    EventArgs       ^evt)
{
    DTSTest_UpdateStatusLine("Phone number to send a text message when an event requires it");
}                                       // end of DTSTest_AdvancedTextMessageToNumberBoxMouseEntered()
//----------------------------------------------------------------------------
// DTSTest_AdvancedVerboseMessagesCheckMouseEntered
//
// Handles the mouse entering the Enable Verbose Messages check
//
// Called by:   DTSTest_AdvancedControlsSetUpWindow
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_AdvancedVerboseMessagesCheckMouseEntered(
    Object          ^sender,
    EventArgs       ^evt)
{
    DTSTest_UpdateStatusLine("Enables verbose modal messages");
}                                       // end of DTSTest_AdvancedVerboseMessagesCheckMouseEntered()
//----------------------------------------------------------------------------
// DTSTest_ConfigFileSaveDontSaveAreaMouseEntered
//
// Handles the mouse entering the Don't Save Config File checkbox
//
// Called by:   DTSTest_AdvancedControlsSetUpWindow
//              DTSTest_InstallToolStrip
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_ConfigFileSaveDontSaveAreaMouseEntered(
    Object          ^sender,
    EventArgs       ^evt)
{
    DTSTest_UpdateStatusLine("Prevents the program config file from being saved when you exit the program");
}                                       // end of DTSTest_ConfigFileSaveDontSaveAreaMouseEntered()
//----------------------------------------------------------------------------
// DTSTest_EmailMessageCloseButtonMouseEntered
//
// Handles the mouse entering the Close Email button
//
// Called by:   DTSTest_GenerateSupportLog
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_EmailMessageCloseButtonMouseEntered(
    Object          ^sender,
    EventArgs       ^evt)
{
    DTSTest_UpdateStatusLine("Closes the email dialogue");
}                                       // end of DTSTest_EmailMessageCloseButtonMouseEntered()
//----------------------------------------------------------------------------
// DTSTest_EmailMessageSendButtonMouseEntered
//
// Handles the mouse entering the Send Email button
//
// Called by:   DTSTest_GenerateSupportLog
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_EmailMessageSendButtonMouseEntered(
    Object          ^sender,
    EventArgs       ^evt)
{
    DTSTest_UpdateStatusLine("Sends an email message to Quartzdyne Support with the Support Log attached");
}                                       // end of DTSTest_EmailMessageSendButtonMouseEntered()
//----------------------------------------------------------------------------
// DTSTest_HelpAboutQuartzdyneLogoMouseEntered
//
// Handles the mouse entering the Quartzdyne Logo image
//
// Called by:   DTSTest_DisplayHelpLink
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_HelpAboutQuartzdyneLogoMouseEntered(
    Object          ^sender,
    EventArgs       ^evt)
{
    DTSTest_UpdateStatusLine("Opens the browser to the Quartzdyne home page");
}                                       // end of DTSTest_HelpAboutQuartzdyneLogoMouseEntered()
//----------------------------------------------------------------------------
// DTSTest_HelpAboutSoftwareLogoMouseEntered
//
// Handles the mouse entering the Software Logo image
//
// Called by:   DTSTest_AboutHelp
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_HelpAboutSoftwareLogoMouseEntered(
    Object          ^sender,
    EventArgs       ^evt)
{
    DTSTest_UpdateStatusLine("Opens the browser to the DTSTest Help page");
}                                       // end of DTSTest_HelpAboutSoftwareLogoMouseEntered()
//----------------------------------------------------------------------------
// DTSTest_HomeAddCommentAreaMouseEntered
//
// Handles the mouse entering the home Add Command area
//
// Called by:   DTSTest_InstallHomeWindowGraphics
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_HomeAddCommentAreaMouseEntered(
    Object          ^sender,
    EventArgs       ^evt)
{
    DTSTest_UpdateStatusLine("Add a text comment to the results log");
}                                       // end of DTSTest_HomeAddCommentAreaMouseEntered()
////----------------------------------------------------------------------------
//// DTSTest_HomeBargeE2PowerDisableButtonMouseEntered
////
//// Handles the mouse entering the home Disable E2 Barge Power button
////
//// Called by:   DTSTest_InstallHomeWindowGraphics
////----------------------------------------------------------------------------
//    void DTSTest_GUIClass::
//DTSTest_HomeBargeE2PowerDisableButtonMouseEntered(
//    Object          ^sender,
//    EventArgs       ^evt)
//{
//    DTSTest_UpdateStatusLine("Disables power to the barge at address E2");
//}                                       // end of DTSTest_HomeBargeE2PowerDisableButtonMouseEntered()
////----------------------------------------------------------------------------
//// DTSTest_HomeBargeE2PowerEnableButtonMouseEntered
////
//// Handles the mouse entering the home Enable E2 Barge Power button
////
//// Called by:   DTSTest_InstallHomeWindowGraphics
////----------------------------------------------------------------------------
//    void DTSTest_GUIClass::
//DTSTest_HomeBargeE2PowerEnableButtonMouseEntered(
//    Object          ^sender,
//    EventArgs       ^evt)
//{
//    DTSTest_UpdateStatusLine("Enables power to the barge at address E2");
//}                                       // end of DTSTest_HomeBargeE2PowerEnableButtonMouseEntered()
//----------------------------------------------------------------------------
// DTSTest_HomeBaudRateLabelMouseEntered
//
// Handles the mouse entering the home Baud Rate label
//
// Called by:   DTSTest_InstallHomeWindowGraphics
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_HomeBaudRateLabelMouseEntered(
    Object          ^sender,
    EventArgs       ^evt)
{
    DTSTest_UpdateStatusLine("The current DTS system (PDGIC, gauges, barges) baud rate");
}                                       // end of DTSTest_HomeBaudRateLabelMouseEntered()
//----------------------------------------------------------------------------
// DTSTest_HomeCalculateCRCsCheckMouseEntered
//
// Handles the mouse entering the home Calculate CRCs checkbox
//
// Called by:   DTSTest_InstallHomeWindowGraphics
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_HomeCalculateCRCsCheckMouseEntered(
    Object          ^sender,
    EventArgs       ^evt)
{
    DTSTest_UpdateStatusLine("Calculate CRCs for your input line and script lines if checked");
}                                       // end of DTSTest_HomeCalculateCRCsCheckMouseEntered()
//----------------------------------------------------------------------------
// DTSTest_HomeClearCommandDialogueButtonMouseEntered
//
// Handles the mouse entering the home Clear Command Dialogue button
//
// Called by:   DTSTest_InstallHomeWindowGraphics
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_HomeClearCommandDialogueButtonMouseEntered(
    Object          ^sender,
    EventArgs       ^evt)
{
    DTSTest_UpdateStatusLine("Clears the command dialogue box");
}                                       // end of DTSTest_HomeClearCommandDialogueButtonMouseEntered()
//----------------------------------------------------------------------------
// DTSTest_HomeCommandDialogueBoxMouseEntered
//
// Handles the mouse entering the home Command Dialogue text box area
//
// Called by:   DTSTest_InstallHomeWindowGraphics
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_HomeCommandDialogueBoxMouseEntered(
    Object          ^sender,
    EventArgs       ^evt)
{
    DTSTest_UpdateStatusLine("Displays commands sent to, and responses from, the device");
}                                       // end of DTSTest_HomeCommandDialogueBoxMouseEntered()
//----------------------------------------------------------------------------
// DTSTest_HomeCSVLogCheckMouseEntered
//
// Handles the mouse entering the home CSV Log Files check area
//
// Called by:   DTSTest_InstallHomeWindowGraphics
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_HomeCSVLogCheckMouseEntered(
    Object          ^sender,
    EventArgs       ^evt)
{
    DTSTest_UpdateStatusLine("Creates .CSV results files when results logs are saved");
}                                       // end of DTSTest_HomeCSVLogCheckMouseEntered()
//----------------------------------------------------------------------------
// DTSTest_HomeDemoModeCheckMouseEntered
//
// Handles the mouse entering the home Demo Mode checkbox
//
// Called by:   DTSTest_InstallHomeWindowGraphics
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_HomeDemoModeCheckMouseEntered(
    Object          ^sender,
    EventArgs       ^evt)
{
    DTSTest_UpdateStatusLine("Enables Demo Mode (does not actually perform the commands) if checked");
}                                       // end of DTSTest_HomeDemoModeCheckMouseEntered()
//----------------------------------------------------------------------------
// DTSTest_HomeDieSerialNumberAreaMouseEntered
//
// Handles the mouse entering the home Die Serial Number area
//
// Called by:   DTSTest_InstallHomeWindowGraphics
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_HomeDieSerialNumberAreaMouseEntered(
    Object          ^sender,
    EventArgs       ^evt)
{
    DTSTest_UpdateStatusLine("Hardware setup (die) serial number");
}                                       // end of DTSTest_HomeDieSerialNumberAreaMouseEntered()
//----------------------------------------------------------------------------
// DTSTest_HomeExitButtonMouseEntered
//
// Handles the mouse entering the home Exit button
//
// Called by:   DTSTest_InstallHomeWindowGraphics
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_HomeExitButtonMouseEntered(
    Object          ^sender,
    EventArgs       ^evt)
{
    DTSTest_UpdateStatusLine("Exits the program");
}                                       // end of DTSTest_HomeExitButtonMouseEntered()
//----------------------------------------------------------------------------
// DTSTest_HomeLoadControlScriptFileButtonMouseEntered
//
// Handles the mouse entering the home Load Control Script button
//
// Called by:   DTSTest_InstallHomeWindowGraphics
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_HomeLoadControlScriptFileButtonMouseEntered(
    Object          ^sender,
    EventArgs       ^evt)
{
    DTSTest_UpdateStatusLine("Loads a control script file to run");
}                                       // end of DTSTest_HomeLoadControlScriptFileButtonMouseEntered()
//----------------------------------------------------------------------------
// DTSTest_HomeLoopControlScriptButtonMouseEntered
//
// Handles the mouse entering the home Loop Control Script button
//
// Called by:   DTSTest_InstallHomeWindowGraphics
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_HomeLoopControlScriptButtonMouseEntered(
    Object          ^sender,
    EventArgs       ^evt)
{
    DTSTest_UpdateStatusLine(String::Concat(
        (DTSTest_ControlScriptLooping ? "Stops" : "Starts"),
        " running the loaded script in a loop"));
}                                       // end of DTSTest_HomeLoopControlScriptButtonMouseEntered()
//----------------------------------------------------------------------------
// DTSTest_HomeNormalizeReadingsCheckMouseEntered
//
// Handles the mouse entering the home Normalize Readings checkbox
//
// Called by:   DTSTest_InstallHomeWindowGraphics
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_HomeNormalizeReadingsCheckMouseEntered(
    Object          ^sender,
    EventArgs       ^evt)
{
    DTSTest_UpdateStatusLine("Normalizes the pressure and temperature readings to near-ambient values");
}                                       // end of DTSTest_HomeNormalizeReadingsCheckMouseEntered()
//----------------------------------------------------------------------------
// DTSTest_HomeOperatorNameAreaMouseEntered
//
// Handles the mouse entering the home Operator Name area
//
// Called by:   DTSTest_InstallHomeWindowGraphics
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_HomeOperatorNameAreaMouseEntered(
    Object          ^sender,
    EventArgs       ^evt)
{
    DTSTest_UpdateStatusLine("Your name, your login name, or designated operator name");
}                                       // end of DTSTest_HomeOperatorNameAreaMouseEntered()
//----------------------------------------------------------------------------
// DTSTest_HomePlaceholderAreaMouseEntered
//
// Handles the mouse entering the home Placeholder area
//
// Called by:   DTSTest_InstallHomeWindowGraphics
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_HomePlaceholderAreaMouseEntered(
    Object          ^sender,
    EventArgs       ^evt)
{
    DTSTest_UpdateStatusLine("Value represented by the $1 script placeholder");
}                                       // end of DTSTest_HomePlaceholderAreaMouseEntered()
//----------------------------------------------------------------------------
// DTSTest_HomePrependDateAndTimeCheckMouseEntered
//
// Handles the mouse entering the home Prepend Date and Time checkbox
//
// Called by:   DTSTest_InstallHomeWindowGraphics
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_HomePrependDateAndTimeCheckMouseEntered(
    Object          ^sender,
    EventArgs       ^evt)
{
    DTSTest_UpdateStatusLine("Prepends the current date and time to each log entry if checked");
}                                       // end of DTSTest_HomePrependDateAndTimeCheckMouseEntered()
//----------------------------------------------------------------------------
// DTSTest_HomeProgressBarMouseEntered
//
// Handles the mouse entering the home Progress Bar
//
// Called by:   DTSTest_InstallHomeWindowGraphics
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_HomeProgressBarMouseEntered(
    Object          ^sender,
    EventArgs       ^evt)
{
    DTSTest_UpdateStatusLine("Displays the script execution progress");
}                                       // end of DTSTest_HomeProgressBarMouseEntered()
//----------------------------------------------------------------------------
// DTSTest_HomeReportCRCErrorsCheckMouseEntered
//
// Handles the mouse entering the home Report CRC Errors checkbox
//
// Called by:   DTSTest_InstallHomeWindowGraphics
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_HomeReportCRCErrorsCheckMouseEntered(
    Object          ^sender,
    EventArgs       ^evt)
{
    DTSTest_UpdateStatusLine("Detects CRC errors if checked");
}                                       // end of DTSTest_HomeReportCRCErrorsCheckMouseEntered()
//----------------------------------------------------------------------------
// DTSTest_HomeRerunControlScriptButtonMouseEntered
//
// Handles the mouse entering the home Rerun Control Script button
//
// Called by:   DTSTest_InstallHomeWindowGraphics
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_HomeRerunControlScriptButtonMouseEntered(
    Object          ^sender,
    EventArgs       ^evt)
{
    DTSTest_UpdateStatusLine("Re-runs the control script once");
}                                       // end of DTSTest_HomeRerunControlScriptButtonMouseEntered()
//----------------------------------------------------------------------------
// DTSTest_HomeResultsLogPathLabelMouseEntered
//
// Handles the mouse entering the home Log Directory label
//
// Called by:   DTSTest_InstallHomeWindowGraphics
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_HomeResultsLogPathLabelMouseEntered(
    Object          ^sender,
    EventArgs       ^evt)
{
    DTSTest_UpdateStatusLine("Path (folder and file name) of the current results log");
}                                       // end of DTSTest_HomeResultsLogPathLabelMouseEntered()
//----------------------------------------------------------------------------
// DTSTest_HomeSaveCommandDialogueButtonMouseEntered
//
// Handles the mouse entering the home Save Command Dialogue button
//
// Called by:   DTSTest_InstallHomeWindowGraphics
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_HomeSaveCommandDialogueButtonMouseEntered(
    Object          ^sender,
    EventArgs       ^evt)
{
    DTSTest_UpdateStatusLine("Saves the current command text box to file");
}                                       // end of DTSTest_HomeSaveCommandDialogueButtonMouseEntered()
//----------------------------------------------------------------------------
// DTSTest_HomeSingleCommandAreaMouseEntered
//
// Handles the mouse entering the home Single Command area
//
// Called by:   DTSTest_InstallHomeWindowGraphics
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_HomeSingleCommandAreaMouseEntered(
    Object          ^sender,
    EventArgs       ^evt)
{
    DTSTest_UpdateStatusLine("Enter a single command manually");
}                                       // end of DTSTest_HomeSingleCommandAreaMouseEntered()
//----------------------------------------------------------------------------
// DTSTest_HomeSwitchBaudRateButtonMouseEntered
//
// Handles the mouse entering the home Switch Baud Rate button
//
// Called by:   DTSTest_InstallHomeWindowGraphics
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_HomeSwitchBaudRateButtonMouseEntered(
    Object          ^sender,
    EventArgs       ^evt)
{
    DTSTest_UpdateStatusLine(String::Concat(
        "Switches the system-wide MODBUS communication rate to ",
        (DTSTest_BaudRateSetTo2400 ? _T("1200") : _T("2400")),
        " baud"));
}                                       // end of DTSTest_HomeSwitchBaudRateButtonMouseEntered()
//----------------------------------------------------------------------------
// DTSTest_HomeVerboseLogMessagesCheckMouseEntered
//
// Handles the mouse entering the Verbose Log Messages checkbox
//
// Called by:   DTSTest_InstallHomeWindowGraphics
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_HomeVerboseLogMessagesCheckMouseEntered(
    Object          ^sender,
    EventArgs       ^evt)
{
    DTSTest_UpdateStatusLine("Enables verbose log messages in the command box if checked");
}                                       // end of DTSTest_HomeVerboseLogMessagesCheckMouseEntered()
//----------------------------------------------------------------------------
// DTSTest_ToolStripAboutDropDownMouseEntered
//
// Handles the mouse entering the About drop-down button
//
// Called by:   DTSTest_InstallToolStrip
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_ToolStripAboutDropDownMouseEntered(
    Object          ^sender,
    EventArgs       ^evt)
{
    DTSTest_UpdateStatusLine("Displays a small popup that briefly describes the software and its version, including links");
}                                       // end of DTSTest_ToolStripAboutDropDownMouseEntered()
//----------------------------------------------------------------------------
// DTSTest_ToolStripAdvancedButtonMouseEntered
//
// Handles the mouse entering the area over the Advanced button
//
// Called by:   DTSTest_InstallToolStrip
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_ToolStripAdvancedButtonMouseEntered(
    Object          ^sender,
    EventArgs       ^evt)
{
    //------------------------------------------------------------------------
    DTSTest_UpdateStatusLine("Presents the advanced functions");
    if (advancedTSDDButton)
    {
        advancedTSDDButton->ShowDropDown();
    }
}                                       // end of DTSTest_ToolStripAdvancedButtonMouseEntered()
//----------------------------------------------------------------------------
// DTSTest_ToolStripAdvancedButtonMouseMoved
//
// Handles the mouse moving over the Advanced button
//
// Called by:   DTSTest_InstallToolStrip
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_ToolStripAdvancedButtonMouseMoved(
    Object          ^sender,
    MouseEventArgs  ^evt)
{
    int             previousVerticalPosition;
    //------------------------------------------------------------------------
    if (advancedTSDDButton)
    {
        previousVerticalPosition = (((int) advancedTSDDButton->Tag) & GUI_DROP_DOWN_VERTICAL_POSITION_MASK);
        advancedTSDDButton->Tag = (GUI_DROP_DOWN_CLOSED | evt->Y);
        if ((evt->Y > previousVerticalPosition) && (evt->X < (advancedTSDDButton->Width - 4)))
            advancedTSDDButton->Tag = (GUI_DROP_DOWN_OPENED | evt->Y);
    }
}                                       // end of DTSTest_ToolStripAdvancedButtonMouseMoved()
//----------------------------------------------------------------------------
// DTSTest_ToolStripAdvancedControlsDropDownMouseEntered
//
// Handles the mouse entering the Advanced Controls drop-down button
//
// Called by:   DTSTest_InstallToolStrip
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_ToolStripAdvancedControlsDropDownMouseEntered(
    Object          ^sender,
    EventArgs       ^evt)
{
    DTSTest_UpdateStatusLine("Displays a window that presents a variety of advanced controls");
}                                       // end of DTSTest_ToolStripAdvancedControlsDropDownMouseEntered()
//----------------------------------------------------------------------------
// DTSTest_ToolStripButtonsMouseExited
//
// Handles mousing away from any of the tool strip drop down buttons
//
// Called by:   DTSTest_InstallToolStrip
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_ToolStripButtonsMouseExited(
    Object          ^sender,
    EventArgs       ^evt)
{
    //------------------------------------------------------------------------
    DTSTest_UpdateStatusLine("DTSTest Ready");
    if (fileTSDDButton)
    {
        if (GUI_DROP_DOWN_CLOSED == (((int) fileTSDDButton->Tag) & GUI_DROP_DOWN_DISPLAY_MASK))
            fileTSDDButton->HideDropDown();
    }
    if (controlTSDDButton)
    {
        if (GUI_DROP_DOWN_CLOSED == (((int) controlTSDDButton->Tag) & GUI_DROP_DOWN_DISPLAY_MASK))
            controlTSDDButton->HideDropDown();
    }
    if (helpTSDDButton)
    {
        if (GUI_DROP_DOWN_CLOSED == (((int) helpTSDDButton->Tag) & GUI_DROP_DOWN_DISPLAY_MASK))
            helpTSDDButton->HideDropDown();
    }
    if (advancedTSDDButton)
    {
        if (GUI_DROP_DOWN_CLOSED == (((int) advancedTSDDButton->Tag) & GUI_DROP_DOWN_DISPLAY_MASK))
            advancedTSDDButton->HideDropDown();
    }
}                                       // end of DTSTest_ToolStripButtonsMouseExited()
//----------------------------------------------------------------------------
// DTSTest_ToolStripCheckForUpdateDropDownMouseEntered
//
// Handles the mouse entering the Check for Update drop-down button
//
// Called by:   DTSTest_InstallToolStrip
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_ToolStripCheckForUpdateDropDownMouseEntered(
    Object          ^sender,
    EventArgs       ^evt)
{
    DTSTest_UpdateStatusLine("Checks online whether an update to the DTSTest software is available, then performs the update if it is");
}                                       // end of DTSTest_ToolStripCheckForUpdateDropDownMouseEntered()
//----------------------------------------------------------------------------
// DTSTest_ToolStripControlButtonMouseEntered
//
// Handles the mouse entering the area over the Controlbutton
//
// Called by:   DTSTest_InstallToolStrip
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_ToolStripControlButtonMouseEntered(
    Object          ^sender,
    EventArgs       ^evt)
{
    //------------------------------------------------------------------------
    DTSTest_UpdateStatusLine("Presents a variety of general control utilities");
    if (controlTSDDButton)
    {
        controlTSDDButton->ShowDropDown();
    }
}                                       // end of DTSTest_ToolStripControlButtonMouseEntered()
//----------------------------------------------------------------------------
// DTSTest_ToolStripControlButtonMouseMoved
//
// Handles the mouse moving over the Control button
//
// Called by:   DTSTest_InstallToolStrip
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_ToolStripControlButtonMouseMoved(
    Object          ^sender,
    MouseEventArgs  ^evt)
{
    int             previousVerticalPosition;
    //------------------------------------------------------------------------
    if (controlTSDDButton)
    {
        previousVerticalPosition = (((int) controlTSDDButton->Tag) & GUI_DROP_DOWN_VERTICAL_POSITION_MASK);
        controlTSDDButton->Tag = (GUI_DROP_DOWN_CLOSED | evt->Y);
        if ((evt->Y > previousVerticalPosition) && (evt->X < (controlTSDDButton->Width - 4)))
            controlTSDDButton->Tag = (GUI_DROP_DOWN_OPENED | evt->Y);
    }
}                                       // end of DTSTest_ToolStripControlButtonMouseMoved()
//----------------------------------------------------------------------------
// DTSTest_ToolStripCSVControlsDropDownMouseEntered
//
// Handles the mouse entering the CSV File Controls drop-down button
//
// Called by:   DTSTest_InstallToolStrip
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_ToolStripCSVControlsDropDownMouseEntered(
    Object          ^sender,
    EventArgs       ^evt)
{
    DTSTest_UpdateStatusLine("Displays a window that presents the CSV file controls");
}                                       // end of DTSTest_ToolStripCSVControlsDropDownMouseEntered()
//----------------------------------------------------------------------------
// DTSTest_ToolStripDisplayEventLogDropDownMouseEntered
//
// Handles the mouse entering the Display Event Log drop-down button
//
// Called by:   DTSTest_InstallToolStrip
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_ToolStripDisplayEventLogDropDownMouseEntered(
    Object          ^sender,
    EventArgs       ^evt)
{
    DTSTest_UpdateStatusLine("Displays the most recent event log, if any are present");
}                                       // end of DTSTest_ToolStripDisplayEventLogDropDownMouseEntered()
//----------------------------------------------------------------------------
// DTSTest_ToolStripDropDownsMouseExited
//
// Handles the event of mousing away from the Toolstrip drop-down menus
//
// Called by:   DTSTest_InstallToolStrip
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_ToolStripDropDownsMouseExited(
    Object          ^sender,
    EventArgs       ^evt)
{
    //------------------------------------------------------------------------
    if (fileTSDDButton)
    {
        fileTSDDButton->HideDropDown();
        fileTSDDButton->Tag = GUI_DROP_DOWN_CLOSED;
    }
    if (controlTSDDButton)
    {
        controlTSDDButton->HideDropDown();
        controlTSDDButton->Tag = GUI_DROP_DOWN_CLOSED;
    }
    if (helpTSDDButton)
    {
        helpTSDDButton->HideDropDown();
        helpTSDDButton->Tag = GUI_DROP_DOWN_CLOSED;
    }
    if (advancedTSDDButton && !eventLogRecordingTSDDButton->Pressed)
    {
        advancedTSDDButton->HideDropDown();
        advancedTSDDButton->Tag = GUI_DROP_DOWN_CLOSED;
    }
}                                       // end of DTSTest_ToolStripDropDownsMouseExited()
//----------------------------------------------------------------------------
// DTSTest_ToolStripExperimentalControlsDropDownMouseEntered
//
// Handles the mouse entering the Experimental Controls drop-down button
//
// Called by:   DTSTest_InstallToolStrip
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_ToolStripExperimentalControlsDropDownMouseEntered(
    Object          ^sender,
    EventArgs       ^evt)
{
    DTSTest_UpdateStatusLine("Displays a window that presents a variety of experimental controls");
}                                       // end of DTSTest_ToolStripExperimentalControlsDropDownMouseEntered()
//----------------------------------------------------------------------------
// DTSTest_ToolStripEventLogAllDropDownMouseEntered
//
// Handles mousing over the Log All Events drop-down button
//
// Called by:   DTSTest_InstallToolStrip
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_ToolStripEventLogAllDropDownMouseEntered(
    Object          ^sender,
    EventArgs       ^evt)
{
    //------------------------------------------------------------------------
    if (DTSTest_EventLogBasicEnabled)
        DTSTest_UpdateStatusLine("Stops all event log recording");
    else
        DTSTest_UpdateStatusLine("Starts logging of all non-test events");
}                                       // end of DTSTest_ToolStripEventLogAllDropDownMouseEntered()
//----------------------------------------------------------------------------
// DTSTest_ToolStripEventLogBasicDropDownMouseEntered
//
// Handles mousing over the Log Basic Events drop-down button
//
// Called by:   DTSTest_InstallToolStrip
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_ToolStripEventLogBasicDropDownMouseEntered(
    Object          ^sender,
    EventArgs       ^evt)
{
    //------------------------------------------------------------------------
    String ^statusString = String::Concat(
        (DTSTest_EventLogBasicEnabled ? "Stops" : "Starts"),
        _T(" logging of basic (normal, top-level) events"));
    DTSTest_UpdateStatusLine(statusString);
}                                       // end of DTSTest_ToolStripEventLogBasicDropDownMouseEntered()
//----------------------------------------------------------------------------
// DTSTest_ToolStripEventLogDetailedDropDownMouseEntered
//
// Handles mousing over the Log Detailed Events drop-down button
//
// Called by:   DTSTest_InstallToolStrip
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_ToolStripEventLogDetailedDropDownMouseEntered(
    Object          ^sender,
    EventArgs       ^evt)
{
    //------------------------------------------------------------------------
    String ^statusString = String::Concat(
        (DTSTest_EventLogDetailedEnabled ? "Stops" : "Starts"),
        _T(" logging of all detailed events"));
    DTSTest_UpdateStatusLine(statusString);
}                                       // end of DTSTest_ToolStripEventLogDetailedDropDownMouseEntered()
//----------------------------------------------------------------------------
// DTSTest_ToolStripEventLogDropDownMouseEntered
//
// Handles the mouse entering the Event Log drop-down button
//
// Called by:   DTSTest_InstallToolStrip
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_ToolStripEventLogDropDownMouseEntered(
    Object          ^sender,
    EventArgs       ^evt)
{
    //------------------------------------------------------------------------
    DTSTest_UpdateStatusLine("Allows you to start logging mouse clicks and other software events to a file");
    if (eventLogRecordingTSDDButton)
    {
        eventLogRecordingTSDDButton->ShowDropDown();
    }
}                                       // end of DTSTest_ToolStripEventLogDropDownMouseEntered()
//----------------------------------------------------------------------------
// DTSTest_ToolStripEventLogDropDownMouseExited
//
// Handles mousing away from the Event Log Toolstrip drop-down menus
//
// Called by:   DTSTest_InstallToolStrip
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_ToolStripEventLogDropDownMouseExited(
    Object          ^sender,
    EventArgs       ^evt)
{
    //------------------------------------------------------------------------
    if (eventLogRecordingTSDDButton)
    {
        eventLogRecordingTSDDButton->HideDropDown();
    }
    if (advancedTSDDButton)
    {
        advancedTSDDButton->HideDropDown();
        advancedTSDDButton->Tag = GUI_DROP_DOWN_CLOSED;
    }
}                                       // end of DTSTest_ToolStripEventLogDropDownMouseExited()
//----------------------------------------------------------------------------
// DTSTest_ToolStripEventLogVerboseDropDownMouseEntered
//
// Handles mousing over the Log Verbose Events drop-down button
//
// Called by:   DTSTest_InstallToolStrip
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_ToolStripEventLogVerboseDropDownMouseEntered(
    Object          ^sender,
    EventArgs       ^evt)
{
    //------------------------------------------------------------------------
    String ^statusString = String::Concat(
        (DTSTest_EventLogVerboseEnabled ? "Stops" : "Starts"),
        _T(" logging of most events"));
    DTSTest_UpdateStatusLine(statusString);
}                                       // end of DTSTest_ToolStripEventLogVerboseDropDownMouseEntered()
//----------------------------------------------------------------------------
// DTSTest_ToolStripExpertModeDropDownMouseEntered
//
// Handles the mouse entering the Expert Mode drop-down button
//
// Called by:   DTSTest_InstallToolStrip
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_ToolStripExpertModeDropDownMouseEntered(
    Object          ^sender,
    EventArgs       ^evt)
{
    //------------------------------------------------------------------------
    if (DTSTest_GeneralInfo->flags & DTSTEST_GENERAL_EXPERT_MODE)
        DTSTest_UpdateStatusLine("Changes the software back to Normal Mode, and hides the Advanced functions");
    else
        DTSTest_UpdateStatusLine("Changes the software to Expert Mode, and makes the Advanced functions available");
}                                       // end of DTSTest_ToolStripExpertModeDropDownMouseEntered()
//----------------------------------------------------------------------------
// DTSTest_ToolStripFileButtonMouseEntered
//
// Handles the mouse entering the area over the File button
//
// Called by:   DTSTest_InstallToolStrip
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_ToolStripFileButtonMouseEntered(
    Object          ^sender,
    EventArgs       ^evt)
{
    //------------------------------------------------------------------------
    DTSTest_UpdateStatusLine("Presents file-related operations, plus an exit function");
    if (fileTSDDButton)
    {
        fileTSDDButton->ShowDropDown();
    }
}                                       // end of DTSTest_ToolStripFileButtonMouseEntered()
//----------------------------------------------------------------------------
// DTSTest_ToolStripFileButtonMouseMoved
//
// Handles the mouse moving over the File button
//
// Called by:   DTSTest_InstallToolStrip
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_ToolStripFileButtonMouseMoved(
    Object          ^sender,
    MouseEventArgs  ^evt)
{
    int             previousVerticalPosition;
    //------------------------------------------------------------------------
    if (fileTSDDButton)
    {
        previousVerticalPosition = (((int) fileTSDDButton->Tag) & GUI_DROP_DOWN_VERTICAL_POSITION_MASK);
        fileTSDDButton->Tag = (GUI_DROP_DOWN_CLOSED | evt->Y);
        if ((evt->Y > previousVerticalPosition) && (evt->X < (fileTSDDButton->Width - 4)))
            fileTSDDButton->Tag = (GUI_DROP_DOWN_OPENED | evt->Y);
    }
}                                       // end of DTSTest_ToolStripFileButtonMouseMoved()
//----------------------------------------------------------------------------
// DTSTest_ToolStripHelpButtonMouseEntered
//
// Handles the mouse entering the area over the Help button
//
// Called by:   DTSTest_InstallToolStrip
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_ToolStripHelpButtonMouseEntered(
    Object          ^sender,
    EventArgs       ^evt)
{
    //------------------------------------------------------------------------
    DTSTest_UpdateStatusLine("Presents help functions such as the online user guide and a submittable support log");
    if (helpTSDDButton)
    {
        helpTSDDButton->ShowDropDown();
    }
}                                       // end of DTSTest_ToolStripHelpButtonMouseEntered()
//----------------------------------------------------------------------------
// DTSTest_ToolStripHelpButtonMouseMoved
//
// Handles the mouse moving over the Help button
//
// Called by:   DTSTest_InstallToolStrip
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_ToolStripHelpButtonMouseMoved(
    Object          ^sender,
    MouseEventArgs  ^evt)
{
    int             previousVerticalPosition;
    //------------------------------------------------------------------------
    if (helpTSDDButton)
    {
        previousVerticalPosition = (((int) helpTSDDButton->Tag) & GUI_DROP_DOWN_VERTICAL_POSITION_MASK);
        helpTSDDButton->Tag = (GUI_DROP_DOWN_CLOSED | evt->Y);
        if ((evt->Y > previousVerticalPosition) && (evt->X < (helpTSDDButton->Width - 4)))
            helpTSDDButton->Tag = (GUI_DROP_DOWN_OPENED | evt->Y);
    }
}                                       // end of DTSTest_ToolStripHelpButtonMouseMoved()
//----------------------------------------------------------------------------
// DTSTest_ToolStripOnlineHelpDropDownMouseEntered
//
// Handles the mouse entering the Online Help drop-down button
//
// Called by:   DTSTest_InstallToolStrip
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_ToolStripOnlineHelpDropDownMouseEntered(
    Object          ^sender,
    EventArgs       ^evt)
{
    DTSTest_UpdateStatusLine("Opens the default browser to display the DTSTest online help website");
}                                       // end of DTSTest_ToolStripOnlineHelpDropDownMouseEntered()
//----------------------------------------------------------------------------
// DTSTest_ToolStripProgInfoDropDownMouseEntered
//
// Handles the mouse entering the Program Info drop-down button
//
// Called by:   DTSTest_InstallToolStrip
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_ToolStripProgInfoDropDownMouseEntered(
    Object          ^sender,
    EventArgs       ^evt)
{
    DTSTest_UpdateStatusLine("Displays a new window that presents current conditions, settings, and other program info");
}                                       // end of DTSTest_ToolStripProgInfoDropDownMouseEntered()
//----------------------------------------------------------------------------
// DTSTest_ToolStripSamplingControlsDropDownMouseEntered
//
// Handles the mouse entering the Sampling Controls drop-down button
//
// Called by:   DTSTest_InstallToolStrip
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_ToolStripSamplingControlsDropDownMouseEntered(
    Object          ^sender,
    EventArgs       ^evt)
{
    DTSTest_UpdateStatusLine("Displays a window that presents the sampling controls");
}                                       // end of DTSTest_ToolStripSamplingControlsDropDownMouseEntered()
//----------------------------------------------------------------------------
// DTSTest_ToolStripScriptControlsDropDownMouseEntered
//
// Handles the mouse entering the Script Controls drop-down button
//
// Called by:   DTSTest_InstallToolStrip
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_ToolStripScriptControlsDropDownMouseEntered(
    Object          ^sender,
    EventArgs       ^evt)
{
    DTSTest_UpdateStatusLine("Displays a window that presents the script controls");
}                                       // end of DTSTest_ToolStripScriptControlsDropDownMouseEntered()
//----------------------------------------------------------------------------
// DTSTest_ToolStripSupportLogDropDownMouseEntered
//
// Handles the mouse entering the support log drop-down button
//
// Called by:   DTSTest_InstallToolStrip
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_ToolStripSupportLogDropDownMouseEntered(
    Object          ^sender,
    EventArgs       ^evt)
{
    DTSTest_UpdateStatusLine("Creates a support log of system and program information");
}                                       // end of DTSTest_ToolStripSupportLogDropDownMouseEntered()
//----------------------------------------------------------------------------
// DTSTest_ToolStripTestingControlsDropDownMouseEntered
//
// Handles the mouse entering the Testing Controls drop-down button
//
// Called by:   DTSTest_InstallToolStrip
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_ToolStripTestingControlsDropDownMouseEntered(
    Object          ^sender,
    EventArgs       ^evt)
{
    DTSTest_UpdateStatusLine("Displays a window that presents the testing controls");
//    DTSTest_UpdateStatusLine("Displays a window that presents the testing controls");
}                                       // end of DTSTest_ToolStripTestingControlsDropDownMouseEntered()
//----------------------------------------------------------------------------
#endif      // MOUSEOVER_CPP
//============================================================================
// End of MouseOver.cpp
//============================================================================
