//============================================================================
// Utility.cpp
//
// The methods used by GUI.cpp for utility tasks
//
// Copyright (C) 2014 - 2016 Quartzdyne, Inc.  All rights reserved.
//
// No part of this source code may be reproduced or transmitted in any form or
// by any means, electronic or mechanical, including photocopying, recording,
// or any information storage and retrieval system, without express written
// permission from Quartzdyne, Inc.  Further, no use of this source code is
// permitted in any form or means without a valid, written license agreement
// with Quartzdyne, Inc.  While every reasonable precaution has been taken in
// the preparation of this source code, Quartzdyne, Inc., assumes no
// responsibility for errors, omissions, or damages from the use of the source
// code contained herein.
//
// NEITHER QUARTZDYNE, INC., ANY MEMBER OF QUARTZDYNE, INC., NOR ANY PERSON OR
// ORGANIZATION ACTING ON BEHALF OF THEM MAKES ANY WARRANTY OR REPRESENTATION
// WHATSOEVER, EXPRESS OR IMPLIED, INCLUDING ANY WARRANTY OF MERCHANTABILITY
// OR FITNESS FOR ANY PURPOSE WITH RESPECT TO THE SOURCE CODE OR ASSUMES ANY
// LIABILITY WHATSOEVER WITH RESPECT TO ANY USE OF THE SOURCE CODE OR ANY
// PORTION THEREOF OR WITH RESPECT TO ANY DAMAGES THAT MAY RESULT FROM SUCH
// USE.
//
// Noji Ratzlaff
//
// See DTSTest.log for a complete history of all updates, changes, and revisions
// of this source and other files and policies regarding DTSTest software
//
// Updated 01-14-2016
//============================================================================
#include    "stdafx.h"
#ifndef     UTILITY_CPP
#define     UTILITY_CPP
#include    "Utility.h"
//----------------------------------------------------------------------------
// DTSTest_AboutHelp
//
// Displays a small windows that describes the DTSTest software and version, plus
// provides some links to Quartzdyne websites
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_AboutHelp(void)
{
    DWORD           yPosition = 10;
    String          ^functionName = _T("DTSTest_AboutHelp");
    //------------------------------------------------------------------------
    RecordVerboseEvent("{0} called", functionName);
    //------------------------------------------------------------------------
    // Create a new window form
    //------------------------------------------------------------------------
    aboutHelpWindow = gcnew Form;
    //------------------------------------------------------------------------
    // Set its icon
    //------------------------------------------------------------------------
    aboutHelpWindow->Icon = DTSTest_SoftwareIcon;
    //------------------------------------------------------------------------
    // Set the background image
    //------------------------------------------------------------------------
//    aboutHelpWindow->BackgroundImage = whiteSandBackground;
    //------------------------------------------------------------------------
    // Set the title, the starting location, the size, and border style
    //------------------------------------------------------------------------
    aboutHelpWindow->Text = _T("About DTSTest");
    aboutHelpWindow->FormBorderStyle = ::FormBorderStyle::Fixed3D;
    aboutHelpWindow->StartPosition = FormStartPosition::CenterScreen;
    //------------------------------------------------------------------------
    // Prevent the user from changing its appearance
    //------------------------------------------------------------------------
    aboutHelpWindow->MaximizeBox = GUI_NO;
    aboutHelpWindow->HelpButton = GUI_NO;
    //------------------------------------------------------------------------
    // Begin pouplating the help text
    //------------------------------------------------------------------------
    DTSTest_DisplayHelpTextLine(
        aboutHelpWindow,
        String::Format(
            "DTSTest, Version {0} - {1:D}",
            DTSTEST_PROGRAM_VERSION_STRING,
            DTSTest_BuildNumber),
        yPosition,
        300);
    yPosition += 26;
    DTSTest_DisplayHelpTextLine(aboutHelpWindow, "Copyright � 2016 Quartzdyne, Inc.", yPosition, 280);
    yPosition += 26;
    //------------------------------------------------------------------------
    // This line contains a link at character offset 12 for 18 characters
    //------------------------------------------------------------------------
    DTSTest_DisplayHelpLink(aboutHelpWindow, "Visit us at www.quartzdyne.com", yPosition, 150, 12, 18);
    yPosition += 52;
    DTSTest_DisplayHelpTextLine(aboutHelpWindow, "Quartzdyne DTSTest", yPosition, 280);
    yPosition += 26;
    DTSTest_DisplayHelpTextLine(aboutHelpWindow, "eDTS / eDPS Testing Software", yPosition, 280);
    aboutHelpWindow->Size = Drawing::Size(440, yPosition + 70);
    //------------------------------------------------------------------------
    // Add an OK button
    //------------------------------------------------------------------------
    Button ^okButton = gcnew Button;
    okButton->Text = _T("OK");
    okButton->Location = Point(aboutHelpWindow->Width - 80, yPosition);
    okButton->Size = Drawing::Size(60, GUI_REGULAR_BUTTON_HEIGHT);
//    okButton->BackgroundImage = gcnew Bitmap(GUI_BG_SAND, GUI_YES);
    GUI_SetButtonInterfaceProperties(okButton);
    okButton->Click +=
        gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_HelpCloseWindow);
    aboutHelpWindow->Controls->Add(okButton);
    aboutHelpWindow->AcceptButton = okButton; // button when user presses Enter
    aboutHelpWindow->CancelButton = okButton; // button when user presses Esc
    //------------------------------------------------------------------------
    // Display the company logo
    //------------------------------------------------------------------------
    Label ^logo = gcnew Label;
    Image ^DTSTestLogo = Image::FromFile(GUI_PROGRAM_LOGO);
    logo->Image = DTSTestLogo;
    logo->Location = Point(aboutHelpWindow->Width - 120, 10);
    logo->Size = Drawing::Size(DTSTestLogo->Width, DTSTestLogo->Height);
    logo->BackColor = Color::Transparent;
    GUI_DisplayHandCursorOnHover(logo);
    logo->Click +=
        gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_ToolStripOnlineHelpDropDownClicked);
    logo->MouseEnter +=
        gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_HelpAboutSoftwareLogoMouseEntered);
    logo->MouseLeave +=
        gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_AnyObjectMouseExited);
    aboutHelpWindow->Controls->Add(logo);
    //------------------------------------------------------------------------
    // Finally, display the new window
    //------------------------------------------------------------------------
    aboutHelpWindow->ShowDialog();
    RecordVerboseEvent("{0} concluded", functionName);
}                                       // end of DTSTest_AboutHelp()
//----------------------------------------------------------------------------
// DTSTest_AffirmStartupConditions
//
// Ensures the operating environment and other conditions are what they should
// be prior to displaying the user interface
//
// Called by:   DTSTest_InitializeGUIComponents
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_AffirmStartupConditions(void)
{
    String          ^functionName = _T("DTSTest_AffirmStartupConditions");
    //------------------------------------------------------------------------
    RecordVerboseEvent("        {0} called", functionName);
    //------------------------------------------------------------------------
    // Check for an update to the current software version
    //------------------------------------------------------------------------
    DTSTest_CheckForCurrentSoftwareVersion(AnyNonErrorMessageEnabled);
//    DWORD numberOfModules = QD_GetNumberOfModules();
//    Modal("The system has {0} QCOM module{1}",
//        String::Concat(numberOfModules),
//        ((numberOfModules == 1) ? "" : "s"));
    RecordVerboseEvent("        {0} concluded", functionName);
}                                       // end of DTSTest_AffirmStartupConditions()
//----------------------------------------------------------------------------
// DTSTest_CheckForCurrentSoftwareVersion
//
// Checks the internet for an update to the current software version
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_CheckForCurrentSoftwareVersion(
    bool            announceResults)
{
    bool            fileSWNeedsUpdating = GUI_NO;
    bool            proceedToDownload = GUI_NO;
    bool            versionSWFound = GUI_NO;
    String          ^functionName = _T("DTSTest_CheckForCurrentSoftwareVersion");
    //------------------------------------------------------------------------
    RecordVerboseEvent("            {0} called", functionName);
    if (DTSTest_InternetIsAvailable())
    {
        //--------------------------------------------------------------------
        // The software has access to the web, so check for the presence of
        // the DTSTest version file
        //--------------------------------------------------------------------
        if (DTSTest_URLExists(DTSTEST_VERSION_URL))
        {
            //----------------------------------------------------------------
            // The version file has been located, so download and parse it
            //----------------------------------------------------------------
            WebClient ^webAccess = gcnew WebClient;
            String ^webVersionFile = webAccess->DownloadString(DTSTEST_VERSION_URL);
            if (!String::IsNullOrEmpty(webVersionFile))
            {
                //------------------------------------------------------------
                // Split up the file into separate lines
                //------------------------------------------------------------
                array <Char> ^pageDelimiters = gcnew array <Char> {'\r', '\n'};
                array <String ^> ^pageLines = webVersionFile->Split(
                    pageDelimiters,
                    StringSplitOptions::RemoveEmptyEntries);
                //------------------------------------------------------------
                // Ensure the first line represents the correct format
                //------------------------------------------------------------
                if (StringICompare(pageLines[0], _T("[DTSTest]")) == 0)
                {
                    String ^webSWVersion;
                    array <Char> ^lineDelimiters = gcnew array <Char> {'='};
                    array <String ^> ^lineParts;
                    for each (String ^pageLine in pageLines)
                    {
                        //----------------------------------------------------
                        // Only parse lines that contain the = character
                        //----------------------------------------------------
                        if (pageLine->Contains("="))
                        {
                            //------------------------------------------------
                            // Split up each line into tag and version
                            //------------------------------------------------
                            lineParts = pageLine->Split(
                                lineDelimiters,
                                StringSplitOptions::RemoveEmptyEntries);
                            if (!String::IsNullOrEmpty(lineParts[1]))
                            {
                                if (StringICompare(lineParts[0], _T("SW")) == 0)
                                {
                                    webSWVersion = lineParts[1];
                                    versionSWFound = GUI_YES;
                                }
                            }
                            break;
                        }
                    }
                    delete [] lineParts;
                    delete [] lineDelimiters;
                    //--------------------------------------------------------
                    // Check whether the software should be updated
                    //--------------------------------------------------------
                    if (versionSWFound)
                    {
                        if (StringICompare(webSWVersion, DTSTEST_PROGRAM_VERSION_STRING) > 0)
                        {
                            proceedToDownload = DTSTest_PromptModal(
                                "Download Software Update",
                                "Your DTSTest software is version {0}, and\n"
                                "version {1} is available for download.\n\n"
                                "Download updated version now?",
                                DTSTEST_PROGRAM_VERSION_STRING,
                                webSWVersion);
                            if (proceedToDownload)
                            {
                                DTSTest_SoftwareUpdateInProgress = GUI_YES;
                                String ^webSWFile = String::Concat(
                                    "NewProgL-", webSWVersion, ".exe");
                                String ^localSWFile = String::Concat(
                                    Application::StartupPath, "\\", webSWFile);
                                String ^downloadSWURL = String::Concat(
                                    DTSTEST_PKG_URL_DIR, webSWFile);
                                //--------------------------------------------
                                // Download the update from the web to the
                                // same folder from where this program started
                                //--------------------------------------------
                                webAccess->DownloadFile(downloadSWURL, localSWFile);
                                //--------------------------------------------
                                // Create a new update file, which contains the
                                // path of this program's executable file, the
                                // path of the downloaded executable file, and
                                // the original command-line parameters that
                                // were passed to this program, in that order
                                //--------------------------------------------
                                String ^updateFile = String::Concat(
                                    Application::StartupPath, "\\", DTSTEST_SW_UPDATE_FILENAME);
                                if (File::Exists(updateFile))
                                    File::Delete(updateFile);
                                StreamWriter ^textWriter = File::CreateText(updateFile);
                                textWriter->WriteLine(Application::ExecutablePath);
                                textWriter->WriteLine(localSWFile);
                                textWriter->WriteLine(DTSTest_GeneralInfo->commandLine);
                                textWriter->Close();
                                //--------------------------------------------
                                // Begin shutting down this program, and
                                // release all allocated memory
                                //--------------------------------------------
                                DTSTest_Finalize(String::Concat(functionName, " concluded"));
                                //--------------------------------------------
                                // Start the downloaded program running, but
                                // with the /u parameter, which signals the
                                // fact that the program is in process of
                                // being updated
                                //--------------------------------------------
                                ProcessStartInfo ^startNewAppCommand = gcnew ProcessStartInfo(localSWFile);
                                startNewAppCommand->WindowStyle = ProcessWindowStyle::Hidden;
                                startNewAppCommand->Arguments = _T("/u");
                                startNewAppCommand->CreateNoWindow = GUI_YES;
                                startNewAppCommand->UseShellExecute = GUI_NO;
                                System::Diagnostics::Process::Start(startNewAppCommand);
                                delete localSWFile;
                                delete downloadSWURL;
                                delete webSWFile;
                                //--------------------------------------------
                                // Exit this program - Application::Exit()
                                // doesn't seem to work
                                //--------------------------------------------
                                exit(0);
                            }
                        }               // end of if (StringICompare(webSWVersion, DTSTEST_PROGRAM_VERSION_STRING) > 0)
                        else
                        {
                            DTSTest_RecordAndModalEventByFlags(
                                DTSTest_EventLogBasicEnabled,
                                announceResults,
                                functionName,
                                "The DTSTest software (version {0}) is up-to-date (online version = {1})",
                                DTSTEST_PROGRAM_VERSION_STRING,
                                webSWVersion);
                        }
                    }                   // end of if (versionSWFound)
                    delete webSWVersion;
                }                       // end of if (StringICompare(pageLines[0], _T("[DTSTest]")) == 0)
                delete [] pageLines;
                delete [] pageDelimiters;
            }                           // end of if (!String::IsNullOrEmpty(webVersionFile))
            delete webVersionFile;
            delete webAccess;
        }                               // end of if (DTSTest_URLExists(DTSTEST_VERSION_URL))
        else
        {
            GUI_DisplaySimpleError(
                functionName,
                "The version file {0} can't be located", DTSTEST_VERSION_URL);
        }
    }                                   // end of if (DTSTest_InternetIsAvailable())
    else
    {
        GUI_DisplaySimpleError(
            functionName,
            "The internet is unavailable at the moment");
    }
    RecordVerboseEvent("            {0} concluded", functionName);
}                                       // end of DTSTest_CheckForCurrentSoftwareVersion()
//----------------------------------------------------------------------------
// DTSTest_CleanUpTextBoxText
//
// Removes all occurrences of spaces, newlines, tabs, commas, and many other
// unwanted characters in the specified text box text
//----------------------------------------------------------------------------
    String ^ DTSTest_GUIClass::
DTSTest_CleanUpTextBoxText(
    String          ^textBoxText)
{
    array <String ^> ^unwantedStringArray =
        gcnew array <String ^>
            {
                Environment::NewLine, " ", "'", "\n", ",", "=", "|", "~", "/",
                "\\", ";", ":", "!", "#", "$", "%", "^", "&", "*", "\"", "\t",
                "(", ")", "[", "]", "{", "}", "<", ">",
                "+", "?", "`"
            };
    //------------------------------------------------------------------------
    if (StringSet(textBoxText))
    {
        for each (String ^unwantedString in unwantedStringArray)
        {
            if (textBoxText->Contains(unwantedString))
                textBoxText = textBoxText->Replace(unwantedString, "");
        }
        textBoxText = textBoxText->Trim();
        RecordVerboseEvent("    Cleaned up text message text box: {0}", textBoxText);
    }
    return textBoxText;
}                                       // end of DTSTest_CleanUpTextBoxText()
//----------------------------------------------------------------------------
// DTSTest_DisplayHelpLink
//
// Displays a link in the help text
//
// Called by:   DTSTest_AboutHelp
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_DisplayHelpLink(
    Form            ^helpWindow,
    String          ^textString,
    DWORD           yPosition,
    DWORD           fieldWidth,
    DWORD           firstLinkCharacterOffset,
    DWORD           numberOfLinkCharacters)
{
    //------------------------------------------------------------------------
    LinkLabel ^helpLinkLabel = gcnew LinkLabel;
    helpLinkLabel->Text = textString;
    helpLinkLabel->LinkArea = LinkArea(firstLinkCharacterOffset, numberOfLinkCharacters);
    helpLinkLabel->Font = gcnew Drawing::Font(
        FontFamily::GenericSansSerif,
        12.0F,                      // em-size of the font
        FontStyle::Bold);           // choose from Bold, Italic, Underline, Strikeout
    helpLinkLabel->Location = Point(10, yPosition);
    helpLinkLabel->Size = Drawing::Size(fieldWidth, GUI_HELP_LABEL_HEIGHT);
    helpLinkLabel->AutoSize = GUI_YES;
    helpLinkLabel->BackColor = Color::Transparent;
    helpLinkLabel->LinkColor = Color::Blue;
    helpLinkLabel->DisabledLinkColor = Color::Red;
    helpLinkLabel->VisitedLinkColor = Color::Purple;
    helpLinkLabel->LinkBehavior = LinkBehavior::HoverUnderline;
    helpLinkLabel->TabIndex = 0;
    helpLinkLabel->TabStop = GUI_YES;
    helpLinkLabel->Links[0]->LinkData = QUARTZDYNE_URL;
    helpLinkLabel->LinkClicked +=
        gcnew LinkLabelLinkClickedEventHandler(this, &DTSTest_GUIClass::DTSTest_HyperLinkClicked);
    helpLinkLabel->MouseEnter +=
        gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_HelpAboutQuartzdyneLogoMouseEntered);
    helpLinkLabel->MouseLeave +=
        gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_AnyObjectMouseExited);
    helpWindow->Controls->Add(helpLinkLabel);
}                                       // end of DTSTest_DisplayHelpLink()
//----------------------------------------------------------------------------
// DTSTest_DisplayHelpTextLine
//
// Displays one line of the help text
//
// Called by:   DTSTest_AboutHelp
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_DisplayHelpTextLine(
    Form            ^helpWindow,
    String          ^textString,
    DWORD           yPosition,
    DWORD           fieldWidth)
{
    //------------------------------------------------------------------------
    Label ^helpText = gcnew Label;
    helpText->Text = textString;
    helpText->Font = gcnew Drawing::Font(
        FontFamily::GenericSansSerif,
        12.0F,                      // em-size of the font
        FontStyle::Bold);           // choose from Bold, Italic, Underline, Strikeout
    helpText->Location = Point(10, yPosition);
    helpText->Size = Drawing::Size(fieldWidth, GUI_HELP_LABEL_HEIGHT);
    helpText->BackColor = Color::Transparent;
    helpWindow->Controls->Add(helpText);
}                                       // end of DTSTest_DisplayHelpTextLine()
//----------------------------------------------------------------------------
// DTSTest_DisplayModalMessage
//
// Displays a modal message, using variable arguments and pausing program
// activity
//
// Returns: System::Windows::Forms::DialogResult::OK
//
// Note:    Because this function uses the String::Format method to format the
//          arguments into a single managed string, the calling convention
//          should look similar to
//
//          char    *unmanagedString = "Testing";
//          DWORD   status = DTSTEST_SUCCESS;
//          . . .
//          DTSTest_DisplayModalMessage(
//              true,
//              GUI_MODAL_ICON_INFORMATION,
//              "Modal Title",
//              "The function returned 0x{0:X8} for XD {1}",
//              status,
//              gcnew String(unmanagedString));
//----------------------------------------------------------------------------
    System::Windows::Forms::DialogResult DTSTest_GUIClass::
DTSTest_DisplayModalMessage(
    bool            allow,
    DWORD           flag,
    String          ^titleString,
    String          ^formatString,
    ...array <Object ^>
                    ^parameters)
{
    System::Windows::Forms::DialogResult
                    result = System::Windows::Forms::DialogResult::OK;
    String          ^functionName = _T("DTSTest_DisplayModalMessage");
    //------------------------------------------------------------------------
    if (allow && StringSet(titleString) && StringSet(formatString))
    {
        RecordBasicEvent("{0} called", functionName);
        String ^formattedString = String::Format(formatString, parameters);
        MessageBoxIcon icon;
        switch (flag)
        {
            case GUI_MODAL_ICON_INFORMATION :                                   // 0x00000001
                icon = MessageBoxIcon::Information;
                break;
            case GUI_MODAL_ICON_WARNING :                                       // 0x00000002
                icon = MessageBoxIcon::Exclamation;
                break;
            case GUI_MODAL_ICON_ERROR :                                         // 0x00000003
                icon = MessageBoxIcon::Error;
                break;
            case GUI_MODAL_ICON_CRITICAL :                                      // 0x00000004
                icon = MessageBoxIcon::Stop;
                break;
            default :
                icon = MessageBoxIcon::None;
                break;
        }
        //--------------------------------------------------------------------
        // Create an invisible window, from which to force the modal window to
        // the forefront
        //--------------------------------------------------------------------
        Form ^invisibleWindow = gcnew Form;
        invisibleWindow->Size = Drawing::Size(1, 1);
        invisibleWindow->Location = Point(1, 1);
        invisibleWindow->Focus();
        invisibleWindow->BringToFront();
        invisibleWindow->TopMost = GUI_YES;
        if (invisibleWindow->CanSelect)
            invisibleWindow->Select();
        invisibleWindow->TopLevel = GUI_YES;
        invisibleWindow->Visible = GUI_NO;
        result = MessageBox::Show(
            invisibleWindow,
            formattedString,
            titleString,
            MessageBoxButtons::OK,
            icon);
        delete invisibleWindow;
        RecordBasicEvent(
            "    Title '{0}' and text\n'{1}'\nresulted in '{2}'",
            titleString,
            formattedString,
            result);
        RecordBasicEvent("{0} concluded, returning {1}", functionName, result);
    }                                   // end of if (allow && ...)
    return result;
}                                       // end of DTSTest_DisplayModalMessage()
//----------------------------------------------------------------------------
// DTSTest_DisplayMostRecentEventLog
//
// Displays the most recent event log
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_DisplayMostRecentEventLog(void)
{
    int             attempts = 3;
    int             numberOfColumns = 0;
    int             numberOfLines = 0;
    int             maximumHorizontalSize = 0;
    int             maximumVerticalSize = 0;
    StreamReader    ^textReader;
    String          ^eventLogText;
    String          ^line;
    String          ^functionName = _T("DTSTest_DisplayMostRecentEventLog");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0} called", functionName);
    if (File::Exists(DTSTest_GeneralInfo->mostRecentEventLogPath))
    {
        textReader = gcnew StreamReader(DTSTest_GeneralInfo->mostRecentEventLogPath);
        if (textReader)
        {
            while (line = textReader->ReadLine())
            {
                numberOfLines++;
                numberOfColumns = Max(numberOfColumns, line->Length);
            }
            textReader->Close();
            maximumVerticalSize = (numberOfLines * 153) / 10;
            maximumHorizontalSize = (numberOfColumns * 86) / 10;
        }                               // end of if (textReader)
        textReader = gcnew StreamReader(DTSTest_GeneralInfo->mostRecentEventLogPath);
        if (textReader)
        {
            eventLogText = textReader->ReadToEnd();
            textReader->Close();
            //----------------------------------------------------------------
            // Create a new window to display the event log text
            //----------------------------------------------------------------
            eventLogWindow = gcnew Form;
            eventLogWindow->HelpButton = GUI_NO;
            eventLogWindow->Icon = DTSTest_SoftwareIcon;
            eventLogWindow->BackgroundImage = gcnew Bitmap(GUI_BG_WHITE_SAND, GUI_YES);
            eventLogWindow->Text = String::Concat(
                "Event Log ", DTSTest_GeneralInfo->mostRecentEventLogPath);
            eventLogWindow->Size = Drawing::Size(1000, 500);
            eventLogWindow->Font = gcnew Drawing::Font(
                FontFamily::GenericMonospace,
                10.0F,
                FontStyle::Regular);
            eventLogWindow->FormBorderStyle = System::Windows::Forms::FormBorderStyle::Sizable;
            eventLogWindow->SizeGripStyle = System::Windows::Forms::SizeGripStyle::Hide;
            //----------------------------------------------------------------
            // Display the text
            //----------------------------------------------------------------
            Label ^eventLogLabel = gcnew Label;
            eventLogLabel->Location = Point(10, 10);
            eventLogLabel->Size = Drawing::Size(
                maximumHorizontalSize,
                maximumVerticalSize);
            eventLogLabel->Text = eventLogText;
            eventLogLabel->BackColor = Color::Transparent;
//            eventLogLabel->DoubleBuffered = GUI_YES;
            eventLogWindow->Controls->Add(eventLogLabel);
            //----------------------------------------------------------------
            // Add a Close button
            //----------------------------------------------------------------
            Button ^closeButton = gcnew Button;
            closeButton->Location = Point(0, 0);
            closeButton->Size = Drawing::Size(1, 1);
            closeButton->DialogResult = System::Windows::Forms::DialogResult::OK;
            GUI_SetObjectInterfaceProperties(closeButton);
            closeButton->Click +=
                gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_EventLogCloseWindow);
            eventLogWindow->Controls->Add(closeButton);
            eventLogWindow->AcceptButton = closeButton; // button when user presses Enter
            eventLogWindow->CancelButton = closeButton; // button when user presses Esc
            //----------------------------------------------------------------
            // Complete the features of the window
            //----------------------------------------------------------------
            eventLogWindow->AutoScroll = GUI_YES;
//            eventLogWindow->AutoScrollPosition = Point(0, 0);
            eventLogWindow->VerticalScroll->Visible = GUI_YES;
            eventLogWindow->VerticalScroll->Enabled = GUI_YES;
            eventLogWindow->VerticalScroll->Maximum = maximumVerticalSize;
            ScrollToControl(closeButton);
            eventLogWindow->ShowDialog();
        }                               // end of if (textReader)
    }                                   // end of if (File::Exists(DTSTest_GeneralInfo->eventLogPath))
    RecordBasicEvent("{0} concluded", functionName);
}                                       // end of DTSTest_DisplayMostRecentEventLog()
//----------------------------------------------------------------------------
// DTSTest_EmailAddressFormatIsValid
//
// Determines whether the specified string is an email address with a valid
// format
//----------------------------------------------------------------------------
    bool DTSTest_GUIClass::
DTSTest_EmailAddressFormatIsValid(
    String          ^emailAddress)
{
    bool            formatIsValid = GUI_NO;
    int             atIndex;
    int             periodIndex;
    String          ^functionName = _T("DTSTest_EmailAddressFormatIsValid");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0} called", functionName);
    if (StringSet(emailAddress))
    {
        if (emailAddress->Contains("@") && emailAddress->Contains("."))
        {
            atIndex = emailAddress->IndexOf("@");
            periodIndex = emailAddress->IndexOf(".");
            if (atIndex && periodIndex &&
                emailAddress->Substring(0, atIndex)->Length &&
                (emailAddress->Substring(atIndex)->Length > 3))
            {
                formatIsValid = GUI_YES;
                RecordVerboseEvent("    The format of {0} as an email address is validated",
                    emailAddress);
            }
        }
        else
        {
            DTSTest_RecordAndModalErrorEvent(
                "{0} : {1} uses an invalid email address format",
                functionName, emailAddress);
        }
    }
    else
    {
        DTSTest_RecordAndModalErrorEvent(
            "{0} was passed an invalid email address string",
            functionName);
    }
    RecordBasicEvent("{0} concluded, returning {1}",
        functionName, (formatIsValid ? "Valid" : "Invalid"));
    return formatIsValid;
}                                       // end of DTSTest_EmailAddressFormatIsValid()
//----------------------------------------------------------------------------
// DTSTest_ErrorAlert
//
// Displays and/or records a general-purpose error message with optional
// parameters
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_ErrorAlert(
    String          ^titleString,
    DWORD           status,
    DWORD           messageFlags,
    String          ^formatString,
    ...array <Object ^>
                    ^parameters)
{
    String          ^errorDescriptionString;
    String          ^errorLogString;
    //------------------------------------------------------------------------
    if (StringSet(formatString))
    {
        String ^promptString = String::Format(formatString, parameters);
        errorDescriptionString = promptString;
        if (DTSTest_StackTracesEnabled)
            errorDescriptionString = String::Concat(
                errorDescriptionString,
                Environment::NewLine, Environment::NewLine,
                Environment::StackTrace);
        if (DTSTest_ErrorMessagesEnabled || (messageFlags & GUI_EMSG_MUST_DISPLAY))
        {
            if (messageFlags & GUI_EMSG_PLAY_SOUND)
                GUI_PlaySound(errorSound);
            if (StringSet(titleString))
                DTSTest_PromptOKModal(titleString, errorDescriptionString);
            else
                DTSTest_PromptOKModal("Error", errorDescriptionString);
        }
        errorLogString = String::Format(
            "{0} :\n{1}",
            titleString,
            errorDescriptionString);
        DTSTest_UpdateErrorLog(errorLogString);
        if (DTSTest_SendTextErrorMessagesEnabled)
        {
            DTSTest_SendTextMessage(
                _T("DTSTest Error Alert"),
                errorDescriptionString);
        }
        if (DTSTest_SendEmailErrorMessagesEnabled)
        {
            DTSTest_SendEmailMessage(
                _T("DTSTest Error Alert"),
                errorDescriptionString);
        }
        RecordBasicEvent(errorLogString);
        delete promptString;
    }                                   // end of if (StringSet(formatString))
}                                       // end of DTSTest_ErrorAlert()
//----------------------------------------------------------------------------
// DTSTest_GenerateSupportLog
//
// Generates the support log file, then prompts the user to save it
//
// Called by:   DTSTest_ToolStripSupportLogDropDownClicked
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_GenerateSupportLog(void)
{
    int             lapsedDays;
    int             lapsedHours;
    int             lapsedMinutes;
    int             lapsedSeconds;
    int             lapsedMilliseconds;
    int             numberOfLogFiles = 0;
    int             numberOfTemporaryFiles = 0;
    int             pathNameArrayEntries = 0;
    array <String ^>
                    ^pathNameStringArray;
    DateTime        dateTime = DateTime::Now;
    String          ^border = GUI_TEXT_FILE_BORDER;
    String          ^lineString;
    String          ^pathString;
    StreamWriter    ^textWriter;
    String          ^functionName = _T("DTSTest_GenerateSupportLog");
    //------------------------------------------------------------------------
    RecordVerboseEvent("{0} called", functionName);
    String ^logDir = String::Concat(DTSTest_GeneralInfo->logDirectory, "\\");
    String ^dateStamp = String::Format(
        "{0:D2}{1:D2}{2:D2}",
        (dateTime.Year % 100),
        dateTime.Month,
        dateTime.Day);
    String ^fileNameString = String::Concat("DTSTest-Support-", dateStamp, ".log");
    StringBuilder ^pathNameBuilder = gcnew StringBuilder(
        DTSTEST_MAXIMUM_FILE_PATH_LENGTH);                                      // 512
    GUI_StringToBuilder(
        String::Concat(logDir, fileNameString),
        pathNameBuilder);
    bool proceedToGenerate = DTSTest_PromptForSaveFile(
        "Save General Support Log",
        pathNameBuilder,
        fileNameString,
        GUI_FILE_TYPE_LOG);
    pathString = pathNameBuilder->ToString();
    delete pathNameBuilder;
    if (proceedToGenerate)
    {
        DTSTest_PleaseWait(
            GUI_PLEASE_WAIT_DISPLAY_NEW_TITLE,
            "Collecting Files for the Support Log");
        DTSTest_GeneralInfo->generalUsePath = pathString;
        DTSTest_GeneralInfo->flags |= DTSTEST_GENERAL_USE_PATH_SPECIFIED;
        fileNameString = Path::GetFileName(pathString);
        //--------------------------------------------------------------------
        // Determine how many files are to be ZIPped up, then add two for the
        // actual Support Log and the Content_Type file
        //--------------------------------------------------------------------
        numberOfLogFiles = Directory::GetFiles(logDir, "*.*")->Length + 2;
        pathNameStringArray = gcnew array <String ^> (numberOfLogFiles);
        pathNameStringArray[pathNameArrayEntries++] = pathString;
        textWriter = File::CreateText(pathString);
        if (textWriter)
        {
            //----------------------------------------------------------------
            // Write out the header, including filename and date
            //----------------------------------------------------------------
            textWriter->WriteLine(border);
            lineString = String::Format(
                "# {0}\n#\n# DTSTest Support Log File\n#\n"
                "# Created on {1:D2} {2} {3:D4} at {4:D2}:{5:D2}:{6:D2}",
                fileNameString,
                dateTime.Day,
                DTSTest_MonthStringArray[dateTime.Month],
                dateTime.Year,
                dateTime.Hour,
                dateTime.Minute,
                dateTime.Second);
            textWriter->WriteLine(lineString->Replace(DTSTEST_STRING_LF, Environment::NewLine));
            textWriter->WriteLine(border);
            MEMORYSTATUSEX memory;
            memory.dwLength = sizeof(MEMORYSTATUSEX);
            GlobalMemoryStatusEx(&memory);
            DriveInfo ^driveInfo = gcnew DriveInfo(Environment::CurrentDirectory);
            lineString = String::Format(
                "    Program Version: {0} Build {1:D}\n"
                "    OS: {2}\n"
                "    Available Memory: {3:D} MB / {4:D} MB\n"
                "    Remaining Disk Space: {5:D} MB / {6:D} MB\n"
                "    General Flags: {7:X8}\n"
                "    Persistent Flags: {8:X8}\n"
                "    Search String: {9}\n"
                "    Email To Address: {10}\n"
                "    Email CC Address: {11}",
                DTSTEST_PROGRAM_VERSION_STRING,
                DTSTest_BuildNumber,
                DTSTest_GeneralInfo->windowsVersion,
                (memory.ullAvailPhys / 1000000),
                (memory.ullTotalPhys / 1000000),
                (driveInfo->AvailableFreeSpace / 1000000),
                (driveInfo->TotalSize / 1000000),
                DTSTest_GeneralInfo->flags,
                DTSTest_GeneralInfo->persistentFlags,
                (StringSet(DTSTest_GeneralInfo->searchString) ?
                    DTSTest_GeneralInfo->searchString : DTSTEST_STRING_NONE),
                (StringSet(DTSTest_GeneralInfo->emailAddress) ?
                    DTSTest_GeneralInfo->emailAddress : DTSTEST_STRING_NONE),
                (StringSet(DTSTest_GeneralInfo->emailCCAddress) ?
                    DTSTest_GeneralInfo->emailCCAddress : DTSTEST_STRING_NONE));
            textWriter->WriteLine(lineString->Replace(DTSTEST_STRING_LF, Environment::NewLine));
            delete driveInfo;
            textWriter->WriteLine(
                String::Concat(
                    "    Command Line Parameters: ",
                    (StringSet(DTSTest_GeneralInfo->commandLine) ?
                        DTSTest_GeneralInfo->commandLine : DTSTEST_STRING_NONE)));
            textWriter->WriteLine(
                String::Concat(
                    "    Configuration File Path: ",
                    (StringSet(DTSTest_GeneralInfo->configFilePath) ?
                        DTSTest_GeneralInfo->configFilePath : DTSTEST_STRING_NONE)));
            textWriter->WriteLine(
                String::Concat(
                    "    Error Log File Path: ",
                    (StringSet(DTSTest_GeneralInfo->errorLogPath) ?
                        DTSTest_GeneralInfo->errorLogPath : DTSTEST_STRING_NONE)));
            textWriter->WriteLine(
                String::Concat(
                    "    Event Log File Path: ",
                    (StringSet(DTSTest_GeneralInfo->eventLogPath) ?
                        DTSTest_GeneralInfo->eventLogPath : DTSTEST_STRING_NONE)));
            lineString = String::Format(
                "    Basic Messages: {0}\n"
                "    Error Messages: {1}\n"
                "    Verbose Messages: {2}\n"
                "    Detailed Messages: {3}\n"
                "    Stack Traces: {4}\n"
                "    Exp Messages: {5}\n"
                "    Basic Event Log: {6}\n"
                "    Verbose Event Log: {7}\n"
                "    Detailed Event Log: {8}\n"
                "    Experiments: {9}\n"
                "    Software Updating: {10}",
                (DTSTest_BasicMessagesEnabled ? "On" : "Off"),
                (DTSTest_ErrorMessagesEnabled ? "On" : "Off"),
                (DTSTest_VerboseMessagesEnabled ? "On" : "Off"),
                (DTSTest_DetailedMessagesEnabled ? "On" : "Off"),
                (DTSTest_StackTracesEnabled ? "On" : "Off"),
                (DTSTest_ExpMessagesEnabled ? "On" : "Off"),
                (DTSTest_EventLogBasicEnabled ? "On" : "Off"),
                (DTSTest_EventLogVerboseEnabled ? "On" : "Off"),
                (DTSTest_EventLogDetailedEnabled ? "On" : "Off"),
                (DTSTest_ExperimentsEnabled ? "On" : "Off"),
                (DTSTest_SoftwareUpdateInProgress ? "Yes" : "No"));
            textWriter->WriteLine(lineString->Replace(DTSTEST_STRING_LF, Environment::NewLine));
            lineString = String::Format(
                "    Text Message To Number: {0}\n"
                "    Text Message CC Number: {1}\n"
                "    Email Message To Address: {2}\n"
                "    Email Message CC Address: {3}\n"
                "    Text Error Messages: {4}\n"
                "    Email Error Messages: {5}",
                (StringSet(DTSTest_GeneralInfo->textMessageToNumber) ?
                    DTSTest_GeneralInfo->textMessageToNumber : DTSTEST_STRING_NONE),
                (StringSet(DTSTest_GeneralInfo->textMessageCCNumber) ?
                    DTSTest_GeneralInfo->textMessageCCNumber : DTSTEST_STRING_NONE),
                (StringSet(DTSTest_GeneralInfo->emailMessageToAddress) ?
                    DTSTest_GeneralInfo->emailMessageToAddress : DTSTEST_STRING_NONE),
                (StringSet(DTSTest_GeneralInfo->emailMessageCCAddress) ?
                    DTSTest_GeneralInfo->emailMessageCCAddress : DTSTEST_STRING_NONE),
                (DTSTest_SendTextErrorMessagesEnabled ? "On" : "Off"),
                (DTSTest_SendEmailErrorMessagesEnabled ? "On" : "Off"));
            textWriter->WriteLine(lineString->Replace(DTSTEST_STRING_LF, Environment::NewLine));
            DTSTest_TimeElapsed(
                GetTickCount() - DTSTest_StartTime,
                &lapsedDays,
                &lapsedHours,
                &lapsedMinutes,
                &lapsedSeconds,
                &lapsedMilliseconds);
            textWriter->WriteLine(
                String::Format(
                    "    Running for {0:D} day{1} {2:D} hour{3} {4:D} minute{5} {6:D} second{7}",
                    lapsedDays, ((lapsedDays == 1) ? "" : "s"),
                    lapsedHours, ((lapsedHours == 1) ? "" : "s"),
                    lapsedMinutes, ((lapsedMinutes == 1) ? "" : "s"),
                    lapsedSeconds, ((lapsedSeconds == 1) ? "" : "s")));
            textWriter->WriteLine(border);
            textWriter->WriteLine(String::Concat("# End of ", fileNameString));
            textWriter->WriteLine(border);
            textWriter->Close();
        }                               // end of if (textWriter)
        //--------------------------------------------------------------------
        // Collect the names of all the files in the Log directory
        //--------------------------------------------------------------------
        if (Directory::Exists(logDir))
        {
            array <String ^> ^logDirFiles = Directory::GetFiles(logDir, "*.*");
            if (StringSet(logDirFiles))
            {
                for each (String ^logDirFile in logDirFiles)
                {
                    if (File::Exists(logDirFile) && StringICompare(logDirFile, pathString))
                    {
                        pathNameStringArray[pathNameArrayEntries++] = logDirFile;
                    }
                }
            }
        }                               // end of if (Directory::Exists(logDir))
        //--------------------------------------------------------------------
        // ZIP up all the support log files
        //--------------------------------------------------------------------
        String ^zipPathString = String::Concat(
            Path::GetDirectoryName(pathString),
            "\\",
            Path::GetFileNameWithoutExtension(pathString),
            ".zip");
        DTSTest_ZipFiles(pathNameStringArray, zipPathString);
        RecordVerboseEvent("    Support Log ZIP {0} created successfully", zipPathString);
        ModalD("Support Log ZIP\n{1}\ncreated successfully", zipPathString);
        delete [] pathNameStringArray;
        DTSTest_PleaseWait(GUI_PLEASE_WAIT_REMOVE, nullptr);
        Thread::Sleep(100);
        //--------------------------------------------------------------------
        // Display the email interface
        //--------------------------------------------------------------------
        emailSupportLogWindow = gcnew Form;
        emailSupportLogWindow->SuspendLayout();
        //--------------------------------------------------------------------
        // Set the appearance
        //--------------------------------------------------------------------
        emailSupportLogWindow->MaximizeBox = GUI_NO;
        emailSupportLogWindow->HelpButton = GUI_NO;
//        emailSupportLogWindow->TopMost = GUI_YES;
        //--------------------------------------------------------------------
        // Set its icon
        //--------------------------------------------------------------------
        emailSupportLogWindow->Icon = DTSTest_SoftwareIcon;
        //--------------------------------------------------------------------
        // Set the background image
        //--------------------------------------------------------------------
//        emailSupportLogWindow->BackgroundImage = whiteSandBackground;
        //--------------------------------------------------------------------
        // Set the title and border style
        //--------------------------------------------------------------------
        emailSupportLogWindow->Text = _T("Email the Support Log with an Issue Description");
        emailSupportLogWindow->FormBorderStyle = ::FormBorderStyle::Fixed3D;
        //--------------------------------------------------------------------
        // Create an email object instance
        //--------------------------------------------------------------------
        EmailInfo ^emailInfo = gcnew EmailInfo;
        emailInfo->attachment = zipPathString;
        //--------------------------------------------------------------------
        // Display the email group box
        //--------------------------------------------------------------------
        GroupBox ^emailGroupBox = gcnew GroupBox;
        //--------------------------------------------------------------------
        // Email group box
        //--------------------------------------------------------------------
        emailGroupBox->Text = _T("Compose Email");
        emailGroupBox->Location = Point(14, 10);
        emailGroupBox->Size = Drawing::Size(
            GUI_DEFAULT_GROUP_BOX_WIDTH,
            144);
        emailGroupBox->BackColor = Color::Transparent;
        String ^targetEmailAddress = DTSTest_GeneralInfo->emailAddress;
        //--------------------------------------------------------------------
        // To label
        //--------------------------------------------------------------------
        Label ^emailToLabel = gcnew Label;
        emailToLabel->Text = _T("To:");
        emailToLabel->Location = Point(10, 22);
        emailToLabel->Size = Drawing::Size(35, GUI_INFO_LABEL_HEIGHT);
        emailToLabel->BackColor = Color::Transparent;
        emailGroupBox->Controls->Add(emailToLabel);
        //--------------------------------------------------------------------
        // To combo
        //--------------------------------------------------------------------
        emailToCombo = gcnew ComboBox;
        emailToCombo->Location = Point(
            emailToLabel->Right + 2,
            emailToLabel->Top - 3);
        emailToCombo->Size = Drawing::Size(
            emailGroupBox->Width - 570,
            GUI_REGULAR_COMBO_BOX_HEIGHT);
        emailToCombo->MaxDropDownItems = 2;
        emailToCombo->FormattingEnabled = GUI_YES;
        emailToCombo->Tag = dynamic_cast <Object ^> (emailInfo);
        emailToCombo->Click +=
            gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_EmailMessageClearComboBox);
        emailToCombo->PreviewKeyDown +=
            gcnew PreviewKeyDownEventHandler(this, &DTSTest_GUIClass::DTSTest_ComboBoxAcceptEnterKey);
        emailToCombo->KeyDown +=
            gcnew KeyEventHandler(this, &DTSTest_GUIClass::DTSTest_EmailMessageProcessComboEnterKey);
        emailToCombo->Items->Add(QUARTZDYNE_SUPPORT_EMAIL_ADDRESS);
        if (StringSet(targetEmailAddress) &&
            StringICompare(
                targetEmailAddress,
                QUARTZDYNE_SUPPORT_EMAIL_ADDRESS))
            emailToCombo->Items->Add(targetEmailAddress);
        emailToCombo->Text = QUARTZDYNE_SUPPORT_EMAIL_ADDRESS;
        emailInfo->toAddress = emailToCombo->Text;
        emailGroupBox->Controls->Add(emailToCombo);
        //--------------------------------------------------------------------
        // From label
        //--------------------------------------------------------------------
        Label ^emailFromLabel = gcnew Label;
        emailFromLabel->Text = _T("From: ");
        emailFromLabel->Location = Point(10, emailToLabel->Bottom + 12);
        emailFromLabel->Size = emailToLabel->Size;
        emailFromLabel->BackColor = Color::Transparent;
        emailGroupBox->Controls->Add(emailFromLabel);
        //--------------------------------------------------------------------
        // From combo
        //--------------------------------------------------------------------
        emailFromCombo = gcnew ComboBox;
        emailFromCombo->Location = Point(
            emailFromLabel->Right + 2,
            emailFromLabel->Top - 3);
        emailFromCombo->Size = emailToCombo->Size;
        emailFromCombo->MaxDropDownItems = 2;
        emailFromCombo->FormattingEnabled = GUI_YES;
        emailFromCombo->Click +=
            gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_EmailMessageClearComboBox);
        emailInfo->fromAddress = emailFromCombo->Text;
        emailInfo->replyAddress = emailFromCombo->Text;
        emailGroupBox->Controls->Add(emailFromCombo);
        //--------------------------------------------------------------------
        // Subject label
        //--------------------------------------------------------------------
        Label ^emailSubjectLabel = gcnew Label;
        emailSubjectLabel->Text = _T("Subject: ");
        emailSubjectLabel->Location = Point(emailToCombo->Right + 20, 23);
        emailSubjectLabel->Size = Drawing::Size(56, GUI_INFO_LABEL_HEIGHT);
        emailSubjectLabel->BackColor = Color::Transparent;
        emailGroupBox->Controls->Add(emailSubjectLabel);
        //--------------------------------------------------------------------
        // Subject box
        //--------------------------------------------------------------------
        emailSubjectBox = gcnew TextBox;
        emailSubjectBox->Text = String::Format(
            "DTSTest Support Log (v{0}-{1:D} {2:D2}-{3:D2}-{4:D2} {5:D2}:{6:D2})",
            DTSTEST_PROGRAM_VERSION_STRING,
            DTSTest_BuildNumber,
            dateTime.Month,
            dateTime.Day,
            dateTime.Year,
            dateTime.Hour,
            dateTime.Minute);
        emailSubjectBox->Location = Point(
            emailSubjectLabel->Right + 2,
            emailSubjectLabel->Top - 3);
        emailSubjectBox->Size = Drawing::Size(
            430,
            GUI_REGULAR_TEXT_BOX_HEIGHT);
        emailSubjectBox->Multiline = GUI_NO;
        emailSubjectBox->AcceptsReturn = GUI_NO;
        emailSubjectBox->AcceptsTab = GUI_NO;
        emailSubjectBox->WordWrap = GUI_NO;
        emailSubjectBox->TextAlign = HorizontalAlignment::Left;
        emailSubjectBox->BackColor = Color::Lavender;
        emailGroupBox->Controls->Add(emailSubjectBox);
        emailInfo->subjectString = emailSubjectBox->Text;
        //--------------------------------------------------------------------
        // Message label
        //--------------------------------------------------------------------
        Label ^emailMessageLabel = gcnew Label;
        emailMessageLabel->Text =
            _T("Please describe the problem or issue you would like to report:");
        emailMessageLabel->Location = Point(
            emailSubjectLabel->Left,
            emailSubjectBox->Bottom + 10);
        emailMessageLabel->Size = Drawing::Size(
            emailSubjectLabel->Width + 2 + emailSubjectBox->Width,
            GUI_INFO_LABEL_HEIGHT);
        emailMessageLabel->BackColor = Color::Transparent;
        emailGroupBox->Controls->Add(emailMessageLabel);
        //--------------------------------------------------------------------
        // Message box
        //--------------------------------------------------------------------
        emailMessageBox = gcnew TextBox;
        GUI_PositionBelow(emailMessageBox, emailMessageLabel, 4);
        emailMessageBox->Size = Drawing::Size(
            emailMessageLabel->Width,
            GUI_REGULAR_TEXT_BOX_HEIGHT * 3);
        emailMessageBox->Multiline = GUI_YES;
        emailMessageBox->AcceptsReturn = GUI_YES;
        emailMessageBox->AcceptsTab = GUI_YES;
        emailMessageBox->WordWrap = GUI_YES;
        emailMessageBox->TextAlign = HorizontalAlignment::Left;
        emailMessageBox->BackColor = Color::Lavender;
        emailGroupBox->Controls->Add(emailMessageBox);
        emailInfo->messageString = emailMessageBox->Text;
        //--------------------------------------------------------------------
        // Status label
        //--------------------------------------------------------------------
        emailStatusLabel = gcnew Label;
        emailStatusLabel->Text = _T("Email not yet sent");
        emailStatusLabel->Location = Point(
            emailFromCombo->Left,
            emailFromLabel->Bottom + 40);
        emailStatusLabel->Size = Drawing::Size(
            223,
            GUI_INFO_LABEL_HEIGHT);
        emailStatusLabel->TextAlign = Drawing::ContentAlignment::MiddleLeft;
        emailStatusLabel->ForeColor = Color::Green;
        emailStatusLabel->BackColor = Color::Transparent;
        emailGroupBox->Controls->Add(emailStatusLabel);
        //--------------------------------------------------------------------
        // Send button
        //--------------------------------------------------------------------
        Button ^emailSendButton = gcnew Button;
        emailSendButton->Text = _T("Send");
        emailSendButton->Location = Point(
            emailFromCombo->Right - 40,
            emailMessageBox->Bottom - 27);
        emailSendButton->Size = Drawing::Size(40, GUI_REGULAR_BUTTON_HEIGHT);
        emailSendButton->BackgroundImage = sandBackground;
        emailSendButton->Tag = dynamic_cast <Object ^> (emailInfo);
        emailSendButton->Click +=
            gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_EmailMessageSendButtonClicked);
        emailSendButton->MouseEnter +=
            gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_EmailMessageSendButtonMouseEntered);
        emailSendButton->MouseLeave +=
            gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_AnyObjectMouseExited);
        emailGroupBox->Controls->Add(emailSendButton);
        emailSupportLogWindow->Controls->Add(emailGroupBox);
        //--------------------------------------------------------------------
        // Set the dimensions of the email window
        //--------------------------------------------------------------------
        emailSupportLogWindow->Size = Drawing::Size(
            GUI_DEFAULT_GROUP_BOX_WIDTH + 40,
            emailGroupBox->Bottom + 85);
        //--------------------------------------------------------------------
        // Close button
        //--------------------------------------------------------------------
        Button ^closeButton = gcnew Button;
        closeButton->Text = _T("Close");
        closeButton->Location = Point(
            emailSupportLogWindow->Right - 100,
            emailSupportLogWindow->Bottom - 70);
        closeButton->Size = Drawing::Size(
            GUI_CLOSE_BUTTON_WIDTH,
            GUI_REGULAR_BUTTON_HEIGHT);
        closeButton->BackgroundImage = sandBackground;
        closeButton->DialogResult = System::Windows::Forms::DialogResult::OK;
        closeButton->Click +=
            gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_EmailSupportLogCloseWindow);
        closeButton->MouseEnter +=
            gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_EmailMessageCloseButtonMouseEntered);
        closeButton->MouseLeave +=
            gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_AnyObjectMouseExited);
        emailSupportLogWindow->Controls->Add(closeButton);
        //--------------------------------------------------------------------
        // Set the remaining window properties
        //--------------------------------------------------------------------
        emailSupportLogWindow->AcceptButton = closeButton;
        emailSupportLogWindow->CancelButton = closeButton;
        //--------------------------------------------------------------------
        // Finally, display the new window
        //--------------------------------------------------------------------
        emailSupportLogWindow->ShowDialog();
        emailSupportLogWindow->ResumeLayout();
        delete emailInfo;
        delete zipPathString;
    }                                   // end of if (proceedToGenerate)
    delete pathString;
    delete logDir;
    RecordVerboseEvent("{0} concluded", functionName);
}                                       // end of DTSTest_GenerateSupportLog()
//----------------------------------------------------------------------------
// DTSTest_GetWindowsEnvironment
//
// Discovers the currently running Windows environment information and sets
// the general strings accordingly
//
// Called by:   DTSTest_InitializeDTSTest
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_GetWindowsEnvironment(void)
{
    String          ^functionName = _T("DTSTest_GetWindowsEnvironment");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0} called", functionName);
    //------------------------------------------------------------------------
    // Retrieve the Windows version
    //------------------------------------------------------------------------
    DTSTest_GetWindowsVersion();
    //------------------------------------------------------------------------
    // Retrieve the login (AD) name
    //------------------------------------------------------------------------
    DTSTest_GeneralInfo->operatorName = Environment::UserName;
    RecordBasicEvent("{0} concluded", functionName);
}                                       // end of DTSTest_GetWindowsEnvironment()
//----------------------------------------------------------------------------
// DTSTest_GetWindowsVersion
//
// Discovers the currently running Windows version and sets the general
// DTSTest_GeneralInfo->windowsVersion string accordingly
//
// Called by:   DTSTest_GetWindowsEnvironment
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_GetWindowsVersion(void)
{
    bool            serverOS = GUI_NO;
    BOOL            is64Bit = GUI_NO;
    DWORD           status;
    OSVERSIONINFOEX osInfo;
    String          ^bitWidthString = _T("32");
    String          ^osString;
    String          ^functionName = _T("DTSTest_GetWindowsVersion");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0} called", functionName);
    ModalD("Loc 2.6.1 : Start");
    //------------------------------------------------------------------------
    // First, initialize the OS version variable
    //------------------------------------------------------------------------
    DTSTest_WindowsVersion = DTSTEST_WIN_VER_UNKNOWN;
    //------------------------------------------------------------------------
    // Next, determine the processor native address size
    //------------------------------------------------------------------------
    if (Environment::Is64BitOperatingSystem)
    {
        bitWidthString = _T("64");
        DTSTest_WindowsVersion |= DTSTEST_WIN_VER_64_BIT;
    }
    ModalD("Loc 2.6.2 : Running in a {0}-bit OS", bitWidthString);
    //------------------------------------------------------------------------
    // Now, determine the operating system version
    //------------------------------------------------------------------------
    osInfo.dwOSVersionInfoSize = sizeof(OSVERSIONINFOEX);
    status = GetVersionEx((LPOSVERSIONINFOW) &osInfo);
    if (status)
    {
//        Modal("OS Major ver = {0:D} min = {1:D} type = {2:D}", osInfo.dwMajorVersion, osInfo.dwMinorVersion, osInfo.wProductType);
//        if (IsWindows10OrGreater())
//            Modal("Windows 10");
//        else
//            Modal("Some other Windows version");
        switch (osInfo.dwMajorVersion)
        {
            case 5 :
                switch (osInfo.dwMinorVersion)
                {
                    case 0 :
                        osString = _T("Windows 2000");
                        DTSTest_WindowsVersion |= DTSTEST_WIN_VER_PRE_XP;
                        break;
                    case 1 :
                        osString = _T("Windows XP");
                        DTSTest_WindowsVersion |= DTSTEST_WIN_VER_XP;
                        break;
                    case 2 :
                        DTSTest_WindowsVersion |= DTSTEST_WIN_VER_SERVER_2003;
                        if (GetSystemMetrics(SM_SERVERR2) == 0)
                        {
                            osString = _T("Windows Server 2003");
                        }
                        else
                        {
                            osString = _T("Windows Server 2003 R2");
                            DTSTest_WindowsVersion |= DTSTEST_WIN_VER_R2;
                        }
                        serverOS = GUI_YES;
                        break;
                    default :
                        osString = _T("Unsupported");
                        break;
                }
                break;
            case 6 :
                switch (osInfo.dwMinorVersion)
                {
                    case 0 :
                        if (osInfo.wProductType == VER_NT_WORKSTATION)
                        {
                            osString = _T("Windows Vista");
                            DTSTest_WindowsVersion |= DTSTEST_WIN_VER_VISTA;
                        }
                        else
                        {
                            osString = _T("Windows Server 2008");
                            DTSTest_WindowsVersion |= DTSTEST_WIN_VER_SERVER_2008;
                            serverOS = GUI_YES;
                        }
                        break;
                    case 1 :
                        if (osInfo.wProductType == VER_NT_WORKSTATION)
                        {
                            osString = _T("Windows 7");
                            DTSTest_WindowsVersion |= DTSTEST_WIN_VER_7;
                        }
                        else
                        {
                            osString = _T("Windows Server 2008 R2");
                            DTSTest_WindowsVersion |= (DTSTEST_WIN_VER_SERVER_2008 | DTSTEST_WIN_VER_R2);
                            serverOS = GUI_YES;
                        }
                        break;
                    case 2 :
                        if (osInfo.wProductType == VER_NT_WORKSTATION)
                        {
                            osString = _T("Windows 8");
                            DTSTest_WindowsVersion |= DTSTEST_WIN_VER_8;
                        }
                        else
                        {
                            osString = _T("Windows Server 2012");
                            DTSTest_WindowsVersion |= DTSTEST_WIN_VER_SERVER_2012;
                            serverOS = GUI_YES;
                        }
                        break;
                    case 3 :
                        if (osInfo.wProductType == VER_NT_WORKSTATION)
                        {
                            osString = _T("Windows 8.1");
                            DTSTest_WindowsVersion |= DTSTEST_WIN_VER_8;
                        }
                        else
                        {
                            osString = _T("Windows Server 2012 R2");
                            DTSTest_WindowsVersion |= DTSTEST_WIN_VER_SERVER_2012;
                            serverOS = GUI_YES;
                        }
                        break;
                    default :
                        osString = _T("Unsupported");
                        break;
                }                       // end of switch (osInfo.dwMinorVersion)
                break;
            case 10 :
                switch (osInfo.dwMinorVersion)
                {
                    case 0 :
                        if (osInfo.wProductType == VER_NT_WORKSTATION)
                        {
                            osString = _T("Windows 10");
                            DTSTest_WindowsVersion |= DTSTEST_WIN_VER_10;
                        }
                        else
                        {
                            osString = _T("Windows Server 2016 TR");
                            DTSTest_WindowsVersion |= DTSTEST_WIN_VER_SERVER_2016;
                            serverOS = GUI_YES;
                        }
                        break;
                    default :
                        osString = _T("Unsupported");
                        break;
                }                       // end of switch (osInfo.dwMinorVersion)
                break;
            default :
                osString = _T("Unsupported");
                break;
        }                               // end of switch (osInfo.dwMajorVersion)
        //--------------------------------------------------------------------
        // Finally, determine the service pack version, if available
        //--------------------------------------------------------------------
        if (wcslen(osInfo.szCSDVersion) && !serverOS)
        {
            String ^SPString = gcnew String(osInfo.szCSDVersion);
            if (SPString->Contains("Service Pack"))
            {
                SPString = SPString->Replace(_T("Service Pack "), _T("SP"));
            }
            DTSTest_GeneralInfo->windowsVersion = String::Format(
                "{0} {1}-bit with {2}",
                osString,
                bitWidthString,
                SPString);
            delete SPString;
        }
        else
        {
            DTSTest_GeneralInfo->windowsVersion = String::Format(
                "{0} {1}-bit",
                osString,
                bitWidthString);
        }
        RecordBasicEvent(
            "    The Windows version is detected as '{0}'",
            DTSTest_GeneralInfo->windowsVersion);
    }                                   // end of if (status)
    else
    {
        DTSTest_RecordAndModalErrorEvent(
            "{0} :\nThe call to GetVersionEx failed",
            functionName);
    }
    ModalD("Loc 2.6.3 : End : OS = {0}",
        DTSTest_GeneralInfo->windowsVersion);
    RecordBasicEvent("{0} concluded", functionName);
}                                       // end of DTSTest_GetWindowsVersion()
//----------------------------------------------------------------------------
// DTSTest_GlobalFileSearch
//
// Searches the file system starting at the specified top-most directory,
// which includes the drive letter, and all its subdirectories for the
// specified filename, and returns the path of the file with the latest
// date-and-time stamp if more than one is found
//
// Returns: GUI_YES or GUI_NO
//----------------------------------------------------------------------------
    bool DTSTest_GUIClass::
DTSTest_GlobalFileSearch(
    String          ^fileName,
    StringBuilder   ^filePath)
{
    bool            fileLocated = GUI_NO;
    String          ^filePathString = filePath->ToString();
    String          ^functionName = _T("DTSTest_GlobalFileSearch");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0} called", functionName);
    if (StringSet(fileName) && StringSet(filePath))
    {
        if (Directory::Exists(filePathString))
        {
            DirectoryInfo ^dirInfo = gcnew DirectoryInfo(filePathString);
            array <FileInfo ^> ^files =
                dirInfo->GetFiles(
                    "*" + fileName + "*",
                    SearchOption::AllDirectories);
            FileInfo ^latestFile;
            DateTime latestDate = DateTime(0);
            for each (FileInfo ^fileInfo in files)
            {
                if (DateTime::Compare(fileInfo->LastWriteTime, latestDate) > 0)
                {
                    latestDate = fileInfo->LastWriteTime;
                    latestFile = fileInfo;
                    fileLocated = GUI_YES;
                }
            }
            if (fileLocated)
            {
                filePath->Length = DTSTEST_MAXIMUM_FILE_PATH_LENGTH;
                GUI_StringToBuilder(latestFile->FullName, filePath);
            }
            delete latestDate;
        }
    }
    RecordBasicEvent("{0} concluded, returning {1}",
        functionName, (fileLocated ? "Found" : "Not Found"));
    return fileLocated;
}                                       // end of DTSTest_GlobalFileSearch()
//----------------------------------------------------------------------------
// DTSTest_InstallUtilities
//
// Installs program utilities and their windows
//
// Called by:   DTSTest_ConstructAndPresentUserInterface
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_InstallUtilities(void)
{
    String          ^functionName = _T("DTSTest_InstallUtilities");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0} called", functionName);
    //------------------------------------------------------------------------
    // Set up the various controls windows
    //------------------------------------------------------------------------
    DTSTest_AdvancedControlsSetUpWindow();
    DTSTest_ExperimentalControlsSetUpWindow();
//    DTSTest_ScriptControlsSetUpWindow();
    DTSTest_SamplingControlsSetUpWindow();
    DTSTest_FileControlsSetUpWindow();
    DTSTest_TestingControlsSetUpWindow();
    RecordBasicEvent("{0} concluded", functionName);
}                                       // end of DTSTest_InstallUtilities()
//----------------------------------------------------------------------------
// DTSTest_InternetIsAvailable
//
// Determines whether the web is available for access
//----------------------------------------------------------------------------
    bool DTSTest_GUIClass::
DTSTest_InternetIsAvailable(void)
{
    bool            webAvailable = GUI_NO;
    int             attempts = 3;
    int             timeout = 120;
    String          ^functionName = _T("DTSTest_InternetIsAvailable");
    //------------------------------------------------------------------------
    RecordVerboseEvent("{0} called", functionName);
    //------------------------------------------------------------------------
    // Determine whether the software has access to the web by pinging the
    // Quartzdyne host website
    //------------------------------------------------------------------------
    while (!webAvailable && attempts--)
    {
        Ping ^webPing = gcnew Ping;
        PingOptions ^pingOptions = gcnew PingOptions;
        pingOptions->DontFragment = GUI_YES;
        String ^pingData = _T("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        array <Byte> ^pingBuffer = Encoding::ASCII->GetBytes(pingData);
        try
        {
            PingReply ^pingReply = webPing->Send(
                QUARTZDYNE_HOST,
                timeout, pingBuffer, pingOptions);
            if (pingReply->Status == IPStatus::Success)
            {
                webAvailable = GUI_YES;
                DTSTest_GeneralInfo->flags |= DTSTEST_GENERAL_INTERNET_AVAILABLE;
                RecordVerboseEvent("    Internet search for {0} succeeded",
                    QUARTZDYNE_HOST);
                attempts = 0;
            }
            else
            {
                if (attempts)
                {
                    Thread::Sleep(500);
                }
                else
                {
                    DTSTest_GeneralInfo->flags &= ~DTSTEST_GENERAL_INTERNET_AVAILABLE;
                    String ^reasonString;
                    switch (pingReply->Status)
                    {
                        case IPStatus::DestinationNetworkUnreachable :
                            reasonString = _T("    Network is unreachable");
                            break;
                        case IPStatus::TimedOut :
                            reasonString = String::Format(
                                "    Attempted access to {0} timed out",
                                QUARTZDYNE_HOST);
                            break;
                        default :
                            reasonString = String::Format(
                                "    Reason unknown (status {0:D})",
                                pingReply->Status);
                            break;
                    }                   // end of switch (pingReply->Status)
                    RecordErrorEvent("    The internet is unavailable at the moment\n{0}",
                        reasonString);
                    delete reasonString;
                }
            }
        }                               // end of try
        catch(PingException ^ex)
        {
            DTSTest_GeneralInfo->flags &= ~DTSTEST_GENERAL_INTERNET_AVAILABLE;
            if (DTSTest_ExpMessagesEnabled)
            {
                DTSTest_RecordAndModalErrorEvent(
                    "Internet ping for {0} failed\nException: {1}",
                    QUARTZDYNE_HOST,
                    ex->Message);
            }
            else
            {
                DTSTest_RecordAndModalErrorEvent(
                    "Unable to locate host {0} during an internet ping (attempt {1:D} of 3)",
                    QUARTZDYNE_HOST,
                    (3 - attempts));
            }
        }
        delete pingOptions;
        delete webPing;
    }                                   // end of while (!webAvailable && attempts--)
    RecordVerboseEvent("{0} concluded, returning {1}",
        functionName, (webAvailable ? "Available" : "Unavailable"));
    return webAvailable;
}                                       // end of DTSTest_InternetIsAvailable()
//----------------------------------------------------------------------------
// DTSTest_LimitFilePathStringWidth
//
// Returns a new string, based on the specified string, but limited in length
// to the specified width in pixels, by replacing leading characters with
// ellipsis
//----------------------------------------------------------------------------
    String ^ DTSTest_GUIClass::
DTSTest_LimitFilePathStringWidth(
    String          ^filePath,
    DWORD           maximumWidth)
{
    //------------------------------------------------------------------------
    if (StringSet(filePath) && (maximumWidth > 26))
    {
        //--------------------------------------------------------------------
        // Subtract the pixels taken by padding, spaces, and a colon
        //--------------------------------------------------------------------
        maximumWidth -= 26;
        if (DTSTest_StringWidth(filePath) > maximumWidth)
        {
            //----------------------------------------------------------------
            // Insert the ellipsis at the front of the string
            //----------------------------------------------------------------
            filePath = filePath->PadLeft(filePath->Length + 3, '.');
            while (DTSTest_StringWidth(filePath->Substring(3)) > maximumWidth)
            {
                if (filePath->Contains("\\"))
                {
                    if (filePath[3] == '\\')
                    {
                        if (filePath->Substring(4)->Contains("\\"))
                        {
                            filePath = filePath->Remove(4, filePath->Substring(4)->IndexOf('\\') + 1);
                        }
                        else
                        {
                            filePath = filePath->Remove(3, 1);
                        }
                    }
                    else
                    {
                        if (filePath->IndexOf('\\') > 3)
                            filePath = filePath->Remove(3, filePath->IndexOf('\\') - 3);
                        else
                            filePath = filePath->Remove(3, 1);
                    }
                }
                else
                {
                    //--------------------------------------------------------
                    // No more back-slashes in the string to reference, so
                    // simply remove enough characters from the front of the
                    // string, except for the ellipsis, to limit its width
                    //--------------------------------------------------------
                    while (DTSTest_StringWidth(filePath->Substring(3)) > maximumWidth)
                    {
                        filePath = filePath->Remove(3, 1);
                    }
                }
            }                           // end of while (DTSTest_StringWidth(filePath) > maximumWidth)
        }                               // end of if (DTSTest_StringWidth(filePath) > maximumWidth)
    }                                   // end of if (StringSet(filePath) && maximumWidth)
    return filePath;
}                                       // end of DTSTest_LimitFilePathStringWidth()
//----------------------------------------------------------------------------
// DTSTest_LimitStringWidth
//
// Returns the specified string, limited to the specified width in pixels, by
// removing either trailing (truncateString == GUI_TRUNCATE_STRING) or leading
// (truncateString == GUI_LOP_STRING) characters
//----------------------------------------------------------------------------
    String ^ DTSTest_GUIClass::
DTSTest_LimitStringWidth(
    String          ^textString,
    DWORD           maximumWidth,
    bool            truncateString)
{
    int             offset = 0;
    //------------------------------------------------------------------------
    if (StringSet(textString) && (maximumWidth > 26))
    {
        //--------------------------------------------------------------------
        // Subtract the pixels taken by padding, spaces, and a colon
        //--------------------------------------------------------------------
        maximumWidth -= 26;
        while (DTSTest_StringWidth(textString) > maximumWidth)
        {
            if (truncateString == GUI_TRUNCATE_STRING)
                offset = textString->Length - 1;
            textString = textString->Remove(offset, 1);
        }
    }
    return textString;
}                                       // end of DTSTest_LimitStringWidth()
//----------------------------------------------------------------------------
// DTSTest_NetworkIsAvailable
//
// Determines whether the server network is available for access
//----------------------------------------------------------------------------
    bool DTSTest_GUIClass::
DTSTest_NetworkIsAvailable(void)
{
    bool            networkAvailable = GUI_NO;
    String          ^functionName = _T("DTSTest_NetworkIsAvailable");
    //------------------------------------------------------------------------
    RecordVerboseEvent("{0} called", functionName);
    if (Directory::Exists(QUARTZDYNE_DTSTEST_FOLDER))
    {
        networkAvailable = GUI_YES;
    }
    else
    {
        array <DriveInfo ^> ^driveInfo = DriveInfo::GetDrives();
        for each (DriveInfo ^oneDrive in driveInfo)
        {
            if (oneDrive->DriveType == DriveType::Network)
            {
                networkAvailable = GUI_YES;
                break;
            }
        }
        delete [] driveInfo;
    }
    if (networkAvailable)
    {
        RecordVerboseEvent("    Server network detection succeeded");
    }
    else
    {
        DTSTest_GeneralInfo->flags &= ~DTSTEST_GENERAL_INTERNET_AVAILABLE;
        RecordVerboseEvent("    The network is unavailable at the moment");
    }
    RecordVerboseEvent("{0} concluded, returning {1}",
        functionName, (networkAvailable ? "Available" : "Unavailable"));
    return networkAvailable;
}                                       // end of DTSTest_NetworkIsAvailable()
//----------------------------------------------------------------------------
// DTSTest_ParseAndConvertHexStringToByte
//
// Tests the string for hex digits and returns the unsigned integer equivalent
// of the string and true if it is formatted properly, or zero and false if it
// is not
//----------------------------------------------------------------------------
    bool DTSTest_GUIClass::
DTSTest_ParseAndConvertHexStringToByte(
    String          ^hexString,
    BYTE            *unsignedEquivalent)
{
    bool            isCorrectFormat = GUI_YES;
    String          ^functionName = _T("DTSTest_ParseAndConvertHexStringToByte");
    //------------------------------------------------------------------------
    try
    {
        *unsignedEquivalent = (BYTE) Convert::ToInt32(hexString, 16);
    }
    catch (Exception ^ex)
    {
        UNREFERENCED_PARAMETER(ex);
        isCorrectFormat = GUI_NO;
    }
    return isCorrectFormat;
}                                       // end of DTSTest_ParseAndConvertHexStringToByte()
//----------------------------------------------------------------------------
// DTSTest_ParseAndConvertStringToInteger
//
// Tests the string for decimal digits and returns the signed integer
// equivalent of the string and true if it is formatted properly, or zero and
// false if it is not
//----------------------------------------------------------------------------
    bool DTSTest_GUIClass::
DTSTest_ParseAndConvertStringToInteger(
    String          ^integerString,
    int             *signedEquivalent)
{
    int             integerEquivalent = 0;
    String          ^functionName = _T("DTSTest_ParseAndConvertStringToInteger");
    //------------------------------------------------------------------------
    bool isIntegerFormat = Int32::TryParse(integerString, integerEquivalent);
    if (isIntegerFormat)
        *signedEquivalent = integerEquivalent;
    else
        *signedEquivalent = 0;
    return isIntegerFormat;
}                                       // end of DTSTest_ParseAndConvertStringToInteger()
//----------------------------------------------------------------------------
// DTSTest_ParseAndConvertStringToUnsigned
//
// Tests the string for decimal digits and returns the unsigned integer
// equivalent of the string and true if it is formatted properly, or zero and
// false if it is not
//----------------------------------------------------------------------------
    bool DTSTest_GUIClass::
DTSTest_ParseAndConvertStringToUnsigned(
    String          ^integerString,
    DWORD           *unsignedEquivalent)
{
    int             integerEquivalent = 0;
    String          ^functionName = _T("DTSTest_ParseAndConvertStringToUnsigned");
    //------------------------------------------------------------------------
    bool isCorrectFormat = Int32::TryParse(integerString, integerEquivalent);
    if (isCorrectFormat)
        *unsignedEquivalent = (DWORD) integerEquivalent;
    else
        *unsignedEquivalent = 0;
    return isCorrectFormat;
}                                       // end of DTSTest_ParseAndConvertStringToUnsigned()
//----------------------------------------------------------------------------
// DTSTest_PerformExperiments
//
// Performs arbitrary experiments on demand
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_PerformExperiments(void)
{
    DWORD           experimentNumber = DTSTest_CurrentExperimentNumber;
    String          ^functionName = _T("DTSTest_PerformExperiments");
    //------------------------------------------------------------------------
    if (DTSTest_ExperimentsEnabled)
    {
        RecordBasicEvent("{0} called for experiment {1:D}", functionName, experimentNumber);
        if (experimentNumber)
        {
            String ^first = _T("This is the first string");
            StringBuilder ^second = gcnew StringBuilder(
                "This is the second string", DTSTEST_MAXIMUM_FILE_PATH_LENGTH);
            switch (experimentNumber)
            {
                case 1 :
                    break;
                case 99 :
                    break;
                case 7 :
                    break;
                default :
                    RecordErrorEvent("    Experiment {0:D} not recognized",
                        experimentNumber);
                    break;
            }                           // end of switch (experimentNumber)
        }                               // end of if (experimentNumber)
        RecordBasicEvent("{0} concluded", functionName);
    }                                   // end of if (DTSTest_ExperimentsEnabled)
    else
    {
        Modal("Experiments are not enabled");
    }
}                                       // end of DTSTest_PerformExperiments()
//----------------------------------------------------------------------------
// DTSTest_PleaseWait
//
// Displays a "Please wait..." window
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_PleaseWait(
    DWORD           action,
    String          ^formatString,
    ...array <Object ^>
                    ^parameters)
{
    int             zeroValue = 0;
    String          ^titleString;
    //------------------------------------------------------------------------
    if (!DTSTest_CommandLineOnly)
    {
        if (StringSet(formatString))
        {
            titleString = String::Format(formatString, parameters);
        }
        switch (action)
        {
            case GUI_PLEASE_WAIT_INSTALL :
                pleaseWaitWindow = gcnew Form;
                pleaseWaitWindow->TopMost = GUI_YES;
                pleaseWaitWindow->Tag = GUI_PLEASE_WAIT_STATE_HIDDEN;
                pleaseWaitWindow->Icon = DTSTest_SoftwareIcon;
                pleaseWaitWindow->BackgroundImage = whiteSandBackground;
                pleaseWaitWindow->FormBorderStyle = ::FormBorderStyle::Fixed3D;
                pleaseWaitWindow->StartPosition = FormStartPosition::CenterScreen;
                pleaseWaitWindow->MaximizeBox = GUI_NO;
                pleaseWaitWindow->MinimizeBox = GUI_NO;
                pleaseWaitWindow->HelpButton = GUI_NO;
                pleaseWaitLabel = gcnew Label;
                pleaseWaitLabel->Text = GUI_PLEASE_WAIT_STRING;
                pleaseWaitLabel->Font = gcnew Drawing::Font(
                    FontFamily::GenericSansSerif,
                    13.0F,
                    FontStyle::Bold);
                pleaseWaitLabel->Size = Drawing::Size(132, 20);
                pleaseWaitLabel->BackColor = Color::Transparent;
                pleaseWaitWindow->Controls->Add(pleaseWaitLabel);
                //------------------------------------------------------------
                // Handle the closing of the window
                //------------------------------------------------------------
                pleaseWaitWindow->FormClosing +=
                    gcnew FormClosingEventHandler(this, &DTSTest_GUIClass::DTSTest_PleaseWaitClosingWindow);
                break;

            case GUI_PLEASE_WAIT_DISPLAY_NEW_TITLE :
                if (pleaseWaitWindow)
                {
                    Cursor = Cursors::WaitCursor;
                    if (((int) pleaseWaitWindow->Tag) == GUI_PLEASE_WAIT_STATE_VISIBLE)
                    {
                        pleaseWaitWindow->Hide();
                        pleaseWaitWindow->Update();
                    }
                    if (StringSet(titleString))
                    {
                        pleaseWaitWindow->Text = titleString;
                        pleaseWaitWindow->Size = Drawing::Size(
                            Max(DTSTest_StringWidth(titleString), DTSTest_StringWidth(GUI_PLEASE_WAIT_STRING)) + 124,
                            100);
                    }
                    else
                    {
                        pleaseWaitWindow->Text = _T("DTSTest");
                        pleaseWaitWindow->Size = Drawing::Size(
                            DTSTest_StringWidth(GUI_PLEASE_WAIT_STRING) + 124,
                            100);
                    }
                    if (pleaseWaitLabel)
                    {
                        pleaseWaitLabel->Location = Point(
                            (abs(pleaseWaitWindow->Width - pleaseWaitLabel->Width) / 2),
                            20);
                    }
                    pleaseWaitWindow->Show();
                    pleaseWaitWindow->Tag = GUI_PLEASE_WAIT_STATE_VISIBLE;
                    pleaseWaitWindow->Update();
                }
                break;

            case GUI_PLEASE_WAIT_DISPLAY_CURRENT_TITLE :
                if (pleaseWaitWindow)
                {
                    pleaseWaitWindow->Show();
                    pleaseWaitWindow->Tag = GUI_PLEASE_WAIT_STATE_VISIBLE;
                    pleaseWaitWindow->Update();
                }
                break;

            case GUI_PLEASE_WAIT_HIDE :
            case GUI_PLEASE_WAIT_REMOVE :
                if (pleaseWaitWindow)
                {
                    Cursor = Cursors::Default;
                    if (((int) pleaseWaitWindow->Tag) == GUI_PLEASE_WAIT_STATE_VISIBLE)
                    {
                        pleaseWaitWindow->Hide();
                        pleaseWaitWindow->Tag = GUI_PLEASE_WAIT_STATE_HIDDEN;
                        pleaseWaitWindow->Update();
                    }
                }
                Cursor = Cursors::Default;
                break;

            case GUI_PLEASE_WAIT_DISPOSE :
                if (pleaseWaitLabel)
                {
                    delete pleaseWaitLabel;
                }
                if (pleaseWaitWindow)
                {
                    pleaseWaitWindow->Close();
                    delete pleaseWaitWindow;
                }
                break;

            default :
                break;
        }                               // end of switch (action)
    }                                   // end of if (!DTSTest_CommandLineOnly)
}                                       // end of DTSTest_PleaseWait()
//----------------------------------------------------------------------------
// DTSTest_PromptForReadFile
//
// Prompts the user for a filename used for reading data, but does not actually
// perform any data transfer
//
// Returns: GUI_ACCEPT or GUI_CANCEL
//----------------------------------------------------------------------------
    bool DTSTest_GUIClass::
DTSTest_PromptForReadFile(
    String          ^titleString,
    StringBuilder   ^filePathBuilder,
    String          ^suggestedFileName,
    DWORD           fileType)
{
    bool            promptResult;
    String          ^filePathString;
    String          ^functionName = _T("DTSTest_PromptForReadFile");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0} called", functionName);
    OpenFileDialog ^readFile = gcnew OpenFileDialog;
    if (StringSet(filePathBuilder))
    {
        if (StringSet(suggestedFileName))
        {
            readFile->FileName = suggestedFileName;
        }
        else
        {
            filePathString = filePathBuilder->ToString();
            readFile->InitialDirectory = Path::GetDirectoryName(filePathString);
            readFile->FileName = Path::GetFileName(filePathString);
        }
    }
    else
    {
        if (DTSTest_GeneralInfo->flags & DTSTEST_GENERAL_USE_PATH_SPECIFIED)
        {
            readFile->InitialDirectory = DTSTest_GeneralInfo->generalUsePath;
        }
        else
        {
            readFile->InitialDirectory =
                Environment::GetFolderPath(Environment::SpecialFolder::Recent);
//                Environment::GetFolderPath(Environment::SpecialFolder::MyDocuments);
        }
    }
    if (String::IsNullOrEmpty(titleString))
        titleString = _T("Read File");
    readFile->Title = titleString;
    switch (fileType)
    {
        case GUI_FILE_TYPE_TEXT :                                               // 1
            readFile->DefaultExt = _T("txt");
            readFile->Filter = GUI_FILE_SPEC_TEXT;
            break;
        case GUI_FILE_TYPE_HEX :                                                // 2
            readFile->DefaultExt = _T("hex");
            readFile->Filter = GUI_FILE_SPEC_HEX;
            break;
        case GUI_FILE_TYPE_LOG :                                                // 3
            readFile->DefaultExt = _T("log");
            readFile->Filter = GUI_FILE_SPEC_LOG;
            break;
        case GUI_FILE_TYPE_DAT :                                                // 4
            readFile->DefaultExt = _T("dat");
            readFile->Filter = GUI_FILE_SPEC_DAT;
            break;
        case GUI_FILE_TYPE_CSV :                                                // 7
            readFile->DefaultExt = _T("log");
            readFile->Filter = GUI_FILE_SPEC_CSV;
            break;
        case GUI_FILE_TYPE_CONFIG :                                             // 8
            readFile->DefaultExt = _T("config");
            readFile->Filter = GUI_FILE_SPEC_CONFIG;
            break;
        case GUI_FILE_TYPE_BIN :                                                // 9
            readFile->DefaultExt = _T("bin");
            readFile->Filter = GUI_FILE_SPEC_BIN;
            break;
        case GUI_FILE_TYPE_EXE :                                                // 10
            readFile->DefaultExt = _T("exe");
            readFile->Filter = GUI_FILE_SPEC_EXE;
            break;
        case GUI_FILE_TYPE_ZIP :                                                // 11
            readFile->DefaultExt = _T("zip");
            readFile->Filter = GUI_FILE_SPEC_ZIP;
            break;
        case GUI_FILE_TYPE_DLL :                                                // 12
            readFile->DefaultExt = _T("dll");
            readFile->Filter = GUI_FILE_SPEC_DLL;
            break;
        case GUI_FILE_TYPE_UNKNOWN :                                            // 0
            if (StringSet(readFile->FileName))
            {
                readFile->DefaultExt = Path::GetExtension(readFile->FileName);
            }
            else
            {
                readFile->FileName = _T("*.*");
                readFile->DefaultExt = _T("*");
            }
            readFile->Filter = GUI_FILE_SPEC_ALL;
            break;
        default :
            if (!StringSet(readFile->FileName))
                readFile->FileName = _T("*.*");
            else
                readFile->DefaultExt = _T("*");
            readFile->Filter = GUI_FILE_SPEC_ALL;
            break;
    }
    if (StringSet(readFile->FileName))
        readFile->FileName = Path::GetFileNameWithoutExtension(readFile->FileName);
    readFile->FilterIndex = 1;          // 1 == specified / 2 == *.*
    readFile->RestoreDirectory = GUI_YES;
    //------------------------------------------------------------------------
    // The following line works around issues with Windows 7 and Vista
    //------------------------------------------------------------------------
    readFile->AutoUpgradeEnabled = GUI_NO;
    //------------------------------------------------------------------------
    // Display the window and query the user
    //------------------------------------------------------------------------
    if (readFile->ShowDialog() == System::Windows::Forms::DialogResult::OK)
    {
        promptResult = GUI_ACCEPT;
        filePathBuilder->Length = DTSTEST_MAXIMUM_FILE_PATH_LENGTH;
        GUI_StringToBuilder(readFile->FileName, filePathBuilder);
        filePathString = filePathBuilder->ToString();
        DTSTest_GeneralInfo->generalUsePath = filePathString;
        DTSTest_GeneralInfo->flags |= DTSTEST_GENERAL_USE_PATH_SPECIFIED;
        RecordVerboseEvent(
            "Prompt for input file accepted:\n{0}",
            readFile->FileName);
    }
    else
    {
        promptResult = GUI_CANCEL;
    }
    delete readFile;
    RecordBasicEvent("{0} concluded, returning {1}",
        functionName, (promptResult ? "Yes" : "No"));
    return promptResult;
}                                       // end of DTSTest_PromptForReadFile()
//----------------------------------------------------------------------------
// DTSTest_PromptForSaveFile
//
// Prompts the user for a filename used for saving data, but does not actually
// perform any data transfer
//
// Returns: GUI_ACCEPT or GUI_CANCEL
//----------------------------------------------------------------------------
    bool DTSTest_GUIClass::
DTSTest_PromptForSaveFile(
    String          ^titleString,
    StringBuilder   ^filePathBuilder,
    String          ^suggestedFileName,
    DWORD           fileType)
{
    bool            promptResult;
    String          ^filePathString;
    String          ^functionName = _T("DTSTest_PromptForSaveFile");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0} called", functionName);
    SaveFileDialog ^saveFile = gcnew SaveFileDialog;
    if (StringSet(filePathBuilder))
    {
        if (StringSet(suggestedFileName))
        {
            saveFile->FileName = suggestedFileName;
        }
        else
        {
            filePathString = filePathBuilder->ToString();
            saveFile->InitialDirectory = Path::GetDirectoryName(filePathString);
            saveFile->FileName = Path::GetFileName(filePathString);
        }
    }
    else
    {
        if (DTSTest_GeneralInfo->flags & DTSTEST_GENERAL_USE_PATH_SPECIFIED)
        {
            saveFile->InitialDirectory = DTSTest_GeneralInfo->generalUsePath;
        }
        else
        {
            saveFile->InitialDirectory =
                Environment::GetFolderPath(Environment::SpecialFolder::Recent);
//                Environment::GetFolderPath(Environment::SpecialFolder::MyDocuments);
        }
    }
    if (String::IsNullOrEmpty(titleString))
        titleString = _T("Save File");
    saveFile->Title = titleString;
    switch (fileType)
    {
        case GUI_FILE_TYPE_TEXT :                                               // 1
            saveFile->DefaultExt = _T("txt");
            saveFile->Filter = GUI_FILE_SPEC_TEXT;
            break;
        case GUI_FILE_TYPE_HEX :                                                // 2
            saveFile->DefaultExt = _T("hex");
            saveFile->Filter = GUI_FILE_SPEC_HEX;
            break;
        case GUI_FILE_TYPE_LOG :                                                // 3
            saveFile->DefaultExt = _T("log");
            saveFile->Filter = GUI_FILE_SPEC_LOG;
            break;
        case GUI_FILE_TYPE_DAT :                                                // 4
            saveFile->DefaultExt = _T("dat");
            saveFile->Filter = GUI_FILE_SPEC_DAT;
            break;
        case GUI_FILE_TYPE_CSV :                                                // 7
            saveFile->DefaultExt = _T("log");
            saveFile->Filter = GUI_FILE_SPEC_CSV;
            break;
        case GUI_FILE_TYPE_CONFIG :                                             // 8
            saveFile->DefaultExt = _T("config");
            saveFile->Filter = GUI_FILE_SPEC_CONFIG;
            break;
        case GUI_FILE_TYPE_BIN :                                                // 9
            saveFile->DefaultExt = _T("bin");
            saveFile->Filter = GUI_FILE_SPEC_BIN;
            break;
        case GUI_FILE_TYPE_EXE :                                                // 10
            saveFile->DefaultExt = _T("exe");
            saveFile->Filter = GUI_FILE_SPEC_EXE;
            break;
        case GUI_FILE_TYPE_ZIP :                                                // 11
            saveFile->DefaultExt = _T("zip");
            saveFile->Filter = GUI_FILE_SPEC_ZIP;
            break;
        case GUI_FILE_TYPE_DLL :                                                // 12
            saveFile->DefaultExt = _T("dll");
            saveFile->Filter = GUI_FILE_SPEC_DLL;
            break;
        case GUI_FILE_TYPE_UNKNOWN :                                            // 0
        default :
            if (StringSet(saveFile->FileName))
                saveFile->FileName = _T("*.*");
            else
                saveFile->DefaultExt = _T("*");
            saveFile->Filter = GUI_FILE_SPEC_ALL;
            break;
    }
    if (StringSet(saveFile->FileName))
        saveFile->FileName = Path::GetFileNameWithoutExtension(saveFile->FileName);
    saveFile->FilterIndex = 1;          // 1 == specified / 2 == *.*
    saveFile->RestoreDirectory = GUI_YES;
    //------------------------------------------------------------------------
    // The following line works around issues with Windows 7 and Vista
    //------------------------------------------------------------------------
    saveFile->AutoUpgradeEnabled = GUI_NO;
    //------------------------------------------------------------------------
    // Display the window and query the user
    //------------------------------------------------------------------------
    if (saveFile->ShowDialog() == System::Windows::Forms::DialogResult::OK)
    {
        promptResult = GUI_ACCEPT;
        filePathBuilder->Length = DTSTEST_MAXIMUM_FILE_PATH_LENGTH;
        GUI_StringToBuilder(saveFile->FileName, filePathBuilder);
        filePathString = filePathBuilder->ToString();
        DTSTest_GeneralInfo->generalUsePath = filePathString;
        DTSTest_GeneralInfo->flags |= DTSTEST_GENERAL_USE_PATH_SPECIFIED;
        FileStream ^fileStream = File::Create(saveFile->FileName);
        fileStream->Close();
        RecordVerboseEvent(
            "Prompt for output file accepted:\n{0}",
            saveFile->FileName);
    }
    else
    {
        promptResult = GUI_CANCEL;
    }
    delete saveFile;
    RecordBasicEvent("{0} concluded, returning {1}",
        functionName, (promptResult ? "Yes" : "No"));
    return promptResult;
}                                       // end of DTSTest_PromptForSaveFile()
//----------------------------------------------------------------------------
// DTSTest_PromptInputModal
//
// Displays a text box input modal with a single prompt line that is at most
// maximumInputStringSize characters (digits) long
//
// Returns: GUI_ACCEPT or GUI_CANCEL
//----------------------------------------------------------------------------
    bool DTSTest_GUIClass::
DTSTest_PromptInputModal(
    String          ^titleString,
    String          ^suggestedInputString,
    DWORD           *inputValue,
    StringBuilder   ^inputStringBuilder,
    DWORD           maximumInputStringSize,
    String          ^formatString,
    ...array <Object ^>
                    ^parameters)
{
    bool            modalResponse = GUI_CANCEL;
    int             buttonWidth = GUI_YES_NO_BUTTON_WIDTH;
    int             lines = 0;
    int             promptWidth = 0;
    int             titleWidth;
    String          ^functionName = _T("DTSTest_PromptInputModal");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0} called", functionName);
    if (StringSet(formatString))
    {
        String ^promptString = String::Format(formatString, parameters);
        //--------------------------------------------------------------------
        // Create a new window
        //--------------------------------------------------------------------
        Form ^inputModal = gcnew Form;
        //--------------------------------------------------------------------
        // Set the title
        //--------------------------------------------------------------------
        if (StringSet(titleString))
        {
            inputModal->Text = titleString;
            titleWidth = DTSTest_StringWidth(titleString);
        }
        else
        {
            inputModal->Text = _T("DTSTest");
        }
        //--------------------------------------------------------------------
        // Set its properties
        //--------------------------------------------------------------------
        inputModal->Icon = DTSTest_SoftwareIcon;
//        inputModal->BackgroundImage = gcnew Bitmap(GUI_BG_WOOD_PANEL, GUI_YES);
        inputModal->FormBorderStyle = ::FormBorderStyle::FixedDialog;
        inputModal->StartPosition = FormStartPosition::CenterScreen;
        inputModal->TopMost = GUI_YES;
        //--------------------------------------------------------------------
        // Prevent the user from changing its appearance
        //--------------------------------------------------------------------
        inputModal->MaximizeBox = GUI_NO;
        inputModal->MinimizeBox = GUI_NO;
        inputModal->HelpButton = GUI_NO;
        //--------------------------------------------------------------------
        // If this is a multi-line prompt, find the number of lines and the
        // width of the longest line
        //--------------------------------------------------------------------
        promptString = promptString->Replace(Environment::NewLine, DTSTEST_STRING_LF);
        array <Char> ^lineDelimiters = gcnew array <Char> {'\r', '\n'};
        array <String ^> ^promptLines = promptString->Split(lineDelimiters);
        lines = promptLines->Length;
        for each (String ^promptLine in promptLines)
        {
            promptWidth = Max(promptWidth, (int) DTSTest_StringWidth(promptLine) + (promptLine->Length / 2));
            Label ^modalMessage = gcnew Label;
            modalMessage->Location = Point(
                10,
                ((Array::IndexOf(promptLines, promptLine) * GUI_PROMPT_LABEL_HEIGHT) + 10));
            modalMessage->Size = Drawing::Size(
                promptWidth,
                GUI_PROMPT_LABEL_HEIGHT);
            modalMessage->TextAlign = Drawing::ContentAlignment::MiddleLeft;
            modalMessage->Text = promptLine;
            modalMessage->ForeColor = Color::Black;
            modalMessage->BackColor = Color::Transparent;
            inputModal->Controls->Add(modalMessage);
            promptWidth = Max(promptWidth, modalMessage->Width);
        }
        delete [] promptLines;
        delete [] lineDelimiters;
        inputModal->Size = Drawing::Size(
            Max(Max((promptWidth + 25), (titleWidth + 100)), 280),
            (lines * GUI_PROMPT_LABEL_HEIGHT) + 85);
        //--------------------------------------------------------------------
        // Create the input text box
        //--------------------------------------------------------------------
        TextBox ^inputTextBox = gcnew TextBox;
        inputTextBox->Size = Drawing::Size(60, 20);
        inputTextBox->Location = Point(
            ((inputModal->Width / 2) - 50),
            inputModal->Height - 62);
        inputTextBox->Multiline = GUI_NO;
        inputTextBox->AcceptsReturn = GUI_NO;
        inputTextBox->AcceptsTab = GUI_NO;
        inputTextBox->WordWrap = GUI_NO;
        inputTextBox->ReadOnly = GUI_NO;
        inputTextBox->MaxLength = maximumInputStringSize;
        inputTextBox->TextAlign = HorizontalAlignment::Center;
        inputTextBox->BackColor = Color::Lavender;
        if (StringSet(suggestedInputString))
            inputTextBox->Text = suggestedInputString;
        inputModal->Controls->Add(inputTextBox);
        //--------------------------------------------------------------------
        // Display the OK button to accept the input
        //--------------------------------------------------------------------
        Button ^okButton = gcnew Button;
        okButton->Text = _T("OK");
        okButton->Location = Point(
            inputTextBox->Right + 10,
            inputTextBox->Top - 2);
        okButton->Size = Drawing::Size(buttonWidth, GUI_REGULAR_BUTTON_HEIGHT);
        okButton->BackgroundImage = gcnew Bitmap(GUI_BG_SAND, GUI_YES);
        okButton->DialogResult = Windows::Forms::DialogResult::OK;
        okButton->KeyPress +=
            gcnew KeyPressEventHandler(this, &DTSTest_GUIClass::DTSTest_PromptKeyPressed);
        inputModal->AcceptButton = okButton;     // button when user presses Enter
        inputModal->Controls->Add(okButton);
        //--------------------------------------------------------------------
        // Display the Cancel button to accept the input
        //--------------------------------------------------------------------
        Button ^cancelButton = gcnew Button;
        cancelButton->Text = _T("Cancel");
        cancelButton->Size = Drawing::Size(50, GUI_REGULAR_BUTTON_HEIGHT);
        cancelButton->Location = Point(inputModal->Width - 70, okButton->Top);
        cancelButton->BackgroundImage = gcnew Bitmap(GUI_BG_SAND, GUI_YES);
        cancelButton->DialogResult = Windows::Forms::DialogResult::Cancel;
        cancelButton->KeyPress +=
            gcnew KeyPressEventHandler(this, &DTSTest_GUIClass::DTSTest_PromptKeyPressed);
        inputModal->CancelButton = cancelButton;     // button when user presses Esc
        inputModal->Controls->Add(cancelButton);
        //--------------------------------------------------------------------
        // Display the window and query the user
        //--------------------------------------------------------------------
        DTSTest_ModalKeyStroke = 0;
        inputModal->ShowDialog();
        if ((DTSTest_ModalKeyStroke == 'Y') || (DTSTest_ModalKeyStroke == 'N'))
        {
            //----------------------------------------------------------------
            // A recognized key was pressed that was not Enter, Esc, or Space
            //----------------------------------------------------------------
            if (DTSTest_ModalKeyStroke == 'Y')
                modalResponse = GUI_ACCEPT;
            else
                modalResponse = GUI_CANCEL;
        }
        else
        {
            //----------------------------------------------------------------
            // A button was clicked, or Enter, Esc, or Space was pressed
            //----------------------------------------------------------------
            if (inputModal->DialogResult == Windows::Forms::DialogResult::OK)
                modalResponse = GUI_ACCEPT;
            else
                modalResponse = GUI_CANCEL;
            if (modalResponse == GUI_CANCEL)
                DTSTest_ModalKeyStroke = GUI_KEY_ESC;
        }
        if (modalResponse == GUI_ACCEPT)
        {
            bool isCorrectFormat = DTSTest_ParseAndConvertStringToUnsigned(
                inputTextBox->Text,
                inputValue);
            if (isCorrectFormat)
            {
                inputStringBuilder->Length = maximumInputStringSize;
                GUI_StringToBuilder(inputTextBox->Text, inputStringBuilder);
            }
            else
            {
                DTSTest_PromptOKModal(
                    "Invalid Characters",
                    "The entry contains invalid characters;\n"
                    "enter only decimal digits");
                RecordErrorEvent(
                    "    Attempted entry of '{0}'",
                    inputTextBox->Text);
                modalResponse = GUI_CANCEL;
            }
            RecordBasicEvent(
                "Prompt for Input with title '{0}' and text\n'{1}'\nresulted in '{2}'",
                titleString,
                promptString,
                ((modalResponse == GUI_ACCEPT) ? inputTextBox->Text : cancelButton->Text));
        }
        else
        {
            RecordBasicEvent(
                "Prompt for Input with title '{0}' and text\n'{1}'\nresulted in '{2}'",
                titleString,
                promptString,
                cancelButton->Text);
        }
        //--------------------------------------------------------------------
        // Dispose of the window components
        //--------------------------------------------------------------------
        delete inputModal;
        this->Refresh();
        delete promptString;
    }
    RecordBasicEvent("{0} concluded, returning {1}",
        functionName, (modalResponse ? "Accept" : "Cancel"));
    return modalResponse;
}                                       // end of DTSTest_PromptInputModal()
//----------------------------------------------------------------------------
// DTSTest_PromptPulldownModal
//
// Displays a combo box (pulldown) input modal with a list that is at most
// maximumPulldownListSize lines long, and returns the offset of the selected
// list line
//
// Returns: GUI_ACCEPT or GUI_CANCEL
//----------------------------------------------------------------------------
    bool DTSTest_GUIClass::
DTSTest_PromptPulldownModal(
    String          ^titleString,
    array <String ^>
                    ^pulldownList,
    DWORD           *listOffset,
    String          ^formatString,
    ...array <Object ^>
                    ^parameters)
{
    bool            modalResponse = GUI_CANCEL;
    int             buttonWidth = GUI_YES_NO_BUTTON_WIDTH;
    int             lines = 0;
    int             pulldownListWidth = 0;
    int             promptWidth = 0;
    int             titleWidth;
    String          ^functionName = _T("DTSTest_PromptPulldownModal");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0} called", functionName);
    if (StringSet(formatString))
    {
        String ^promptString = String::Format(formatString, parameters);
        //--------------------------------------------------------------------
        // Create a new window
        //--------------------------------------------------------------------
        Form ^promptPulldownModal = gcnew Form;
        //--------------------------------------------------------------------
        // Set the title
        //--------------------------------------------------------------------
        if (StringSet(titleString))
        {
            promptPulldownModal->Text = titleString;
            titleWidth = DTSTest_StringWidth(titleString);
        }
        else
        {
            promptPulldownModal->Text = _T("DTSTest");
        }
        //--------------------------------------------------------------------
        // Set its properties
        //--------------------------------------------------------------------
        promptPulldownModal->Icon = DTSTest_SoftwareIcon;
//        promptPulldownModal->BackgroundImage = gcnew Bitmap(GUI_BG_WOOD_PANEL, GUI_YES);
        promptPulldownModal->FormBorderStyle = ::FormBorderStyle::FixedDialog;
        promptPulldownModal->StartPosition = FormStartPosition::CenterScreen;
        promptPulldownModal->TopMost = GUI_YES;
        //--------------------------------------------------------------------
        // Prevent the user from changing its appearance
        //--------------------------------------------------------------------
        promptPulldownModal->MaximizeBox = GUI_NO;
        promptPulldownModal->MinimizeBox = GUI_NO;
        promptPulldownModal->HelpButton = GUI_NO;
        //--------------------------------------------------------------------
        // If this is a multi-line prompt, find the number of lines and the
        // width of the longest line
        //--------------------------------------------------------------------
        promptString = promptString->Replace(Environment::NewLine, DTSTEST_STRING_LF);
        array <Char> ^lineDelimiters = gcnew array <Char> {'\r', '\n'};
        array <String ^> ^promptLines = promptString->Split(lineDelimiters);
        lines = promptLines->Length;
        for each (String ^promptLine in promptLines)
        {
            promptWidth = Max(promptWidth, (int) DTSTest_StringWidth(promptLine) + (promptLine->Length / 2));
            Label ^modalMessage = gcnew Label;
            modalMessage->Location = Point(
                10,
                ((Array::IndexOf(promptLines, promptLine) * GUI_PROMPT_LABEL_HEIGHT) + 10));
            modalMessage->Size = Drawing::Size(
                promptWidth,
                GUI_PROMPT_LABEL_HEIGHT);
            modalMessage->TextAlign = Drawing::ContentAlignment::MiddleLeft;
            modalMessage->Text = promptLine;
            modalMessage->ForeColor = Color::Black;
            modalMessage->BackColor = Color::Transparent;
            promptPulldownModal->Controls->Add(modalMessage);
            promptWidth = Max(promptWidth, modalMessage->Width);
        }
        delete [] promptLines;
        delete [] lineDelimiters;
        //--------------------------------------------------------------------
        // Create the pulldown combo box
        //--------------------------------------------------------------------
        Drawing::Font ^currentFont = gcnew Drawing::Font(this->Font, FontStyle::Regular);
        for each (String ^pulldownEntry in pulldownList)
        {
            Drawing::Size ^numberOfPixels =
                Drawing::Size(TextRenderer::MeasureText(pulldownEntry, currentFont));
            pulldownListWidth = Max(pulldownListWidth, numberOfPixels->Width);
        }
        promptPulldownModal->Width =
            Max((DWORD) promptPulldownModal->Width, (DWORD) (pulldownListWidth + buttonWidth + 120));
        delete currentFont;
        ComboBox ^inputComboBox = gcnew ComboBox;
        inputComboBox->Size = Drawing::Size(
            pulldownListWidth + 20,
            GUI_REGULAR_COMBO_BOX_HEIGHT);
        inputComboBox->Location = Point(
            10,
            promptPulldownModal->Height - 62);
        inputComboBox->MaxDropDownItems = 12;
        inputComboBox->FormattingEnabled = GUI_YES;
        inputComboBox->Items->AddRange(pulldownList);
        inputComboBox->Text = pulldownList[*listOffset];
        promptPulldownModal->Controls->Add(inputComboBox);
        //--------------------------------------------------------------------
        // Display the OK button to accept the input
        //--------------------------------------------------------------------
        Button ^okButton = gcnew Button;
        okButton->Text = _T("OK");
        okButton->Location = Point(
            inputComboBox->Right + 10,
            inputComboBox->Top - 2);
        okButton->Size = Drawing::Size(buttonWidth, GUI_REGULAR_BUTTON_HEIGHT);
        okButton->BackgroundImage = gcnew Bitmap(GUI_BG_SAND, GUI_YES);
        okButton->DialogResult = Windows::Forms::DialogResult::OK;
        okButton->KeyPress +=
            gcnew KeyPressEventHandler(this, &DTSTest_GUIClass::DTSTest_PromptKeyPressed);
        promptPulldownModal->AcceptButton = okButton;     // button when user presses Enter
        promptPulldownModal->Controls->Add(okButton);
        //--------------------------------------------------------------------
        // Display the Cancel button to accept the input
        //--------------------------------------------------------------------
        Button ^cancelButton = gcnew Button;
        cancelButton->Text = _T("Cancel");
        cancelButton->Size = Drawing::Size(50, GUI_REGULAR_BUTTON_HEIGHT);
        cancelButton->Location = Point(
            promptPulldownModal->Width - 70,
            okButton->Top);
        cancelButton->BackgroundImage = gcnew Bitmap(GUI_BG_SAND, GUI_YES);
        cancelButton->DialogResult = Windows::Forms::DialogResult::Cancel;
        cancelButton->KeyPress +=
            gcnew KeyPressEventHandler(this, &DTSTest_GUIClass::DTSTest_PromptKeyPressed);
        promptPulldownModal->CancelButton = cancelButton;     // button when user presses Esc
        promptPulldownModal->Controls->Add(cancelButton);
        //--------------------------------------------------------------------
        // Display the window and query the user
        //--------------------------------------------------------------------
        promptPulldownModal->ShowDialog();
        if (promptPulldownModal->DialogResult == Windows::Forms::DialogResult::OK)
            modalResponse = GUI_ACCEPT;
        else
            modalResponse = GUI_CANCEL;
        if (modalResponse == GUI_ACCEPT)
        {
            if (inputComboBox->SelectedIndex && (inputComboBox->SelectedIndex != -1))
            {
                *listOffset = inputComboBox->SelectedIndex;
            }
        }
        RecordBasicEvent(
            "Prompt Pulldown with title '{0}' and text\n'{1}'\nresulted in '{2}'",
            titleString,
            promptString,
            ((modalResponse == GUI_ACCEPT) ? pulldownList[*listOffset] : cancelButton->Text));
        //--------------------------------------------------------------------
        // Dispose of the window components
        //--------------------------------------------------------------------
        delete promptPulldownModal;
        this->Refresh();
        delete promptString;
    }
    RecordBasicEvent("{0} concluded, returning {1}",
        functionName, (modalResponse ? "Accept" : "Cancel"));
    return modalResponse;
}                                       // end of DTSTest_PromptPulldownModal()
//----------------------------------------------------------------------------
// DTSTest_PromptYesNoModal
//
// Displays a Yes / No modal with a single prompt line
//
// Returns: GUI_ACCEPT or GUI_CANCEL
//
// Note:    If the user presses Enter, the 'Yes' button will be accepted; if
//          the user presses Esc, the 'No' button will be accepted
//
// Note:    If either yesText or noText is NULL, only the 'OK' button will be
//          displayed
//
// Note:    If yesText is a zero-length string, the OK button will be
//          displayed as 'Yes' and if noText is a zero-length string,
//          Cancel button will be displayed as 'No'
//----------------------------------------------------------------------------
    bool DTSTest_GUIClass::
DTSTest_PromptYesNoModal(
    String          ^titleString,
    String          ^yesText,
    String          ^noText,
    String          ^formatString,
    ...array <Object ^>
                    ^parameters)
{
    bool            modalResponse = GUI_NO; // defaults to a 'No' response
    int             buttonCenter;
    int             buttonWidth = GUI_YES_NO_BUTTON_WIDTH;
    int             lines = 0;
    int             promptWidth = 0;
    int             titleWidth;
    char            *nextLine = (char *) 0;
    DWORD           textWidth;
    Button          ^noButton;
    Button          ^okButton;
    Button          ^yesButton;
    String          ^responseButton;
    String          ^functionName = _T("DTSTest_PromptYesNoModal");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0} called", functionName);
    if (StringSet(formatString))
    {
        String ^promptString = String::Format(formatString, parameters);
        //--------------------------------------------------------------------
        // Create a new window
        //--------------------------------------------------------------------
        Form ^promptYNModal = gcnew Form;
        //--------------------------------------------------------------------
        // Set the title
        //--------------------------------------------------------------------
        if (StringSet(titleString))
        {
            promptYNModal->Text = titleString;
            titleWidth = DTSTest_StringWidth(titleString);
        }
        else
        {
            promptYNModal->Text = _T("DTSTest");
        }
        //--------------------------------------------------------------------
        // Set its properties
        //--------------------------------------------------------------------
        promptYNModal->Icon = DTSTest_SoftwareIcon;
//        promptYNModal->BackgroundImage = gcnew Bitmap(GUI_BG_WOOD_PANEL, GUI_YES);
        promptYNModal->FormBorderStyle = ::FormBorderStyle::FixedDialog;
        promptYNModal->StartPosition = FormStartPosition::CenterScreen;
        promptYNModal->TopMost = GUI_YES;
        //--------------------------------------------------------------------
        // Prevent the user from changing its appearance
        //--------------------------------------------------------------------
        promptYNModal->MaximizeBox = GUI_NO;
        promptYNModal->MinimizeBox = GUI_NO;
        promptYNModal->HelpButton = GUI_NO;
        //--------------------------------------------------------------------
        // Add text to prompt the user
        //--------------------------------------------------------------------
        Label ^modalMessage = gcnew Label;
        modalMessage->Location = Point(10, 10);
        modalMessage->TextAlign = Drawing::ContentAlignment::MiddleLeft;
        //--------------------------------------------------------------------
        // If this is a multi-line prompt, find the number of lines and the
        // width of the longest line
        //--------------------------------------------------------------------
        promptString = promptString->Replace(Environment::NewLine, DTSTEST_STRING_LF);
        array <Char> ^lineDelimiters = gcnew array <Char> {'\r', '\n'};
        array <String ^> ^promptLines = promptString->Split(lineDelimiters);
        lines = promptLines->Length;
        for each (String ^promptLine in promptLines)
        {
            promptWidth = Max(promptWidth, (int) DTSTest_StringWidth(promptLine) + (promptLine->Length / 2));
            Label ^modalMessage = gcnew Label;
            modalMessage->Location = Point(
                10,
                ((Array::IndexOf(promptLines, promptLine) * GUI_PROMPT_LABEL_HEIGHT) + 10));
            modalMessage->Size = Drawing::Size(
                promptWidth,
                GUI_PROMPT_LABEL_HEIGHT);
            modalMessage->TextAlign = Drawing::ContentAlignment::MiddleLeft;
            modalMessage->Text = promptLine;
            modalMessage->ForeColor = Color::Black;
            modalMessage->BackColor = Color::Transparent;
            promptYNModal->Controls->Add(modalMessage);
            promptWidth = Max(promptWidth, modalMessage->Width);
        }
        delete [] promptLines;
        delete [] lineDelimiters;
        promptYNModal->Size = Drawing::Size(
            Max((promptWidth + 25), (titleWidth + 100)),
            (lines * GUI_PROMPT_LABEL_HEIGHT) + 85);
        if (yesText && noText)
        {
            //----------------------------------------------------------------
            // Create the 'Yes' and 'No' buttons
            //----------------------------------------------------------------
            if (String::IsNullOrEmpty(yesText))
                yesText = _T("Yes");
            if (String::IsNullOrEmpty(noText))
                noText = _T("No");
            textWidth = Max(DTSTest_StringWidth(yesText), DTSTest_StringWidth(noText));
            if (textWidth > 25)
                buttonWidth += (textWidth - 25);
            buttonCenter = Max((promptYNModal->Width / 4), buttonWidth);
            promptYNModal->Width = Max(promptYNModal->Width, (buttonCenter * 4));
            yesButton = gcnew Button;
            yesButton->Text = yesText;
            yesButton->Tag = 1;
            yesButton->Size = Drawing::Size(buttonWidth, GUI_REGULAR_BUTTON_HEIGHT);
            yesButton->Location = Point(
                (buttonCenter - (buttonWidth / 2)),
                promptYNModal->Height - 65);
            yesButton->BackgroundImage = gcnew Bitmap(GUI_BG_SAND, GUI_YES);
            yesButton->DialogResult = Windows::Forms::DialogResult::OK;
            yesButton->KeyPress +=
                gcnew KeyPressEventHandler(this, &DTSTest_GUIClass::DTSTest_PromptKeyPressed);
            noButton = gcnew Button;
            noButton->Text = noText;
            noButton->Size = yesButton->Size;
            noButton->Location = Point(
                (promptYNModal->Width - yesButton->Left - buttonWidth),
                yesButton->Top);
            noButton->BackgroundImage = gcnew Bitmap(GUI_BG_SAND, GUI_YES);
            noButton->DialogResult = Windows::Forms::DialogResult::Cancel;
            noButton->KeyPress +=
                gcnew KeyPressEventHandler(this, &DTSTest_GUIClass::DTSTest_PromptKeyPressed);
            //----------------------------------------------------------------
            // Relate the buttons to the window
            //----------------------------------------------------------------
            promptYNModal->AcceptButton = yesButton;    // button when user presses Enter
            promptYNModal->CancelButton = noButton;     // button when user presses Esc
            array <Button ^> ^modalButtons =
            {
                yesButton,
                noButton
            };
            promptYNModal->Controls->AddRange(modalButtons);
        }                               // end of if (yesText && noText)
        else
        {
            okButton = gcnew Button;
            okButton->Text = _T("OK");
            okButton->Location = Point(
                (promptYNModal->Width - okButton->Width - 15),
                promptYNModal->Height - 65);
            okButton->Size = Drawing::Size(buttonWidth, GUI_REGULAR_BUTTON_HEIGHT);
            okButton->BackgroundImage = gcnew Bitmap(GUI_BG_SAND, GUI_YES);
            okButton->DialogResult = Windows::Forms::DialogResult::OK;
            okButton->KeyPress +=
                gcnew KeyPressEventHandler(this, &DTSTest_GUIClass::DTSTest_PromptKeyPressed);
            promptYNModal->AcceptButton = okButton;     // button when user presses Enter
            promptYNModal->Controls->Add(okButton);
            //----------------------------------------------------------------
            // Create but miniaturize the Cancel button to accept the Esc key
            //----------------------------------------------------------------
            Button ^cancelButton = gcnew Button;
            cancelButton->Size = Drawing::Size(1, 1);
            cancelButton->Location = Point(okButton->Left, okButton->Top);
            cancelButton->DialogResult = Windows::Forms::DialogResult::Cancel;
            cancelButton->KeyPress +=
                gcnew KeyPressEventHandler(this, &DTSTest_GUIClass::DTSTest_PromptKeyPressed);
            promptYNModal->CancelButton = cancelButton;     // button when user presses Esc
            promptYNModal->Controls->Add(cancelButton);
        }
        //--------------------------------------------------------------------
        // Display the window and query the user
        //--------------------------------------------------------------------
        DTSTest_ModalKeyStroke = 0;
        promptYNModal->ShowDialog();
        if ((DTSTest_ModalKeyStroke == 'Y') || (DTSTest_ModalKeyStroke == 'N'))
        {
            //----------------------------------------------------------------
            // A recognized key was pressed that was not Enter, Esc, or Space
            //----------------------------------------------------------------
            if (DTSTest_ModalKeyStroke == 'Y')
                modalResponse = GUI_ACCEPT;
            else
                modalResponse = GUI_CANCEL;
        }
        else
        {
            //----------------------------------------------------------------
            // A button was clicked, or Enter, Esc, or Space was pressed
            //----------------------------------------------------------------
            if (promptYNModal->DialogResult == Windows::Forms::DialogResult::OK)
                modalResponse = GUI_ACCEPT;
            else
                modalResponse = GUI_CANCEL;
            if (modalResponse == GUI_CANCEL)
                DTSTest_ModalKeyStroke = GUI_KEY_ESC;
        }
        if (yesText && noText)
        {
            if (modalResponse == GUI_ACCEPT)
                responseButton = yesButton->Text;
            else
                responseButton = noButton->Text;
        }
        else
        {
            if (modalResponse == GUI_ACCEPT)
                responseButton = okButton->Text;
            else
                responseButton = _T("Esc");
        }
        RecordBasicEvent(
            "Prompt Y/N with title '{0}' and text\n'{1}'\nresulted in '{2}'",
            titleString,
            promptString,
            responseButton);
        //--------------------------------------------------------------------
        // Dispose of the window components
        //--------------------------------------------------------------------
        delete modalMessage;
        delete promptYNModal;
        this->Refresh();
        delete promptString;
    }                                   // end of if (StringSet(formatString))
    RecordBasicEvent("{0} concluded, returning {1}",
        functionName, (modalResponse ? "Accept" : "Cancel"));
    return modalResponse;
}                                       // end of DTSTest_PromptYesNoModal()
//----------------------------------------------------------------------------
// DTSTest_RecordAndModalErrorEvent
//
// Records the message as an error event, then prompts the user with the same
// message
//
// Note:    The Error Log will be updated with the formatted message string if
//          the log file exists, regardless of any other flag setting, but the
//          Event Log will be updated with the message only if one or more of
//          the event log flags is enabled, and the modal dialog will be
//          displayed only if the global error messages flag is enabled
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_RecordAndModalErrorEvent(
    String          ^formatString,
    ...array <Object ^>
                    ^parameters)
{
    //------------------------------------------------------------------------
    if (StringSet(formatString))
    {
        String ^formattedString = String::Format(formatString, parameters);
        RecordErrorEvent(formattedString);
        DTSTest_UpdateErrorLog(formattedString);
        ModalE(formattedString);
        delete formattedString;
    }
}                                       // end of DTSTest_RecordAndModalErrorEvent()
//----------------------------------------------------------------------------
// DTSTest_RecordAndModalEventByFlags
//
// Records the message as an event if the event flag is set, then prompts the
// user with the same message, if the message flag is set
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_RecordAndModalEventByFlags(
    bool            eventFlag,
    bool            messageFlag,
    String          ^sourceFunction,
    String          ^formatString,
    ...array <Object ^>
                    ^parameters)
{
    //------------------------------------------------------------------------
    if ((eventFlag || messageFlag) && StringSet(formatString))
    {
        String ^formattedString = String::Format(formatString, parameters);
        DTSTest_RecordEvent(eventFlag, String::Format(
            "{0} :\n{1}", sourceFunction, formattedString));
        DTSTest_DisplayModalMessage(
            messageFlag,
            MB_ICONINFORMATION,
            sourceFunction,
            formattedString);
        delete formattedString;
    }
}                                       // end of DTSTest_RecordAndModalEventByFlags()
//----------------------------------------------------------------------------
// DTSTest_RemoveFilesAndSubFolders
//
// Removes (deletes) all the files and sub-folders in the specified folder,
// but not the specified folder itself
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_RemoveFilesAndSubFolders(
    String          ^folderString)
{
    //------------------------------------------------------------------------
    if (StringSet(folderString))
    {
        if (Directory::Exists(folderString))
        {
            array <String ^> ^files = Directory::GetFiles(folderString);
            for each (String ^fileString in files)
            {
                if (StringICompare(Path::GetFileName(fileString), "Thumbs.db"))
                    File::Delete(fileString);
            }
            array <String ^> ^subFolders = Directory::GetDirectories(folderString);
            for each (String ^subFolderString in subFolders)
            {
                Directory::Delete(subFolderString, GUI_YES);
            }
        }
    }
}                                       // end of DTSTest_RemoveFilesAndSubFolders()
//----------------------------------------------------------------------------
// DTSTest_SaveBinaryData
//
// Saves the specified array of Bytes to the specified binary file
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_SaveBinaryData(
    array <Byte>    ^binaryData,
    String          ^binaryFileName)
{
    BinaryWriter    ^writeStream;
    //------------------------------------------------------------------------
    if (StringSet(binaryData) && StringSet(binaryFileName))
    {
        if (File::Exists(binaryFileName))
            File::Delete(binaryFileName);
        writeStream = WriteBinary(binaryFileName);
        if (writeStream)
        {
            writeStream->Write(binaryData);
            writeStream->Close();
            delete writeStream;
        }
    }
}                                       // end of DTSTest_SaveBinaryData()
//----------------------------------------------------------------------------
// DTSTest_SendEmailMessage
//
// Sends an email with the specified subject and message
//
// Returns: 0       = Success
//          nonzero = Failure
//----------------------------------------------------------------------------
    DWORD DTSTest_GUIClass::
DTSTest_SendEmailMessage(
    String          ^emailSubjectString,
    String          ^emailMessageString)
{
    DWORD           status = DTSTEST_SUCCESS;
    String          ^functionName = _T("DTSTest_SendEmailMessage");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0} called", functionName);
    if (StringSet(advancedEmailMessageToAddressBox->Text))
    {
        if (StringSet(emailSubjectString) && StringSet(emailMessageString))
        {
            EmailInfo ^emailInfo = gcnew EmailInfo;
            emailInfo->subjectString = emailSubjectString;
            emailInfo->messageString = emailMessageString;
            MailMessage ^emailMessage = gcnew MailMessage;
            emailMessage->From = gcnew MailAddress(DTSTEST_EMAIL_MESSAGE_SOURCE);
            MailAddress ^toAddress = gcnew MailAddress(advancedEmailMessageToAddressBox->Text);
            emailMessage->To->Add(toAddress);
            delete toAddress;
            if (StringSet(advancedTextMessageCCNumberBox->Text))
            {
                MailAddress ^ccAddress = gcnew MailAddress(advancedEmailMessageCCAddressBox->Text);
                emailMessage->CC->Add(ccAddress);
                delete ccAddress;
            }
            if (StringSet(emailInfo->messageString))
            {
                emailMessage->Body = emailInfo->messageString->Trim();
                emailMessage->BodyEncoding = Encoding::UTF8;
            }
            else
            {
                DTSTest_RecordAndModalErrorEvent(
                    "{0} :\nMessage text is absent",
                    functionName);
                status = DTSTEST_ERROR_EMAIL_MISSING_MESSAGE;                   // 0x00000094
            }
            if (StringSet(emailInfo->subjectString))
            {
                emailMessage->Subject = emailInfo->subjectString->Trim();
                emailMessage->SubjectEncoding = Encoding::UTF8;
            }
            else
            {
                DTSTest_RecordAndModalErrorEvent(
                    "{0} :\nSubject text is absent",
                    functionName);
                status = DTSTEST_ERROR_EMAIL_MISSING_SUBJECT;                   // 0x00000093
            }
            if (status == DTSTEST_SUCCESS)
            {
                status = DTSTest_SendSMTPMail(emailMessage);
            }                           // end of if (status == DTSTEST_SUCCESS)
            emailMessage->~MailMessage();
            delete emailMessage;
            delete emailInfo;
        }                               // end of if (StringSet(emailSubjectString) && ...)
        else
        {
            if (!StringSet(emailSubjectString))
            {
                DTSTest_RecordAndModalErrorEvent(
                    "{0} : No email subject string specified", functionName);
                status = DTSTEST_ERROR_EMAIL_MISSING_SUBJECT;                   // 0x00000093
            }
            if (!StringSet(emailMessageString))
            {
                DTSTest_RecordAndModalErrorEvent(
                    "{0} : No email message string specified", functionName);
                status = DTSTEST_ERROR_EMAIL_MISSING_MESSAGE;                   // 0x00000094
            }
        }
    }
    else
    {
        DTSTest_SendEmailErrorMessagesEnabled = GUI_NO;
        DTSTest_UpdateMessageChecks();
        Modal("No email address specified to send error message");
        status = DTSTEST_ERROR_EMAIL_MISSING_COMPONENT;                         // 0x00000092
    }
    RecordBasicEvent("{0} concluded, returning 0x{1:X8}", functionName, status);
    return status;
}                                       // end of DTSTest_SendEmailMessage()
//----------------------------------------------------------------------------
// DTSTest_SendEmailStructure
//
// Sends an email using the specified email structure, which is needed for
// sending attachments
//
// Returns: 0       = Success
//          nonzero = Failure
//----------------------------------------------------------------------------
    DWORD DTSTest_GUIClass::
DTSTest_SendEmailStructure(
    EmailInfo       ^emailInfo)
{
    DWORD           status = DTSTEST_SUCCESS;
    String          ^carbonAddress;
    String          ^emailAddress;
    String          ^returnAddress;
    String          ^sourceAddress;
    String          ^functionName = _T("DTSTest_SendEmailStructure");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0} called", functionName);
    if (emailInfo && StringSet(emailInfo->toAddress) &&
        StringSet(emailInfo->fromAddress) &&
        StringSet(emailInfo->messageString))
    {
        emailAddress = emailInfo->toAddress;
        sourceAddress = emailInfo->fromAddress;
        //--------------------------------------------------------------------
        // Loosely verify the format of the email address
        //--------------------------------------------------------------------
        if (DTSTest_EmailAddressFormatIsValid(emailAddress) &&
            DTSTest_EmailAddressFormatIsValid(sourceAddress))
        {
            MailAddress ^toAddress = gcnew MailAddress(emailAddress);
            MailAddress ^fromAddress = gcnew MailAddress(sourceAddress);
            MailMessage ^emailMessage = gcnew MailMessage(fromAddress, toAddress);
            carbonAddress = emailInfo->ccAddress;
            if (StringSet(carbonAddress))
            {
                if (DTSTest_EmailAddressFormatIsValid(carbonAddress))
                {
                    MailAddress ^ccAddress = gcnew MailAddress(carbonAddress);
                    emailMessage->CC->Add(ccAddress);
                }
                else
                {
                    DTSTest_RecordAndModalErrorEvent(
                        "{0}({1}) : Email CC address '{2}' is invalid",
                        functionName, emailAddress, carbonAddress);
                    status = DTSTEST_ERROR_INVALID_EMAIL_ADDRESS;               // 0x00000091
                }
            }
            returnAddress = emailInfo->replyAddress;
            if (StringSet(returnAddress))
            {
                if (DTSTest_EmailAddressFormatIsValid(returnAddress))
                {
                    MailAddress ^replyAddress = gcnew MailAddress(returnAddress);
                    emailMessage->ReplyToList->Add(replyAddress);
                }
                else
                {
                    DTSTest_RecordAndModalErrorEvent(
                        "{0}({1}) : Email reply address '{2}' is invalid",
                        functionName, emailAddress, returnAddress);
                    status = DTSTEST_ERROR_INVALID_EMAIL_ADDRESS;               // 0x00000091
                }
            }
            if (StringSet(emailInfo->messageString))
            {
                emailMessage->Body = emailInfo->messageString->Trim();
                emailMessage->BodyEncoding = Encoding::UTF8;
            }
            else
            {
                DTSTest_RecordAndModalErrorEvent(
                    "{0}({1}) : Message text is absent",
                    functionName, emailAddress);
                status = DTSTEST_ERROR_EMAIL_MISSING_MESSAGE;                   // 0x00000094
            }
            if (StringSet(emailInfo->subjectString))
            {
                emailMessage->Subject = emailInfo->subjectString->Trim();
                emailMessage->SubjectEncoding = Encoding::UTF8;
            }
            else
            {
                DTSTest_RecordAndModalErrorEvent(
                    "{0}({1}) : Subject text is absent",
                    functionName, emailAddress);
                status = DTSTEST_ERROR_EMAIL_MISSING_SUBJECT;                   // 0x00000093
            }
            if (status == DTSTEST_SUCCESS)
            {
                if (StringSet(emailInfo->attachment) || StringSet(emailInfo->attachmentArray))
                {
                    if (StringSet(emailInfo->attachment))
                    {
                        if (File::Exists(emailInfo->attachment))
                        {
                            Attachment ^attachment = gcnew Attachment(
                                emailInfo->attachment, MediaTypeNames::Application::Zip);
                            emailMessage->Attachments->Add(attachment);
                        }
                        else
                        {
                            DTSTest_RecordAndModalErrorEvent(
                                "{0}({1}) : Attachment {2} could not be found",
                                functionName, emailAddress, emailInfo->attachment);
                            status = DTSTEST_ERROR_EMAIL_MISSING_ATTACHMENT;    // 0x00000095
                        }
                    }
                    else
                    {
                        for each (String ^attachmentFilePath in emailInfo->attachmentArray)
                        {
                            if (File::Exists(attachmentFilePath))
                            {
                                Attachment ^attachment = gcnew Attachment(
                                    attachmentFilePath, MediaTypeNames::Application::Zip);
                                emailMessage->Attachments->Add(attachment);
                            }
                            else
                            {
                                DTSTest_RecordAndModalErrorEvent(
                                    "{0}({1}) : Attachment {2} could not be found",
                                    functionName, emailAddress, attachmentFilePath);
                                status = DTSTEST_ERROR_EMAIL_MISSING_ATTACHMENT;// 0x00000095
                            }
                        }
                    }
                }                       // end of if (StringSet(emailInfo->attachment) || ...)
                status = DTSTest_SendSMTPMail(emailMessage);
            }                           // end of if (status == DTSTEST_SUCCESS)
            emailMessage->~MailMessage();
            delete emailMessage;
            delete fromAddress;
            delete toAddress;
        }
        else
        {
            DTSTest_RecordAndModalErrorEvent(
                "{0}({1}) :\nInvalid email address '{2}'",
                functionName, emailAddress,
                (DTSTest_EmailAddressFormatIsValid(emailAddress) ? sourceAddress : emailAddress));
            status = DTSTEST_ERROR_INVALID_EMAIL_ADDRESS;
        }
    }                                   // end of if (emailInfo && ...)
    else
    {
        DTSTest_RecordAndModalErrorEvent(
            "{0} : Nothing to email", functionName);
        status = DTSTEST_ERROR_EMAIL_MISSING_COMPONENT;
    }
    RecordBasicEvent("{0} concluded, returning 0x{1:X8}", functionName, status);
    return status;
}                                       // end of DTSTest_SendEmailStructure()
//----------------------------------------------------------------------------
// DTSTest_SendSMTPMail
//
// Creates and sends the specified mail package via SMTP
//
// Returns: 0       = Success
//          nonzero = Failure
//
// Called by:   DTSTest_SendEmailMessage
//              DTSTest_SendEmailStructure
//              DTSTest_SendTextMessage
//----------------------------------------------------------------------------
    DWORD DTSTest_GUIClass::
DTSTest_SendSMTPMail(
    MailMessage     ^mailPackage)
{
    int             portNumber = GMAIL_MAIL_SERVER_PORT_NUMBER;                 // 587
    DWORD           status = DTSTEST_SUCCESS;
    String          ^hostName = GMAIL_MAIL_SERVER;
    String          ^primary = DTSTEST_CREDENTIAL_PRIMARY;
    String          ^secondary = DTSTEST_CREDENTIAL_SECONDARY;
    String          ^unhashed;
    String          ^functionName = _T("DTSTest_SendSMTPMail");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0} called", functionName);
    unhashed = String::Empty;
    for (int offset = 0; offset < primary->Length; offset++)
    {
        unhashed = String::Concat(
            unhashed, Char::ConvertFromUtf32(primary[offset] - offset + 0x1F));
    }
    primary = unhashed;
    unhashed = String::Empty;
    for (int offset = 0; offset < secondary->Length; offset++)
    {
        unhashed = String::Concat(
            unhashed, Char::ConvertFromUtf32(secondary[offset] - (2 * offset) - 0x01));
    }
    secondary = unhashed;
    //------------------------------------------------------------------------
    // The actual credentials are recorded in Log Book 1, page 148
    //
    // Modal("About to send to {0} using {1}", primary, secondary);
    //------------------------------------------------------------------------
    // The following works from work:
    //
    // SmtpClient ^client = gcnew SmtpClient("mail.quartzdyne.com", 25);
    // client->UseDefaultCredentials = GUI_YES;
    // client->EnableSsl = GUI_YES;
    //
    // or
    //
    // SmtpClient ^client = gcnew SmtpClient(QUARTZDYNE_EXCHANGE_SERVER);
    //
    // The following works from home:
    //
    // SmtpClient ^client = gcnew SmtpClient("smtp.gmail.com", 587);
    // client->UseDefaultCredentials = GUI_NO;
    // client->Credentials = gcnew NetworkCredential("dtstest.notify", "dtstest9119");
    //------------------------------------------------------------------------
    SmtpClient ^client = gcnew SmtpClient(hostName, portNumber);
    client->UseDefaultCredentials = GUI_NO;
    client->Credentials = gcnew NetworkCredential(primary, secondary);
    client->EnableSsl = GUI_YES;
    try
    {
        client->Send(mailPackage);
        client->~SmtpClient();
    }
    catch (Exception ^ex)
    {
        DTSTest_RecordAndModalErrorEvent(
            "{0} :\nProblem sending mail via host {1} on port {2:D}\nException: {3}",
            functionName, hostName, portNumber,
            ex->ToString());
        status = DTSTEST_ERROR_EMAIL_FAILED_TO_SEND;
    }
    delete unhashed;
    delete secondary;
    delete primary;
    RecordBasicEvent("{0} concluded, returning 0x{1:X8}", functionName, status);
    return status;
}                                       // end of DTSTest_SendSMTPMail()
//----------------------------------------------------------------------------
// DTSTest_SendTextMessage
//
// Sends the specified text message
//
// Returns: 0       = Success
//          nonzero = Failure
//----------------------------------------------------------------------------
    DWORD DTSTest_GUIClass::
DTSTest_SendTextMessage(
    String          ^textSubjectString,
    String          ^textMessageString)
{
    DWORD           status = DTSTEST_SUCCESS;
    array <String ^>
                    ^gatewayHostArray =
                        {
                            _T("txt.att.net"),              // AT&T
                            _T("vtext.com"),                // Verizon
                            _T("tmomail.net"),              // T-Mobile
                            _T("messaging.sprintpcs.com"),  // Sprint
                            _T("sms.mycricket.com"),        // Cricket
                            _T("messaging.nextel.com"),     // Nextel
                            _T("vmobl.com"),                // Virgin Mobile
                            _T("message.alltel.com"),       // Alltel
                            _T("myboostmobile.com"),        // Boost Mobile
                            _T("email.uscc.net"),           // US Cellular
                            _T("sms.thumbcellular.com"),    // Thumb Cellular
                            _T("ptel.net"),                 // PowerTel
                            _T("MyMetroPCS.com"),           // Metro PCS
                            _T("phone.cellone.net"),        // Cellular One - East Coast
                            _T("mobile.celloneusa.com"),    // Cellular One - USA Other
                            _T("messagealert.com"),         // GTE
                            _T("mci.com"),                  // MCI
                            _T("pacbellpcs.net"),           // Pacific Bell
                            _T("qwestmp.com"),              // Qwest
                            _T("mmst5.tracfone.com"),       // Tracfone
                            _T("mobipcs.net"),              // Mobi PCS
                            _T("pcs.rogers.com"),           // Rogers Canada
                            _T("cellularonewest.com"),      // Western Wireless
                            _T("msg.telus.com")             // Telus
                        };
    String          ^gatewaySection;
    String          ^numberSection;
    String          ^functionName = _T("DTSTest_SendTextMessage");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0} called", functionName);
    if (StringSet(advancedTextMessageToNumberBox->Text))
    {
        if (StringSet(textSubjectString) && StringSet(textMessageString))
        {
            EmailInfo ^emailInfo = gcnew EmailInfo;
            emailInfo->subjectString = textSubjectString;
            emailInfo->messageString = textMessageString;
            MailMessage ^emailMessage = gcnew MailMessage;
            emailMessage->From = gcnew MailAddress(DTSTEST_TEXT_MESSAGE_SOURCE);
            if (advancedTextMessageToNumberBox->Text->Contains("@"))
            {
                gatewaySection = advancedTextMessageToNumberBox->Text->Substring(
                    advancedTextMessageToNumberBox->Text->IndexOf("@"));
                numberSection = advancedTextMessageToNumberBox->Text->Substring(
                    0, advancedTextMessageToNumberBox->Text->IndexOf("@"));
                if (numberSection->Contains("-"))
                    numberSection = numberSection->Replace("-", "");
                emailInfo->toAddress = String::Concat(numberSection, gatewaySection);
                MailAddress ^toAddress = gcnew MailAddress(emailInfo->toAddress);
                emailMessage->To->Add(toAddress);
                delete toAddress;
            }
            else
            {
                //------------------------------------------------------------
                // If the gateway is not specified, use all of them
                //------------------------------------------------------------
                numberSection = advancedTextMessageToNumberBox->Text;
                if (numberSection->Contains("-"))
                    numberSection = numberSection->Replace("-", "");
                for each (String ^gateway in gatewayHostArray)
                {
                    emailInfo->toAddress = String::Concat(
                        numberSection, "@", gateway);
                    MailAddress ^toAddress = gcnew MailAddress(emailInfo->toAddress);
                    emailMessage->To->Add(toAddress);
                    delete toAddress;
                }
            }
            if (StringSet(advancedTextMessageCCNumberBox->Text))
            {
                if (advancedTextMessageCCNumberBox->Text->Contains("@"))
                {
                    gatewaySection = advancedTextMessageCCNumberBox->Text->Substring(
                        advancedTextMessageCCNumberBox->Text->IndexOf("@"));
                    numberSection = advancedTextMessageCCNumberBox->Text->Substring(
                        0, advancedTextMessageCCNumberBox->Text->IndexOf("@"));
                    if (numberSection->Contains("-"))
                        numberSection = numberSection->Replace("-", "");
                    emailInfo->ccAddress = String::Concat(numberSection, gatewaySection);
                    MailAddress ^ccAddress = gcnew MailAddress(emailInfo->ccAddress);
                    emailMessage->CC->Add(ccAddress);
                    delete ccAddress;
                }
                else
                {
                    numberSection = advancedTextMessageCCNumberBox->Text;
                    if (numberSection->Contains("-"))
                        numberSection = numberSection->Replace("-", "");
                    for each (String ^gateway in gatewayHostArray)
                    {
                        emailInfo->ccAddress = String::Concat(
                            numberSection, "@", gateway);
                        MailAddress ^ccAddress = gcnew MailAddress(emailInfo->ccAddress);
                        emailMessage->CC->Add(ccAddress);
                        delete ccAddress;
                    }
                }
            }
            if (StringSet(emailInfo->messageString))
            {
                emailMessage->Body = emailInfo->messageString->Trim();
                emailMessage->BodyEncoding = Encoding::UTF8;
            }
            else
            {
                DTSTest_RecordAndModalErrorEvent(
                    "{0} :\nMessage text is absent",
                    functionName);
                status = DTSTEST_ERROR_TEXT_MISSING_MESSAGE;                    // 0x0000009B
            }
            if (StringSet(emailInfo->subjectString))
            {
                emailMessage->Subject = emailInfo->subjectString->Trim();
                emailMessage->SubjectEncoding = Encoding::UTF8;
            }
            else
            {
                DTSTest_RecordAndModalErrorEvent(
                    "{0} :\nSubject text is absent",
                    functionName);
                status = DTSTEST_ERROR_TEXT_MISSING_SUBJECT;                    // 0x0000009A
            }
            if (status == DTSTEST_SUCCESS)
            {
                status = DTSTest_SendSMTPMail(emailMessage);
            }                           // end of if (status == DTSTEST_SUCCESS)
            emailMessage->~MailMessage();
            delete emailMessage;
            delete emailInfo;
        }                               // end of if (StringSet(textSubjectString) && ...)
        else
        {
            if (!StringSet(textSubjectString))
            {
                DTSTest_RecordAndModalErrorEvent(
                    "{0} : No text subject string specified", functionName);
                status = DTSTEST_ERROR_TEXT_MISSING_SUBJECT;                    // 0x0000009A
            }
            if (!StringSet(textMessageString))
            {
                DTSTest_RecordAndModalErrorEvent(
                    "{0} : No text message string specified", functionName);
                status = DTSTEST_ERROR_TEXT_MISSING_MESSAGE;                    // 0x0000009B
            }
        }
    }
    else
    {
        DTSTest_SendTextErrorMessagesEnabled = GUI_NO;
        DTSTest_UpdateMessageChecks();
        Modal("No text message number specified to send error message");
        status = DTSTEST_ERROR_TEXT_MISSING_COMPONENT;                          // 0x00000099
    }
    RecordBasicEvent("{0} concluded, returning 0x{1:X8}", functionName, status);
    return status;
}                                       // end of DTSTest_SendTextMessage()
//----------------------------------------------------------------------------
// DTSTest_SetHostBaudRate
//
// Sets the host baud rate to the specified value
//
// Called by:   DTSTest_SendCommandArray
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_SetHostBaudRate(
    int             baudRate)
{
    String          ^functionName = _T("DTSTest_SetHostBaudRate");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0} called", functionName);
    if (DTSTest_GeneralInfo->pgInfo)
    {
        PDGICInfo ^pgInfo = DTSTest_GeneralInfo->pgInfo;
        pgInfo->baudRate = baudRate;
        SerialPort ^port = gcnew SerialPort();
        port->PortName = pgInfo->portName;
        port->BaudRate = pgInfo->baudRate;
        port->DataBits = pgInfo->dataBits;
        port->ReadTimeout = pgInfo->timeout;
        port->Parity = pgInfo->parity;
        port->StopBits = pgInfo->stopBits;
        port->Handshake = pgInfo->handShaking;
        try
        {
            port->Open();
            Thread::Sleep(100);
            if (port->IsOpen)
            {
                //------------------------------------------------------------
                // Clear out the buffers
                //------------------------------------------------------------
                port->DiscardOutBuffer();
                port->DiscardInBuffer();
            }
        }
        catch (UnauthorizedAccessException ^ex)
        {
            UNREFERENCED_PARAMETER(ex);
            DTSTest_PromptOKModal(functionName,
                "Port {0} is already being used by another program\n\n"
                "Please close the other program and try again",
                port->PortName);
        }
        if (port->IsOpen)
            port->Close();
        port->~SerialPort();
        delete port;
    }                                   // end of if (DTSTest_GeneralInfo->pgInfo)
    RecordBasicEvent("{0} concluded", functionName);
}                                       // end of DTSTest_SetHostBaudRate()
//----------------------------------------------------------------------------
// DTSTest_ShutDownSoftware
//
// Returns allocated memory to the pool, destroys the linked list of devices,
// and terminates the software
//
// Called by:   DTSTest_HomeClosingWindow
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_ShutDownSoftware(void)
{
    String          ^functionName = _T("DTSTest_ShutDownSoftware");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0} called", functionName);
    //------------------------------------------------------------------------
    // Shut down all background processes
    //------------------------------------------------------------------------
    if (oneSecondTimer->Enabled)
        oneSecondTimer->Stop();
    if (scriptControlLoopTimer->Enabled)
        scriptControlLoopTimer->Stop();
//    if (samplingTimer->Enabled)
//        samplingTimer->Stop();
    //------------------------------------------------------------------------
    // Save the logged contents
    //------------------------------------------------------------------------
    if (StringSet(generalLogFileString))
    {
        try
        {
            StreamWriter ^textWriter = File::CreateText(
                DTSTest_GeneralInfo->mainScript->resultsLogFilePath);
            if (textWriter)
            {
                textWriter->WriteLine(generalLogFileString);
                textWriter->Close();
            }
        }
        catch (Exception ^ex)
        {
            UNREFERENCED_PARAMETER(ex);
            //----------------------------------------------------------------
            // The log file is probably open, so just ignore the error and
            // therefore skip saving it
            //----------------------------------------------------------------
        }
    }
    if (StringSet(generalCSVFileString))
    {
        String ^csvPathString = DTSTest_GeneralInfo->mainScript->resultsLogFilePath->Replace(
            Path::GetExtension(DTSTest_GeneralInfo->mainScript->resultsLogFilePath), ".csv");
        //--------------------------------------------------------------------
        // Encode as ISO-8859 for the degree � symbol and save the file
        //--------------------------------------------------------------------
        try
        {
            StreamWriter ^textWriter = gcnew StreamWriter(
                csvPathString,
                GUI_NO,
                Encoding::GetEncoding("ISO-8859-15"));
            if (textWriter)
            {
                textWriter->WriteLine(generalCSVFileString);
                textWriter->Close();
            }
        }
        catch (Exception ^ex)
        {
            UNREFERENCED_PARAMETER(ex);
            //----------------------------------------------------------------
            // CSV file is probably open, so just ignore the error and
            // therefore skip saving it
            //----------------------------------------------------------------
        }
    }
    //------------------------------------------------------------------------
    // Remove the Please Wait window
    //------------------------------------------------------------------------
    DTSTest_PleaseWait(GUI_PLEASE_WAIT_DISPOSE, nullptr);
    //------------------------------------------------------------------------
    // Close the port connection
    //------------------------------------------------------------------------
    PDGICInfo ^pgInfo = DTSTest_GeneralInfo->pgInfo;
    SerialPort ^port = pgInfo->port;
    if (port && port->IsOpen)
    {
        port->Close();
        port->~SerialPort();
    }
    //------------------------------------------------------------------------
    // Announce software conclusion
    //------------------------------------------------------------------------
    GUI_PlaySound(downSound);
    //------------------------------------------------------------------------
    // Save the config file and conclude any running logs
    //------------------------------------------------------------------------
    DTSTest_Finalize(String::Concat(functionName, " concluded"));
}                                       // end of DTSTest_ShutDownSoftware()
//----------------------------------------------------------------------------
// DTSTest_StringWidth
//
// Returns the width of the specified string in pixels
//----------------------------------------------------------------------------
    DWORD DTSTest_GUIClass::
DTSTest_StringWidth(
    String          ^textString)
{
    DWORD           widthInPixels = 0;
    //------------------------------------------------------------------------
    if (StringSet(textString))
    {
        Drawing::Size ^numberOfPixels = Drawing::Size(
            TextRenderer::MeasureText(
                textString,
                gcnew Drawing::Font(this->Font, FontStyle::Regular)));
        widthInPixels = (DWORD) numberOfPixels->Width;
    }
    return widthInPixels;
}                                       // end of DTSTest_StringWidth()
//----------------------------------------------------------------------------
// DTSTest_UpdateMessageChecks
//
// Updates the message and event log check marks in the Home window
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_UpdateMessageChecks(void)
{
    bool            displayExpComponents;
    String          ^functionName = _T("DTSTest_UpdateMessageChecks");
    //------------------------------------------------------------------------
    RecordDetailedEvent("{0} called", functionName);
    displayExpComponents =
        (DTSTest_ExperimentsEnabled && (DTSTest_GeneralInfo->flags & DTSTEST_GENERAL_EXPERT_MODE)) ?
            GUI_YES : GUI_NO;
    advancedExperimentNumberBox->Visible = displayExpComponents;
    advancedExpOneButton->Visible = displayExpComponents;
    advancedBasicMessagesCheck->Checked = DTSTest_BasicMessagesEnabled ? GUI_YES : GUI_NO;
    advancedErrorMessagesCheck->Checked = DTSTest_ErrorMessagesEnabled ? GUI_YES : GUI_NO;
    advancedEnableExperimentsCheck->Checked = DTSTest_ExperimentsEnabled ? GUI_YES : GUI_NO;
    advancedVerboseMessagesCheck->Checked = DTSTest_VerboseMessagesEnabled ? GUI_YES : GUI_NO;
    advancedDetailedMessagesCheck->Checked = DTSTest_DetailedMessagesEnabled ? GUI_YES : GUI_NO;
    advancedExpMessagesCheck->Checked = DTSTest_ExpMessagesEnabled ? GUI_YES : GUI_NO;
    advancedEnableStackTracesCheck->Checked = DTSTest_StackTracesEnabled ? GUI_YES : GUI_NO;
    advancedSendTextErrorMessageCheck->Checked = DTSTest_SendTextErrorMessagesEnabled ? GUI_YES : GUI_NO;
    advancedSendTextErrorMessageCheck->Enabled =
        (StringSet(advancedTextMessageToNumberBox->Text) || StringSet(advancedTextMessageCCNumberBox->Text)) ?
            GUI_YES : GUI_NO;
    advancedSendEmailErrorMessageCheck->Checked = DTSTest_SendEmailErrorMessagesEnabled ? GUI_YES : GUI_NO;
    advancedSendEmailErrorMessageCheck->Enabled =
        (StringSet(advancedEmailMessageToAddressBox->Text) || StringSet(advancedEmailMessageCCAddressBox->Text)) ?
            GUI_YES : GUI_NO;
    advancedDontSaveConfigCheck->Checked =
        (DTSTest_GeneralInfo->flags & DTSTEST_GENERAL_CONFIG_DONT_SAVE) ?
            GUI_YES : GUI_NO;
    advancedDeleteConfigCheck->Checked =
        (DTSTest_GeneralInfo->flags & DTSTEST_GENERAL_CONFIG_DELETE_ON_EXIT) ?
            GUI_YES : GUI_NO;
    //------------------------------------------------------------------------
    // Modify the display of the ToolStrip pull-downs
    //------------------------------------------------------------------------
    eventLogAllTSButton->Text =
        (DTSTest_EventLogBasicEnabled || DTSTest_EventLogVerboseEnabled || DTSTest_EventLogDetailedEnabled) ?
            GUI_ELOG_ALL_STOP_STRING : GUI_ELOG_ALL_START_STRING;
    eventLogBasicTSButton->Text =
        DTSTest_EventLogBasicEnabled ?
            GUI_ELOG_BASIC_STOP_STRING : GUI_ELOG_BASIC_START_STRING;
    eventLogVerboseTSButton->Text =
        DTSTest_EventLogVerboseEnabled ?
            GUI_ELOG_VERBOSE_STOP_STRING : GUI_ELOG_VERBOSE_START_STRING;
    eventLogDetailedTSButton->Text =
        DTSTest_EventLogDetailedEnabled ?
            GUI_ELOG_DETAILED_STOP_STRING : GUI_ELOG_DETAILED_START_STRING;
    displayEventLogTSButton->Enabled =
        StringSet(DTSTest_GeneralInfo->mostRecentEventLogPath) ?
            GUI_YES : GUI_NO;
    RecordDetailedEvent("{0} concluded", functionName);
}                                       // end of DTSTest_UpdateMessageChecks()
//----------------------------------------------------------------------------
// DTSTest_URLExists
//
// Determines whether the specified URL exists
//----------------------------------------------------------------------------
    bool DTSTest_GUIClass::
DTSTest_URLExists(
    String          ^URL)
{
    bool            URLExists = GUI_NO;
    String          ^functionName = _T("DTSTest_URLExists");
    //------------------------------------------------------------------------
    RecordVerboseEvent("{0} called", functionName);
    try
    {
        HttpWebRequest ^webRequest =
            dynamic_cast <HttpWebRequest ^> (WebRequest::Create(URL));
        if (webRequest)
        {
            webRequest->Method = _T("HEAD");
            HttpWebResponse ^webResponse =
                dynamic_cast <HttpWebResponse ^> (webRequest->GetResponse());
            if (webResponse)
            {
                if (webResponse->StatusCode == HttpStatusCode::OK)
                {
                    URLExists = GUI_YES;
                    RecordVerboseEvent("    Found {0}", URL);
                    //--------------------------------------------------------
                    // Call the destructor, which will prevent the software
                    // from hanging until it times out, if it ever calls this
                    // function multiple times in rapid succession
                    //--------------------------------------------------------
                    webResponse->~HttpWebResponse();
                }
            }
        }
    }
    catch (WebException ^ex)
    {
        DTSTest_RecordAndModalErrorEvent(
            "{0} for {1} failed\nException: {2}",
            functionName, URL, ex->Message);
    }
    RecordVerboseEvent("{0} concluded, returning {1}",
        functionName, (URLExists ? "Found" : "Not Found"));
    return URLExists;
}                                       // end of DTSTest_URLExists()
//----------------------------------------------------------------------------
// DTSTest_ValidateAndSendEmail
//
// Validates the contents of the specified email, then sends it if they appear
// valid
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_ValidateAndSendEmail(
    EmailInfo       ^emailInfo)
{
    int             numberOfBlankFields = 0;
    DWORD           status;
    String          ^blankFieldText;
    String          ^carbonAddress;
    String          ^emailAddress;
    String          ^returnAddress;
    String          ^sourceAddress;
    String          ^functionName = _T("DTSTest_ValidateAndSendEmail");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0} called", functionName);
    if (emailInfo && StringSet(emailInfo->toAddress) &&
        StringSet(emailInfo->fromAddress) &&
        StringSet(emailInfo->subjectString) &&
        StringSet(emailInfo->messageString))
    {
        emailAddress = emailInfo->toAddress;
        sourceAddress = emailInfo->fromAddress;
        //--------------------------------------------------------------------
        // Loosely verify the format of the email addresses
        //--------------------------------------------------------------------
        if (DTSTest_EmailAddressFormatIsValid(emailAddress))
        {
            if (DTSTest_EmailAddressFormatIsValid(sourceAddress))
            {
                DTSTest_GeneralInfo->emailAddress = sourceAddress;
                //------------------------------------------------------------
                // Check for a carbon-copy address
                //------------------------------------------------------------
                carbonAddress = emailInfo->ccAddress;
                if (StringSet(carbonAddress))
                {
                    if (!DTSTest_EmailAddressFormatIsValid(carbonAddress))
                    {
                        DTSTest_PromptOKModal(
                            "Invalid Email Address",
                            "Email CC address '{0}' is invalid",
                            carbonAddress);
                    }
                }
                //------------------------------------------------------------
                // Check for a reply address
                //------------------------------------------------------------
                returnAddress = emailInfo->replyAddress;
                if (StringSet(returnAddress))
                {
                    if (!DTSTest_EmailAddressFormatIsValid(returnAddress))
                    {
                        DTSTest_PromptOKModal(
                            "Invalid Email Address",
                            "Email reply address '{0}' is invalid",
                            returnAddress);
                    }
                }
                //------------------------------------------------------------
                // Check for attachments
                //------------------------------------------------------------
                if (StringSet(emailInfo->attachment))
                {
                    if (!File::Exists(emailInfo->attachment))
                    {
                        DTSTest_PromptOKModal(
                            "Email Attachment Missing",
                            "Attachment {0} could not be found",
                            emailInfo->attachment);
                    }
                }
                else
                {
                    for each (String ^attachmentFilePath in emailInfo->attachmentArray)
                    {
                        if (!File::Exists(attachmentFilePath))
                        {
                            DTSTest_PromptOKModal(
                                "Email Attachment Missing",
                                "Attachment {0} could not be found",
                                attachmentFilePath);
                        }
                    }
                }
                //------------------------------------------------------------
                // Possible errors encountered up to this point are not
                // serious enough to prevent sending the email
                //------------------------------------------------------------
                emailToCombo->BackColor = Color::White;
                emailFromCombo->BackColor = Color::White;
                emailSubjectBox->BackColor = Color::Lavender;
                emailMessageBox->BackColor = Color::Lavender;
                emailStatusLabel->Text = _T("Email sent...awaiting confirmation");
                emailStatusLabel->ForeColor = Color::Purple;
                emailStatusLabel->Update();
                status = DTSTest_SendEmailStructure(emailInfo);
                if (status == DTSTEST_SUCCESS)
                {
                    emailStatusLabel->Text = _T("Email successfully sent");
                    emailStatusLabel->ForeColor = Color::Blue;
                    emailStatusLabel->Update();
                    DTSTest_PromptOKModal(
                        "Send Email",
                        "Email successfully sent to\n{0}", emailAddress);
                }
                else
                {
                    emailStatusLabel->Text = _T("Email failed to send");
                    emailStatusLabel->ForeColor = Color::Red;
                    emailStatusLabel->Update();
                    GUI_DisplayMandatoryError(functionName,
                        "Failed to send email to\n{0}", emailAddress);
                }
            }                           // end of if (DTSTest_EmailAddressFormatIsValid(sourceAddress))
            else
            {
                emailFromCombo->BackColor = Color::Yellow;
                DTSTest_PromptOKModal(
                    "Invalid Email Address",
                    "Invalid 'From' email address");
            }
        }                               // end of if (DTSTest_EmailAddressFormatIsValid(emailAddress))
        else
        {
            emailToCombo->BackColor = Color::Yellow;
            DTSTest_PromptOKModal(
                "Invalid Email Address",
                "Invalid 'To' email address");
        }
    }                                   // end of if (emailInfo && ...)
    else
    {
        emailStatusLabel->ForeColor = Color::Red;
        if (emailInfo)
        {
            if (StringSet(emailInfo->toAddress))
            {
                emailToCombo->BackColor = Color::White;
            }
            else
            {
                numberOfBlankFields++;
                blankFieldText = _T("The 'To' field is blank");
                emailToCombo->BackColor = Color::Yellow;
            }
            if (StringSet(emailInfo->fromAddress))
            {
                emailFromCombo->BackColor = Color::White;
            }
            else
            {
                numberOfBlankFields++;
                blankFieldText = _T("The 'From' field is blank");
                emailFromCombo->BackColor = Color::Yellow;
            }
            if (StringSet(emailInfo->subjectString))
            {
                emailSubjectBox->BackColor = Color::Lavender;
            }
            else
            {
                numberOfBlankFields++;
                blankFieldText = _T("The Subject field is blank");
                emailSubjectBox->BackColor = Color::Yellow;
            }
            if (StringSet(emailInfo->messageString))
            {
                emailMessageBox->BackColor = Color::Lavender;
            }
            else
            {
                numberOfBlankFields++;
                blankFieldText = _T("The Message field is blank");
                emailMessageBox->BackColor = Color::Yellow;
            }
            emailStatusLabel->Text =
                (numberOfBlankFields == 1) ?
                blankFieldText :
                _T("Multiple fields are blank");
            DTSTest_PromptOKModal(
                "Email Field Missing",
                "Fill in the missing fields and try again");
        }                               // end of if (emailInfo)
        else
        {
            emailStatusLabel->Text = _T("The email structure is invalid");
            GUI_DisplayMandatoryError(functionName,
                "The email structure is invalid");
        }
    }
    RecordBasicEvent("{0} concluded", functionName);
}                                       // end of DTSTest_ValidateAndSendEmail()
//----------------------------------------------------------------------------
// DTSTest_ZipFiles
//
// Creates the specified .zip file from the collection of files indicated by
// the specified array of files
//
// Note:    The resulting .zip file will contain a file called
//          [Content_Types].xml when it is unZIPped. This file contains content
//          information about the types of files included in the .zip file, and
//          and is explained on http://www.codeproject.com/KB/vb/ZipDemo.aspx
//          under "Points of Interest"
//
// Note:    This function requires WindowsBase.dll
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_ZipFiles(
    array <String ^>
                    ^filesToZip,
    String          ^zipFileName)
{
    bool            includeThisFile;
    String          ^functionName = _T("DTSTest_ZipFiles");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0} called", functionName);
    if (StringSet(filesToZip) && StringSet(zipFileName))
    {
        Package ^zipPackage = Package::Open(zipFileName, FileMode::Create);
        for each (String ^pathString in filesToZip)
        {
            if (pathString && File::Exists(pathString) &&
                StringICompare(pathString, zipFileName))
            {
                includeThisFile = GUI_YES;
                FileInfo ^pathInfo = gcnew FileInfo(pathString);
                //------------------------------------------------------------
                // Attempting to package a file larger than 25 MB will result
                // in a Data Error exception, so exclude those files from the
                // package
                //
                // By experimentation, this limit seems to be greater than
                // 26,331,258 and less than 26,331,336
                //------------------------------------------------------------
                if (pathInfo->Length > 26300000)
                {
                    Modal("File is too large to ZIP and will be skipped:\n{0}", pathString);
                }
                else
                {
                    for each (String ^fileString in filesToZip)
                    {
                        //----------------------------------------------------
                        // If a file with a duplicate filename exists in the
                        // array, take the one with the later date
                        //----------------------------------------------------
                        if (StringICompare(Path::GetFileName(pathString), Path::GetFileName(fileString)) == 0)
                        {
                            FileInfo ^fileInfo = gcnew FileInfo(fileString);
                            if (fileInfo->LastAccessTime > pathInfo->LastAccessTime)
                            {
                                includeThisFile = GUI_NO;
                                break;
                            }
                        }
                    }                   // end of for each (String ^fileString in filesToZip)
                    if (includeThisFile)
                    {
                        String ^zipURI = String::Concat(
                            "/", Path::GetFileName(pathString)->Replace(' ', '_'));
                        Uri ^partURI = gcnew Uri(zipURI, UriKind::Relative);
                        PackagePart ^packagePart = zipPackage->CreatePart(
                            partURI,
                            MediaTypeNames::Application::Zip,
                            CompressionOption::Normal);
                        array <Byte> ^fileBytes = File::ReadAllBytes(pathString);
                        packagePart->GetStream()->Write(fileBytes, 0, fileBytes->Length);
                        delete [] fileBytes;
                        delete partURI;
                    }                   // end of if (includeThisFile)
                }                       // end of else of if (pathInfo->Length > 26300000)
                delete pathInfo;
            }                           // end of if (pathString && ...)
        }                               // end of for each (String ^pathString in filesToZip)
        zipPackage->Close();
        delete zipPackage;
    }                                   // end of if (StringSet(filesToZip) && StringSet(zipFileName))
    RecordBasicEvent("{0} concluded", functionName);
}                                       // end of DTSTest_ZipFiles()
//----------------------------------------------------------------------------
// DTSTest_CalculatePercentage
//
// Calculates an integer (whole number) percentage
//
// Returns: The result of the integer percentage calculation
//----------------------------------------------------------------------------
    int
DTSTest_CalculatePercentage(
    DWORD           dividend,
    DWORD           divisor)
{
    int             quotient = 0;
    DWORD           holder;
    //------------------------------------------------------------------------
    if (dividend && divisor)
    {
        //--------------------------------------------------------------------
        // Multiply by 10 twice using the fast multiply
        //--------------------------------------------------------------------
        holder = Mult10(dividend);
        holder = Mult10(holder);
        //--------------------------------------------------------------------
        // perform the integer (div) division
        //--------------------------------------------------------------------
        quotient = (int) (holder / divisor);
    }
    return quotient;
}                                       // end of DTSTest_CalculatePercentage()
//----------------------------------------------------------------------------
// DTSTest_ConvertString
//
// Converts a String ^string to a char *string
//
// Returns unmanagedString
//----------------------------------------------------------------------------
    char *
DTSTest_ConvertString(
    String          ^managedString,
    char            *unmanagedString,
    size_t          unmanagedBufferSize)
{
    size_t          returnValue;
    //------------------------------------------------------------------------
    if (StringSet(managedString) && unmanagedString)
    {
        pin_ptr <const wchar_t> widePtr = PtrToStringChars(managedString);
        wcstombs_s(
            &returnValue,
            unmanagedString,
            unmanagedBufferSize,
            widePtr,
            ((wcslen(widePtr) >= unmanagedBufferSize) ? _TRUNCATE : wcslen(widePtr)));
    }
    return unmanagedString;
}                                       // end of DTSTest_ConvertString()
//----------------------------------------------------------------------------
// DTSTest_ModalMessage
//
// Displays a modal message, using variable arguments
//
// Note:    Because this function uses the String::Format method to format the
//          arguments into a single managed string, the calling convention
//          should look similar to
//
//          char    *unmanagedString = "Testing";
//          DWORD   status = DTSTEST_SUCCESS;
//          . . .
//          DTSTest_ModalMessage(
//              true,
//              MB_ICONINFORMATION,
//              "Modal Title",
//              "The function returned 0x{0:X8} for XD {1}",
//              status,
//              gcnew String(unmanagedString));
//
// Called by:   DTSTest_Main
//              DTSTest_SetCommandLineFlags
//----------------------------------------------------------------------------
    System::Windows::Forms::DialogResult
DTSTest_ModalMessage(
    bool            allow,
    DWORD           flag,
    String          ^titleString,
    String          ^formatString,
    ...array <Object ^>
                    ^parameters)
{
    System::Windows::Forms::DialogResult
                    result = System::Windows::Forms::DialogResult::OK;
    //------------------------------------------------------------------------
    if (allow && StringSet(titleString) && StringSet(formatString))
    {
        String ^formattedString = String::Format(formatString, parameters);
        MessageBoxIcon icon;
        switch (flag)
        {
            case GUI_MODAL_ICON_INFORMATION :                                   // 0x00000001
                icon = MessageBoxIcon::Information;
                break;
            case GUI_MODAL_ICON_WARNING :                                       // 0x00000002
                icon = MessageBoxIcon::Exclamation;
                break;
            case GUI_MODAL_ICON_ERROR :                                         // 0x00000003
                icon = MessageBoxIcon::Error;
                break;
            case GUI_MODAL_ICON_CRITICAL :                                      // 0x00000004
                icon = MessageBoxIcon::Stop;
                break;
            default :
                icon = MessageBoxIcon::None;
                break;
        }
        //--------------------------------------------------------------------
        // Create an invisible window, from which to force the modal window to
        // the forefront
        //--------------------------------------------------------------------
        Form ^invisibleWindow = gcnew Form;
        invisibleWindow->Size = Drawing::Size(1, 1);
        invisibleWindow->Location = Point(1, 1);
        invisibleWindow->Focus();
        invisibleWindow->BringToFront();
        invisibleWindow->TopMost = GUI_YES;
        if (invisibleWindow->CanSelect)
            invisibleWindow->Select();
        invisibleWindow->TopLevel = GUI_YES;
        invisibleWindow->Visible = GUI_NO;
        result = MessageBox::Show(
            invisibleWindow,
            formattedString,
            titleString,
            MessageBoxButtons::OK,
            icon);
        delete invisibleWindow;
    }
    return result;
}                                       // end of DTSTest_ModalMessage()
//----------------------------------------------------------------------------
// DTSTest_DisplayStackTrace
//
// Displays a stack trace
//----------------------------------------------------------------------------
    void
DTSTest_DisplayStackTrace(
    String          ^messageString)
{
    String          ^stack;
    //------------------------------------------------------------------------
    if (StringSet(messageString))
    {
        stack = String::Concat(
            messageString,
            Environment::NewLine,
            Environment::StackTrace);
    }
    else
    {
        stack = String::Concat(
            "Stack Trace:",
            Environment::StackTrace);
    }
    pin_ptr <const wchar_t> widePtr = PtrToStringChars(stack);
    MessageBoxEx(
        NULL,
        widePtr,
        _T("Stack Trace"),
        MB_OK | MB_SETFOREGROUND | MB_ICONINFORMATION, 0);
}                                       // end of DTSTest_DisplayStackTrace()
//----------------------------------------------------------------------------
// DTSTest_ItoA
//
// Converts an unsigned, non-negative 32-bit value into a base-10 string
//
// Returns: The array passed to the function
//
// Note:        The function itoa() is inadequate because it uses too many
//              high-level operations, resulting in excessive program delays
//----------------------------------------------------------------------------
    char *
DTSTest_ItoA(
    DWORD           value,
    char            *valueString)
{
    char            *out = valueString;
    char            *start = valueString;
    char            temp;
    DWORD           quotient = value;
    //------------------------------------------------------------------------
    do
    {
        *out++ = "0123456789ABCDEF"[quotient % 10];
        quotient /= 10;
    }
    while (quotient);

    *out-- = DTSTEST_CHAR_NULL;         // append a null character before stepping back
    while (start < out)
    {
        temp = *start;
        *start++ = *out;
        *out-- = temp;
    }
    return valueString;
}                                       // end of DTSTest_ItoA()
//----------------------------------------------------------------------------
// DTSTest_ItoX
//
// Converts an unsigned, non-negative 32-bit value into a base-16 string
//
// Returns: The array passed to the function
//----------------------------------------------------------------------------
    char *
DTSTest_ItoX(
    DWORD           value,
    char            *valueString)
{
    char            *out = valueString;
    char            *start = valueString;
    char            temp;
    DWORD           quotient = value;
    //------------------------------------------------------------------------
    do
    {
        *out++ = "0123456789ABCDEF"[quotient % 16];
        quotient >>= 4;
    }
    while (quotient);

    *out-- = DTSTEST_CHAR_NULL;         // append a null character before stepping back
    while (start < out)
    {
        temp = *start;
        *start++ = *out;
        *out-- = temp;
    }
    memmove((valueString + 2), valueString, (strlen(valueString) + 1));
    memcpy(valueString, "0x", 2);
    return valueString;
}                                       // end of DTSTest_ItoX()
//----------------------------------------------------------------------------
// DTSTest_PromptYesNoModal
//
// Displays a Yes / No modal with a single prompt line
//
// Returns: GUI_ACCEPT or GUI_CANCEL
//----------------------------------------------------------------------------
    bool
DTSTest_PromptYesNoModal(
    String          ^titleString,
    String          ^formatString,
    ...array <Object ^>
                    ^parameters)
{
    bool            modalResponse = GUI_NO; // defaults to a 'No' response
    int             response;
    //------------------------------------------------------------------------
    if (StringSet(formatString) && StringSet(titleString))
    {
        //--------------------------------------------------------------------
        // Convert String ^titleString into wchar_t *wideModalTitle
        //--------------------------------------------------------------------
        pin_ptr <const wchar_t> wideModalTitle = PtrToStringChars(titleString);
        //--------------------------------------------------------------------
        // Gather the arguments into String ^formattedString
        //--------------------------------------------------------------------
        String ^formattedString = String::Format(formatString, parameters);
        //--------------------------------------------------------------------
        // Convert String ^formattedString into wchar_t *wideModalMessage
        //--------------------------------------------------------------------
        pin_ptr <const wchar_t> wideModalMessage = PtrToStringChars(formattedString);
        response = MessageBoxExW(
            NULL,
            wideModalMessage,
            wideModalTitle,
            MB_YESNO | MB_TOPMOST | MB_ICONINFORMATION, 0);
        if ((response == IDOK) || (response == IDYES))
            modalResponse = GUI_YES;
        delete formattedString;
    }                                   // end of if (StringSet(formatString) && ...)
    return modalResponse;
}                                       // end of DTSTest_PromptYesNoModal()
//----------------------------------------------------------------------------
// DTSTest_StringContains
//
// Determines whether testString is a sub-string of sourceString, without
// regard to case
//----------------------------------------------------------------------------
    bool
DTSTest_StringContains(
    char            *sourceString,
    char            *testString)
{
    bool            stringFound = GUI_NO;
    char            *sourcePtr = sourceString;
    size_t          testStringLength;
    //------------------------------------------------------------------------
    if (sourceString && strlen(sourceString) && testString && strlen(testString))
    {
        testStringLength = strlen(testString);
        while (testStringLength <= strlen(sourcePtr))
        {
            if (_memicmp(sourcePtr++, testString, testStringLength) == 0)
            {
                stringFound = GUI_YES;
                break;
            }
        }
    }
    return stringFound;
}                                       // end of DTSTest_StringContains()
//----------------------------------------------------------------------------
// DTSTest_TimeElapsed
//
// Determines the amount of time that has elapsed in days, hours, minutes,
// seconds, and milliseconds from the total time in milliseconds elapsed
//----------------------------------------------------------------------------
    void
DTSTest_TimeElapsed(
    DWORD           lapsedTime,
    int             *lapsedDays,
    int             *lapsedHours,
    int             *lapsedMinutes,
    int             *lapsedSeconds,
    int             *lapsedMilliseconds)
{
    //------------------------------------------------------------------------
    *lapsedDays = 0;
    *lapsedHours = 0;
    *lapsedMinutes = 0;
    *lapsedSeconds = 0;
    while (lapsedTime >= 86400000)
    {
        (*lapsedDays)++;
        lapsedTime -= 86400000;
    }
    while (lapsedTime >= 3600000)
    {
        (*lapsedHours)++;
        lapsedTime -= 3600000;
    }
    while (lapsedTime >= 60000)
    {
        (*lapsedMinutes)++;
        lapsedTime -= 60000;
    }
    while (lapsedTime >= 1000)
    {
        (*lapsedSeconds)++;
        lapsedTime -= 1000;
    }
    *lapsedMilliseconds = lapsedTime;
}                                       // end of DTSTest_TimeElapsed()
//----------------------------------------------------------------------------
#endif      // UTILITY_CPP
//============================================================================
// End of Utility.cpp
//============================================================================
