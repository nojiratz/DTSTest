//============================================================================
// Tools.cpp
//
// DTSTest-specific tools used by GUI.cpp
//
// Copyright (C) 2014 - 2016 Quartzdyne, Inc.  All rights reserved.
//
// No part of this source code may be reproduced or transmitted in any form or
// by any means, electronic or mechanical, including photocopying, recording,
// or any information storage and retrieval system, without express written
// permission from Quartzdyne, Inc.  Further, no use of this source code is
// permitted in any form or means without a valid, written license agreement
// with Quartzdyne, Inc.  While every reasonable precaution has been taken in
// the preparation of this source code, Quartzdyne, Inc., assumes no
// responsibility for errors, omissions, or damages from the use of the source
// code contained herein.
//
// NEITHER QUARTZDYNE, INC., ANY MEMBER OF QUARTZDYNE, INC., NOR ANY PERSON OR
// ORGANIZATION ACTING ON BEHALF OF THEM MAKES ANY WARRANTY OR REPRESENTATION
// WHATSOEVER, EXPRESS OR IMPLIED, INCLUDING ANY WARRANTY OF MERCHANTABILITY
// OR FITNESS FOR ANY PURPOSE WITH RESPECT TO THE SOURCE CODE OR ASSUMES ANY
// LIABILITY WHATSOEVER WITH RESPECT TO ANY USE OF THE SOURCE CODE OR ANY
// PORTION THEREOF OR WITH RESPECT TO ANY DAMAGES THAT MAY RESULT FROM SUCH
// USE.
//
// Noji Ratzlaff
//
// See DTSTest.log for a complete history of all updates, changes, and revisions
// of this source and other files and policies regarding DTSTest software
//
// Updated 01-14-2016
//============================================================================
#include    "stdafx.h"
#ifndef     TOOLS_CPP
#define     TOOLS_CPP
#include    "Tools.h"
//----------------------------------------------------------------------------
// DTSTest_CommandDialogueAppendLine
//
// Appends the specified line string to the command dialogue box
//
// Called by:   DTSTest_ProcessCommandLine
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_CommandDialogueAppendLine(
    String          ^lineString)
{
    DateTime        dateTime = DateTime::Now;
    String          ^functionName = _T("DTSTest_CommandDialogueAppendLine");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0} called", functionName);
    if (StringSet(lineString))
    {
        String ^resultingString = lineString;
        if (DTSTest_PrependDateAndTime && !lineString->StartsWith(DTSTEST_STRING_POUND))
        {
            resultingString = String::Concat(
                String::Format("[ {0:D2}-{1:D2}-{2:D4} {3:D2}:{4:D2}:{5:D2}.{6:D3} ] ",
                    dateTime.Month,
                    dateTime.Day,
                    dateTime.Year,
                    dateTime.Hour,
                    dateTime.Minute,
                    dateTime.Second,
                    dateTime.Millisecond),
                    lineString);
            RecordVerboseEvent("    {0}", lineString);
        }
        if (DTSTest_TestingDisplayInCommandDialogue || !DTSTest_TestingRunning)
        {
            homeCommandDialogueBox->Text += resultingString;
            if (homeCommandDialogueBox->Text->Length < 128000)
            {
                homeCommandDialogueBox->Update();
                homeCommandDialogueBox->SelectionStart = homeCommandDialogueBox->Text->Length;
                homeCommandDialogueBox->ScrollToCaret();
            }
            else
            {
//                DTSTest_AppendLineToDataLog(homeCommandDialogueBox->Text);
                homeCommandDialogueBox->Clear();
                RecordBasicEvent("    {0} Command dialogue box cleared", functionName);
            }
        }                               // end of if (DTSTest_TestingDisplayInCommandDialogue || !DTSTest_TestingRunning)
        generalLogFileString += resultingString;
    }                                   // end of if (StringSet(lineString))
    RecordBasicEvent("{0} concluded", functionName);
}                                       // end of DTSTest_CommandDialogueAppendLine()
//----------------------------------------------------------------------------
// DTSTest_DetermineResultsLog
//
// Determines the next results log file, but does not create a new file
//
// Called by:   DTSTest_InitializeDTSTest
//              DTSTest_ScriptRunMainControlScriptThread
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_DetermineResultsLog(void)
{
    bool            fileNameIdentified = GUI_NO;
    bool            keepLooking = GUI_YES;
    int             logInstance = 1;
    String          ^fileString;
    String          ^pathString;
    String          ^topPathString;
    DateTime        dateTime = DateTime::Now;
    String          ^functionName = _T("DTSTest_DetermineResultsLog");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0} called", functionName);
    if (DTSTest_GeneralInfo)
    {
        if (StringSet(DTSTest_GeneralInfo->mainScript->resultsLogFilePath))
        {
            topPathString = String::Concat(
                Path::GetDirectoryName(DTSTest_GeneralInfo->mainScript->resultsLogFilePath),
                DTSTEST_STRING_BACKSLASH);
        }
        else
        {
            topPathString = String::Concat(DTSTest_GeneralInfo->logDirectory, DTSTEST_STRING_BACKSLASH);
        }
        while (keepLooking)
        {
            fileString = String::Format(
                "DTSTest-Results-{0:D2}{1:D2}{2:D2}-{3:D3}.log",
                (dateTime.Year % 100),
                dateTime.Month,
                dateTime.Day,
                logInstance);
            pathString = String::Concat(topPathString, fileString);
            if (File::Exists(pathString))
            {
                logInstance++;
            }
            else
            {
                keepLooking = GUI_NO;
                fileNameIdentified = GUI_YES;
            }
            if (logInstance >= 1000)
            {
                Modal("No more results logs could be created");
                keepLooking = fileNameIdentified = GUI_NO;
            }
        }                               // end of while (keepLooking)
        if (fileNameIdentified)
        {
            DTSTest_GeneralInfo->mainScript->resultsLogFilePath = pathString;
            if (homeResultsLogPathLabel)
            {
                homeResultsLogPathLabel->Text = String::Concat(
                    _T("Results log: "),
                    DTSTest_GeneralInfo->mainScript->resultsLogFilePath);
                testingResultsLogPathLabel->Text = String::Concat(
                    _T("Test results: "),
                    DTSTest_GeneralInfo->mainScript->resultsLogFilePath);
            }
        }
    }
    RecordBasicEvent("{0} concluded", functionName);
}                                       // end of DTSTest_DetermineResultsLog()
//----------------------------------------------------------------------------
// DTSTest_ProcessCommandLine
//
// Processes the specified command string
//
// Called by:   DTSTest_HomeSingleCommandSendButtonClicked
//              DTSTest_HomeTextBoxAcceptEnterKey
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_ProcessCommandLine(
    String          ^commandLineString,
    bool            testingContext)
{
    String          ^functionName = _T("DTSTest_ProcessCommandLine");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0} called", functionName);
    DTSTest_ScriptProcessLine(
        commandLineString,
        testingContext);
    RecordBasicEvent("{0} concluded", functionName);
}                                       // end of DTSTest_ProcessCommandLine()
//----------------------------------------------------------------------------
// DTSTest_ReturnScriptCommandInterpretationString
//
// Returns a string interpretation of the specified script command string
//
// Called by:   DTSTest_ScriptProcessLine
//----------------------------------------------------------------------------
    String ^ DTSTest_GUIClass::
DTSTest_ReturnScriptCommandInterpretationString(
    String          ^scriptCommandString,
    bool            testingContext)
{
    bool            verboseMessages = GUI_NO;
    String          ^interpretationString = String::Empty;
    String          ^functionName = _T("DTSTest_ReturnScriptCommandInterpretationString");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0} called", functionName);
    if (DTSTest_GeneralInfo->flags & DTSTEST_GENERAL_VERBOSE_LOG_MESSAGES)
        verboseMessages = GUI_YES;
    //------------------------------------------------------------------------
    // Remove the leading and trailing white spaces
    //------------------------------------------------------------------------
    scriptCommandString = scriptCommandString->Trim();
    //------------------------------------------------------------------------
    // Begin parsing the command string
    //------------------------------------------------------------------------
    if (scriptCommandString->Length)
    {
        RecordVerboseEvent("    Processing '{0}'", scriptCommandString);
        //--------------------------------------------------------------------
        // Parse the command string
        //--------------------------------------------------------------------
        if (scriptCommandString->Contains(DTSTEST_STRING_QUESTION) ||
            scriptCommandString->ToUpper()->Contains(_T("HELP")))
        {
            //----------------------------------------------------------------
            // The help commands override all other commands, so proccess them
            // instead of any actual specified command
            //----------------------------------------------------------------
            PDGICInfo ^pgInfo = DTSTest_GeneralInfo->pgInfo;
            interpretationString += String::Concat(
                _T("    Scripting shortcut commands:"), Environment::NewLine,
                _T("        ###[:]      delay for ### ms before continuing (':' needed only if followed by a command)"), Environment::NewLine,
                _T("        BR:[rate]   switch baud rate (to optional 'rate')"), Environment::NewLine,
                _T("        CN:         calculate CRCs ON"), Environment::NewLine,
                _T("        CF:         calculate CRCs OFF"), Environment::NewLine,
                _T("        NN:         normalize measurements ON"), Environment::NewLine,
                _T("        NF:         normalize measurements OFF"), Environment::NewLine,
                _T("        PS:[text]   pause script (with optional 'text' prompt) until OK is clicked"), Environment::NewLine,
                _T("        ? or HELP   this help text"), Environment::NewLine);
            interpretationString += DTSTest_PDGICReturnDeviceInformationString(pgInfo);
        }
        else
        {
            if (scriptCommandString->Contains(DTSTEST_STRING_COLON))
            {
                //------------------------------------------------------------
                // The delay, if any, was removed by
                // DTSTest_ScriptParseLineForCommandString, so test for a
                // valid directive
                //------------------------------------------------------------
                array <Char> ^colonDelimiter = gcnew array <Char> {DTSTEST_CHAR_COLON};
                array <String ^> ^colonlessStrings = scriptCommandString->Split(
                    colonDelimiter,
                    StringSplitOptions::RemoveEmptyEntries);
                String ^directiveString = colonlessStrings[0]->Trim();
                if (directiveString->StartsWith(_T("BR"), StringComparison::OrdinalIgnoreCase) ||
                    directiveString->StartsWith(_T("CF"), StringComparison::OrdinalIgnoreCase) ||
                    directiveString->StartsWith(_T("CN"), StringComparison::OrdinalIgnoreCase) ||
                    directiveString->StartsWith(_T("NF"), StringComparison::OrdinalIgnoreCase) ||
                    directiveString->StartsWith(_T("NN"), StringComparison::OrdinalIgnoreCase) ||
                    directiveString->StartsWith(_T("PS"), StringComparison::OrdinalIgnoreCase) ||
                    directiveString->StartsWith(_T("VS"), StringComparison::OrdinalIgnoreCase))
                {
                    String ^directiveModifierString = String::Empty;
                    if (colonlessStrings->Length > 1)
                    {
                        //----------------------------------------------------
                        // Directive modifier specified
                        //----------------------------------------------------
                        directiveModifierString = colonlessStrings[1]->Trim();
                    }
                    if (directiveString->StartsWith(_T("BR"), StringComparison::OrdinalIgnoreCase))
                    {
                        interpretationString += DTSTest_ScriptProcessBaudRateChangeString(
                            scriptCommandString);
                    }
                    if (directiveString->StartsWith(_T("CF"), StringComparison::OrdinalIgnoreCase))
                    {
                        //----------------------------------------------------
                        // Turn off automatic CRC calculations
                        //----------------------------------------------------
                        DTSTest_SetCalculateCRCs(GUI_NO);
                        interpretationString += _T("    => CRC calculation turned off");
                        generalCSVEntry->loggedCSVInterpretationString = _T("CRC calculation disabled");
                    }
                    if (directiveString->StartsWith(_T("CN"), StringComparison::OrdinalIgnoreCase))
                    {
                        //----------------------------------------------------
                        // Turn on automatic CRC calculations
                        //----------------------------------------------------
                        DTSTest_SetCalculateCRCs(GUI_YES);
                        interpretationString += _T("    => CRC calculation turned on");
                        generalCSVEntry->loggedCSVInterpretationString = _T("CRC calculation enabled");
                    }
                    if (directiveString->StartsWith(_T("NF"), StringComparison::OrdinalIgnoreCase))
                    {
                        //----------------------------------------------------
                        // Turn off measurement normalization
                        //----------------------------------------------------
                        DTSTest_SetNormalizeMeasurements(GUI_NO);
                        interpretationString += _T("    => pressure and temperature normalization turned off");
                        generalCSVEntry->loggedCSVInterpretationString = _T("measurement normalization disabled");
                    }
                    if (directiveString->StartsWith(_T("NN"), StringComparison::OrdinalIgnoreCase))
                    {
                        //----------------------------------------------------
                        // Turn on measurement normalization
                        //----------------------------------------------------
                        DTSTest_SetNormalizeMeasurements(GUI_YES);
                        interpretationString += _T("    => pressure and temperature normalization turned on");
                        generalCSVEntry->loggedCSVInterpretationString = _T("measurement normalization enabled");
                    }
                    if (directiveString->StartsWith(_T("PS"), StringComparison::OrdinalIgnoreCase))
                    {
                        //--------------------------------------------------------
                        // Pause the script
                        //--------------------------------------------------------
                        String ^promptText = directiveModifierString;
                        if (!StringSet(promptText))
                        {
                            promptText = _T("Click OK to continue");
                        }
                        DateTime dateTime = DateTime::Now;
                        interpretationString += String::Format("    => Script paused at  {0:D2}-{1:D2}-{2:D4} {3:D2}:{4:D2}:{5:D2}",
                            dateTime.Month,
                            dateTime.Day,
                            dateTime.Year,
                            dateTime.Hour,
                            dateTime.Minute,
                            dateTime.Second);
                        DTSTest_PromptOKModal(
                            _T("Script Paused"),
                            promptText);
                        dateTime = DateTime::Now;
                        interpretationString += String::Concat(
                            Environment::NewLine,
                            String::Format("    => Script resumed at {0:D2}-{1:D2}-{2:D4} {3:D2}:{4:D2}:{5:D2}",
                                dateTime.Month,
                                dateTime.Day,
                                dateTime.Year,
                                dateTime.Hour,
                                dateTime.Minute,
                                dateTime.Second));
                    }                   // end of if (directiveString->StartsWith(_T("PS"), ...))
                    if (directiveString->StartsWith(_T("VS"), StringComparison::OrdinalIgnoreCase))
                    {
                        //----------------------------------------------------
                        // Set the script interpreter version
                        //----------------------------------------------------
                        if (StringSet(directiveModifierString))
                        {
                            int scriptVersion = 0;
                            bool isDecimalInteger = DTSTest_ParseAndConvertStringToInteger(
                                directiveModifierString,
                                &scriptVersion);
                            if (isDecimalInteger)
                                interpretationString += String::Concat(
                                    _T("    => Running script interpreter version "),
                                    scriptVersion);
                            generalCSVEntry->loggedCSVInterpretationString = _T("Version 2 script");
                        }
                    }                   // end of if (directiveString->StartsWith(_T("VS"), ...))
                }
                else
                {
                    //--------------------------------------------------------
                    // Invalid directive specified
                    //--------------------------------------------------------
                    DTSTest_PromptOKModal(
                        "Invalid Directive",
                        "'{0}' is not recognized",
                        directiveString);
                    generalCSVEntry->loggedCSVInterpretationString = _T("Invalid directive");
                }
                delete [] colonlessStrings;
                delete [] colonDelimiter;
            }                           // end of if (scriptCommandString->Contains(DTSTEST_STRING_COLON))
            else
            {
                String ^translatedString = DTSTest_ScriptTranslateCommandString(
                    scriptCommandString,
                    testingContext);
                //------------------------------------------------------------
                // At this point the CRC has been calculated and appended
                //------------------------------------------------------------
                if (StringSet(translatedString) && !translatedString->Contains("=>"))
                {
                    array <Char> ^commandDelimiters = gcnew array <Char> {DTSTEST_CHAR_SPACE};
                    array <String ^> ^spacelessStrings = translatedString->Split(
                        commandDelimiters,
                        StringSplitOptions::RemoveEmptyEntries);
                    int numberOfBytesToSend = spacelessStrings->Length;
                    if (numberOfBytesToSend > 1)
                    {
                        array <unsigned char> ^commandArray = gcnew array <unsigned char>(PDGIC_MODBUS_MAXIMUM_COMMAND_LENGTH);
                        for (int offset = 0; offset < numberOfBytesToSend; offset++)
                        {
                            if (StringSet(spacelessStrings[offset]) && (spacelessStrings[offset]->Length == 2))
                                commandArray[offset] =
                                    (AtoX(spacelessStrings[offset][0]) << 4) | AtoX(spacelessStrings[offset][1]);
                        }
                        if (!DTSTest_DemoModeEnabled)
                        {
                            if (verboseMessages)
                            {
                                interpretationString += String::Concat(
//                                    Environment::NewLine,
                                    "    => sending ",
                                    numberOfBytesToSend,
                                    " bytes :");
                                String ^inputLineString = String::Empty;
                                for (int count = 0; count < numberOfBytesToSend; count++)
                                {
                                    inputLineString += String::Format(" {0:X2}", commandArray[count]);
                                }
                                interpretationString += inputLineString;
                            }
                            //------------------------------------------------
                            // Send the command to be executed
                            //------------------------------------------------
                            interpretationString += DTSTest_SendCommandArray(
                                commandArray,
                                numberOfBytesToSend,
                                testingContext);
                        }
                        delete [] commandArray;
                    }                   // end of if (numberOfBytesToSend > 1)
                    delete [] spacelessStrings;
                    delete [] commandDelimiters;
                }                       // end of if (StringSet(translatedString) && !translatedString->Contains("=>"))
                else
                {
                    if (translatedString->Contains("=>"))
                        interpretationString += translatedString;
                }
            }
        }                               // end of else of if (scriptCommandString->Contains(DTSTEST_STRING_QUESTION) || ...)
    }                                   // end of if (scriptCommandString->Length)
    else
    {
        RecordBasicEvent("    Command string is empty");
    }
    RecordBasicEvent("{0} concluded", functionName);
    return interpretationString;
}                                       // end of DTSTest_ReturnScriptCommandInterpretationString()
//----------------------------------------------------------------------------
// DTSTest_SendCommandArray
//
// Sends the specified MODBUS character array to the device and returns the
// equivalent response string
//
// Called by:   DTSTest_ReturnScriptCommandInterpretationString
//----------------------------------------------------------------------------
    String ^ DTSTest_GUIClass::
DTSTest_SendCommandArray(
    array <unsigned char>
                    ^commandArray,
    int             numberOfBytesToSend,
    bool            testingContext)
{
    bool            coefficientDataLoaded = GUI_NO;
    bool            failureEncountered = GUI_NO;
    bool            failureException = GUI_NO;
    bool            noDataReturned = GUI_NO;
    bool            targetIsGauge = GUI_NO;
    bool            verboseMessages = GUI_NO;
    DWORD           status = DTSTEST_SUCCESS;
    BYTE            *coefficientData;
    String          ^errorString = String::Empty;
    String          ^replyDataString = String::Empty;
    String          ^replyString = String::Empty;
    String          ^resultString = String::Empty;
    String          ^functionName = _T("DTSTest_SendCommandArray");
    //------------------------------------------------------------------------
    RecordDetailedEvent("{0} called", functionName);
    if (DTSTest_GeneralInfo->flags & DTSTEST_GENERAL_VERBOSE_LOG_MESSAGES)
        verboseMessages = GUI_YES;
    if (commandArray && commandArray->Length && numberOfBytesToSend)
    {
        if (DTSTest_GeneralInfo->pgInfo)
        {
            PDGICInfo ^pgInfo = DTSTest_GeneralInfo->pgInfo;
            BYTE nodeAddress = commandArray[0];
            pgInfo->nodeAddress = nodeAddress;
            SensorInfo ^sensor = pgInfo->sensorInfoArray[nodeAddress];
            if (sensor->sensorType == DTSTEST_SENSOR_TYPE_UNKNOWN)
            {
                status = DTSTest_SensorRetrieveType(sensor);
                if (status == DTSTEST_SUCCESS)
                {
                    DWORD sensorType = sensor->sensorType;
                    coefficientData = (LPBYTE) sensor->coefficientInfo->coefficientData;
                    memcpy_s(
                        (void *) coefficientData,
                        sizeof(CoefficientDataFormat),
                        (void *) DTSTest_GeneralInfo->defaultCoefficientInfo->coefficientData,
                        sizeof(CoefficientDataFormat));
                    sensor->coefficientInfo->coefficientDataLoaded = GUI_YES;
                }
            }
            else
            {
                coefficientData = (LPBYTE) sensor->coefficientInfo->coefficientData;
                if (sensor->sensorType & DTSTEST_SENSOR_TYPE_GAUGE)
                    targetIsGauge = GUI_YES;
            }
            generalCSVEntry->loggedCSVHardwareIDString = sensor->hardwareIDString;
            coefficientDataLoaded = GUI_YES;
            //----------------------------------------------------------------
            // Locate the applicable test entry, if any
            //----------------------------------------------------------------
            TestEntry ^testEntry = DTSTest_TestEntryArray[DTSTest_CurrentEntryNumber];
            if (testEntry->entryTestResults != DTSTEST_TEST_RESULT_FAILED)
                testEntry->entryTestResults = DTSTEST_TEST_RESULT_PASSED;
            //----------------------------------------------------------------
            // Copy the command bytes to the PDGIC structure
            //----------------------------------------------------------------
            pgInfo->numberOfCommandBytes = numberOfBytesToSend;
            String ^commandString = String::Empty;
            for (int index = 0; index < numberOfBytesToSend; index++)
            {
                pgInfo->commandArray[index] = commandArray[index];
                commandString += String::Format(
                    "{0}{1:X2}",
                    (index ? DTSTEST_STRING_SPACE : String::Empty),
                    commandArray[index]);
            }
            generalCSVEntry->loggedCSVSentString = commandString;
            BYTE functionCode = pgInfo->commandArray[1];
            String ^nodeAddressString = String::Format("{0:X2}", nodeAddress);
            generalCSVEntry->loggedCSVAddressString = nodeAddressString;
            switch (functionCode)
            {
                case MODBUS_COMMAND_REPORT_SLAVE_ID :                           // 0x11
                    break;
                case MODBUS_COMMAND_READ_HOLDING_REGISTERS :                    // 0x03
                case MODBUS_COMMAND_READ_INPUT_REGISTERS :                      // 0x04
                case MODBUS_COMMAND_WRITE_MULTIPLE_COILS :                      // 0x0F
                    pgInfo->startingRegisterOffset = (pgInfo->commandArray[2] << 8) | pgInfo->commandArray[3];
                    pgInfo->numberOfRegistersToTransfer = (pgInfo->commandArray[4] << 8) | pgInfo->commandArray[5];
                    break;
                case MODBUS_COMMAND_WRITE_SINGLE_REGISTER :                     // 0x06
                    if (nodeAddress == DTSTEST_SENSOR_ADDRESS_BROADCAST)        // 0xFE
                    {
                        switch (pgInfo->commandArray[3])
                        {
                            case 0x02 :
                            case 0x03 :
                                {
                                    //----------------------------------------
                                    // Set the gauge baud rate
                                    //----------------------------------------
                                    String ^directionString = String::Empty;
                                    switch (pgInfo->commandArray[5])
                                    {
                                        case 0x2E : pgInfo->writeData = 1200; directionString = _T("Rx");
                                            break;
                                        case 0xED : pgInfo->writeData = 1200; directionString = _T("Tx");
                                            break;
                                        case 0x16 :
                                        case 0x17 : pgInfo->writeData = 2400; directionString = _T("Rx");
                                            break;
                                        case 0x76 : pgInfo->writeData = 2400; directionString = _T("Tx");
                                            break;
                                        case 0x0B : pgInfo->writeData = 4800; directionString = _T("Rx");
                                            break;
                                        case 0xBB : pgInfo->writeData = 4800; directionString = _T("Tx");
                                            break;
                                        default : pgInfo->writeData = 0;
                                            break;
                                    }
                                    if (pgInfo->writeData && verboseMessages)
                                    {
                                        replyString += String::Concat(
                                            Environment::NewLine,
                                            String::Format(
                                                "    => will attempt to change gauge {0} {1} baud rate to {2:D} baud",
                                                nodeAddressString, directionString, pgInfo->writeData));
                                    }
                                }
                                break;
                            case 0x0B :
                                //--------------------------------------------
                                // Set the barge baud rate
                                //--------------------------------------------
                                switch (pgInfo->commandArray[5])
                                {
                                    case 0 : pgInfo->writeData = 600;
                                        break;
                                    case 1 : pgInfo->writeData = 1200;
                                        break;
                                    case 2 : pgInfo->writeData = 2400;
                                        break;
                                    case 3 : pgInfo->writeData = 4800;
                                        break;
                                    default : pgInfo->writeData = 0;
                                        break;
                                }
                                if (pgInfo->writeData && verboseMessages)
                                {
                                    String ^whichBarges = (nodeAddress == DTSTEST_EXPERIMENTAL_ALL_BARGES_VALUE) ? "all barges" : String::Concat("barge ", nodeAddressString);
                                    replyString += String::Concat(
                                        Environment::NewLine,
                                        "    => attempting to change ",
                                        whichBarges,
                                        " to ",
                                        pgInfo->writeData,
                                        " baud");
                                }
                                break;
                            default :
                                break;
                        }               // end of switch (pgInfo->commandArray[3])
                    }
                    else
                    {
                        RecordBasicEvent("    {0} : Encountered illegal command '0x{1:X2} 0x{2:X2}'",
                            functionName,
                            nodeAddress, functionCode);
                        generalCSVEntry->loggedCSVInterpretationString = _T("Invalid command");
                    }
                    break;
                default :
                    //--------------------------------------------------------
                    // Illegal command, but let it go; only log it, so that
                    // the software can determine further error granularity
                    //--------------------------------------------------------
//                    failureEncountered = GUI_YES;
                    RecordBasicEvent("    {0} : Encountered illegal command '0x{1:X2}'",
                        functionName,
                        functionCode);
//                    generalCSVEntry->loggedCSVInterpretationString = _T("Invalid command");
                    break;
            }                           // end of switch (functionCode)
            //----------------------------------------------------------------
            // Execute the command
            //----------------------------------------------------------------
            status = DTSTest_PDGICSendRawCommand(pgInfo);
            if (verboseMessages)
            {
                if (pgInfo->numberOfBytesRead)
                {
                    for (int count = 0; count < pgInfo->numberOfBytesRead; count++)
                        replyDataString += String::Format(" {0:X2}", pgInfo->responseArray[count]);
                    replyString += String::Concat(
                        Environment::NewLine,
                        _T("    => returned"),
                        replyDataString);
                }
                else
                {
                    noDataReturned = GUI_YES;
                    replyDataString = _T("no data returned");
                    replyString += String::Concat(
                        Environment::NewLine,
                        _T("    => "),
                        replyDataString);
                    generalCSVEntry->loggedCSVInterpretationString = _T("No data");
                }
                if (!StringSet(generalCSVEntry->loggedCSVReplyString))
                    generalCSVEntry->loggedCSVReplyString = replyDataString;
                replyString += Environment::NewLine;
            }                           // end of if (verboseMessages)
            if (DTSTest_PDGICSuccessfulReply && (status == DTSTEST_SUCCESS))
            {
                if (nodeAddress != DTSTEST_EXPERIMENTAL_ALL_BARGES_VALUE)
                    sensor->sensorPresent = GUI_YES;
                //------------------------------------------------------------
                // Snoop on the command, to help determine the response string
                //------------------------------------------------------------
                WORD memoryAddress = (WORD) (pgInfo->commandArray[2] << 8) | pgInfo->commandArray[3];
                WORD wordsRequested = (WORD) (pgInfo->commandArray[4] << 8) | pgInfo->commandArray[5];
                WORD outputValue = wordsRequested;
                WORD dataWord = wordsRequested;
                WORD registerQuantity = wordsRequested;
                BYTE replyByteCount = pgInfo->responseArray[2];
                WORD replyWordCount = (WORD) (replyByteCount / 2);
                if ((pgInfo->responseArray[1] & 0x80) == 0x80)
                {
                    String ^errorCodeString = String::Format(
                        "{0:X2} {1:X2}", pgInfo->responseArray[1], pgInfo->responseArray[2]);
                    //--------------------------------------------------------
                    // Error response
                    //--------------------------------------------------------
                    errorString += _T("    !!! ");
                    switch (pgInfo->responseArray[2])
                    {
                        case 0x01 :
                            errorString += String::Format(
                                "Function code 0x{0:X2} not supported",
                                functionCode);
                            generalCSVEntry->loggedCSVInterpretationString = _T("Not implemented");
                            break;
                        case 0x02 :
                            switch (pgInfo->responseArray[1])
                            {
                                case 0x81 :
                                case 0x82 :
                                case 0x83 :
                                case 0x84 :
                                case 0x8F :
                                case 0x90 :
                                    errorString += String::Format(
                                        "Invalid starting address 0x{0:X4} or register quantity 0x{1:X4}",
                                        memoryAddress, wordsRequested);
                                    generalCSVEntry->loggedCSVInterpretationString = _T("Range error");
                                    break;
                                case 0x85 :
                                case 0x86 :
                                    errorString += String::Format(
                                        "Invalid starting address 0x{0:X4}",
                                        memoryAddress);
                                    generalCSVEntry->loggedCSVInterpretationString = _T("Range error");
                                    break;
                                case 0x88 :
                                    errorString += _T("Invalid data value");
                                    generalCSVEntry->loggedCSVInterpretationString = errorString;
                                    break;
                                default :
                                    errorString += String::Format(
                                        "Unknown error code 0x{0:X2}",
                                        pgInfo->responseArray[1]);
                                    generalCSVEntry->loggedCSVInterpretationString = _T("Unknown error");
                                    break;
                            }           // end of switch (pgInfo->responseArray[1])
                            break;
                        case 0x03 :
                            switch (pgInfo->responseArray[1])
                            {
                                case 0x81 :
                                case 0x82 :
                                case 0x83 :
                                case 0x84 :
                                    errorString += String::Format(
                                        "Invalid register quantity 0x{0:X4}; must be 0x0001 through 0x007D",
                                        wordsRequested);
                                    generalCSVEntry->loggedCSVInterpretationString = _T("Range error");
                                    break;
                                case 0x85 :
                                    errorString += String::Format(
                                        "Invalid output value 0x{0:X4}; must be 0x0000 or 0xFF00",
                                        outputValue);
                                    generalCSVEntry->loggedCSVInterpretationString = _T("Range error");
                                    break;
                                case 0x86 :
                                    errorString += String::Format(
                                        "Invalid register value 0x{0:X4}; must be 0x0000 through 0xFFFF",
                                        outputValue);
                                    generalCSVEntry->loggedCSVInterpretationString = _T("Range error");
                                    break;
                                case 0x88 :
                                    errorString += String::Format(
                                        "Sub-function code {0:X2} {1:X2} returned",
                                        pgInfo->commandArray[2], pgInfo->commandArray[3]);
                                    generalCSVEntry->loggedCSVInterpretationString = _T("Unknown error");
                                    break;
                                case 0x8F :
                                    errorString += String::Format(
                                        "Invalid quantity 0x{0:X4} (must be 0x0001 through 0x07B0) or invalid byte count 0x{1:X2}",
                                        registerQuantity, pgInfo->commandArray[6]);
                                    generalCSVEntry->loggedCSVInterpretationString = _T("Range error");
                                    break;
                                case 0x90 :
                                    errorString += String::Format(
                                        "Invalid quantity 0x{0:X4} (must be 0x0001 through 0x007B) or invalid byte count 0x{1:X2}",
                                        registerQuantity, pgInfo->commandArray[6]);
                                    generalCSVEntry->loggedCSVInterpretationString = _T("Range error");
                                    break;
                                default :
                                    errorString += String::Format(
                                        "Invalid register quantity 0x{0:X4} requested",
                                        wordsRequested);
                                    generalCSVEntry->loggedCSVInterpretationString = _T("Range error");
                                    break;
                            }   // end of switch (pgInfo->responseArray[1])
                            break;
                        case 0x04 :
                            if (functionCode == 0x88)
                                errorString += _T("Diagnostic failed");
                            else
                                errorString += _T("General failure");
                            generalCSVEntry->loggedCSVInterpretationString = errorString;
                            break;
                        default :
                            errorString += String::Format(
                                "Unknown error exception code 0x{0:X2}",
                                pgInfo->responseArray[2]);
                            generalCSVEntry->loggedCSVInterpretationString = _T("Unknown error");
                            break;
                    }                   // end of switch (pgInfo->responseArray[2])
                    if (StringICompare(errorCodeString, generalCSVEntry->loggedCSVExpectedString))
                        failureEncountered = GUI_YES;
                    generalCSVEntry->loggedCSVErrorString = errorString;
                }                       // end of if ((pgInfo->responseArray[1] & 0x80) == 0x80)
                else
                {
                    //--------------------------------------------------------
                    // Normal response
                    //--------------------------------------------------------
                    int baudRate = 0;
                    switch (functionCode)
                    {
                        case MODBUS_COMMAND_REPORT_SLAVE_ID :                   // 0x11
                            {
                                switch (pgInfo->responseArray[3])
                                {
                                    case DTSTEST_EXPERIMENTAL_GAUGE_2D_VALUE :
                                    case DTSTEST_EXPERIMENTAL_GAUGE_3E_VALUE :
                                        targetIsGauge = GUI_YES;
                                        break;
                                    case DTSTEST_EXPERIMENTAL_BARGE_B4_VALUE :
                                    case DTSTEST_EXPERIMENTAL_BARGE_C9_VALUE :
                                    case DTSTEST_EXPERIMENTAL_BARGE_E2_VALUE :
                                        targetIsGauge = GUI_NO;
                                        break;
                                    default :
//                                        targetIsGauge = GUI_NO;
                                        break;
                                }
                                String ^identifyString = String::Empty;
                                if ((pgInfo->responseArray[4] == 0xFF) && (pgInfo->responseArray[3] != 0x00))
                                {
                                    identifyString += String::Format(
                                        "    {0} successfully identified at address 0x{1:X2}",
                                        (targetIsGauge ? "ROC-X Gauge" : "DTS / DPS"),
                                        pgInfo->responseArray[3]);
                                    generalCSVEntry->loggedCSVInterpretationString = identifyString;
                                }
                                else
                                {
                                    identifyString += _T("    No device identified (possibly multiple devices present)");
                                    failureEncountered = GUI_YES;
                                    generalCSVEntry->loggedCSVErrorString = identifyString;
                                }
                                replyString += identifyString;
                            }
                            break;
                        case MODBUS_COMMAND_READ_HOLDING_REGISTERS :            // 0x03
                        case MODBUS_COMMAND_READ_INPUT_REGISTERS :              // 0x04
                            if (replyWordCount)
                            {
                                String ^titleString = String::Empty;
                                String ^bargeResultString = String::Empty;
                                String ^gaugeResultString = String::Empty;
                                int numberOfPrefixWords = 0;
                                WORD prefixWordsOffset = DTSTEST_REPLY_HEADER_BYTES;
                                int remainingBytesOffset = DTSTEST_REPLY_HEADER_BYTES;
                                WORD numberOfRemainingWords = replyWordCount;
                                BYTE numberOfRemainingBytes = replyByteCount;
                                WORD remainingBytesAddress = memoryAddress;
                                if (pgInfo->responseArray[1] == MODBUS_COMMAND_READ_INPUT_REGISTERS)
                                {
                                    String ^pressureValueString = String::Empty;
                                    String ^temperatureValueString = String::Empty;
                                    //----------------------------------------
                                    // Read Input Registers
                                    //----------------------------------------
                                    int statusOffset = 0;
                                    int chipIDOffset = 0;
                                    int pressureOffset = 0;
                                    int temperatureOffset = 0;
                                    int ADC1Offset = 0;
                                    int ADC2Offset = 0;
                                    int OTP1Offset = 0;
                                    int OTP2Offset = 0;
                                    if (targetIsGauge)
                                    {
                                        bool readAndDisplayGaugePressure = GUI_NO;
                                        bool readAndDisplayGaugeTemperature = GUI_NO;
                                        bool readAndDisplayGaugeADC0 = GUI_NO;
                                        bool readAndDisplayGaugeADC1 = GUI_NO;
                                        bool readAndDisplayGaugeADC2 = GUI_NO;
                                        bool readAndDisplayGaugeADC3 = GUI_NO;
                                        bool readAndDisplayGaugeStatus0 = GUI_NO;
                                        bool readAndDisplayGaugeStatus1 = GUI_NO;
                                        bool readAndDisplayGaugeType0 = GUI_NO;
                                        bool readAndDisplayGaugeType1 = GUI_NO;
                                        bool readAndDisplayGaugeVersion0 = GUI_NO;
                                        bool readAndDisplayGaugeVersion1 = GUI_NO;
                                        bool readAndDisplayGaugeHR0 = GUI_NO;
                                        bool readAndDisplayGaugeHR1 = GUI_NO;
                                        bool readAndDisplayGaugeHR2 = GUI_NO;
                                        bool readAndDisplayGaugeHR3 = GUI_NO;
                                        bool readAndDisplayGaugeFlags = GUI_NO;
                                        bool readAndDisplayGaugeVendorPrefix = GUI_NO;
                                        bool readAndDisplayGaugeVendor = GUI_NO;
                                        bool readAndDisplayGaugeDocumentPrefix = GUI_NO;
                                        bool readAndDisplayGaugeDocument = GUI_NO;
                                        bool readAndDisplayGaugeRevisionPrefix = GUI_NO;
                                        bool readAndDisplayGaugeRevision = GUI_NO;
                                        int ADCOffset = 0;
                                        int flagsOffset = 0;
                                        int typeOffset = 0;
                                        int versionOffset = 0;
                                        int holdingRegisterOffset = 0;
                                        int vendorOffset = 0;
                                        int vendorPrefixOffset = 0;
                                        int documentOffset = 0;
                                        int documentPrefixOffset = 0;
                                        int revisionOffset = 0;
                                        int revisionPrefixOffset = 0;
                                        WORD numberOfVendorWords = 0;
                                        //------------------------------------
                                        // Read from the gauge registers
                                        //------------------------------------
                                        if (numberOfRemainingBytes)
                                        {
                                            if ((memoryAddress <= DTSTEST_GAUGE_PRESSURE_ADDRESS) &&
                                                (wordsRequested >= (DTSTEST_GAUGE_PRESSURE_ADDRESS - memoryAddress + DTSTEST_GAUGE_PRESSURE_WORDS)))
                                            {
                                                //--------------------------------
                                                // Gauge pressure - addr 0000
                                                //--------------------------------
                                                readAndDisplayGaugePressure = GUI_YES;
                                                pressureOffset = remainingBytesOffset;
                                                remainingBytesAddress += DTSTEST_GAUGE_PRESSURE_WORDS;
                                                remainingBytesOffset += DTSTEST_GAUGE_PRESSURE_BYTES;
                                                numberOfRemainingBytes -= DTSTEST_GAUGE_PRESSURE_BYTES;
                                            }
                                        }
                                        String ^addr01String = String::Empty;
                                        if (numberOfRemainingBytes)
                                        {
                                            if (memoryAddress == (DTSTEST_GAUGE_PRESSURE_ADDRESS + 1))
                                            {
                                                int addr01Offset = remainingBytesOffset;
                                                addr01String = String::Concat(
                                                    Environment::NewLine,
                                                    "        1 word at gauge memory address ",
                                                    String::Format("{0:D2}", memoryAddress),
                                                    " : ",
                                                    String::Format("0x{0:X4}",
                                                        ((pgInfo->responseArray[addr01Offset] << 8) | pgInfo->responseArray[addr01Offset + 1])));
                                                remainingBytesAddress += 1;
                                                remainingBytesOffset += 2;
                                                numberOfRemainingBytes -= 2;
                                            }
                                        }
                                        if (numberOfRemainingBytes)
                                        {
                                            if ((memoryAddress <= DTSTEST_GAUGE_TEMPERATURE_ADDRESS) &&
                                                (wordsRequested >= (DTSTEST_GAUGE_TEMPERATURE_ADDRESS - memoryAddress + DTSTEST_GAUGE_TEMPERATURE_WORDS)))
                                            {
                                                //--------------------------------
                                                // Gauge temperature - addr 0002
                                                //--------------------------------
                                                readAndDisplayGaugeTemperature = GUI_YES;
                                                temperatureOffset = remainingBytesOffset;
                                                remainingBytesAddress += DTSTEST_GAUGE_TEMPERATURE_WORDS;
                                                remainingBytesOffset += DTSTEST_GAUGE_TEMPERATURE_BYTES;
                                                numberOfRemainingBytes -= DTSTEST_GAUGE_TEMPERATURE_BYTES;
                                            }
                                        }
                                        String ^addr03String = String::Empty;
                                        if (numberOfRemainingBytes)
                                        {
                                            if ((remainingBytesAddress > DTSTEST_GAUGE_TEMPERATURE_ADDRESS) &&
                                                (remainingBytesAddress < DTSTEST_GAUGE_ADC_0_ADDRESS))
                                            {
                                                int addr03Offset = remainingBytesOffset;
                                                WORD numberOfInterimWords = Min((numberOfRemainingBytes / 2), (DTSTEST_GAUGE_ADC_0_ADDRESS - remainingBytesAddress));
                                                addr03String = String::Concat(
                                                    Environment::NewLine,
                                                    "        ", numberOfInterimWords,
                                                    " word",
                                                    ((numberOfInterimWords == 1) ? "" : "s"),
                                                    " at gauge memory address ",
                                                    String::Format("{0:D2}", remainingBytesAddress),
                                                    " :");
                                                for (WORD count = 0; count < numberOfInterimWords; count++)
                                                    addr03String += String::Format(" 0x{0:X4}",
                                                        ((pgInfo->responseArray[(count * 2) + addr03Offset] << 8) | pgInfo->responseArray[(count * 2) + addr03Offset + 1]));
                                                remainingBytesAddress += numberOfInterimWords;
                                                remainingBytesOffset += (numberOfInterimWords * 2);
                                                numberOfRemainingBytes -= (numberOfInterimWords * 2);
                                            }
                                        }
                                        String ^gaugeADCString = String::Empty;
                                        if (numberOfRemainingBytes)
                                        {
                                            if ((memoryAddress <= DTSTEST_GAUGE_ADC_0_ADDRESS) &&
                                                (wordsRequested >= (DTSTEST_GAUGE_ADC_0_ADDRESS - memoryAddress + DTSTEST_GAUGE_ADC_0_WORDS)))
                                            {
                                                //--------------------------------
                                                // Gauge ADC 0 - addr 0008
                                                //--------------------------------
                                                readAndDisplayGaugeADC0 = GUI_YES;
                                                ADCOffset = remainingBytesOffset;
                                                remainingBytesAddress += DTSTEST_GAUGE_ADC_0_WORDS;
                                                remainingBytesOffset += DTSTEST_GAUGE_ADC_0_BYTES;
                                                numberOfRemainingBytes -= DTSTEST_GAUGE_ADC_0_BYTES;
                                            }
                                        }
                                        if (numberOfRemainingBytes)
                                        {
                                            if ((memoryAddress <= DTSTEST_GAUGE_ADC_1_ADDRESS) &&
                                                (wordsRequested >= (DTSTEST_GAUGE_ADC_1_ADDRESS - memoryAddress + DTSTEST_GAUGE_ADC_1_WORDS)))
                                            {
                                                //--------------------------------
                                                // Gauge ADC 1 - addr 0009
                                                //--------------------------------
                                                readAndDisplayGaugeADC1 = GUI_YES;
                                                if (!ADCOffset)
                                                    ADCOffset = remainingBytesOffset;
                                                remainingBytesAddress += DTSTEST_GAUGE_ADC_1_WORDS;
                                                remainingBytesOffset += DTSTEST_GAUGE_ADC_1_BYTES;
                                                numberOfRemainingBytes -= DTSTEST_GAUGE_ADC_1_BYTES;
                                            }
                                        }
                                        if (numberOfRemainingBytes)
                                        {
                                            if ((memoryAddress <= DTSTEST_GAUGE_ADC_2_ADDRESS) &&
                                                (wordsRequested >= (DTSTEST_GAUGE_ADC_2_ADDRESS - memoryAddress + DTSTEST_GAUGE_ADC_2_WORDS)))
                                            {
                                                //--------------------------------
                                                // Gauge ADC 2 - addr 000A
                                                //--------------------------------
                                                readAndDisplayGaugeADC2 = GUI_YES;
                                                if (!ADCOffset)
                                                    ADCOffset = remainingBytesOffset;
                                                remainingBytesAddress += DTSTEST_GAUGE_ADC_2_WORDS;
                                                remainingBytesOffset += DTSTEST_GAUGE_ADC_2_BYTES;
                                                numberOfRemainingBytes -= DTSTEST_GAUGE_ADC_2_BYTES;
                                            }
                                        }
                                        if (numberOfRemainingBytes)
                                        {
                                            if ((memoryAddress <= DTSTEST_GAUGE_ADC_3_ADDRESS) &&
                                                (wordsRequested >= (DTSTEST_GAUGE_ADC_3_ADDRESS - memoryAddress + DTSTEST_GAUGE_ADC_3_WORDS)))
                                            {
                                                //--------------------------------
                                                // Gauge ADC 3 - addr 000B
                                                //--------------------------------
                                                readAndDisplayGaugeADC3 = GUI_YES;
                                                if (!ADCOffset)
                                                    ADCOffset = remainingBytesOffset;
                                                remainingBytesAddress += DTSTEST_GAUGE_ADC_3_WORDS;
                                                remainingBytesOffset += DTSTEST_GAUGE_ADC_3_BYTES;
                                                numberOfRemainingBytes -= DTSTEST_GAUGE_ADC_3_BYTES;
                                            }
                                        }
                                        String ^addr13String = String::Empty;
                                        if (numberOfRemainingBytes)
                                        {
                                            if (memoryAddress == (DTSTEST_GAUGE_STATUS_0_ADDRESS + 1))
                                            {
                                                int addr13Offset = remainingBytesOffset;
                                                addr13String = String::Concat(
                                                    Environment::NewLine,
                                                    "         1 word at gauge memory address ",
                                                    String::Format("{0:D2}", memoryAddress),
                                                    " : ",
                                                    String::Format("0x{0:X4}",
                                                        ((pgInfo->responseArray[addr13Offset] << 8) | pgInfo->responseArray[addr13Offset + 1])));
                                                remainingBytesAddress += 1;
                                                remainingBytesOffset += 2;
                                                numberOfRemainingBytes -= 2;
                                            }
                                        }
                                        String ^gaugeStatusString = String::Empty;
                                        if (numberOfRemainingBytes)
                                        {
                                            if ((memoryAddress <= DTSTEST_GAUGE_STATUS_0_ADDRESS) &&
                                                (wordsRequested >= (DTSTEST_GAUGE_STATUS_0_ADDRESS - memoryAddress + DTSTEST_GAUGE_STATUS_0_WORDS)))
                                            {
                                                //--------------------------------
                                                // Gauge status 0 - addr 0012
                                                //--------------------------------
                                                readAndDisplayGaugeStatus0 = GUI_YES;
                                                if (remainingBytesOffset)
                                                    statusOffset = remainingBytesOffset;
                                                else
                                                    statusOffset = DTSTEST_REPLY_HEADER_BYTES;
                                                remainingBytesAddress += DTSTEST_GAUGE_STATUS_0_WORDS;
                                                remainingBytesOffset += DTSTEST_GAUGE_STATUS_0_BYTES;
                                                numberOfRemainingBytes -= DTSTEST_GAUGE_STATUS_0_BYTES;
                                            }
                                        }
                                        if (numberOfRemainingBytes)
                                        {
                                            if ((memoryAddress <= DTSTEST_GAUGE_STATUS_1_ADDRESS) &&
                                                (wordsRequested >= (DTSTEST_GAUGE_STATUS_1_ADDRESS - memoryAddress + DTSTEST_GAUGE_STATUS_1_WORDS)))
                                            {
                                                //--------------------------------
                                                // Gauge status 1 - addr 0014
                                                //--------------------------------
                                                readAndDisplayGaugeStatus1 = GUI_YES;
                                                if (!statusOffset)
                                                    statusOffset = remainingBytesOffset;
                                                remainingBytesAddress += DTSTEST_GAUGE_STATUS_1_WORDS;
                                                remainingBytesOffset += DTSTEST_GAUGE_STATUS_1_BYTES;
                                                numberOfRemainingBytes -= DTSTEST_GAUGE_STATUS_1_BYTES;
                                            }
                                        }
                                        String ^addr15String = String::Empty;
                                        if (numberOfRemainingBytes)
                                        {
                                            if ((remainingBytesAddress > DTSTEST_GAUGE_STATUS_1_ADDRESS) &&
                                                (remainingBytesAddress < DTSTEST_GAUGE_TYPE_0_ADDRESS))
                                            {
                                                int addr15Offset = remainingBytesOffset;
                                                WORD numberOfInterimWords = Min((numberOfRemainingBytes / 2), (DTSTEST_GAUGE_TYPE_0_ADDRESS - remainingBytesAddress));
                                                addr15String = String::Concat(
                                                    Environment::NewLine,
                                                    "        ", numberOfInterimWords,
                                                    " word",
                                                    ((numberOfInterimWords == 1) ? "" : "s"),
                                                    " at gauge memory address ",
                                                    String::Format("{0:D2}", remainingBytesAddress),
                                                    " :");
                                                if (numberOfInterimWords > 8)
                                                {
                                                    addr15String += String::Concat(
                                                        Environment::NewLine,
                                                        "            ");
                                                    for (WORD count = 0; count < 8; count++)
                                                        addr15String += String::Format(" 0x{0:X4}",
                                                            ((pgInfo->responseArray[(count * 2) + addr15Offset] << 8) | pgInfo->responseArray[(count * 2) + addr15Offset + 1]));
                                                    addr15String += String::Concat(
                                                        Environment::NewLine,
                                                        "            ");
                                                    for (WORD count = 8; count < numberOfInterimWords; count++)
                                                        addr15String += String::Format(" 0x{0:X4}",
                                                            ((pgInfo->responseArray[(count * 2) + addr15Offset] << 8) | pgInfo->responseArray[(count * 2) + addr15Offset + 1]));
                                                }
                                                else
                                                {
                                                    for (WORD count = 0; count < numberOfInterimWords; count++)
                                                        addr15String += String::Format(" 0x{0:X4}",
                                                            ((pgInfo->responseArray[(count * 2) + addr15Offset] << 8) | pgInfo->responseArray[(count * 2) + addr15Offset + 1]));
                                                }
                                                remainingBytesAddress += numberOfInterimWords;
                                                remainingBytesOffset += (numberOfInterimWords * 2);
                                                numberOfRemainingBytes -= (numberOfInterimWords * 2);
                                            }
                                        }
                                        String ^gaugeTypeString = String::Empty;
                                        if (numberOfRemainingBytes)
                                        {
                                            if ((memoryAddress <= DTSTEST_GAUGE_TYPE_0_ADDRESS) &&
                                                (wordsRequested >= (DTSTEST_GAUGE_TYPE_0_ADDRESS - memoryAddress + DTSTEST_GAUGE_TYPE_0_WORDS)))
                                            {
                                                //--------------------------------
                                                // Gauge type 0 - addr 0020
                                                //--------------------------------
                                                readAndDisplayGaugeType0 = GUI_YES;
                                                if (!typeOffset)
                                                    typeOffset = remainingBytesOffset;
                                                remainingBytesAddress += DTSTEST_GAUGE_TYPE_0_WORDS;
                                                remainingBytesOffset += DTSTEST_GAUGE_TYPE_0_BYTES;
                                                numberOfRemainingBytes -= DTSTEST_GAUGE_TYPE_0_BYTES;
                                            }
                                        }
                                        if (numberOfRemainingBytes)
                                        {
                                            if ((memoryAddress <= DTSTEST_GAUGE_TYPE_1_ADDRESS) &&
                                                (wordsRequested >= (DTSTEST_GAUGE_TYPE_1_ADDRESS - memoryAddress + DTSTEST_GAUGE_TYPE_1_WORDS)))
                                            {
                                                //--------------------------------
                                                // Gauge type 1 - addr 0021
                                                //--------------------------------
                                                readAndDisplayGaugeType1 = GUI_YES;
                                                if (!typeOffset)
                                                    typeOffset = remainingBytesOffset;
                                                remainingBytesAddress += DTSTEST_GAUGE_TYPE_1_WORDS;
                                                remainingBytesOffset += DTSTEST_GAUGE_TYPE_1_BYTES;
                                                numberOfRemainingBytes -= DTSTEST_GAUGE_TYPE_1_BYTES;
                                            }
                                        }
                                        String ^gaugeVersionString = String::Empty;
                                        if (numberOfRemainingBytes)
                                        {
                                            if ((memoryAddress <= DTSTEST_GAUGE_VERSION_0_ADDRESS) &&
                                                (wordsRequested >= (DTSTEST_GAUGE_VERSION_0_ADDRESS - memoryAddress + DTSTEST_GAUGE_VERSION_0_WORDS)))
                                            {
                                                //--------------------------------
                                                // Gauge version 0 - addr 0022
                                                //--------------------------------
                                                readAndDisplayGaugeVersion0 = GUI_YES;
                                                if (!versionOffset)
                                                    versionOffset = remainingBytesOffset;
                                                remainingBytesAddress += DTSTEST_GAUGE_VERSION_0_WORDS;
                                                remainingBytesOffset += DTSTEST_GAUGE_VERSION_0_BYTES;
                                                numberOfRemainingBytes -= DTSTEST_GAUGE_VERSION_0_BYTES;
                                            }
                                        }
                                        if (numberOfRemainingBytes)
                                        {
                                            if ((memoryAddress <= DTSTEST_GAUGE_VERSION_1_ADDRESS) &&
                                                (wordsRequested >= (DTSTEST_GAUGE_VERSION_1_ADDRESS - memoryAddress + DTSTEST_GAUGE_VERSION_1_WORDS)))
                                            {
                                                //--------------------------------
                                                // Gauge version 1 - addr 0023
                                                //--------------------------------
                                                readAndDisplayGaugeVersion1 = GUI_YES;
                                                if (!versionOffset)
                                                    versionOffset = remainingBytesOffset;
                                                remainingBytesAddress += DTSTEST_GAUGE_VERSION_1_WORDS;
                                                remainingBytesOffset += DTSTEST_GAUGE_VERSION_1_BYTES;
                                                numberOfRemainingBytes -= DTSTEST_GAUGE_VERSION_1_BYTES;
                                            }
                                        }
                                        if (numberOfRemainingBytes)
                                        {
                                            if ((memoryAddress <= DTSTEST_GAUGE_HOLDING_0_ADDRESS) &&
                                                (wordsRequested >= (DTSTEST_GAUGE_HOLDING_0_ADDRESS - memoryAddress + DTSTEST_GAUGE_HOLDING_0_WORDS)))
                                            {
                                                //--------------------------------
                                                // Gauge HR 0 - addr 0024
                                                //--------------------------------
                                                readAndDisplayGaugeHR0 = GUI_YES;
                                                holdingRegisterOffset = remainingBytesOffset;
                                                remainingBytesAddress += DTSTEST_GAUGE_HOLDING_0_WORDS;
                                                remainingBytesOffset += DTSTEST_GAUGE_HOLDING_0_BYTES;
                                                numberOfRemainingBytes -= DTSTEST_GAUGE_HOLDING_0_BYTES;
                                            }
                                        }
                                        if (numberOfRemainingBytes)
                                        {
                                            if ((memoryAddress <= DTSTEST_GAUGE_HOLDING_1_ADDRESS) &&
                                                (wordsRequested >= (DTSTEST_GAUGE_HOLDING_1_ADDRESS - memoryAddress + DTSTEST_GAUGE_HOLDING_1_WORDS)))
                                            {
                                                //--------------------------------
                                                // Gauge HR 1 - addr 0025
                                                //--------------------------------
                                                readAndDisplayGaugeHR1 = GUI_YES;
                                                if (!holdingRegisterOffset)
                                                    holdingRegisterOffset = remainingBytesOffset;
                                                remainingBytesAddress += DTSTEST_GAUGE_HOLDING_1_WORDS;
                                                remainingBytesOffset += DTSTEST_GAUGE_HOLDING_1_BYTES;
                                                numberOfRemainingBytes -= DTSTEST_GAUGE_HOLDING_1_BYTES;
                                            }
                                        }
                                        if (numberOfRemainingBytes)
                                        {
                                            if ((memoryAddress <= DTSTEST_GAUGE_HOLDING_2_ADDRESS) &&
                                                (wordsRequested >= (DTSTEST_GAUGE_HOLDING_2_ADDRESS - memoryAddress + DTSTEST_GAUGE_HOLDING_2_WORDS)))
                                            {
                                                //--------------------------------
                                                // Gauge HR 2 - addr 0026
                                                //--------------------------------
                                                readAndDisplayGaugeHR2 = GUI_YES;
                                                if (!holdingRegisterOffset)
                                                    holdingRegisterOffset = remainingBytesOffset;
                                                remainingBytesAddress += DTSTEST_GAUGE_HOLDING_2_WORDS;
                                                remainingBytesOffset += DTSTEST_GAUGE_HOLDING_2_BYTES;
                                                numberOfRemainingBytes -= DTSTEST_GAUGE_HOLDING_2_BYTES;
                                            }
                                        }
                                        if (numberOfRemainingBytes)
                                        {
                                            if ((memoryAddress <= DTSTEST_GAUGE_HOLDING_3_ADDRESS) &&
                                                (wordsRequested >= (DTSTEST_GAUGE_HOLDING_3_ADDRESS - memoryAddress + DTSTEST_GAUGE_HOLDING_3_WORDS)))
                                            {
                                                //--------------------------------
                                                // Gauge HR 3 - addr 0027
                                                //--------------------------------
                                                readAndDisplayGaugeHR3 = GUI_YES;
                                                if (!holdingRegisterOffset)
                                                    holdingRegisterOffset = remainingBytesOffset;
                                                remainingBytesAddress += DTSTEST_GAUGE_HOLDING_3_WORDS;
                                                remainingBytesOffset += DTSTEST_GAUGE_HOLDING_3_BYTES;
                                                numberOfRemainingBytes -= DTSTEST_GAUGE_HOLDING_3_BYTES;
                                            }
                                        }
                                        String ^addr40String = String::Empty;
                                        if (numberOfRemainingBytes)
                                        {
                                            if ((remainingBytesAddress > DTSTEST_GAUGE_HOLDING_3_ADDRESS) &&
                                                (remainingBytesAddress < DTSTEST_GAUGE_FLAGS_ADDRESS))
                                            {
                                                int addr40Offset = remainingBytesOffset;
                                                WORD numberOfInterimWords = Min((numberOfRemainingBytes / 2), (DTSTEST_GAUGE_FLAGS_ADDRESS - remainingBytesAddress));
                                                addr40String = String::Concat(
                                                    Environment::NewLine,
                                                    "        ", numberOfInterimWords,
                                                    " word",
                                                    ((numberOfInterimWords == 1) ? "" : "s"),
                                                    " at gauge memory address ",
                                                    String::Format("{0:D2}", remainingBytesAddress),
                                                    " :");
                                                for (WORD count = 0; count < numberOfInterimWords; count++)
                                                    addr40String += String::Format(" 0x{0:X4}",
                                                        ((pgInfo->responseArray[(count * 2) + addr40Offset] << 8) | pgInfo->responseArray[(count * 2) + addr40Offset + 1]));
                                                remainingBytesAddress += numberOfInterimWords;
                                                remainingBytesOffset += (numberOfInterimWords * 2);
                                                numberOfRemainingBytes -= (numberOfInterimWords * 2);
                                            }
                                        }
                                        if (numberOfRemainingBytes)
                                        {
                                            if ((memoryAddress <= DTSTEST_GAUGE_FLAGS_ADDRESS) &&
                                                (wordsRequested >= (DTSTEST_GAUGE_FLAGS_ADDRESS - memoryAddress + DTSTEST_GAUGE_FLAGS_WORDS)))
                                            {
                                                //--------------------------------
                                                // Gauge flags - addr 002A
                                                //--------------------------------
                                                readAndDisplayGaugeFlags = GUI_YES;
                                                if (!flagsOffset)
                                                    flagsOffset = remainingBytesOffset;
                                                remainingBytesAddress += DTSTEST_GAUGE_FLAGS_WORDS;
                                                remainingBytesOffset += DTSTEST_GAUGE_FLAGS_BYTES;
                                                numberOfRemainingBytes -= DTSTEST_GAUGE_FLAGS_BYTES;
                                            }
                                        }
                                        if (numberOfRemainingBytes)
                                        {
                                            if ((memoryAddress <= DTSTEST_GAUGE_VENDOR_PREFIX_ADDRESS) &&
                                                (wordsRequested >= (DTSTEST_GAUGE_VENDOR_PREFIX_ADDRESS - memoryAddress + DTSTEST_GAUGE_VENDOR_PREFIX_WORDS)))
                                            {
                                                //--------------------------------
                                                // Gauge vendor prefix - addr 002B
                                                //--------------------------------
                                                readAndDisplayGaugeVendorPrefix = GUI_YES;
                                                if (!vendorPrefixOffset)
                                                    vendorPrefixOffset = remainingBytesOffset;
                                                remainingBytesAddress += DTSTEST_GAUGE_VENDOR_PREFIX_WORDS;
                                                remainingBytesOffset += DTSTEST_GAUGE_VENDOR_PREFIX_BYTES;
                                                numberOfRemainingBytes -= DTSTEST_GAUGE_VENDOR_PREFIX_BYTES;
                                            }
                                        }
                                        int numberOfVendorBytes = numberOfRemainingBytes;
                                        if (numberOfRemainingBytes)
                                        {
                                            if ((memoryAddress <= DTSTEST_GAUGE_VENDOR_ADDRESS) &&
                                                (wordsRequested >= (DTSTEST_GAUGE_VENDOR_ADDRESS - memoryAddress + 1)))
                                            {
                                                //--------------------------------
                                                // Gauge vendor - addr 002C
                                                //--------------------------------
                                                readAndDisplayGaugeVendor = GUI_YES;
                                                if (numberOfRemainingBytes > DTSTEST_GAUGE_VENDOR_BYTES)
                                                    numberOfVendorBytes = DTSTEST_GAUGE_VENDOR_BYTES;
                                                if (!vendorOffset)
                                                    vendorOffset = remainingBytesOffset;
                                                remainingBytesAddress += numberOfVendorBytes / 2; // DTSTEST_GAUGE_VENDOR_WORDS;
                                                remainingBytesOffset += numberOfVendorBytes; // DTSTEST_GAUGE_VENDOR_BYTES;
                                                numberOfRemainingBytes -= numberOfVendorBytes; // DTSTEST_GAUGE_VENDOR_BYTES;
                                            }
                                        }
                                        if (numberOfRemainingBytes)
                                        {
                                            if ((memoryAddress <= DTSTEST_GAUGE_DOCUMENT_PREFIX_ADDRESS) &&
                                                (wordsRequested >= (DTSTEST_GAUGE_DOCUMENT_PREFIX_ADDRESS - memoryAddress + DTSTEST_GAUGE_DOCUMENT_PREFIX_WORDS)))
                                            {
                                                //--------------------------------
                                                // Gauge document prefix - addr 0039
                                                //--------------------------------
                                                readAndDisplayGaugeDocumentPrefix = GUI_YES;
                                                if (!documentPrefixOffset)
                                                    documentPrefixOffset = remainingBytesOffset;
                                                remainingBytesAddress += DTSTEST_GAUGE_DOCUMENT_PREFIX_WORDS;
                                                remainingBytesOffset += DTSTEST_GAUGE_DOCUMENT_PREFIX_BYTES;
                                                numberOfRemainingBytes -= DTSTEST_GAUGE_DOCUMENT_PREFIX_BYTES;
                                            }
                                        }
                                        int numberOfDocumentBytes = numberOfRemainingBytes;
                                        if (numberOfRemainingBytes)
                                        {
                                            if ((memoryAddress <= DTSTEST_GAUGE_DOCUMENT_ADDRESS) &&
                                                (wordsRequested >= (DTSTEST_GAUGE_DOCUMENT_ADDRESS - memoryAddress + 1)))
                                            {
                                                //--------------------------------
                                                // Gauge document - addr 003A
                                                //--------------------------------
                                                readAndDisplayGaugeDocument = GUI_YES;
                                                if (numberOfRemainingBytes > DTSTEST_GAUGE_DOCUMENT_BYTES)
                                                    numberOfDocumentBytes = DTSTEST_GAUGE_DOCUMENT_BYTES;
                                                if (!documentOffset)
                                                    documentOffset = remainingBytesOffset;
                                                remainingBytesAddress += numberOfDocumentBytes / 2; // DTSTEST_GAUGE_DOCUMENT_WORDS;
                                                remainingBytesOffset += numberOfDocumentBytes; // DTSTEST_GAUGE_DOCUMENT_BYTES;
                                                numberOfRemainingBytes -= numberOfDocumentBytes; // DTSTEST_GAUGE_DOCUMENT_BYTES;
                                            }
                                        }
                                        if (numberOfRemainingBytes)
                                        {
                                            if ((memoryAddress <= DTSTEST_GAUGE_REVISION_PREFIX_ADDRESS) &&
                                                (wordsRequested >= (DTSTEST_GAUGE_REVISION_PREFIX_ADDRESS - memoryAddress + DTSTEST_GAUGE_REVISION_PREFIX_WORDS)))
                                            {
                                                //--------------------------------
                                                // Gauge revision prefix - addr 003E
                                                //--------------------------------
                                                readAndDisplayGaugeRevisionPrefix = GUI_YES;
                                                if (!revisionPrefixOffset)
                                                    revisionPrefixOffset = remainingBytesOffset;
                                                remainingBytesAddress += DTSTEST_GAUGE_REVISION_PREFIX_WORDS;
                                                remainingBytesOffset += DTSTEST_GAUGE_REVISION_PREFIX_BYTES;
                                                numberOfRemainingBytes -= DTSTEST_GAUGE_REVISION_PREFIX_BYTES;
                                            }
                                        }
                                        int numberOfRevisionBytes = numberOfRemainingBytes;
                                        if (numberOfRemainingBytes)
                                        {
                                            if ((memoryAddress <= DTSTEST_GAUGE_REVISION_ADDRESS) &&
                                                (wordsRequested >= (DTSTEST_GAUGE_REVISION_ADDRESS - memoryAddress + 1)))
                                            {
                                                //--------------------------------
                                                // Gauge revision - addr 003F
                                                //--------------------------------
                                                readAndDisplayGaugeRevision = GUI_YES;
                                                if (numberOfRemainingBytes > DTSTEST_GAUGE_REVISION_BYTES)
                                                    numberOfRevisionBytes = DTSTEST_GAUGE_REVISION_BYTES;
                                                if (!revisionOffset)
                                                    revisionOffset = remainingBytesOffset;
                                                remainingBytesAddress += numberOfRevisionBytes / 2; // DTSTEST_GAUGE_REVISION_WORDS;
                                                remainingBytesOffset += numberOfRevisionBytes; // DTSTEST_GAUGE_REVISION_BYTES;
                                                numberOfRemainingBytes -= numberOfRevisionBytes; // DTSTEST_GAUGE_REVISION_BYTES;
                                            }
                                        }
                                        if (readAndDisplayGaugePressure ||
                                            readAndDisplayGaugeTemperature ||
                                            readAndDisplayGaugeADC0 ||
                                            readAndDisplayGaugeADC1 ||
                                            readAndDisplayGaugeADC2 ||
                                            readAndDisplayGaugeADC3 ||
                                            readAndDisplayGaugeStatus0 ||
                                            readAndDisplayGaugeStatus1 ||
                                            readAndDisplayGaugeType0 ||
                                            readAndDisplayGaugeType1 ||
                                            readAndDisplayGaugeVersion0 ||
                                            readAndDisplayGaugeVersion1 ||
                                            readAndDisplayGaugeHR0 ||
                                            readAndDisplayGaugeHR1 ||
                                            readAndDisplayGaugeHR2 ||
                                            readAndDisplayGaugeHR3 ||
                                            readAndDisplayGaugeFlags ||
                                            readAndDisplayGaugeVendorPrefix ||
                                            readAndDisplayGaugeVendor ||
                                            readAndDisplayGaugeDocumentPrefix ||
                                            readAndDisplayGaugeDocument ||
                                            readAndDisplayGaugeRevisionPrefix  |
                                            readAndDisplayGaugeRevision)
                                        {
                                            titleString += String::Concat(
                                                "    ROC-X Gauge ",
                                                nodeAddressString);
                                            DWORD gaugePressureCount = 0;
                                            String ^gaugePressureString = String::Empty;
                                            if (readAndDisplayGaugePressure)
                                            {
                                                gaugePressureCount = (DWORD)
                                                    (pgInfo->responseArray[pressureOffset] << 24) | (pgInfo->responseArray[pressureOffset + 1] << 16) | (pgInfo->responseArray[pressureOffset + 2] << 8) | pgInfo->responseArray[pressureOffset + 3];
                                                sensor->currentPressureCount = gaugePressureCount;
                                                gaugePressureString = String::Format(
                                                    "        Pressure = 0x{0:X8} = {0:D}",
                                                    gaugePressureCount);
                                            }   // end of if (readAndDisplayGaugePressure)
//RecordDetailedEvent("BP 4 : numberOfRemainingBytes = {0:D}  temperatureOffset = {1:D} gauge is {2}", numberOfRemainingBytes, temperatureOffset, (gauge ? "valid" : "invalid"));
//RecordDetailedEvent("Gauge pointer {0} valid", (gauge ? "is" : "is not"));
                                            DWORD gaugeTemperatureCount = 0;
                                            String ^gaugeTemperatureString = String::Empty;
                                            if (readAndDisplayGaugeTemperature)
                                            {
                                                gaugeTemperatureCount = (DWORD)
                                                    (pgInfo->responseArray[temperatureOffset] << 24) | (pgInfo->responseArray[temperatureOffset + 1] << 16) | (pgInfo->responseArray[temperatureOffset + 2] << 8) | pgInfo->responseArray[temperatureOffset + 3];
                                                sensor->currentTemperatureCount = gaugeTemperatureCount;
                                                gaugeTemperatureString = String::Format(
                                                    "        Temperature = 0x{0:X8} = {0:D}",
                                                    gaugeTemperatureCount);
                                            }   // end of if (readAndDisplayGaugeTemperature)
                                            else
                                            {
                                                gaugeTemperatureCount = sensor->currentTemperatureCount;
                                            }
//RecordDetailedEvent("BP 5 : numberOfRemainingBytes = {0:D}", numberOfRemainingBytes);
//                                            String ^gaugeStatusString = String::Empty;
                                            if (readAndDisplayGaugeADC0)
                                            {
                                                DWORD gaugeADC0 = (DWORD)
                                                    (pgInfo->responseArray[ADCOffset] << 8) | pgInfo->responseArray[ADCOffset + 1];
                                                gaugeADCString += String::Format(
                                                    "        ADC0 = 0x{0:X4}",
                                                    gaugeADC0);
                                                ADCOffset += DTSTEST_GAUGE_ADC_0_BYTES;
                                            }
                                            if (readAndDisplayGaugeADC1)
                                            {
                                                DWORD gaugeADC1 = (DWORD)
                                                    (pgInfo->responseArray[ADCOffset] << 8) | pgInfo->responseArray[ADCOffset + 1];
                                                gaugeADCString += String::Format(
                                                    "        ADC1 = 0x{0:X4}",
                                                    gaugeADC1);
                                                ADCOffset += DTSTEST_GAUGE_ADC_1_BYTES;
                                            }
                                            if (readAndDisplayGaugeADC2)
                                            {
                                                DWORD gaugeADC2 = (DWORD)
                                                    (pgInfo->responseArray[ADCOffset] << 8) | pgInfo->responseArray[ADCOffset + 1];
                                                gaugeADCString += String::Format(
                                                    "        ADC2 = 0x{0:X4}",
                                                    gaugeADC2);
                                                ADCOffset += DTSTEST_GAUGE_ADC_2_BYTES;
                                            }
                                            if (readAndDisplayGaugeADC3)
                                            {
                                                DWORD gaugeADC3 = (DWORD)
                                                    (pgInfo->responseArray[ADCOffset] << 8) | pgInfo->responseArray[ADCOffset + 1];
                                                gaugeADCString += String::Format(
                                                    "        ADC3 = 0x{0:X4}",
                                                    gaugeADC3);
                                                ADCOffset += DTSTEST_GAUGE_ADC_3_BYTES;
                                            }
                                            if (readAndDisplayGaugeStatus0)
                                            {
                                                DWORD gaugeStatus = (DWORD)
                                                    (pgInfo->responseArray[statusOffset] << 24) | (pgInfo->responseArray[statusOffset + 1] << 16) | (pgInfo->responseArray[statusOffset + 2] << 8) | pgInfo->responseArray[statusOffset + 3];
                                                gaugeStatusString += String::Format(
                                                    "        Status0 = 0x{0:X8}",
                                                    gaugeStatus);
                                                statusOffset += DTSTEST_GAUGE_STATUS_0_BYTES;
                                            }
                                            if (readAndDisplayGaugeStatus1)
                                            {
                                                DWORD gaugeStatus = (DWORD)
                                                    (pgInfo->responseArray[statusOffset] << 24) | (pgInfo->responseArray[statusOffset + 1] << 16) | (pgInfo->responseArray[statusOffset + 2] << 8) | pgInfo->responseArray[statusOffset + 3];
                                                gaugeStatusString += String::Format(
                                                    "        Status1 = 0x{0:X8}",
                                                    gaugeStatus);
                                            }
//                                            String ^gaugeTypeString = String::Empty;
                                            if (readAndDisplayGaugeType0)
                                            {
                                                WORD gaugeType = (WORD)
                                                    (pgInfo->responseArray[typeOffset] << 8) | pgInfo->responseArray[typeOffset + 1];
                                                gaugeTypeString += String::Format(
                                                    "        Type0 = 0x{0:X4}",
                                                    gaugeType);
                                                generalCSVEntry->loggedCSVTypeString = String::Format(
                                                    "{0:X4}", gaugeType);
                                                typeOffset += DTSTEST_GAUGE_TYPE_0_BYTES;
                                            }
                                            if (readAndDisplayGaugeType1)
                                            {
                                                WORD gaugeType = (WORD)
                                                    (pgInfo->responseArray[typeOffset] << 8) | pgInfo->responseArray[typeOffset + 1];
                                                gaugeTypeString += String::Format(
                                                    "        Type1 = 0x{0:X4}",
                                                    gaugeType);
                                            }
//                                            String ^gaugeVersionString = String::Empty;
//RecordDetailedEvent("Version display : versionOffset = {0:D}", versionOffset);
                                            if (readAndDisplayGaugeVersion0)
                                            {
                                                WORD gaugeVersion = (WORD)
                                                    (pgInfo->responseArray[versionOffset] << 8) | pgInfo->responseArray[versionOffset + 1];
                                                gaugeVersionString += String::Format(
                                                    "        Version0 = 0x{0:X4}",
                                                    gaugeVersion);
                                                generalCSVEntry->loggedCSVVersionString = String::Format(
                                                    "{0:X4}", gaugeVersion);
                                                versionOffset += DTSTEST_GAUGE_VERSION_0_BYTES;
                                            }
                                            if (readAndDisplayGaugeVersion1)
                                            {
                                                WORD gaugeVersion = (WORD)
                                                    (pgInfo->responseArray[versionOffset] << 8) | pgInfo->responseArray[versionOffset + 1];
                                                gaugeVersionString += String::Format(
                                                    "        Version1 = 0x{0:X4}",
                                                    gaugeVersion);
                                            }
                                            String ^gaugeHR0String = String::Empty;
                                            String ^gaugeHR1String = String::Empty;
                                            String ^gaugeHR2String = String::Empty;
                                            String ^gaugeHR3String = String::Empty;
                                            if (readAndDisplayGaugeHR0 ||
                                                readAndDisplayGaugeHR1 ||
                                                readAndDisplayGaugeHR2 ||
                                                readAndDisplayGaugeHR3)
                                            {
                                                String ^holdingRegisterString = String::Empty;
                                                if (readAndDisplayGaugeHR0)
                                                {
                                                    WORD gaugeHoldingRegister = (WORD)
                                                        (pgInfo->responseArray[holdingRegisterOffset] << 8) | pgInfo->responseArray[holdingRegisterOffset + 1];
                                                    String ^HR0String = String::Format("{0:X4}", gaugeHoldingRegister);
                                                    gaugeHR0String += String::Concat(
                                                        "        Holding Register 0 = 0x",
                                                        HR0String,
                                                        " : ",
                                                        ((gaugeHoldingRegister == 0x0411) ? "Password verified" : "Invalid password"));
                                                    holdingRegisterString = HR0String;
                                                    holdingRegisterOffset += DTSTEST_GAUGE_HOLDING_0_BYTES;
                                                }
                                                if (readAndDisplayGaugeHR1)
                                                {
                                                    WORD gaugeHoldingRegister = (WORD)
                                                        (pgInfo->responseArray[holdingRegisterOffset] << 8) | pgInfo->responseArray[holdingRegisterOffset + 1];
                                                    String ^HR1String = String::Format("{0:X4}", gaugeHoldingRegister);
                                                    gaugeHR1String += String::Concat(
                                                        "        Holding Register 1 = 0x",
                                                        HR1String,
                                                        " : ",
                                                        ((((gaugeHoldingRegister >> 8) & 0xFF) == 0xFF) ? "All slots on" : "Some slots masked"),
                                                        ", MODBUS address ",
                                                        (((gaugeHoldingRegister & 0xFF) == nodeAddress) ? "matches" : "mismatch"));
                                                    if (StringSet(holdingRegisterString))
                                                    {
                                                        holdingRegisterString += String::Concat(
                                                            DTSTEST_STRING_HYPHEN,
                                                            HR1String);
                                                    }
                                                    else
                                                    {
                                                        holdingRegisterString = HR1String;
                                                    }
                                                    holdingRegisterOffset += DTSTEST_GAUGE_HOLDING_1_BYTES;
                                                }
                                                if (readAndDisplayGaugeHR2)
                                                {
                                                    WORD gaugeHoldingRegister = (WORD)
                                                        (pgInfo->responseArray[holdingRegisterOffset] << 8) | pgInfo->responseArray[holdingRegisterOffset + 1];
                                                    String ^HR2String = String::Format("{0:X4}", gaugeHoldingRegister);
                                                    gaugeHR2String += String::Concat(
                                                        "        Holding Register 2 = 0x",
                                                        HR2String,
                                                        " : Receive data rate = ",
                                                        ((gaugeHoldingRegister == 0x002E) ? "1200" : ((gaugeHoldingRegister == 0x0016) ? "2400" : "Unknown")),
                                                        " baud");
                                                    if (StringSet(holdingRegisterString))
                                                    {
                                                        holdingRegisterString += String::Concat(
                                                            DTSTEST_STRING_HYPHEN,
                                                            HR2String);
                                                    }
                                                    else
                                                    {
                                                        holdingRegisterString = HR2String;
                                                    }
                                                    holdingRegisterOffset += DTSTEST_GAUGE_HOLDING_2_BYTES;
                                                }
                                                if (readAndDisplayGaugeHR3)
                                                {
                                                    WORD gaugeHoldingRegister = (WORD)
                                                        (pgInfo->responseArray[holdingRegisterOffset] << 8) | pgInfo->responseArray[holdingRegisterOffset + 1];
                                                    String ^HR3String = String::Format("{0:X4}", gaugeHoldingRegister);
                                                    gaugeHR3String += String::Concat(
                                                        "        Holding Register 3 = 0x",
                                                        HR3String,
                                                        " : Transmit data rate = ",
                                                        ((gaugeHoldingRegister == 0x02ED) ? "1200" : ((gaugeHoldingRegister == 0x0176) ? "2400" : "4800")),
                                                        " baud");
                                                    if (StringSet(holdingRegisterString))
                                                    {
                                                        holdingRegisterString += String::Concat(
                                                            DTSTEST_STRING_HYPHEN,
                                                            HR3String);
                                                    }
                                                    else
                                                    {
                                                        holdingRegisterString = HR3String;
                                                    }
                                                    holdingRegisterOffset += DTSTEST_GAUGE_HOLDING_3_BYTES;
                                                }
                                                generalCSVEntry->loggedCSVHoldingString = holdingRegisterString;
                                            }
                                            String ^gaugeFlagsString = String::Empty;
                                            if (readAndDisplayGaugeFlags)
                                            {
                                                WORD gaugeFlagsRegister = (WORD)
                                                    (pgInfo->responseArray[flagsOffset] << 8) | pgInfo->responseArray[flagsOffset + 1];
                                                gaugeFlagsString += String::Format(
                                                    "        Flags = 0x{0:X4}",
                                                    gaugeFlagsRegister);
                                            }
                                            String ^gaugeVendorString = String::Empty;
                                            String ^vendorPrefixString = String::Empty;
                                            if (readAndDisplayGaugeVendorPrefix)
                                            {
                                                vendorPrefixString = String::Concat(
                                                    Environment::NewLine,
                                                    "        Vendor prefix word at gauge memory address ",
                                                    DTSTEST_GAUGE_VENDOR_PREFIX_ADDRESS,
                                                    String::Format(" = 0x{0:X4}",
                                                        ((pgInfo->responseArray[vendorPrefixOffset] << 8) | pgInfo->responseArray[vendorPrefixOffset + 1])),
                                                    String::Format(" (string field {0:D} : {1:D} byte",
                                                        pgInfo->responseArray[vendorPrefixOffset], pgInfo->responseArray[vendorPrefixOffset + 1]),
                                                    ((pgInfo->responseArray[vendorPrefixOffset + 1] == 1) ? "" : "s"),
                                                    ")");
                                            }
                                            String ^vendorString = String::Empty;
                                            if (readAndDisplayGaugeVendor)
                                            {
//RecordDetailedEvent("Vendor 0 : vendorOffset = {0:D}  remainingBytesAddress = {1:D}", vendorOffset, remainingBytesAddress);
//                                                if ((remainingBytesAddress == DTSTEST_GAUGE_VENDOR_PREFIX_ADDRESS) &&
//                                                    numberOfRemainingBytes)
//                                                {
//                                                    vendorPrefixString = String::Concat(
//                                                        Environment::NewLine,
//                                                        "        Vendor prefix word at gauge memory address ",
//                                                        String::Format("{0:D2}", remainingBytesAddress),
//                                                        " = ",
//                                                        String::Format("0x{0:X4}",
//                                                            ((pgInfo->responseArray[vendorOffset] << 8) | pgInfo->responseArray[vendorOffset + 1])),
//                                                        String::Format(" (string field {0:D} : {1:D} byte",
//                                                            pgInfo->responseArray[vendorOffset], pgInfo->responseArray[vendorOffset + 1]),
//                                                        ((pgInfo->responseArray[vendorOffset + 1] == 1) ? "" : "s"),
//                                                        ")");
//                                                    vendorOffset += 2;
//                                                    remainingBytesAddress++;
//                                                    remainingBytesOffset += 2;
//                                                    numberOfRemainingBytes -= 2;
//RecordDetailedEvent("Vendor 1 : vendorOffset = {0:D}  remainingBytesAddress = {1:D} (s/b 44)", vendorOffset, remainingBytesAddress);
//                                                }
//                                                if ((remainingBytesAddress == DTSTEST_GAUGE_VENDOR_ADDRESS) &&
//                                                    numberOfRemainingBytes)
//                                                {
                                                    char vendorCharString[32];
                                                    ClearBuffer(vendorCharString, 32);
//Modal("vendorOffset = {0:D} numberOfVendorBytes = {1:D}", vendorOffset, numberOfVendorBytes);
                                                    for (int index = 0; index < numberOfVendorBytes; index++)
                                                        vendorCharString[index] = (char) pgInfo->responseArray[vendorOffset + index];
                                                    vendorString = String::Concat(
                                                        Environment::NewLine,
                                                        "        Vendor = '",
                                                        gcnew String(vendorCharString),
                                                        DTSTEST_STRING_APOSTROPHE);
//                                                    vendorOffset += numberOfVendorBytes;
//                                                    remainingBytesAddress += (numberOfVendorBytes / 2);
//                                                    remainingBytesOffset += numberOfVendorBytes;
//                                                    numberOfRemainingBytes -= numberOfVendorBytes;
//RecordDetailedEvent("Vendor 2 : vendorOffset = {0:D}  remainingBytesAddress = {1:D} (s/b 57)", vendorOffset, remainingBytesAddress);
                                            }
                                            String ^documentPrefixString = String::Empty;
                                            if (readAndDisplayGaugeDocumentPrefix)
                                            {
                                                documentPrefixString = String::Concat(
                                                    Environment::NewLine,
                                                    "        Document prefix word at gauge memory address ",
                                                    DTSTEST_GAUGE_DOCUMENT_PREFIX_ADDRESS,
                                                    String::Format(" = 0x{0:X4}",
                                                        ((pgInfo->responseArray[documentPrefixOffset] << 8) | pgInfo->responseArray[documentPrefixOffset + 1])),
                                                    String::Format(" (string field {0:D} : {1:D} byte",
                                                        pgInfo->responseArray[documentPrefixOffset], pgInfo->responseArray[documentPrefixOffset + 1]),
                                                    ((pgInfo->responseArray[documentPrefixOffset + 1] == 1) ? "" : "s"),
                                                    ")");
                                            }
                                            String ^documentString = String::Empty;
                                            if (readAndDisplayGaugeDocument)
                                            {
                                                char documentCharString[32];
                                                ClearBuffer(documentCharString, 32);
                                                for (int index = 0; index < numberOfDocumentBytes; index++)
                                                    documentCharString[index] = (char) pgInfo->responseArray[documentOffset + index];
                                                documentString = String::Concat(
                                                    Environment::NewLine,
                                                    "        Document = '",
                                                    gcnew String(documentCharString),
                                                    DTSTEST_STRING_APOSTROPHE);
                                            }
                                            String ^revisionPrefixString = String::Empty;
                                            if (readAndDisplayGaugeRevisionPrefix)
                                            {
                                                revisionPrefixString = String::Concat(
                                                    Environment::NewLine,
                                                    "        Revision prefix word at gauge memory address ",
                                                    DTSTEST_GAUGE_REVISION_PREFIX_ADDRESS,
                                                    String::Format(" = 0x{0:X4}",
                                                        ((pgInfo->responseArray[revisionPrefixOffset] << 8) | pgInfo->responseArray[revisionPrefixOffset + 1])),
                                                    String::Format(" (string field {0:D} : {1:D} byte",
                                                        pgInfo->responseArray[revisionPrefixOffset], pgInfo->responseArray[revisionPrefixOffset + 1]),
                                                    ((pgInfo->responseArray[revisionPrefixOffset + 1] == 1) ? "" : "s"),
                                                    ")");
                                            }
                                            String ^revisionString = String::Empty;
                                            if (readAndDisplayGaugeRevision)
                                            {
                                                char revisionCharString[32];
                                                ClearBuffer(revisionCharString, 32);
                                                for (int index = 0; index < numberOfRevisionBytes; index++)
                                                    revisionCharString[index] = (char) pgInfo->responseArray[revisionOffset + index];
                                                revisionString = String::Concat(
                                                    Environment::NewLine,
                                                    "        Revision = '",
                                                    gcnew String(revisionCharString),
                                                    DTSTEST_STRING_APOSTROPHE);
                                            }
//                                                if ((remainingBytesAddress == DTSTEST_GAUGE_DOCUMENT_PREFIX_ADDRESS) &&
//                                                    numberOfRemainingBytes)
//                                                {
//                                                    documentPrefixString = String::Concat(
//                                                        Environment::NewLine,
//                                                        "        Document prefix word at gauge memory address ",
//                                                        String::Format("{0:D2}", remainingBytesAddress),
//                                                        " = ",
//                                                        String::Format("0x{0:X4}",
//                                                            ((pgInfo->responseArray[vendorOffset] << 8) | pgInfo->responseArray[vendorOffset + 1])),
//                                                        String::Format(" (string field {0:D} : {1:D} byte",
//                                                            pgInfo->responseArray[vendorOffset], pgInfo->responseArray[vendorOffset + 1]),
//                                                        ((pgInfo->responseArray[vendorOffset + 1] == 1) ? "" : "s"),
//                                                        ")");
//                                                    vendorOffset += 2;
//                                                    remainingBytesAddress++;
//                                                    remainingBytesOffset += 2;
//                                                    numberOfRemainingBytes -= 2;
//                                                    RecordDetailedEvent("Vendor 3 : vendorOffset = {0:D}  numberOfRemainingBytes = {1:D}  remainingBytesAddress = {2:D} (s/b 58)", vendorOffset, numberOfRemainingBytes, remainingBytesAddress);
//                                                }
//                                                if ((remainingBytesAddress == DTSTEST_GAUGE_DOCUMENT_ADDRESS) &&
//                                                    numberOfRemainingBytes)
//                                                {
//                                                    int numberOfDocumentBytes =
//                                                        (numberOfRemainingBytes > DTSTEST_GAUGE_DOCUMENT_BYTES) ? DTSTEST_GAUGE_DOCUMENT_BYTES : numberOfRemainingBytes;
//                                                    char documentCharString[32];
//                                                    ClearBuffer(documentCharString, 32);
//                                                    for (int index = 0; index < numberOfDocumentBytes; index++)
//                                                        documentCharString[index] = (char) pgInfo->responseArray[vendorOffset + index];
//                                                    documentString = String::Concat(
//                                                        Environment::NewLine,
//                                                        "        Document = '",
//                                                        gcnew String(documentCharString),
//                                                        DTSTEST_STRING_APOSTROPHE);
//                                                    vendorOffset += numberOfDocumentBytes;
//                                                    remainingBytesAddress += (numberOfDocumentBytes / 2);
//                                                    remainingBytesOffset += numberOfDocumentBytes;
//                                                    numberOfRemainingBytes -= numberOfDocumentBytes;
//RecordDetailedEvent("Vendor 4 : vendorOffset = {0:D}  remainingBytesAddress = {1:D} (s/b 62)", vendorOffset, remainingBytesAddress);
//                                                }
//RecordDetailedEvent("BP 6 : numberOfRemainingBytes = {0:D}", numberOfRemainingBytes);
//                                                if (numberOfRemainingBytes == 3)
//                                                {
//                                                    revisionPrefixString = String::Concat(
//                                                        Environment::NewLine,
//                                                        "        Revision prefix word at gauge memory address ",
//                                                        String::Format("{0:D2}", remainingBytesAddress),
//                                                        " = ",
//                                                        String::Format("0x{0:X4}",
//                                                            ((pgInfo->responseArray[vendorOffset] << 8) | pgInfo->responseArray[vendorOffset + 1])),
//                                                        String::Format(" (string field {0:D} : {1:D} byte",
//                                                            pgInfo->responseArray[vendorOffset], pgInfo->responseArray[vendorOffset + 1]),
//                                                        ((pgInfo->responseArray[vendorOffset + 1] == 1) ? "" : "s"),
//                                                        ")");
//                                                    vendorOffset += 2;
//                                                    numberOfRemainingBytes = 0;
//                                                    char revisionCharString[32];
//                                                    ClearBuffer(revisionCharString, 32);
//                                                    revisionCharString[0] = (char) pgInfo->responseArray[vendorOffset];
//                                                    revisionString = String::Concat(
//                                                        Environment::NewLine,
//                                                        "        Revision = '",
//                                                        gcnew String(revisionCharString),
//                                                        DTSTEST_STRING_APOSTROPHE);
//                                                }
//                                            }
                                            gaugeVendorString += String::Concat(
                                                vendorPrefixString,
                                                vendorString,
                                                documentPrefixString,
                                                documentString,
                                                revisionPrefixString,
                                                revisionString);
                                            generalCSVEntry->loggedCSVVendorString = vendorString;
                                            if (readAndDisplayGaugePressure || readAndDisplayGaugeTemperature)
                                            {
                                                if (coefficientDataLoaded)
                                                {
                                                    double pressureValuePSI = 0.0;
                                                    double temperatureValueCelsius = 0.0;
                                                    status = QD_CalculatePressureAndTemperature(
                                                        (LPBYTE) coefficientData,
                                                        gaugePressureCount,
                                                        gaugeTemperatureCount,
                                                        &pressureValuePSI,
                                                        &temperatureValueCelsius);
                                                    pressureValuePSI += (DTSTest_NormalizeReadings ? sensor->pressurePSIBias : 0);
                                                    sensor->currentPressurePSI = pressureValuePSI;
                                                    temperatureValueCelsius += (DTSTest_NormalizeReadings ? sensor->temperatureCelsiusBias : 0);
                                                    sensor->currentTemperatureCelsius = temperatureValueCelsius;
                                                    if (readAndDisplayGaugePressure)
                                                    {
                                                        pressureValueString = String::Format("{0:F3}", pressureValuePSI);
//                                                        if (readAndDisplayGaugeTemperature)
                                                        {
                                                            if ((pressureValuePSI > 0.0) && (pressureValuePSI < 650.0))
                                                            {
                                                                gaugePressureString += String::Concat(
                                                                    _T(" ("),
                                                                    pressureValueString,
                                                                    _T(" psi)"));
                                                                if (testEntry->entryTestResults != DTSTEST_TEST_RESULT_FAILED)
                                                                    testEntry->entryTestResults = DTSTEST_TEST_RESULT_PASSED;
                                                            }
                                                            else
                                                            {
                                                                gaugePressureString += String::Concat(
                                                                    _T(" (invalid pressure value "),
                                                                    pressureValueString,
                                                                    _T(" psi out of range)"));
                                                                failureEncountered = GUI_YES;
                                                                testEntry->entryTestResults = DTSTEST_TEST_RESULT_FAILED;
                                                                generalCSVEntry->loggedCSVInterpretationString = _T("Bounds error");
                                                            }
                                                            if (DTSTest_TestingRunning)
                                                                testEntry->entryPressureLabel->Text = pressureValueString;
                                                        }
//                                                        else
//                                                        {
//                                                            gaugePressureString +=
//                                                                _T(" (temperature unavailable to calculate pressure psi)");
//                                                        }
                                                        generalCSVEntry->loggedCSVPressureActualString = pressureValueString;
//failureException = GUI_YES;
                                                    }
                                                    if (readAndDisplayGaugeTemperature)
                                                    {
                                                        temperatureValueString = String::Format("{0:F3}", temperatureValueCelsius);
                                                        if ((temperatureValueCelsius > 0.0) && (temperatureValueCelsius < 300.0))
                                                        {
                                                            gaugeTemperatureString += String::Concat(
                                                                _T(" ("),
                                                                temperatureValueString,
                                                                _T(" �C)"));
                                                            if (testEntry->entryTestResults != DTSTEST_TEST_RESULT_FAILED)
                                                                testEntry->entryTestResults = DTSTEST_TEST_RESULT_PASSED;
                                                        }
                                                        else
                                                        {
                                                            gaugeTemperatureString += String::Concat(
                                                                _T(" (invalid temperature value "),
                                                                temperatureValueString,
                                                                _T(" �C out of range)"));
                                                            failureEncountered = GUI_YES;
                                                            testEntry->entryTestResults = DTSTEST_TEST_RESULT_FAILED;
                                                            generalCSVEntry->loggedCSVInterpretationString = _T("Bounds error");
                                                        }
                                                        if (DTSTest_TestingRunning)
                                                            testEntry->entryTemperatureLabel->Text = temperatureValueString;
                                                        generalCSVEntry->loggedCSVTemperatureActualString = temperatureValueString;
//failureException = GUI_YES;
                                                    }
                                                }   // end of if (coefficientDataLoaded)
                                            }       // end of if (readAndDisplayGaugePressure || readAndDisplayGaugeTemperature)
                                            if (readAndDisplayGaugePressure)
                                            {
                                                gaugePressureString = String::Concat(
                                                    Environment::NewLine,
                                                    gaugePressureString);
                                            }
                                            if (readAndDisplayGaugeTemperature)
                                            {
                                                gaugeTemperatureString = String::Concat(
                                                    Environment::NewLine,
                                                    gaugeTemperatureString);
                                            }
                                            if (readAndDisplayGaugeADC0 ||
                                                readAndDisplayGaugeADC1 ||
                                                readAndDisplayGaugeADC2 ||
                                                readAndDisplayGaugeADC3)
                                            {
                                                gaugeADCString = String::Concat(
                                                    Environment::NewLine,
                                                    gaugeADCString);
                                            }
                                            if (readAndDisplayGaugeStatus0 ||
                                                readAndDisplayGaugeStatus1)
                                            {
                                                gaugeStatusString = String::Concat(
                                                    Environment::NewLine,
                                                    gaugeStatusString);
                                            }
                                            if (readAndDisplayGaugeType0 ||
                                                readAndDisplayGaugeType1)
                                            {
                                                gaugeTypeString = String::Concat(
                                                    Environment::NewLine,
                                                    gaugeTypeString);
                                            }
                                            if (readAndDisplayGaugeVersion0 ||
                                                readAndDisplayGaugeVersion1)
                                            {
                                                gaugeVersionString = String::Concat(
                                                    Environment::NewLine,
                                                    gaugeVersionString);
                                            }
                                            if (readAndDisplayGaugeHR0)
                                            {
                                                gaugeHR0String = String::Concat(
                                                    Environment::NewLine,
                                                    gaugeHR0String);
                                            }
                                            if (readAndDisplayGaugeHR1)
                                            {
                                                gaugeHR1String = String::Concat(
                                                    Environment::NewLine,
                                                    gaugeHR1String);
                                            }
                                            if (readAndDisplayGaugeHR2)
                                            {
                                                gaugeHR2String = String::Concat(
                                                    Environment::NewLine,
                                                    gaugeHR2String);
                                            }
                                            if (readAndDisplayGaugeHR3)
                                            {
                                                gaugeHR3String = String::Concat(
                                                    Environment::NewLine,
                                                    gaugeHR3String);
                                            }
                                            if (readAndDisplayGaugeFlags)
                                            {
                                                gaugeFlagsString = String::Concat(
                                                    Environment::NewLine,
                                                    gaugeFlagsString);
                                            }
                                            gaugeResultString += String::Concat(
                                                gaugePressureString,
                                                addr01String,
                                                gaugeTemperatureString,
                                                addr03String,
                                                gaugeADCString,
                                                gaugeStatusString,
                                                addr13String,
                                                addr15String,
                                                gaugeTypeString,
                                                gaugeVersionString,
                                                gaugeHR0String,
                                                gaugeHR1String,
                                                gaugeHR2String,
                                                gaugeHR3String,
                                                addr40String,
                                                gaugeFlagsString,
                                                gaugeVendorString);
                                        }   // end of if (readAndDisplayGaugePressure || ...)
                                    }       // end of if (targetIsGauge)
                                    else
                                    {
                                        bool readAndDisplayBargeADC1 = GUI_NO;
                                        bool readAndDisplayBargeADC2 = GUI_NO;
                                        bool readAndDisplayBargeChipID = GUI_NO;
                                        bool readAndDisplayBargeOTP1 = GUI_NO;
                                        bool readAndDisplayBargeOTP2 = GUI_NO;
                                        bool readAndDisplayBargePressure = GUI_NO;
                                        bool readAndDisplayBargeTemperature = GUI_NO;
                                        bool readAndDisplayBargeStatus = GUI_NO;
                                        //------------------------------------
                                        // Read from the barge registers
                                        //------------------------------------
                                        if (numberOfRemainingBytes)
                                        {
                                            if ((memoryAddress <= DTSTEST_BARGE_STATUS_ADDRESS) &&
                                                (wordsRequested >= (DTSTEST_BARGE_STATUS_ADDRESS - memoryAddress + DTSTEST_BARGE_STATUS_WORDS)))
                                            {
                                                //--------------------------------
                                                // Barge status
                                                //--------------------------------
                                                readAndDisplayBargeStatus = GUI_YES;
                                                statusOffset = DTSTEST_REPLY_HEADER_BYTES;
                                                remainingBytesOffset += DTSTEST_BARGE_STATUS_BYTES;
                                                numberOfRemainingBytes -= DTSTEST_BARGE_STATUS_BYTES;
                                                remainingBytesAddress += DTSTEST_BARGE_STATUS_WORDS;
                                            }
                                        }
                                        if (numberOfRemainingBytes)
                                        {
                                            if ((memoryAddress <= DTSTEST_BARGE_CHIP_ID_ADDRESS) &&
                                                (wordsRequested >= (DTSTEST_BARGE_CHIP_ID_ADDRESS - memoryAddress + DTSTEST_BARGE_CHIP_ID_WORDS)))
                                            {
                                                //--------------------------------
                                                // Barge chip ID
                                                //--------------------------------
                                                readAndDisplayBargeChipID = GUI_YES;
                                                if (remainingBytesOffset)
                                                    chipIDOffset = remainingBytesOffset;
                                                else
                                                    chipIDOffset = DTSTEST_REPLY_HEADER_BYTES;
                                                remainingBytesOffset += DTSTEST_BARGE_CHIP_ID_BYTES;
                                                numberOfRemainingBytes -= DTSTEST_BARGE_CHIP_ID_BYTES;
                                                remainingBytesAddress += DTSTEST_BARGE_CHIP_ID_WORDS;
                                            }
                                        }
                                        if (numberOfRemainingBytes)
                                        {
                                            if ((memoryAddress <= DTSTEST_BARGE_PRESSURE_ADDRESS) &&
                                                (wordsRequested >= (DTSTEST_BARGE_PRESSURE_ADDRESS - memoryAddress + DTSTEST_BARGE_PRESSURE_WORDS)))
                                            {
                                                //--------------------------------
                                                // Barge pressure
                                                //--------------------------------
                                                readAndDisplayBargePressure = GUI_YES;
                                                if (remainingBytesOffset)
                                                    pressureOffset = remainingBytesOffset;
                                                else
                                                    pressureOffset = DTSTEST_REPLY_HEADER_BYTES;
                                                remainingBytesOffset += DTSTEST_BARGE_PRESSURE_BYTES;
                                                numberOfRemainingBytes -= DTSTEST_BARGE_PRESSURE_BYTES;
                                                remainingBytesAddress += DTSTEST_BARGE_PRESSURE_WORDS;
                                            }
                                        }
                                        if (numberOfRemainingBytes)
                                        {
                                            if ((memoryAddress <= DTSTEST_BARGE_TEMPERATURE_ADDRESS) &&
                                                (wordsRequested >= (DTSTEST_BARGE_TEMPERATURE_ADDRESS - memoryAddress + DTSTEST_BARGE_TEMPERATURE_WORDS)))
                                            {
                                                if ((memoryAddress > DTSTEST_BARGE_PRESSURE_ADDRESS) &&
                                                    (memoryAddress < DTSTEST_BARGE_TEMPERATURE_ADDRESS))
                                                {
                                                    numberOfPrefixWords = DTSTEST_BARGE_TEMPERATURE_ADDRESS - memoryAddress;
                                                    remainingBytesOffset += ((DTSTEST_BARGE_TEMPERATURE_ADDRESS - memoryAddress) * 2);
                                                    numberOfRemainingBytes -= ((DTSTEST_BARGE_TEMPERATURE_ADDRESS - memoryAddress) * 2);
                                                }
                                                //--------------------------------
                                                // Barge temperature
                                                //--------------------------------
                                                readAndDisplayBargeTemperature = GUI_YES;
                                                if (remainingBytesOffset)
                                                    temperatureOffset = remainingBytesOffset;
                                                else
                                                    temperatureOffset = DTSTEST_REPLY_HEADER_BYTES;
                                                remainingBytesOffset += DTSTEST_BARGE_TEMPERATURE_BYTES;
                                                numberOfRemainingBytes -= DTSTEST_BARGE_TEMPERATURE_BYTES;
                                                remainingBytesAddress += DTSTEST_BARGE_TEMPERATURE_WORDS;
                                            }
                                        }
                                        if (numberOfRemainingBytes)
                                        {
                                            if ((memoryAddress <= DTSTEST_BARGE_ADC1_ADDRESS) &&
                                                (wordsRequested >= (DTSTEST_BARGE_ADC1_ADDRESS - memoryAddress + DTSTEST_BARGE_ADC1_WORDS)))
                                            {
                                                if ((memoryAddress > DTSTEST_BARGE_TEMPERATURE_ADDRESS) &&
                                                    (memoryAddress < DTSTEST_BARGE_ADC1_ADDRESS))
                                                {
                                                    numberOfPrefixWords = DTSTEST_BARGE_ADC1_ADDRESS - memoryAddress;
                                                    remainingBytesOffset += ((DTSTEST_BARGE_ADC1_ADDRESS - memoryAddress) * 2);
                                                    numberOfRemainingBytes -= ((DTSTEST_BARGE_ADC1_ADDRESS - memoryAddress) * 2);
                                                }
                                                //--------------------------------
                                                // Barge ADC1 register
                                                //--------------------------------
                                                readAndDisplayBargeADC1 = GUI_YES;
                                                if (remainingBytesOffset)
                                                    ADC1Offset = remainingBytesOffset;
                                                else
                                                    ADC1Offset = DTSTEST_REPLY_HEADER_BYTES;
                                                remainingBytesOffset += DTSTEST_BARGE_ADC1_BYTES;
                                                numberOfRemainingBytes -= DTSTEST_BARGE_ADC1_BYTES;
                                                remainingBytesAddress += DTSTEST_BARGE_ADC1_WORDS;
                                            }
                                        }
                                        if (numberOfRemainingBytes)
                                        {
                                            if ((memoryAddress <= DTSTEST_BARGE_ADC2_ADDRESS) &&
                                                (wordsRequested >= (DTSTEST_BARGE_ADC2_ADDRESS - memoryAddress + DTSTEST_BARGE_ADC2_WORDS)))
                                            {
                                                //--------------------------------
                                                // Barge ADC2 register
                                                //--------------------------------
                                                readAndDisplayBargeADC2 = GUI_YES;
                                                if (remainingBytesOffset)
                                                    ADC2Offset = remainingBytesOffset;
                                                else
                                                    ADC2Offset = DTSTEST_REPLY_HEADER_BYTES;
                                                remainingBytesOffset += DTSTEST_BARGE_ADC2_BYTES;
                                                numberOfRemainingBytes -= DTSTEST_BARGE_ADC2_BYTES;
                                                remainingBytesAddress += DTSTEST_BARGE_ADC2_WORDS;
                                            }
                                        }
                                        if (numberOfRemainingBytes)
                                        {
                                            if ((memoryAddress <= DTSTEST_BARGE_OTP1_ADDRESS) &&
                                                (wordsRequested >= (DTSTEST_BARGE_OTP1_ADDRESS - memoryAddress + DTSTEST_BARGE_OTP1_WORDS)))
                                            {
                                                //--------------------------------
                                                // Barge OTP1 register
                                                //--------------------------------
                                                readAndDisplayBargeOTP1 = GUI_YES;
                                                if (remainingBytesOffset)
                                                    OTP1Offset = remainingBytesOffset;
                                                else
                                                    OTP1Offset = DTSTEST_REPLY_HEADER_BYTES;
                                                remainingBytesOffset += DTSTEST_BARGE_OTP1_BYTES;
                                                numberOfRemainingBytes -= DTSTEST_BARGE_OTP1_BYTES;
                                                remainingBytesAddress += DTSTEST_BARGE_OTP1_WORDS;
                                            }
                                        }
                                        if (numberOfRemainingBytes)
                                        {
                                            if ((memoryAddress <= DTSTEST_BARGE_OTP2_ADDRESS) &&
                                                (wordsRequested >= (DTSTEST_BARGE_OTP2_ADDRESS - memoryAddress + DTSTEST_BARGE_OTP2_WORDS)))
                                            {
                                                //--------------------------------
                                                // Barge OTP2 register
                                                //--------------------------------
                                                readAndDisplayBargeOTP2 = GUI_YES;
                                                if (remainingBytesOffset)
                                                    OTP2Offset = remainingBytesOffset;
                                                else
                                                    OTP2Offset = DTSTEST_REPLY_HEADER_BYTES;
                                                remainingBytesOffset += DTSTEST_BARGE_OTP2_BYTES;
                                                numberOfRemainingBytes -= DTSTEST_BARGE_OTP2_BYTES;
                                                remainingBytesAddress += DTSTEST_BARGE_OTP2_WORDS;
                                            }
                                        }
                                        if (readAndDisplayBargeStatus ||
                                            readAndDisplayBargeChipID ||
                                            readAndDisplayBargePressure ||
                                            readAndDisplayBargeTemperature ||
                                            readAndDisplayBargeADC1 ||
                                            readAndDisplayBargeADC2 ||
                                            readAndDisplayBargeOTP1 ||
                                            readAndDisplayBargeOTP2)
                                        {
                                            titleString += String::Concat(
                                                ((sensor->sensorType == DTSTEST_SENSOR_TYPE_DTS) ? "    DTS " : "    DPS "),
                                                nodeAddressString);
                                            String ^bargeStatusString = String::Empty;
                                            String ^bargeStatusInterpretationString = String::Empty;
                                            if (readAndDisplayBargeStatus)
                                            {
                                                WORD bargeStatus = (WORD)
                                                    (pgInfo->responseArray[statusOffset] << 8) | pgInfo->responseArray[statusOffset + 1];
                                                bargeStatusString = String::Format(
                                                    "        Status = 0x{0:X4}", bargeStatus);
                                                bargeStatusInterpretationString = String::Concat(
                                                    "            ",
                                                    ((bargeStatus & 0xE800) ? ((bargeStatus & 0x2000) ? "Pressure stale" : "Pressure unavailable") :
                                                        String::Concat(((bargeStatus & 0x1000) ? "Pressure sync set" : "Pressure sync not set"), ", Pressure register healthy")),
                                                    Environment::NewLine,
                                                    "            ",
                                                    ((bargeStatus & 0x00E8) ? ((bargeStatus & 0x0020) ? "Temperature stale" : "Temperature unavailable") :
                                                        String::Concat(((bargeStatus & 0x0010) ? "Temperature sync set" : "Temperature sync not set"), ", Temperature register healthy")));
                                                generalCSVEntry->loggedCSVStatusString = String::Format(
                                                    "{0:X4}", bargeStatus);
                                            }
                                            String ^bargeChipIDString = String::Empty;
                                            if (readAndDisplayBargeChipID)
                                            {
                                                WORD bargeChipID = (WORD)
                                                    (pgInfo->responseArray[chipIDOffset] << 8) | pgInfo->responseArray[chipIDOffset + 1];
                                                bargeChipIDString = String::Format(
                                                    "        Chip ID = 0x{0:X4} ({1})",
                                                    bargeChipID,
                                                    ((bargeChipID == DTSTEST_SENSOR_CHIPSET_DTS) ? "Quartzdyne DTS" :
                                                        ((bargeChipID == DTSTEST_SENSOR_CHIPSET_DPS) ? "Quartzdyne DPS" : "Quartzdyne other chipset")));
                                                generalCSVEntry->loggedCSVChipIDString = String::Format(
                                                    "{0:X4}", bargeChipID);
                                            }
                                            DWORD bargePressureCount = 0;
                                            String ^bargePressureString = String::Empty;
                                            if (readAndDisplayBargePressure)
                                            {
                                                bargePressureCount = (DWORD)
                                                    (pgInfo->responseArray[pressureOffset] << 24) | (pgInfo->responseArray[pressureOffset + 1] << 16) | (pgInfo->responseArray[pressureOffset + 2] << 8) | pgInfo->responseArray[pressureOffset + 3];
                                                sensor->currentPressureCount = bargePressureCount;
                                                bargePressureString = String::Format(
                                                    "        Pressure = 0x{0:X8} = {0:D}",
                                                    bargePressureCount);
                                                generalCSVEntry->loggedCSVPressureCountHexString = String::Format(
                                                    "{0:X8}", bargePressureCount);
                                                generalCSVEntry->loggedCSVPressureCountDecimalString = String::Format(
                                                    "{0:D}", bargePressureCount);
                                            }
                                            DWORD bargeTemperatureCount = 0;
                                            String ^bargeTemperatureString = String::Empty;
                                            if (readAndDisplayBargeTemperature)
                                            {
                                                bargeTemperatureCount = (DWORD)
                                                    (pgInfo->responseArray[temperatureOffset] << 24) | (pgInfo->responseArray[temperatureOffset + 1] << 16) | (pgInfo->responseArray[temperatureOffset + 2] << 8) | pgInfo->responseArray[temperatureOffset + 3];
                                                sensor->currentTemperatureCount = bargeTemperatureCount;
                                                bargeTemperatureString = String::Format(
                                                    "        Temperature = 0x{0:X8} = {0:D}",
                                                    bargeTemperatureCount);
                                                generalCSVEntry->loggedCSVTemperatureCountHexString = String::Format(
                                                    "{0:X8}", bargeTemperatureCount);
                                                generalCSVEntry->loggedCSVTemperatureCountDecimalString = String::Format(
                                                    "{0:D}", bargeTemperatureCount);
                                            }
                                            else
                                            {
                                                bargeTemperatureCount = sensor->currentTemperatureCount;
                                            }
                                            String ^bargeADC1String = String::Empty;
                                            String ^bargeADC2String = String::Empty;
                                            if (readAndDisplayBargeADC1 || readAndDisplayBargeADC2)
                                            {
                                                if (readAndDisplayBargeADC1)
                                                {
                                                    WORD bargeADC1 = (WORD)
                                                        (pgInfo->responseArray[ADC1Offset] << 8) | pgInfo->responseArray[ADC1Offset + 1];
                                                    bargeADC1String = String::Format(
                                                        "0x{0:X4}", bargeADC1);
                                                }
                                                if (readAndDisplayBargeADC2)
                                                {
                                                    WORD bargeADC2 = (WORD)
                                                        (pgInfo->responseArray[ADC2Offset] << 8) | pgInfo->responseArray[ADC2Offset + 1];
                                                    bargeADC2String = String::Format(
                                                        "0x{0:X4}", bargeADC2);
                                                }
                                            }
                                            String ^bargeOTP1String = String::Empty;
                                            String ^bargeOTP2String = String::Empty;
                                            String ^bargeOTP1InterpretationString = String::Empty;
                                            String ^bargeOTP2InterpretationString = String::Empty;
                                            if (readAndDisplayBargeOTP1 || readAndDisplayBargeOTP2)
                                            {
                                                WORD bargeOTP1 = 0;
                                                if (readAndDisplayBargeOTP1)
                                                {
                                                    bargeOTP1 = (WORD)
                                                        (pgInfo->responseArray[OTP1Offset] << 8) | pgInfo->responseArray[OTP1Offset + 1];
                                                    bargeOTP1String = String::Format(
                                                        "0x{0:X4}", bargeOTP1);
                                                    bargeOTP1InterpretationString = String::Concat(
                                                        "            Status = ", String::Format("{0:X1}", ((bargeOTP1 >> 12) & 0xF)),
                                                        Environment::NewLine,
                                                        "            Oscillator Bias = ", String::Format("{0:X1}", ((bargeOTP1 >> 8) & 0xF)),
                                                        Environment::NewLine,
                                                        "            MODBUS Address = ", String::Format("{0:X2}", (bargeOTP1 & 0xFF)),
                                                        (((bargeOTP1 & 0xFF) == nodeAddress) ? " => confirmed" : " => mismatch error"));
                                                }
                                                WORD bargeOTP2 = 0;
                                                if (readAndDisplayBargeOTP2)
                                                {
                                                    bargeOTP2 = (WORD)
                                                        (pgInfo->responseArray[OTP2Offset] << 8) | pgInfo->responseArray[OTP2Offset + 1];
                                                    bargeOTP2String = String::Format(
                                                        "0x{0:X4}", bargeOTP2);
                                                    bargeOTP2InterpretationString = String::Concat(
                                                        "            Serial Number = ", bargeOTP2String);
                                                }
                                                generalCSVEntry->loggedCSVOTPString = String::Format(
                                                    "{0:X4}{1:X4}", bargeOTP1, bargeOTP2);
                                            }
                                            if (readAndDisplayBargePressure || readAndDisplayBargeTemperature)
                                            {
                                                DTSTest_SetSync(GUI_NO, testingContext);
                                                if (coefficientDataLoaded)
                                                {
                                                    //------------------------
                                                    // Append actual values if
                                                    // the coefficient data is
                                                    // loaded
                                                    //------------------------
                                                    double pressureValuePSI = 0.0;
                                                    double temperatureValueCelsius = 0.0;
                                                    status = QD_CalculatePressureAndTemperature(
                                                        coefficientData,
                                                        bargePressureCount,
                                                        bargeTemperatureCount,
                                                        &pressureValuePSI,
                                                        &temperatureValueCelsius);
//Modal("PBias = {0:F3} TBias = {1:F3}",
//    sensor->pressurePSIBias,
//    sensor->temperatureCelsiusBias);
//Modal("BPCount = {0}  BTC = {1}", bargePressureCount, bargeTemperatureCount);
                                                    pressureValuePSI += (DTSTest_NormalizeReadings ? sensor->pressurePSIBias : 0);
                                                    sensor->currentPressurePSI = pressureValuePSI;
                                                    temperatureValueCelsius += (DTSTest_NormalizeReadings ? sensor->temperatureCelsiusBias : 0);
                                                    sensor->currentTemperatureCelsius = temperatureValueCelsius;
                                                    if (readAndDisplayBargePressure)
                                                    {
                                                        pressureValueString = String::Format("{0:F3}", pressureValuePSI);
//                                                        if (readAndDisplayBargeTemperature)
                                                        {
                                                            if ((pressureValuePSI > 0.0) && (pressureValuePSI < 650.0))
                                                            {
                                                                bargePressureString += String::Concat(
                                                                    _T(" ("),
                                                                    pressureValueString,
                                                                    _T(" psi)"));
                                                                if (testEntry->entryTestResults != DTSTEST_TEST_RESULT_FAILED)
                                                                    testEntry->entryTestResults = DTSTEST_TEST_RESULT_PASSED;
                                                            }
                                                            else
                                                            {
                                                                bargePressureString += String::Concat(
                                                                    _T(" (invalid pressure value "),
                                                                    pressureValueString,
                                                                    _T(" psi out of range)"));
                                                                failureEncountered = GUI_YES;
                                                                testEntry->entryTestResults = DTSTEST_TEST_RESULT_FAILED;
                                                                generalCSVEntry->loggedCSVInterpretationString = _T("Bounds error");
                                                            }
                                                            if (DTSTest_TestingRunning)
                                                                testEntry->entryPressureLabel->Text = pressureValueString;
                                                        }
//                                                        else
//                                                        {
//                                                            bargePressureString +=
//                                                                _T(" (temperature unavailable to calculate pressure psi)");
//                                                            if (DTSTest_TestingRunning)
//                                                                testEntry->entryTemperatureLabel->Text = DTSTEST_STRING_UNKNOWN;
//                                                        }
                                                        generalCSVEntry->loggedCSVPressureActualString = pressureValueString;
//failureException = GUI_YES;
                                                    }
                                                    if (readAndDisplayBargeTemperature)
                                                    {
                                                        temperatureValueString = String::Format("{0:F3}", temperatureValueCelsius);
                                                        if ((temperatureValueCelsius > 0.0) && (temperatureValueCelsius < 300.0))
                                                        {
                                                            bargeTemperatureString += String::Concat(
                                                                _T(" ("),
                                                                temperatureValueString,
                                                                _T(" �C)"));
                                                            if (testEntry->entryTestResults != DTSTEST_TEST_RESULT_FAILED)
                                                                testEntry->entryTestResults = DTSTEST_TEST_RESULT_PASSED;
                                                        }
                                                        else
                                                        {
                                                            bargeTemperatureString += String::Concat(
                                                                _T(" (invalid temperature value "),
                                                                temperatureValueString,
                                                                _T(" �C out of range)"));
                                                            failureEncountered = GUI_YES;
                                                            testEntry->entryTestResults = DTSTEST_TEST_RESULT_FAILED;
                                                            generalCSVEntry->loggedCSVInterpretationString = _T("Bounds error");
                                                        }
                                                        if (DTSTest_TestingRunning)
                                                            testEntry->entryTemperatureLabel->Text = temperatureValueString;
                                                        generalCSVEntry->loggedCSVTemperatureActualString = temperatureValueString;
//failureException = GUI_YES;
                                                    }
                                                }
                                            }       // end of if (readAndDisplayBargePressure || readAndDisplayBargeTemperature)
                                            if (readAndDisplayBargeStatus)
                                            {
                                                bargeResultString += String::Concat(
                                                    Environment::NewLine,
                                                    bargeStatusString,
                                                    Environment::NewLine,
                                                    bargeStatusInterpretationString);
                                            }
                                            if (readAndDisplayBargeChipID)
                                            {
                                                bargeResultString += String::Concat(
                                                    Environment::NewLine,
                                                    bargeChipIDString);
                                            }
                                            if (readAndDisplayBargePressure)
                                            {
                                                bargeResultString += String::Concat(
                                                    Environment::NewLine,
                                                    bargePressureString);
                                            }
                                            if (readAndDisplayBargeTemperature)
                                            {
                                                bargeResultString += String::Concat(
                                                    Environment::NewLine,
                                                    bargeTemperatureString);
                                            }
                                            if (readAndDisplayBargeADC1 || readAndDisplayBargeADC2)
                                            {
                                                bargeResultString += String::Concat(
                                                    Environment::NewLine,
                                                    "        ",
                                                    (readAndDisplayBargeADC1 && readAndDisplayBargeADC2) ? "2 words" : "1 word",
                                                    " (ADC) at DTS memory address ",
                                                    String::Format("{0:X4}", readAndDisplayBargeADC1 ? DTSTEST_BARGE_ADC1_ADDRESS : DTSTEST_BARGE_ADC2_ADDRESS),
                                                    " : ");
                                                if (readAndDisplayBargeADC1)
                                                {
                                                    bargeResultString += bargeADC1String;
                                                }
                                                if (readAndDisplayBargeADC2)
                                                {
                                                    if (readAndDisplayBargeADC1)
                                                        bargeResultString += " ";
                                                    bargeResultString += bargeADC2String;
                                                }
                                            }
                                            if (readAndDisplayBargeOTP1 || readAndDisplayBargeOTP2)
                                            {
                                                bargeResultString += String::Concat(
                                                    Environment::NewLine,
                                                    "        ",
                                                    (readAndDisplayBargeOTP1 && readAndDisplayBargeOTP2) ? "2 words" : "1 word",
                                                    " (OTP) at DTS memory address ",
                                                    String::Format("{0:X4}", readAndDisplayBargeOTP1 ? DTSTEST_BARGE_OTP1_ADDRESS : DTSTEST_BARGE_OTP2_ADDRESS),
                                                    " : ");
                                                if (readAndDisplayBargeOTP1)
                                                {
                                                    bargeResultString += bargeOTP1String;
                                                }
                                                if (readAndDisplayBargeOTP2)
                                                {
                                                    if (readAndDisplayBargeOTP1)
                                                        bargeResultString += " ";
                                                    bargeResultString += bargeOTP2String;
                                                }
                                                if (readAndDisplayBargeOTP1)
                                                {
                                                    bargeResultString += String::Concat(
                                                        Environment::NewLine,
                                                        bargeOTP1InterpretationString);
                                                }
                                                if (readAndDisplayBargeOTP2)
                                                {
                                                    bargeResultString += String::Concat(
                                                        Environment::NewLine,
                                                        bargeOTP2InterpretationString);
                                                }
                                            }
                                        }           // end of if (readAndDisplayBargeStatus || ...)
                                    }               // end of if (targetIsGauge)
                                }           // end of if (pgInfo->responseArray[1] == MODBUS_COMMAND_READ_INPUT_REGISTERS)
                                else
                                {
                                    numberOfRemainingWords = replyWordCount - remainingBytesOffset;
                                }
                                replyString += titleString;
                                if (numberOfPrefixWords)
                                {
                                    String ^prefixString = String::Concat(
                                        numberOfPrefixWords,
                                        " word",
                                        ((numberOfPrefixWords == 1) ? "" : "s"),
                                        " at ",
                                        (targetIsGauge ? "gauge" : "DTS"),
                                        " memory address ",
                                        String::Format("{0:D2}", memoryAddress),
                                        " :");
                                    for (WORD count = 0; count < numberOfPrefixWords; count++)
                                        prefixString += String::Format(" 0x{0:X4}",
                                            ((pgInfo->responseArray[(count * 2) + DTSTEST_REPLY_HEADER_BYTES] << 8) | pgInfo->responseArray[(count * 2) + DTSTEST_REPLY_HEADER_BYTES + 1]));
                                    replyString += String::Concat(
                                        Environment::NewLine,
                                        "        ",
                                        prefixString);
                                    generalCSVEntry->loggedCSVPrefixString = prefixString;
                                }
                                if (StringSet(bargeResultString) || StringSet(gaugeResultString))
                                {
                                    if (StringSet(bargeResultString))
                                    {
                                        replyString += bargeResultString;
                                    }
                                    else
                                    {
                                        if (StringSet(gaugeResultString))
                                        {
                                            replyString += gaugeResultString;
                                        }
                                    }
                                }
                                numberOfRemainingWords = (WORD) (numberOfRemainingBytes > 0) ? (numberOfRemainingBytes / 2) : 0;
                                if (numberOfRemainingWords)
                                {
                                    String ^remainingString = String::Concat(
                                        numberOfRemainingWords,
                                        " word",
                                        ((numberOfRemainingWords == 1) ? "" : "s"),
                                        " at ",
                                        (targetIsGauge ? "gauge" : "DTS"),
                                        " memory address ",
                                        String::Format("{0:D2}", remainingBytesAddress),
                                        " :");
                                    if (numberOfRemainingWords > 8)
                                    {
                                        remainingString += String::Concat(
                                            Environment::NewLine,
                                            "            ");
                                        for (WORD count = 0; count < 8; count++)
                                            remainingString += String::Format(" 0x{0:X4}",
                                                ((pgInfo->responseArray[(count * 2) + remainingBytesOffset] << 8) | pgInfo->responseArray[(count * 2) + remainingBytesOffset + 1]));
                                        remainingString += String::Concat(
                                            Environment::NewLine,
                                            "            ");
                                        if (numberOfRemainingWords > 16)
                                        {
                                            for (WORD count = 8; count < 16; count++)
                                                remainingString += String::Format(" 0x{0:X4}",
                                                    ((pgInfo->responseArray[(count * 2) + remainingBytesOffset] << 8) | pgInfo->responseArray[(count * 2) + remainingBytesOffset + 1]));
                                            remainingString += String::Concat(
                                                Environment::NewLine,
                                                "            ");
                                            for (WORD count = 16; count < numberOfRemainingWords; count++)
                                                remainingString += String::Format(" 0x{0:X4}",
                                                    ((pgInfo->responseArray[(count * 2) + remainingBytesOffset] << 8) | pgInfo->responseArray[(count * 2) + remainingBytesOffset + 1]));
                                        }
                                        else
                                        {
                                            for (WORD count = 8; count < numberOfRemainingWords; count++)
                                                remainingString += String::Format(" 0x{0:X4}",
                                                    ((pgInfo->responseArray[(count * 2) + remainingBytesOffset] << 8) | pgInfo->responseArray[(count * 2) + remainingBytesOffset + 1]));
                                        }
                                    }
                                    else
                                    {
                                        for (WORD count = 0; count < numberOfRemainingWords; count++)
                                            remainingString += String::Format(" 0x{0:X4}",
                                                ((pgInfo->responseArray[(count * 2) + remainingBytesOffset] << 8) | pgInfo->responseArray[(count * 2) + remainingBytesOffset + 1]));
                                    }
                                    replyString += String::Concat(
                                        (numberOfPrefixWords || (StringSet(bargeResultString) || StringSet(gaugeResultString)) ? Environment::NewLine : String::Empty),
                                        "        ",
                                        remainingString);
                                    generalCSVEntry->loggedCSVRemainingString = remainingString;
                                }
                            }           // end of if (replyWordCount)
                            else
                            {
                                noDataReturned = GUI_YES;
                                replyString += _T("    !!! No data returned");
                                generalCSVEntry->loggedCSVInterpretationString = _T("No data");
                            }
                            break;
                        case MODBUS_COMMAND_WRITE_SINGLE_REGISTER :             // 0x06
                            switch (pgInfo->commandArray[3])
                            {
                                case 0x02 :
                                case 0x03 :
                                    {
                                        //------------------------------------
                                        // Set the gauge baud rate
                                        //------------------------------------
                                        String ^directionString = String::Empty;
                                        switch (pgInfo->commandArray[5])
                                        {
                                            case 0x2E : baudRate = 1200; directionString = _T("Rx");
                                                break;
                                            case 0xED : baudRate = 1200; directionString = _T("Tx");
                                                break;
                                            case 0x16 :
                                            case 0x17 : baudRate = 2400; directionString = _T("Rx");
                                                break;
                                            case 0x76 : baudRate = 2400; directionString = _T("Tx");
                                                break;
                                            case 0x0B : baudRate = 4800; directionString = _T("Rx");
                                                break;
                                            case 0xBB : baudRate = 4800; directionString = _T("Tx");
                                                break;
                                            default : baudRate = 0;
                                                break;
                                        }
                                        if (baudRate)
                                        {
                                            if (verboseMessages)
                                            {
                                                replyString += String::Concat(
                                                    String::Format(
                                                        "    Gauge {0} {1} now set to {2:D} baud",
                                                        nodeAddressString, directionString, baudRate));
                                            }
                                        }
                                        else
                                        {
                                            replyString += String::Format(
                                                "    !!! Gauge {0} {1} baud rate not modified",
                                                nodeAddressString, directionString);
                                        }
                                    }
                                    break;
                                case 0x0A :
                                    if (nodeAddress == DTSTEST_SENSOR_ADDRESS_BROADCAST)        // 0xFE
                                    {
                                        replyString += _T("    Sync successful");
                                        DTSTest_SyncEnabled = GUI_YES;
                                        testingSyncLEDLabel->Image = greenDotOnImage;
                                        generalCSVEntry->loggedCSVInterpretationString = _T("Sync");
                                    }
                                    else
                                    {
//                                        failureEncountered = GUI_YES;
                                        replyString += String::Format(
                                            "    Successful write of 0x{0:X4}",
                                            dataWord);
                                        generalCSVEntry->loggedCSVInterpretationString = _T("Write register");
                                    }
                                    break;
                                case 0x0B :
                                    //----------------------------------------
                                    // Set the barge baud rate
                                    //----------------------------------------
                                    switch (pgInfo->commandArray[5])
                                    {
                                        case 0 : baudRate = 600;
                                            break;
                                        case 1 : baudRate = 1200;
                                            DTSTest_BaudRateSetTo2400 = GUI_NO;
                                            break;
                                        case 2 : baudRate = 2400;
                                            DTSTest_BaudRateSetTo2400 = GUI_YES;
                                            break;
                                        default : baudRate = 0;
                                            break;
                                    }
                                    if (baudRate)
                                    {
                                        String ^whichBarges =
                                            (nodeAddress == DTSTEST_EXPERIMENTAL_ALL_BARGES_VALUE) ? "All DTS nodes" : String::Concat("DTS ", nodeAddressString);
                                        replyString += String::Concat(
                                            "    ",
                                            whichBarges,
                                            " now set to ",
                                            baudRate,
                                            " baud");
                                        pgInfo->baudRate = baudRate;
                                        homeSwitchBaudRateButton->Text = String::Concat(
                                            _T("Switch to "),
                                            (DTSTest_BaudRateSetTo2400 ? _T("1200") : _T("2400")),
                                            _T(" Baud"));
                                        homeBaudRateLabel->Text =
                                            DTSTest_BaudRateSetTo2400 ? _T("2400 Baud") : _T("1200 Baud");
                                    }
                                    else
                                    {
                                        replyString += String::Concat(
                                            "    !!! DTS baud rates not modified");
                                    }
                                    break;
                                default :
//                                    WORD controlFT = (WORD) (pgInfo->commandArray[4] << 8) | pgInfo->commandArray[5];
//                                    if (controlFT == DTSTEST_GAUGE_TOOLHEAD_PASSWORD)
                                    if (dataWord == DTSTEST_GAUGE_TOOLHEAD_PASSWORD)
                                    {
                                        replyString += String::Concat(
                                            _T("    Successfully set feedthru control from gauge "),
                                            nodeAddressString);
                                    }
                                    break;
                            }           // end of switch (pgInfo->commandArray[3])
                            break;
                        case MODBUS_COMMAND_WRITE_MULTIPLE_COILS :              // 0x0F
                            if ((pgInfo->commandArray[5] == 0x10) && (pgInfo->commandArray[6] == 0x02))
                            {
                                if (pgInfo->commandArray[7] == 0x03)
                                {
                                    pgInfo->powerToBargesEnabled = GUI_NO;
                                    if (nodeAddress == 0x00)
                                    {
                                        replyString +=
                                            _T("    Successfully disabled DTS power from all gauges");
                                    }
                                    else
                                    {
                                        replyString += String::Concat(
                                            _T("    Successfully disabled DTS power from gauge "),
                                            nodeAddressString);
                                    }
                                }
                                if (pgInfo->commandArray[7] == 0x0F)
                                {
                                    pgInfo->powerToBargesEnabled = GUI_YES;
                                    if (nodeAddress == 0x00)
                                    {
                                        replyString +=
                                            _T("    Successfully enabled DTS power from all gauges");
                                    }
                                    else
                                    {
                                        replyString += String::Concat(
                                            _T("    Successfully enabled DTS power from gauge "),
                                            nodeAddressString);
                                    }
                                }
                            }
                            break;
                        default :
                            //------------------------------------------------
                            // Illegal command, but let it go; only log it
                            //------------------------------------------------
                            failureEncountered = GUI_YES;
                            RecordErrorEvent("    {0} : Response to illegal command '0x{1:X2}'",
                                functionName,
                                functionCode);
                            break;
                    }                   // end of switch (functionCode)
                }                       // end of else of if ((pgInfo->responseArray[1] & 0x80) == 0x80)
                if (StringSet(generalCSVEntry->loggedCSVErrorString))
                    generalCSVEntry->loggedCSVResultString = _T("Fail");
                else
                    generalCSVEntry->loggedCSVResultString = _T("Pass");
//                    generalCSVEntry->loggedCSVResultString = StringSet(errorString) ? _T("Fail") : _T("Pass");
                replyString += errorString;
            }                           // end of if (DTSTest_PDGICSuccessfulReply && (status == DTSTEST_SUCCESS))
            else
            {
                //------------------------------------------------------------
                // Evaluate the error code
                //------------------------------------------------------------
                if (status == DTSTEST_SUCCESS)
                {
                    replyString += String::Format(
                        "    !!! Command '{0:X2}' failed", functionCode);
                    generalCSVEntry->loggedCSVErrorString = String::Format(
                        "Command '{0:X2}' failed,", functionCode);
                }
                else
                {
                    String ^failureMessage = _T("Unknown failure");
                    switch (status)
                    {
                        case DTSTEST_ERROR_COMMAND_FAILED :                     // 0x00000050
                            failureMessage = _T("Invalid response to a valid command");
                            generalCSVEntry->loggedCSVInterpretationString = _T("Invalid reply");
                            break;
                        case DTSTEST_ERROR_ILLEGAL_COMMAND :                    // 0x00000051
                            failureMessage = _T("Not a valid MODBUS command");
                            generalCSVEntry->loggedCSVInterpretationString = _T("Invalid command");
                            break;
                        case DTSTEST_ERROR_UNSUPPORTED_COMMAND :                // 0x00000052
                            failureMessage = _T("Command not supported");
                            generalCSVEntry->loggedCSVInterpretationString = _T("Invalid command");
                            break;
                        case DTSTEST_ERROR_INVALID_REPLY_DATA :                 // 0x00000053
                            failureMessage = _T("Invalid reply data");
                            generalCSVEntry->loggedCSVInterpretationString = _T("Invalid reply");
                            break;
                        case DTSTEST_ERROR_UNSUPPORTED_TARGET :                 // 0x00000054
                            failureMessage = String::Format(
                                "No device found at MODBUS node address 0x{0:X2}",
                                nodeAddress);
                            generalCSVEntry->loggedCSVInterpretationString = _T("Invalid MODBUS address");
                            break;
                        case DTSTEST_ERROR_COMMAND_CRC_INVALID :                // 0x00000055
                            failureMessage = _T("Command CRC is incorrect");
                            generalCSVEntry->loggedCSVInterpretationString = _T("Bad CRC");
                            break;
                        case DTSTEST_ERROR_DATA_CRC_INVALID :                   // 0x00000056
                            failureMessage = _T("Returned CRC is incorrect");
                            generalCSVEntry->loggedCSVInterpretationString = _T("Bad CRC returned");
                            break;
                        case DTSTEST_ERROR_INVALID_BROADCAST_INSTANCE :         // 0x00000058
                            failureMessage = _T("Not permitted for this type of broadcast");
                            generalCSVEntry->loggedCSVInterpretationString = _T("Not permitted");
                            break;
                        case DTSTEST_ERROR_INVALID_BROADCAST_COMMAND :          // 0x00000059
                            failureMessage = _T("Not permitted for broadcast");
                            generalCSVEntry->loggedCSVInterpretationString = _T("Not permitted");
                            break;
                        case DTSTEST_ERROR_PDGIC_PORT_NAME_MISSING :            // 0x000000C4
                            failureMessage = _T("PDGIC serial port not identified");
                            generalCSVEntry->loggedCSVInterpretationString = _T("Invalid serial port");
                            break;
                        case DTSTEST_ERROR_PDGIC_PORT_IN_USE :                  // 0x000000C5
                            failureMessage = String::Format(
                                "PDGIC serial port {0} is in use",
                                pgInfo->portName);
                            generalCSVEntry->loggedCSVInterpretationString = _T("Serial port in use");
                            break;
                        case DTSTEST_ERROR_PDGIC_PORT_UNKNOWN_FAILURE :         // 0x000000CF
                            failureMessage = String::Format(
                                "Could not open PDGIC serial port {0} (not in use)",
                                pgInfo->portName);
                            generalCSVEntry->loggedCSVInterpretationString = _T("Serial port in use");
                            break;
                        default :
                            failureMessage = String::Format(
                                "Unknown failure 0x{0:X8}", status);
                            generalCSVEntry->loggedCSVInterpretationString = _T("Unknown error");
                            break;
                    }                   // end of switch (status)
                    replyString += String::Format(
                        "    !!! Command '{0:X2}' : {1}",
                        functionCode, failureMessage);
                    generalCSVEntry->loggedCSVErrorString = String::Format(
                        "Command '{0:X2}' : {1},", functionCode, failureMessage);
//                    generalCSVEntry->loggedCSVInterpretationString = failureMessage;
                }                       // end of else of if (status == DTSTEST_SUCCESS)
                failureEncountered = GUI_YES;
                status = DTSTEST_ERROR_COMMAND_FAILED;                          // 0x00000050
                generalCSVEntry->loggedCSVResultString = _T("Fail");
            }                           // end of else of if (DTSTest_PDGICSuccessfulReply)
        }                               // end of if (DTSTest_GeneralInfo->pgInfo)
        else
        {
            status = DTSTEST_ERROR_PDGIC_INFO_POINTER_INVALID;                  // 0x000000C1
        }
    }                                   // end of if (commandArray && commandArray->Length && numberOfBytesToSend)
    //------------------------------------------------------------------------
    // If the reported interpretation matches what was expected, it is not an
    // error
    //------------------------------------------------------------------------
    if (!replyDataString->Contains(generalCSVEntry->loggedCSVExpectedString))
        failureEncountered = GUI_YES;
    if (failureException)
        failureEncountered = GUI_NO;
    if (StringICompare(generalCSVEntry->loggedCSVInterpretationString, generalCSVEntry->loggedCSVExpectedString) == 0)
        failureEncountered = GUI_NO;
    if (noDataReturned && ((StringICompare(generalCSVEntry->loggedCSVExpectedString, "no data") == 0) ||
        (StringICompare(generalCSVEntry->loggedCSVExpectedString, "bad crc") == 0)))
        failureEncountered = GUI_NO;
    if (failureEncountered)
    {
        DTSTest_GeneralInfo->mainScript->scriptNumberOfFailures++;
        generalCSVEntry->loggedCSVResultString = _T("Fail");
    }
    else
    {
        DTSTest_GeneralInfo->mainScript->scriptNumberOfPasses++;
        generalCSVEntry->loggedCSVResultString = _T("Pass");
    }
    RecordVerboseEvent("    {0}", replyString);
    RecordDetailedEvent("{0} concluded", functionName);
    return replyString;
}                                       // end of DTSTest_SendCommandArray()
//----------------------------------------------------------------------------
// DTSTest_SwitchBaudRate
//
// Switches the system-wide baud rate and updates the home labels accordingly
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_SwitchBaudRate(void)
{
//    DWORD           status = DTSTEST_SUCCESS;
    String          ^functionName = _T("DTSTest_SwitchBaudRate");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0} called", functionName);
    DTSTest_SetDisplayBaudRate(DTSTest_BaudRateSetTo2400 ? 1200 : 2400);
    RecordBasicEvent("{0} concluded", functionName);
}                                       // end of DTSTest_SwitchBaudRate()
//----------------------------------------------------------------------------
// DTSTest_Sync
//
// Issues the Sync command to the DTS system
//
// Called by:   DTSTest_ExperimentalSyncAllButtonClicked
//              DTSTest_ExperimentalSyncB4ButtonClicked
//              DTSTest_ExperimentalSyncE2ButtonClicked
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_Sync(void)
{
    PDGICInfo       ^pgInfo = DTSTest_GeneralInfo->pgInfo;
    String          ^functionName = _T("DTSTest_Sync");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0} called", functionName);
    if (pgInfo->powerToBargesEnabled)
    {
        pgInfo->commandArray[1] = MODBUS_COMMAND_WRITE_SINGLE_REGISTER;         // 0x06
        pgInfo->commandArray[2] = 0;
        pgInfo->commandArray[3] = 0x0A;
        pgInfo->commandArray[4] = 0;
        pgInfo->commandArray[5] = 1;
        pgInfo->startingRegisterOffset = 0x000A;
        pgInfo->writeData = 0x01;
        pgInfo->numberOfCommandBytes = 8;
        DTSTest_PDGICSendRawCommand(pgInfo);
        if (DTSTest_PDGICSuccessfulReply)
        {
        }
    }
    else
    {
        Modal("!!! Barge power from {0:X2} is not enabled", pgInfo->commandArray[0]);
    }
    RecordBasicEvent("{0} concluded", functionName);
}                                       // end of DTSTest_Sync()
//----------------------------------------------------------------------------
// DTSTest_SendSync
//
// Issues the Sync command to the DTS system
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_SendSync(
    bool            testingContext)
{
    String          ^functionName = _T("DTSTest_SendSync");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0} called", functionName);
    String ^scriptLineString = _T("sync"); //_T("FE 06 00 0A 00 01");
    DTSTest_CommandDialogueAppendLine(
        String::Concat(scriptLineString, Environment::NewLine));
    bool originalCRCOnState = DTSTest_CalculateCRCs;
    DTSTest_SetCalculateCRCs(GUI_YES);
    String ^interpretationString = DTSTest_ReturnScriptCommandInterpretationString(
        scriptLineString,
        testingContext);
    DTSTest_SetCalculateCRCs(originalCRCOnState);
    DTSTest_FileCreateCSVEntry(generalCSVEntry, GUI_CSV_REGULAR_ENTRY);
    if (StringSet(interpretationString))
        interpretationString += Environment::NewLine;
    if (StringSet(scriptLineString))
    {
        bool originalDateAndTimeState = DTSTest_PrependDateAndTime;
        DTSTest_PrependDateAndTime = GUI_NO;
        DTSTest_CommandDialogueAppendLine(interpretationString);
        DTSTest_PrependDateAndTime = originalDateAndTimeState;
    }
    RecordBasicEvent("{0} concluded", functionName);
}                                       // end of DTSTest_SendSync()
//----------------------------------------------------------------------------
#endif      // TOOLS_CPP
//============================================================================
// End of Tools.cpp
//============================================================================
