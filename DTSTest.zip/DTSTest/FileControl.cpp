//============================================================================
// FileControl.cpp
//
// The methods for control and manipulation of the log and CSV files
//
// Copyright (C) 2014 - 2016 Quartzdyne, Inc.  All rights reserved.
//
// No part of this source code may be reproduced or transmitted in any form or
// by any means, electronic or mechanical, including photocopying, recording,
// or any information storage and retrieval system, without express written
// permission from Quartzdyne, Inc.  Further, no use of this source code is
// permitted in any form or means without a valid, written license agreement
// with Quartzdyne, Inc.  While every reasonable precaution has been taken in
// the preparation of this source code, Quartzdyne, Inc., assumes no
// responsibility for errors, omissions, or damages from the use of the source
// code contained herein.
//
// NEITHER QUARTZDYNE, INC., ANY MEMBER OF QUARTZDYNE, INC., NOR ANY PERSON OR
// ORGANIZATION ACTING ON BEHALF OF THEM MAKES ANY WARRANTY OR REPRESENTATION
// WHATSOEVER, EXPRESS OR IMPLIED, INCLUDING ANY WARRANTY OF MERCHANTABILITY
// OR FITNESS FOR ANY PURPOSE WITH RESPECT TO THE SOURCE CODE OR ASSUMES ANY
// LIABILITY WHATSOEVER WITH RESPECT TO ANY USE OF THE SOURCE CODE OR ANY
// PORTION THEREOF OR WITH RESPECT TO ANY DAMAGES THAT MAY RESULT FROM SUCH
// USE.
//
// Noji Ratzlaff
//
// See DTSTest.log for a complete history of all updates, changes, and revisions
// of this source and other files and policies regarding DTSTest software
//
// Updated 01-14-2016
//============================================================================
#include    "stdafx.h"
#ifndef     FILECONTROL_CPP
#define     FILECONTROL_CPP
#include    "FileControl.h"
//----------------------------------------------------------------------------
// DTSTest_AppendLineToCSVLog
//
// Appends the CSV log with the specified text
//
// Note: if the CSV log doesn't exist, this method will create the file
//
// Note: this method also appends an Environment::NewLine to the text
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_AppendLineToCSVLog(
    String          ^csvLineString)
{
    DateTime        dateTime = DateTime::Now;
    String          ^functionName = _T("DTSTest_AppendLineToCSVLog");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0} called", functionName);
    if (StringSet(csvLineString))
    {
        String ^csvPathString = DTSTest_GeneralInfo->mainScript->resultsLogFilePath->Replace(
            Path::GetExtension(DTSTest_GeneralInfo->mainScript->resultsLogFilePath), ".csv");
        //--------------------------------------------------------------------
        // Encode as ISO-8859 for the degree � symbol
        //--------------------------------------------------------------------
        StreamWriter ^textWriter = gcnew StreamWriter(
            csvPathString,
            GUI_YES,
            Encoding::GetEncoding("ISO-8859-15"));
        if (textWriter)
        {
            textWriter->WriteLine(csvLineString);
            textWriter->Close();
        }                           // end of if (textWriter)
    }                               // end of if (StringSet(csvLineString))
    else
    {
        RecordBasicEvent("    Log CSV string is empty");
    }
    RecordBasicEvent("{0} concluded", functionName);
}                                       // end of DTSTest_AppendLineToCSVLog()
//----------------------------------------------------------------------------
// DTSTest_AppendLineToDataLog
//
// Appends the data log with the specified text
//
// Note: if the data log doesn't exist, this method will create the file
//
// Note: this method also appends an Environment::NewLine to the text
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_AppendLineToDataLog(
    String          ^logLineString)
{
    DateTime        dateTime = DateTime::Now;
    String          ^functionName = _T("DTSTest_AppendLineToDataLog");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0} called", functionName);
    if (StringSet(logLineString))
    {
        StreamWriter ^textWriter = File::AppendText(
            DTSTest_GeneralInfo->mainScript->resultsLogFilePath);
        if (textWriter)
        {
            textWriter->WriteLine(logLineString);
            textWriter->Close();
        }                           // end of if (textWriter)
    }                               // end of if (StringSet(logLineString))
    else
    {
        RecordBasicEvent("    Log text string is empty");
    }
    RecordBasicEvent("{0} concluded", functionName);
}                                       // end of DTSTest_AppendLineToDataLog()
//----------------------------------------------------------------------------
// DTSTest_FileControlsCloseWindow
//
// Event that closes the File Controls display window
//
// Called by:   DTSTest_FileControlsSetUpWindow
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_FileControlsCloseWindow(
    Object          ^sender,
    EventArgs       ^evt)
{
    //------------------------------------------------------------------------
    RecordBasicEvent("File Controls window closed");
    if (fileControlsWindow)
    {
        fileControlsWindow->Hide();
    }
}                                       // end of DTSTest_FileControlsCloseWindow()
//----------------------------------------------------------------------------
// DTSTest_FileControlsClosingWindow
//
// Handles the closing of the File Controls window by the red X
//
// Called by:   DTSTest_FileControlsSetUpWindow
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_FileControlsClosingWindow(
    Object          ^sender,
    FormClosingEventArgs
                    ^evt)
{
    //------------------------------------------------------------------------
    evt->Cancel = GUI_YES;              // cancel the closing of the window
    RecordBasicEvent("File Controls window closed");
    if (fileControlsWindow)
    {
        fileControlsWindow->Hide();
    }
}                                       // end of DTSTest_FileControlsClosingWindow()
//----------------------------------------------------------------------------
// DTSTest_FileControlsSetUpWindow
//
// Displays File controls in a new window
//
// Called by:   DTSTest_InstallUtilities
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_FileControlsSetUpWindow(void)
{
    SensorInfo      ^sensor = nullptr;
    PDGICInfo       ^pgInfo = DTSTest_GeneralInfo->pgInfo;
    String          ^functionName = _T("DTSTest_FileControlsSetUpWindow");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0} called", functionName);
    if (DTSTest_GeneralInfo)
    {
        //--------------------------------------------------------------------
        // Create a new window form each time this is called, due to the
        // dynamic nature of the program values
        //--------------------------------------------------------------------
        fileControlsWindow = gcnew Form;
        fileControlsWindow->SuspendLayout();
        //--------------------------------------------------------------------
        // Set its properties
        //--------------------------------------------------------------------
        fileControlsWindow->MaximizeBox = GUI_NO;
        fileControlsWindow->HelpButton = GUI_NO;
        //--------------------------------------------------------------------
        // Set its icon
        //--------------------------------------------------------------------
        fileControlsWindow->Icon = DTSTest_SoftwareIcon;
        //--------------------------------------------------------------------
        // Set the background image
        //--------------------------------------------------------------------
    //        fileControlsWindow->BackgroundImage = whiteSandBackground;
        //--------------------------------------------------------------------
        // Set the title and border style
        //--------------------------------------------------------------------
        fileControlsWindow->Text = _T("DTSTest File Controls");
        fileControlsWindow->FormBorderStyle = ::FormBorderStyle::Fixed3D;
        //--------------------------------------------------------------------
        // Set the dimensions of the File Controls window
        //--------------------------------------------------------------------
        fileControlsWindow->Size = Drawing::Size(
            GUI_FILE_CONTROLS_WINDOW_WIDTH,
            GUI_FILE_CONTROLS_WINDOW_HEIGHT);
        for (int offset = 0; offset < DTSTEST_MAXIMUM_NUMBER_OF_PLACEHOLDERS; offset++)
        {
            int index = offset + 1;
//            ScriptPlaceholder ^placeholder = DTSTest_ScriptPlaceholderArray[offset];
//            //----------------------------------------------------------------
//            // Placeholder label
//            //----------------------------------------------------------------
//            placeholder->placeholderLabel = gcnew Label;
//            placeholder->placeholderLabel->Text = String::Concat(
//                DTSTEST_STRING_DOLLAR, index, _T(" :"));
//            if (offset == 0)
//            {
//                placeholder->placeholderLabel->Location = Point(10, 20);
//                placeholder->placeholderLabel->Size = Drawing::Size(30, GUI_INFO_LABEL_HEIGHT);
//                placeholder->placeholderLabel->BackColor = Color::Transparent;
//            }
//            else
//            {
//                GUI_PositionAndSizeBelow(
//                    placeholder->placeholderLabel,
//                    DTSTest_ScriptPlaceholderArray[offset - 1]->placeholderLabel,
//                    8);
//            }
//            placeholder->placeholderLabel->TextAlign = Drawing::ContentAlignment::MiddleLeft;
//            fileControlsWindow->Controls->Add(placeholder->placeholderLabel);
//            //----------------------------------------------------------------
//            // Placeholder text box
//            //----------------------------------------------------------------
//            placeholder->placeholderBox = gcnew TextBox;
//            placeholder->placeholderBox->Tag = index;
//            placeholder->placeholderBox->Text = String::Format(
//                "{0:X2}", placeholder->placeholderValue);
//            placeholder->placeholderBox->Location = Point(
//                placeholder->placeholderLabel->Right + 2,
//                placeholder->placeholderLabel->Top - 2);
//            placeholder->placeholderBox->Size = Drawing::Size(
//                30,
//                GUI_REGULAR_TEXT_BOX_HEIGHT);
//            placeholder->placeholderBox->Multiline = GUI_NO;
//            placeholder->placeholderBox->AcceptsReturn = GUI_NO;
//            placeholder->placeholderBox->AcceptsTab = GUI_NO;
//            placeholder->placeholderBox->WordWrap = GUI_NO;
//            placeholder->placeholderBox->TextAlign = HorizontalAlignment::Center;
//            placeholder->placeholderBox->BackColor = Color::White;
//            placeholder->placeholderBox->CharacterCasing = CharacterCasing::Upper;
//            placeholder->placeholderBox->Validating +=
//                gcnew CancelEventHandler(this, &DTSTest_GUIClass::DTSTest_ValidateScriptPlaceholderValue);
//            fileControlsWindow->Controls->Add(placeholder->placeholderBox);
//            //----------------------------------------------------------------
//            // Placeholder Load Coefficient Data button
//            //----------------------------------------------------------------
//            placeholder->placeholderButton = gcnew Button;
//            placeholder->placeholderButton->Tag = index;
//            placeholder->placeholderButton->Text = _T("Load Coefficient Data");
//            placeholder->placeholderButton->Location = Point(
//                placeholder->placeholderBox->Right + 6,
//                placeholder->placeholderBox->Top - 1);
//            placeholder->placeholderButton->Size = Drawing::Size(140, GUI_NARROW_BUTTON_HEIGHT);
//            GUI_SetButtonInterfaceProperties(placeholder->placeholderButton);
//            placeholder->placeholderButton->Click +=
//                gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_ScriptPlaceholderLoadEraseButtonClicked);
//            placeholder->placeholderButton->Enabled = GUI_NO;
//            fileControlsWindow->Controls->Add(placeholder->placeholderButton);
//            //----------------------------------------------------------------
//            // Initialize remaining fields
//            //----------------------------------------------------------------
//            placeholder->coefficientDataLoaded = GUI_NO;
        }                               // end of for (int offset = 0; ...)
//        //--------------------------------------------------------------------
//        // Auto Load Coefficient Data check box
//        //--------------------------------------------------------------------
//        CheckBox ^scriptAutoLoadCFDataCheck = gcnew CheckBox;
//        scriptAutoLoadCFDataCheck->Text = _T("Automatically load coefficient data");
//        scriptAutoLoadCFDataCheck->Location = Point(
//            10, (DTSTEST_MAXIMUM_NUMBER_OF_PLACEHOLDERS * (GUI_NARROW_BUTTON_HEIGHT + 4)) + 2);
//        scriptAutoLoadCFDataCheck->Size = Drawing::Size(200, GUI_REGULAR_CHECK_BOX_HEIGHT);
//        GUI_SetObjectInterfaceProperties(scriptAutoLoadCFDataCheck);
//        scriptAutoLoadCFDataCheck->Click +=
//            gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_ScriptAutoLoadCFDataChecked);
//        fileControlsWindow->Controls->Add(scriptAutoLoadCFDataCheck);
//        //--------------------------------------------------------------------
//        // Auto Load Coefficient Data check box tool tip
//        //--------------------------------------------------------------------
//        ToolTip ^scriptAutoLoadCFDataCheckToolTip = gcnew ToolTip;
//        scriptAutoLoadCFDataCheckToolTip->ShowAlways = GUI_YES;
//        scriptAutoLoadCFDataCheckToolTip->AutoPopDelay = 10000;     // let stand for ten seconds
//        scriptAutoLoadCFDataCheckToolTip->ToolTipTitle =
//            _T("Auto Load Coefficient Data");
//        String ^scriptAutoLoadCFDataCheckToolTipText = String::Concat(
//            "When checked, the software will automatically", Environment::NewLine,
//            "load the appropriate coefficient data for the", Environment::NewLine,
//            "sensor whose address is added to the", Environment::NewLine,
//            "placeholder list");
//        scriptAutoLoadCFDataCheckToolTip->SetToolTip(scriptAutoLoadCFDataCheck, scriptAutoLoadCFDataCheckToolTipText);
//        delete scriptAutoLoadCFDataCheckToolTipText;
//        //--------------------------------------------------------------------
//        // Clear All Placeholders button
//        //--------------------------------------------------------------------
//        Button ^scriptClearAllPlaceholdersButton = gcnew Button;
//        scriptClearAllPlaceholdersButton->Text = _T("Clear All Placeholders");
//        scriptClearAllPlaceholdersButton->Location = Point(
//            10, scriptAutoLoadCFDataCheck->Bottom + 6);
//        scriptClearAllPlaceholdersButton->Size = Drawing::Size(180, GUI_REGULAR_BUTTON_HEIGHT);
//        scriptClearAllPlaceholdersButton->BackColor = Color::Transparent;
//        GUI_SetButtonInterfaceProperties(scriptClearAllPlaceholdersButton);
//        scriptClearAllPlaceholdersButton->Click +=
//            gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_ScriptClearAllPlaceholdersButtonClicked);
//        fileControlsWindow->Controls->Add(scriptClearAllPlaceholdersButton);
//        //--------------------------------------------------------------------
//        // Clear All Placeholders button tool tip
//        //--------------------------------------------------------------------
//        ToolTip ^scriptClearAllPlaceholdersButtonToolTip = gcnew ToolTip;
//        scriptClearAllPlaceholdersButtonToolTip->ShowAlways = GUI_YES;
//        scriptClearAllPlaceholdersButtonToolTip->AutoPopDelay = 10000;   // let stand for ten seconds
//        scriptClearAllPlaceholdersButtonToolTip->ToolTipTitle =
//            _T("Clear All Placeholders");
//        String ^scriptClearAllPlaceholdersButtonToolTipText = String::Concat(
//            "Sets all the script placeholders to 00");
//        scriptClearAllPlaceholdersButtonToolTip->SetToolTip(scriptClearAllPlaceholdersButton, scriptClearAllPlaceholdersButtonToolTipText);
//        delete scriptClearAllPlaceholdersButtonToolTipText;
        //--------------------------------------------------------------------
        // Add a Close button
        //--------------------------------------------------------------------
        Button ^closeButton = gcnew Button;
        closeButton->Text = _T("Close");
        closeButton->Location = Point(
            fileControlsWindow->Right - 100,
            fileControlsWindow->Bottom - 70);
        closeButton->Size = Drawing::Size(
            GUI_CLOSE_BUTTON_WIDTH,
            GUI_REGULAR_BUTTON_HEIGHT);
        GUI_SetButtonInterfaceProperties(closeButton);
        closeButton->DialogResult = System::Windows::Forms::DialogResult::OK;
        closeButton->Click +=
            gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_FileControlsCloseWindow);
        fileControlsWindow->Controls->Add(closeButton);
        //------------------------------------------------------------------------
        // Handle the closing of the window by any other way
        //------------------------------------------------------------------------
        fileControlsWindow->FormClosing +=
            gcnew FormClosingEventHandler(this, &DTSTest_GUIClass::DTSTest_FileControlsClosingWindow);
        //--------------------------------------------------------------------
        // Set the remaining window properties
        //--------------------------------------------------------------------
        fileControlsWindow->AcceptButton = closeButton;
        fileControlsWindow->CancelButton = closeButton;
        //--------------------------------------------------------------------
        // Finally, hide the new window
        //--------------------------------------------------------------------
        fileControlsWindow->ResumeLayout();
        fileControlsWindow->Hide();
    }                                   // end of if (DTSTest_GeneralInfo)
    RecordBasicEvent("{0} concluded", functionName);
}                                       // end of DTSTest_FileControlsSetUpWindow()
//----------------------------------------------------------------------------
// DTSTest_FileCreateCSVEntry
//
// Creates the CSV entry line from all the structure components, appends the
// entry to the ongoing CSV file, along with the current date and time, and
// clears the structure
//
// Called by:   DTSTest_FileInitializeCSVHeader
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_FileCreateCSVEntry(
    CSVEntryInfo    ^entry,
    bool            isHeaderEntry)
{
    DateTime        dateTime = DateTime::Now;
    String          ^functionName = _T("DTSTest_FileCreateCSVEntry");
    //------------------------------------------------------------------------
    RecordDetailedEvent("{0} called", functionName);
    if (entry)
    {
        if (!isHeaderEntry)
        {
            entry->loggedCSVDateString = String::Format(
                "{0:D2}-{1}-{2:D4}",
                dateTime.Day,
                DTSTest_MonthStringArray[dateTime.Month],
                dateTime.Year);
            entry->loggedCSVTimeString = String::Format(
                " {0:D2}:{1:D2}:{2:D2}.{3:D3}",
                dateTime.Hour,
                dateTime.Minute,
                dateTime.Second,
                dateTime.Millisecond);
            if (entry->logCSVState)
            {
                entry->loggedCSVBaudRateStateString = DTSTest_BaudRateSetTo2400 ? DTSTEST_STRING_2400_BAUD : DTSTEST_STRING_1200_BAUD;
                entry->loggedCSVCRCStateString = DTSTest_CalculateCRCs ? DTSTEST_STRING_CRC_ON : DTSTEST_STRING_CRC_OFF;
                entry->loggedCSVStateString = String::Concat(
                    entry->loggedCSVBaudRateStateString,
                    DTSTEST_STRING_SLASH,
                    entry->loggedCSVCRCStateString);
                if (entry->logCSVSyncState && StringSet(entry->loggedCSVSyncStateString))
                    entry->loggedCSVStateString = String::Concat(
                        entry->loggedCSVStateString,
                        DTSTEST_STRING_SLASH,
                        entry->loggedCSVSyncStateString);
                if (entry->logCSVFreshState && StringSet(entry->loggedCSVFreshStateString))
                    entry->loggedCSVStateString = String::Concat(
                        entry->loggedCSVStateString,
                        DTSTEST_STRING_SLASH,
                        entry->loggedCSVFreshStateString);
                if (entry->logCSVCableLengthState && StringSet(entry->loggedCSVCableLengthStateString))
                    entry->loggedCSVStateString = String::Concat(
                        entry->loggedCSVStateString,
                        DTSTEST_STRING_SLASH,
                        entry->loggedCSVCableLengthStateString);
                if (entry->logCSVTempState && StringSet(entry->loggedCSVTempStateString))
                    entry->loggedCSVStateString = String::Concat(
                        entry->loggedCSVStateString,
                        DTSTEST_STRING_SLASH,
                        entry->loggedCSVTempStateString);
                if (entry->logCSVVoltageState && StringSet(entry->loggedCSVVoltageStateString))
                    entry->loggedCSVStateString = String::Concat(
                        entry->loggedCSVStateString,
                        DTSTEST_STRING_SLASH,
                        entry->loggedCSVVoltageStateString);
            }                           // end of if (entry->logCSVState)
        }                               // end of if (!isHeaderEntry)
        //--------------------------------------------------------------------
        // Remove the commas from the comments because these are user-entered
        //--------------------------------------------------------------------
        if (entry->loggedCSVInstructionalCommentString->Contains(DTSTEST_STRING_COMMA))
            entry->loggedCSVInstructionalCommentString =
                entry->loggedCSVInstructionalCommentString->Replace(DTSTEST_STRING_COMMA, String::Empty);
        if (entry->loggedCSVCommentString->Contains(DTSTEST_STRING_COMMA))
            entry->loggedCSVCommentString =
                entry->loggedCSVCommentString->Replace(DTSTEST_STRING_COMMA, String::Empty);
        //--------------------------------------------------------------------
        // Compile the entry
        //--------------------------------------------------------------------
        entry->loggedCSVEntryString = String::Concat(
            entry->loggedCSVHardwareIDString->Trim(), DTSTEST_STRING_COMMA,
            entry->loggedCSVDateString, DTSTEST_STRING_COMMA,
            entry->loggedCSVTimeString, DTSTEST_STRING_COMMA,
////////            entry->loggedCSVInputString->Trim(), DTSTEST_STRING_COMMA,
            entry->loggedCSVDelayString->Trim(), DTSTEST_STRING_COMMA,
            entry->loggedCSVInstructionalCommentString->Trim(), DTSTEST_STRING_COMMA,
////////            entry->loggedCSVAddressString->Trim(), DTSTEST_STRING_COMMA,
            entry->loggedCSVCommandString->Trim(), DTSTEST_STRING_COMMA,
            entry->loggedCSVSentString->Trim(), DTSTEST_STRING_COMMA,
            entry->loggedCSVExpectedString->Trim(), DTSTEST_STRING_COMMA,
            entry->loggedCSVReplyString->Trim(), DTSTEST_STRING_COMMA,
            entry->loggedCSVStateString->Trim(), DTSTEST_STRING_COMMA,
////////            entry->loggedCSVPrefixString->Trim(), DTSTEST_STRING_COMMA,
////////            entry->loggedCSVStatusString->Trim(), DTSTEST_STRING_COMMA,
////////            entry->loggedCSVChipIDString->Trim(), DTSTEST_STRING_COMMA,
////////            entry->loggedCSVOTPString->Trim(), DTSTEST_STRING_COMMA,
////////            entry->loggedCSVPressureCountHexString->Trim(), DTSTEST_STRING_COMMA,
////////            entry->loggedCSVPressureCountDecimalString->Trim(), DTSTEST_STRING_COMMA,
            entry->loggedCSVPressureActualString->Trim(), DTSTEST_STRING_COMMA,
////////            entry->loggedCSVTemperatureCountHexString->Trim(), DTSTEST_STRING_COMMA,
////////            entry->loggedCSVTemperatureCountDecimalString->Trim(), DTSTEST_STRING_COMMA,
            entry->loggedCSVTemperatureActualString->Trim(), DTSTEST_STRING_COMMA,
////////            entry->loggedCSVTypeString->Trim(), DTSTEST_STRING_COMMA,
////////            entry->loggedCSVVersionString->Trim(), DTSTEST_STRING_COMMA,
////////            entry->loggedCSVHoldingString->Trim(), DTSTEST_STRING_COMMA,
////////            entry->loggedCSVVendorString->Trim(), DTSTEST_STRING_COMMA,
////////            entry->loggedCSVRemainingString->Trim(), DTSTEST_STRING_COMMA,
            entry->loggedCSVInterpretationString->Trim(), DTSTEST_STRING_COMMA,
////////            entry->loggedCSVCommentString->Trim(), DTSTEST_STRING_COMMA,
////////            entry->loggedCSVErrorString->Trim(), DTSTEST_STRING_COMMA,
            entry->loggedCSVResultString->Trim());
////////            entry->scriptLineNumber, DTSTEST_STRING_COMMA,
////////            entry->loggedCSVResultString->Trim(),
////////            (isHeaderEntry ? String::Empty : DTSTEST_STRING_COMMA),
////////            (isHeaderEntry ? String::Empty : String::Concat(++entry->scriptLineNumber))
////////            );
        if (isHeaderEntry)
        {
            entry->loggedCSVEntryString = String::Concat(
                entry->loggedCSVEntryString, DTSTEST_STRING_COMMA,
                entry->scriptLineNumberString->Trim());
            entry->loggedCSVHardwareIDString = String::Empty;
        }
        else
        {
            if (!DTSTest_TestingRunning)
                entry->loggedCSVEntryString = String::Concat(
                    entry->loggedCSVEntryString, DTSTEST_STRING_COMMA,
                    String::Concat(entry->scriptLineNumber));
        }
        //--------------------------------------------------------------------
        // Store the entry as a line in the file
        //--------------------------------------------------------------------
        generalCSVFileString += String::Concat(
            entry->loggedCSVEntryString,
            Environment::NewLine);
        //--------------------------------------------------------------------
        // Clear all the entry strings
        //--------------------------------------------------------------------
        entry->scriptLineNumberString = String::Empty;
        entry->loggedCSVDateString = String::Empty;
        entry->loggedCSVTimeString = String::Empty;
//        entry->loggedCSVHardwareIDString = String::Empty;
        entry->loggedCSVStateString = String::Empty;
//        entry->loggedCSVBaudRateStateString = String::Empty;
//        entry->loggedCSVCRCStateString = String::Empty;
//        entry->loggedCSVSyncStateString = String::Empty;
//        entry->loggedCSVFreshStateString = String::Empty;
//        entry->loggedCSVCableLengthStateString = String::Empty;
//        entry->loggedCSVTempStateString = String::Empty;
//        entry->loggedCSVVoltageStateString = String::Empty;
        entry->loggedCSVInputString = String::Empty;
        entry->loggedCSVDelayString = String::Empty;
        entry->loggedCSVAddressString = String::Empty;
        entry->loggedCSVCommandString = String::Empty;
        entry->loggedCSVSentString = String::Empty;
        entry->loggedCSVReplyString = String::Empty;
        entry->loggedCSVExpectedString = String::Empty;
        entry->loggedCSVPrefixString = String::Empty;
        entry->loggedCSVStatusString = String::Empty;
        entry->loggedCSVChipIDString = String::Empty;
        entry->loggedCSVOTPString = String::Empty;
        entry->loggedCSVPressureCountHexString = String::Empty;
        entry->loggedCSVPressureCountDecimalString = String::Empty;
        entry->loggedCSVPressureActualString = String::Empty;
        entry->loggedCSVTemperatureCountHexString = String::Empty;
        entry->loggedCSVTemperatureCountDecimalString = String::Empty;
        entry->loggedCSVTemperatureActualString = String::Empty;
        entry->loggedCSVTypeString = String::Empty;
        entry->loggedCSVVersionString = String::Empty;
        entry->loggedCSVHoldingString = String::Empty;
        entry->loggedCSVVendorString = String::Empty;
        entry->loggedCSVRemainingString = String::Empty;
        entry->loggedCSVInterpretationString = String::Empty;
        entry->loggedCSVResultString = String::Empty;
        entry->loggedCSVErrorString = String::Empty;
        entry->loggedCSVCommentString = String::Empty;
        entry->loggedCSVInstructionalCommentString = String::Empty;
    }                                   // end of if (DTSTest_GeneralInfo->pgInfo)
    RecordDetailedEvent("{0} concluded", functionName);
}                                       // end of DTSTest_FileCreateCSVEntry()
//----------------------------------------------------------------------------
// DTSTest_FileInitializeCSVHeader
//
// Populates the CSV file header with column titles
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_FileInitializeCSVHeader(
    CSVEntryInfo    ^entry)
{
    String          ^functionName = _T("DTSTest_FileInitializeCSVHeader");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0} called", functionName);
    generalCSVFileString = String::Empty;
    entry->loggedCSVHardwareIDString = _T("Device");
    entry->loggedCSVDateString = _T("Date");
    entry->loggedCSVTimeString = _T("Time");
    entry->loggedCSVDelayString = _T("Delay");
    entry->loggedCSVInstructionalCommentString = _T("Comment");
    entry->loggedCSVAddressString = _T("Address");
    entry->loggedCSVCommandString = _T("Command");
    entry->loggedCSVSentString = _T("Sent");
    entry->loggedCSVExpectedString = _T("Expected");
    entry->loggedCSVReplyString = _T("Response");
    entry->loggedCSVStateString = _T("State");
    entry->loggedCSVPressureActualString = _T("psi");
    entry->loggedCSVTemperatureActualString = _T("�C");
    entry->loggedCSVInterpretationString = _T("Interpretation");
    entry->loggedCSVResultString = _T("Result");
    entry->scriptLineNumberString = _T("Line");
    DTSTest_FileCreateCSVEntry(entry, GUI_CSV_HEADER_ENTRY);
    entry->scriptLineNumber = 0;
    RecordBasicEvent("{0} concluded", functionName);
}                                       // end of DTSTest_FileInitializeCSVHeader()
//----------------------------------------------------------------------------
#endif      // FILECONTROL_CPP
//============================================================================
// End of FileControl.cpp
//============================================================================
