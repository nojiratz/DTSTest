//============================================================================
// Scripting.cpp
//
// The methods provided for script control
//
// Copyright (C) 2014 - 2016 Quartzdyne, Inc.  All rights reserved.
//
// No part of this source code may be reproduced or transmitted in any form or
// by any means, electronic or mechanical, including photocopying, recording,
// or any information storage and retrieval system, without express written
// permission from Quartzdyne, Inc.  Further, no use of this source code is
// permitted in any form or means without a valid, written license agreement
// with Quartzdyne, Inc.  While every reasonable precaution has been taken in
// the preparation of this source code, Quartzdyne, Inc., assumes no
// responsibility for errors, omissions, or damages from the use of the source
// code contained herein.
//
// NEITHER QUARTZDYNE, INC., ANY MEMBER OF QUARTZDYNE, INC., NOR ANY PERSON OR
// ORGANIZATION ACTING ON BEHALF OF THEM MAKES ANY WARRANTY OR REPRESENTATION
// WHATSOEVER, EXPRESS OR IMPLIED, INCLUDING ANY WARRANTY OF MERCHANTABILITY
// OR FITNESS FOR ANY PURPOSE WITH RESPECT TO THE SOURCE CODE OR ASSUMES ANY
// LIABILITY WHATSOEVER WITH RESPECT TO ANY USE OF THE SOURCE CODE OR ANY
// PORTION THEREOF OR WITH RESPECT TO ANY DAMAGES THAT MAY RESULT FROM SUCH
// USE.
//
// Noji Ratzlaff
//
// See DTSTest.log for a complete history of all updates, changes, and revisions
// of this source and other files and policies regarding DTSTest software
//
// Updated 01-14-2016
//============================================================================
#include    "stdafx.h"
#ifndef     SCRIPTING_CPP
#define     SCRIPTING_CPP
#include    "Scripting.h"
//----------------------------------------------------------------------------
// DTSTest_ScriptCalculateAndAppendCRC
//
// Calculates the CRC for the specified string as an array of command bytes,
// then returns the same string with the CRC bytes appended
//
// Called by:   DTSTest_ScriptTranslateCommandString
//----------------------------------------------------------------------------
    String ^ DTSTest_GUIClass::
DTSTest_ScriptCalculateAndAppendCRC(
    String          ^commandString)
{
    String          ^calculatedString = String::Empty;
    String          ^functionName = _T("DTSTest_ScriptCalculateAndAppendCRC");
    //------------------------------------------------------------------------
    RecordVerboseEvent("{0} called", functionName);
    array <Char> ^spaceDelimiters = gcnew array <Char> {DTSTEST_CHAR_SPACE};
    array <String ^> ^hexByteStrings = commandString->Split(
        spaceDelimiters,
        StringSplitOptions::RemoveEmptyEntries);
    int numberOfBytesToCRC = hexByteStrings->Length;
    array <unsigned char> ^commandArray = gcnew array <unsigned char>(PDGIC_MODBUS_MAXIMUM_COMMAND_LENGTH);
    for (int offset = 0; offset < numberOfBytesToCRC; offset++)
    {
        if (StringSet(hexByteStrings[offset]) && (hexByteStrings[offset]->Length == 2))
            commandArray[offset] =
                (AtoX(hexByteStrings[offset][0]) << 4) | AtoX(hexByteStrings[offset][1]);
    }
    WORD calculatedCRC = PDGIC_CalculateWordCRC(commandArray, numberOfBytesToCRC);
    calculatedString = String::Concat(
        commandString, DTSTEST_STRING_SPACE,
        String::Format("{0:X2} {1:X2}", calculatedCRC & 0xFF, (calculatedCRC >> 8) & 0xFF));
    delete [] commandArray;
    delete [] hexByteStrings;
    delete [] spaceDelimiters;
    RecordVerboseEvent("{0} concluded", functionName);
    return calculatedString;
}                                       // end of DTSTest_ScriptCalculateAndAppendCRC()
//----------------------------------------------------------------------------
// DTSTest_ScriptControlLoopTimerElapsed
//
// Handles the lapsing of the loop timer
//
// Called by:   DTSTest_InitializeGUIComponents
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_ScriptControlLoopTimerElapsed(
    Object          ^sender,
    EventArgs       ^evt)
{
    PDGICInfo       ^pgInfo = DTSTest_GeneralInfo->pgInfo;
    String          ^functionName = _T("DTSTest_ScriptControlLoopTimerElapsed");
    //------------------------------------------------------------------------
    if (DTSTest_ControlScriptLooping)
    {
        //--------------------------------------------------------------------
        // Reset the loop timer
        //--------------------------------------------------------------------
        scriptControlLoopTimer->Start();
    }
}                                       // end of DTSTest_ScriptControlLoopTimerElapsed()
////----------------------------------------------------------------------------
//// DTSTest_ScriptControlsCloseWindow
////
//// Event that closes the Script Controls display window
////
//// Called by:   DTSTest_ScriptControlsSetUpWindow
////----------------------------------------------------------------------------
//    void DTSTest_GUIClass::
//DTSTest_ScriptControlsCloseWindow(
//    Object          ^sender,
//    EventArgs       ^evt)
//{
//    //------------------------------------------------------------------------
//    RecordBasicEvent("Script Controls window closed");
//    if (scriptControlsWindow)
//    {
//        scriptControlsWindow->Hide();
//    }
//}                                       // end of DTSTest_ScriptControlsCloseWindow()
////----------------------------------------------------------------------------
//// DTSTest_ScriptControlsClosingWindow
////
//// Handles the closing of the Script Controls window by the red X
////
//// Called by:   DTSTest_ScriptControlsSetUpWindow
////----------------------------------------------------------------------------
//    void DTSTest_GUIClass::
//DTSTest_ScriptControlsClosingWindow(
//    Object          ^sender,
//    FormClosingEventArgs
//                    ^evt)
//{
//    //------------------------------------------------------------------------
//    evt->Cancel = GUI_YES;              // cancel the closing of the window
//    RecordBasicEvent("Script Controls window closed");
//    if (scriptControlsWindow)
//    {
//        scriptControlsWindow->Hide();
//    }
//}                                       // end of DTSTest_ScriptControlsClosingWindow()
////----------------------------------------------------------------------------
//// DTSTest_ScriptControlsSetUpWindow
////
//// Displays Scripting controls in a new window
////
//// Called by:   DTSTest_InstallUtilities
////----------------------------------------------------------------------------
//    void DTSTest_GUIClass::
//DTSTest_ScriptControlsSetUpWindow(void)
//{
//    SensorInfo      ^sensor = nullptr;
//    PDGICInfo       ^pgInfo = DTSTest_GeneralInfo->pgInfo;
//    String          ^functionName = _T("DTSTest_ScriptControlsSetUpWindow");
//    //------------------------------------------------------------------------
//    RecordBasicEvent("{0} called", functionName);
//    if (DTSTest_GeneralInfo)
//    {
//        //--------------------------------------------------------------------
//        // Create a new window form each time this is called, due to the
//        // dynamic nature of the program values
//        //--------------------------------------------------------------------
//        scriptControlsWindow = gcnew Form;
//        scriptControlsWindow->SuspendLayout();
//        //--------------------------------------------------------------------
//        // Set its properties
//        //--------------------------------------------------------------------
//        scriptControlsWindow->MaximizeBox = GUI_NO;
//        scriptControlsWindow->HelpButton = GUI_NO;
//        //--------------------------------------------------------------------
//        // Set its icon
//        //--------------------------------------------------------------------
//        scriptControlsWindow->Icon = DTSTest_SoftwareIcon;
//        //--------------------------------------------------------------------
//        // Set the background image
//        //--------------------------------------------------------------------
//    //        scriptControlsWindow->BackgroundImage = whiteSandBackground;
//        //--------------------------------------------------------------------
//        // Set the title and border style
//        //--------------------------------------------------------------------
//        scriptControlsWindow->Text = _T("DTSTest Script Controls");
//        scriptControlsWindow->FormBorderStyle = ::FormBorderStyle::Fixed3D;
//        //--------------------------------------------------------------------
//        // Set the dimensions of the Script Controls window
//        //--------------------------------------------------------------------
//        scriptControlsWindow->Size = Drawing::Size(
//            GUI_SCRIPT_CONTROLS_WINDOW_WIDTH,
//            GUI_SCRIPT_CONTROLS_WINDOW_HEIGHT);
//        for (int offset = 0; offset < DTSTEST_MAXIMUM_NUMBER_OF_PLACEHOLDERS; offset++)
//        {
//            int index = offset + 1;
//            ScriptPlaceholder ^placeholder = DTSTest_ScriptPlaceholderArray[offset];
//            //----------------------------------------------------------------
//            // Placeholder label
//            //----------------------------------------------------------------
//            placeholder->placeholderLabel = gcnew Label;
//            placeholder->placeholderLabel->Text = String::Concat(
//                DTSTEST_STRING_DOLLAR, index, _T(" :"));
//            if (offset == 0)
//            {
//                placeholder->placeholderLabel->Location = Point(10, 20);
//                placeholder->placeholderLabel->Size = Drawing::Size(30, GUI_INFO_LABEL_HEIGHT);
//                placeholder->placeholderLabel->BackColor = Color::Transparent;
//            }
//            else
//            {
//                GUI_PositionAndSizeBelow(
//                    placeholder->placeholderLabel,
//                    DTSTest_ScriptPlaceholderArray[offset - 1]->placeholderLabel,
//                    8);
//            }
//            placeholder->placeholderLabel->TextAlign = Drawing::ContentAlignment::MiddleLeft;
//            scriptControlsWindow->Controls->Add(placeholder->placeholderLabel);
//            //----------------------------------------------------------------
//            // Placeholder text box
//            //----------------------------------------------------------------
//            placeholder->placeholderBox = gcnew TextBox;
//            placeholder->placeholderBox->Tag = index;
//            placeholder->placeholderBox->Text = String::Format(
//                "{0:X2}", placeholder->placeholderValue);
//            placeholder->placeholderBox->Location = Point(
//                placeholder->placeholderLabel->Right + 2,
//                placeholder->placeholderLabel->Top - 2);
//            placeholder->placeholderBox->Size = Drawing::Size(
//                30,
//                GUI_REGULAR_TEXT_BOX_HEIGHT);
//            placeholder->placeholderBox->Multiline = GUI_NO;
//            placeholder->placeholderBox->AcceptsReturn = GUI_NO;
//            placeholder->placeholderBox->AcceptsTab = GUI_NO;
//            placeholder->placeholderBox->WordWrap = GUI_NO;
//            placeholder->placeholderBox->TextAlign = HorizontalAlignment::Center;
//            placeholder->placeholderBox->BackColor = Color::White;
//            placeholder->placeholderBox->CharacterCasing = CharacterCasing::Upper;
//            placeholder->placeholderBox->Validating +=
//                gcnew CancelEventHandler(this, &DTSTest_GUIClass::DTSTest_ValidateScriptPlaceholderValue);
//            scriptControlsWindow->Controls->Add(placeholder->placeholderBox);
//            //----------------------------------------------------------------
//            // Placeholder Load Coefficient Data button
//            //----------------------------------------------------------------
//            placeholder->placeholderButton = gcnew Button;
//            placeholder->placeholderButton->Tag = index;
//            placeholder->placeholderButton->Text = _T("Load Coefficient Data");
//            placeholder->placeholderButton->Location = Point(
//                placeholder->placeholderBox->Right + 6,
//                placeholder->placeholderBox->Top - 1);
//            placeholder->placeholderButton->Size = Drawing::Size(140, GUI_NARROW_BUTTON_HEIGHT);
//            GUI_SetButtonInterfaceProperties(placeholder->placeholderButton);
//            placeholder->placeholderButton->Click +=
//                gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_ScriptPlaceholderLoadEraseButtonClicked);
//            placeholder->placeholderButton->Enabled = GUI_NO;
//            scriptControlsWindow->Controls->Add(placeholder->placeholderButton);
//            //----------------------------------------------------------------
//            // Initialize remaining fields
//            //----------------------------------------------------------------
//            placeholder->coefficientDataLoaded = GUI_NO;
//        }                               // end of for (int offset = 0; ...)
//        //--------------------------------------------------------------------
//        // Auto Load Coefficient Data check box
//        //--------------------------------------------------------------------
//        CheckBox ^scriptAutoLoadCFDataCheck = gcnew CheckBox;
//        scriptAutoLoadCFDataCheck->Text = _T("Automatically load coefficient data");
//        scriptAutoLoadCFDataCheck->Location = Point(
//            10, (DTSTEST_MAXIMUM_NUMBER_OF_PLACEHOLDERS * (GUI_NARROW_BUTTON_HEIGHT + 6)) + 6);
//        scriptAutoLoadCFDataCheck->Size = Drawing::Size(200, GUI_REGULAR_CHECK_BOX_HEIGHT);
//        GUI_SetObjectInterfaceProperties(scriptAutoLoadCFDataCheck);
//        scriptAutoLoadCFDataCheck->Click +=
//            gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_ScriptAutoLoadCFDataChecked);
//        scriptControlsWindow->Controls->Add(scriptAutoLoadCFDataCheck);
//        scriptAutoLoadCFDataCheck->Checked = DTSTest_ScriptAutoLoadCoefficientData;
//        //--------------------------------------------------------------------
//        // Auto Load Coefficient Data check box tool tip
//        //--------------------------------------------------------------------
//        ToolTip ^scriptAutoLoadCFDataCheckToolTip = gcnew ToolTip;
//        scriptAutoLoadCFDataCheckToolTip->ShowAlways = GUI_YES;
//        scriptAutoLoadCFDataCheckToolTip->AutoPopDelay = 10000;     // let stand for ten seconds
//        scriptAutoLoadCFDataCheckToolTip->ToolTipTitle =
//            _T("Auto Load Coefficient Data");
//        String ^scriptAutoLoadCFDataCheckToolTipText = String::Concat(
//            "When checked, the software will automatically", Environment::NewLine,
//            "load the appropriate coefficient data for the", Environment::NewLine,
//            "sensor whose address is added to the", Environment::NewLine,
//            "placeholder list");
//        scriptAutoLoadCFDataCheckToolTip->SetToolTip(scriptAutoLoadCFDataCheck, scriptAutoLoadCFDataCheckToolTipText);
//        delete scriptAutoLoadCFDataCheckToolTipText;
//        //--------------------------------------------------------------------
//        // Clear All Placeholders button
//        //--------------------------------------------------------------------
//        Button ^scriptClearAllPlaceholdersButton = gcnew Button;
//        scriptClearAllPlaceholdersButton->Text = _T("Clear All Placeholders");
//        scriptClearAllPlaceholdersButton->Location = Point(
//            10, scriptAutoLoadCFDataCheck->Bottom + 6);
//        scriptClearAllPlaceholdersButton->Size = Drawing::Size(180, GUI_REGULAR_BUTTON_HEIGHT);
//        scriptClearAllPlaceholdersButton->BackColor = Color::Transparent;
//        GUI_SetButtonInterfaceProperties(scriptClearAllPlaceholdersButton);
//        scriptClearAllPlaceholdersButton->Click +=
//            gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_ScriptClearAllPlaceholdersButtonClicked);
//        scriptControlsWindow->Controls->Add(scriptClearAllPlaceholdersButton);
//        //--------------------------------------------------------------------
//        // Clear All Placeholders button tool tip
//        //--------------------------------------------------------------------
//        ToolTip ^scriptClearAllPlaceholdersButtonToolTip = gcnew ToolTip;
//        scriptClearAllPlaceholdersButtonToolTip->ShowAlways = GUI_YES;
//        scriptClearAllPlaceholdersButtonToolTip->AutoPopDelay = 10000;   // let stand for ten seconds
//        scriptClearAllPlaceholdersButtonToolTip->ToolTipTitle =
//            _T("Clear All Placeholders");
//        String ^scriptClearAllPlaceholdersButtonToolTipText = String::Concat(
//            "Sets all the script placeholders to 00");
//        scriptClearAllPlaceholdersButtonToolTip->SetToolTip(scriptClearAllPlaceholdersButton, scriptClearAllPlaceholdersButtonToolTipText);
//        delete scriptClearAllPlaceholdersButtonToolTipText;
//        //--------------------------------------------------------------------
//        // Add a Close button
//        //--------------------------------------------------------------------
//        Button ^closeButton = gcnew Button;
//        closeButton->Text = _T("Close");
//        closeButton->Location = Point(
//            scriptControlsWindow->Right - 100,
//            scriptControlsWindow->Bottom - 70);
//        closeButton->Size = Drawing::Size(
//            GUI_CLOSE_BUTTON_WIDTH,
//            GUI_REGULAR_BUTTON_HEIGHT);
//        GUI_SetButtonInterfaceProperties(closeButton);
//        closeButton->DialogResult = System::Windows::Forms::DialogResult::OK;
//        closeButton->Click +=
//            gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_ScriptControlsCloseWindow);
//        scriptControlsWindow->Controls->Add(closeButton);
//        //------------------------------------------------------------------------
//        // Handle the closing of the window by any other way
//        //------------------------------------------------------------------------
//        scriptControlsWindow->FormClosing +=
//            gcnew FormClosingEventHandler(this, &DTSTest_GUIClass::DTSTest_ScriptControlsClosingWindow);
//        //--------------------------------------------------------------------
//        // Set the remaining window properties
//        //--------------------------------------------------------------------
//        scriptControlsWindow->AcceptButton = closeButton;
//        scriptControlsWindow->CancelButton = closeButton;
//        //--------------------------------------------------------------------
//        // Finally, hide the new window
//        //--------------------------------------------------------------------
//        scriptControlsWindow->ResumeLayout();
//        scriptControlsWindow->Hide();
//    }                                   // end of if (DTSTest_GeneralInfo)
//    RecordBasicEvent("{0} concluded", functionName);
//}                                       // end of DTSTest_ScriptControlsSetUpWindow()
////----------------------------------------------------------------------------
//// DTSTest_ScriptClearAllPlaceholdersButtonClicked
////
//// Clears all the script placeholders
////
//// Called by:   DTSTest_ScriptControlsSetUpWindow
////----------------------------------------------------------------------------
//    void DTSTest_GUIClass::
//DTSTest_ScriptClearAllPlaceholdersButtonClicked(
//    Object          ^sender,
//    EventArgs       ^evt)
//{
//    String          ^functionName = _T("DTSTest_ScriptClearAllPlaceholdersButtonClicked");
//    //------------------------------------------------------------------------
//    RecordBasicEvent("{0} called", functionName);
//    for (int offset = 0; offset < DTSTEST_MAXIMUM_NUMBER_OF_PLACEHOLDERS; offset++)
//    {
//        DTSTest_ScriptPlaceholderArray[offset]->placeholderValue = 0;
//        DTSTest_ScriptPlaceholderArray[offset]->placeholderBox->Text = String::Format(
//            "{0:X2}", DTSTest_ScriptPlaceholderArray[offset]->placeholderValue);
//        DTSTest_ScriptPlaceholderArray[offset]->placeholderButton->Text = _T("Load Coefficient Data");
//        DTSTest_ScriptPlaceholderArray[offset]->placeholderButton->Enabled = GUI_NO;
//    }
//    RecordBasicEvent("{0} concluded", functionName);
//}                                       // end of DTSTest_ScriptClearAllPlaceholdersButtonClicked()
//----------------------------------------------------------------------------
// DTSTest_ScriptLoadControlScriptFile
//
// Loads the control script contained in the specified file
//
// Returns the entire control script as a string
//
// Called by:   DTSTest_HomeLoopControlScriptButtonClicked
//----------------------------------------------------------------------------
    String ^ DTSTest_GUIClass::
DTSTest_ScriptLoadControlScriptFile(
    String          ^scriptFilePathString)
{
    String          ^controlScript = String::Empty;
    String          ^functionName = _T("DTSTest_ScriptLoadControlScriptFile");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0} called", functionName);
    if (StringSet(scriptFilePathString))
    {
        if (File::Exists(scriptFilePathString))
        {
            StreamReader ^textReader = File::OpenText(scriptFilePathString);
            if (textReader)
            {
                controlScript = textReader->ReadToEnd();
                textReader->Close();
//                PDGICInfo ^pgInfo = DTSTest_GeneralInfo->pgInfo;
                DTSTest_GeneralInfo->mainScript->controlScriptString = controlScript;
                DTSTest_GeneralInfo->mainScript->controlScriptIsLoaded = GUI_YES;
                homeLoopControlScriptButton->Enabled = GUI_YES;
            }                           // end of if (textReader)
        }                               // end of if (File::Exists(scriptFilePathString))
        else
        {
            RecordErrorEvent("    {0} : {1} is not found",
                functionName, scriptFilePathString);
        }
    }                                   // end of if (StringSet(scriptFilePathString))
    RecordBasicEvent("{0} concluded", functionName);
    return controlScript;
}                                       // end of DTSTest_ScriptLoadControlScriptFile()
//----------------------------------------------------------------------------
// DTSTest_ScriptParseLineForCommandString
//
// Removes the 'expected' and comment strings from the specified script line,
// performs the delay specified in the script command string, if any, or the
// specified default delay amount if it is not specified, stores all the above
// in their appropriate CSV strings, then returns the remaining command string
//
// Returns the string containing only the command
//
// Called by:   DTSTest_ScriptProcessLine
//              DTSTest_TestingProcessTestEntry
//----------------------------------------------------------------------------
    String ^ DTSTest_GUIClass::
DTSTest_ScriptParseLineForCommandString(
    String          ^scriptCommandString,
    int             defaultDelay,
    bool            testingContext)
{
    String          ^commandString = scriptCommandString;
    String          ^functionName = _T("DTSTest_ScriptParseLineForCommandString");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0} called", functionName);
    if (StringSet(scriptCommandString))
    {
        bool commentLineOnly = GUI_NO;
        generalCSVEntry->loggedCSVCommentString = String::Empty;
        generalCSVEntry->loggedCSVDelayString = String::Empty;
        generalCSVEntry->loggedCSVCommandString = String::Empty;
        generalCSVEntry->loggedCSVExpectedString = String::Empty;
        generalCSVEntry->loggedCSVInstructionalCommentString = String::Empty;
        //--------------------------------------------------------------------
        // Copy and remove all comment strings, if any
        //--------------------------------------------------------------------
        if (StringSet(commandString) && commandString->Contains(DTSTEST_STRING_POUND))
        {
            if (commandString[0] == DTSTEST_CHAR_POUND)
            {
                //------------------------------------------------------------
                // The first character is a comment marker, so the entire
                // string is a comment
                //------------------------------------------------------------
                generalCSVEntry->loggedCSVCommentString = commandString->Trim();
                commandString = String::Empty;
                commentLineOnly = GUI_YES;
            }
            else
            {
                //------------------------------------------------------------
                // The comment marker is located after the start of the line,
                // so treat the comment as an instructional comment
                //------------------------------------------------------------
                generalCSVEntry->loggedCSVInstructionalCommentString = commandString->Substring(
                    commandString->IndexOf(DTSTEST_CHAR_POUND) + 1)->Trim();
                //------------------------------------------------------------
                // Keep all characters up to, but not including, the comment
                // marker
                //------------------------------------------------------------
                commandString = commandString->Substring(0, commandString->IndexOf(DTSTEST_CHAR_POUND))->Trim();
            }
        }
        //--------------------------------------------------------------------
        // Copy and remove all 'expected' strings, if any
        //--------------------------------------------------------------------
        if (StringSet(commandString) && commandString->Contains(DTSTEST_STRING_SEMICOLON))
        {
            generalCSVEntry->loggedCSVExpectedString = commandString->Substring(
                commandString->IndexOf(DTSTEST_CHAR_SEMICOLON) + 1)->Trim();
            //----------------------------------------------------------------
            // Replace the 'expected' placeholders
            //----------------------------------------------------------------
            if (generalCSVEntry->loggedCSVExpectedString->Contains(DTSTEST_STRING_DOLLAR))
            {
                String ^placeholder = String::Empty;
                String ^placeholderValueString = String::Empty;
                TestEntry ^testEntry = DTSTest_TestEntryArray[DTSTest_CurrentEntryNumber];
                placeholder = _T("$1");
                if (generalCSVEntry->loggedCSVExpectedString->Contains(placeholder))
                {
                    if (testingContext)
                    {
                        if (testEntry->placeholder1Value)
                        {
                            placeholderValueString = String::Format(
                                "{0:X2}", testEntry->placeholder1Value);
                        }
                    }
                    else
                    {
                        if (DTSTest_GeneralInfo->mainScript->placeholder1Value)
                        {
                            placeholderValueString = String::Format(
                                "{0:X2}", DTSTest_GeneralInfo->mainScript->placeholder1Value);
                        }
                    }
                    generalCSVEntry->loggedCSVExpectedString = generalCSVEntry->loggedCSVExpectedString->Replace(
                        placeholder, placeholderValueString);
                }
                placeholder = _T("$2");
                if (generalCSVEntry->loggedCSVExpectedString->Contains(placeholder))
                {
                    if (testingContext)
                    {
                        if (testEntry->placeholder2Value)
                        {
                            placeholderValueString = String::Format(
                                "{0:X2}", testEntry->placeholder2Value);
                        }
                    }
                    else
                    {
                        if (DTSTest_GeneralInfo->mainScript->placeholder2Value)
                        {
                            placeholderValueString = String::Format(
                                "{0:X2}", DTSTest_GeneralInfo->mainScript->placeholder2Value);
                        }
                    }
                    generalCSVEntry->loggedCSVExpectedString = generalCSVEntry->loggedCSVExpectedString->Replace(
                        placeholder, placeholderValueString);
                }
                placeholder = _T("$3");
                if (generalCSVEntry->loggedCSVExpectedString->Contains(placeholder))
                {
                    if (testingContext)
                    {
                        if (testEntry->placeholder3Value)
                        {
                            placeholderValueString = String::Format(
                                "{0:X2}", testEntry->placeholder3Value);
                        }
                    }
                    else
                    {
                        if (DTSTest_GeneralInfo->mainScript->placeholder3Value)
                        {
                            placeholderValueString = String::Format(
                                "{0:X2}", DTSTest_GeneralInfo->mainScript->placeholder3Value);
                        }
                    }
                    generalCSVEntry->loggedCSVExpectedString = generalCSVEntry->loggedCSVExpectedString->Replace(
                        placeholder, placeholderValueString);
                }
            }                           // end of if (generalCSVEntry->loggedCSVExpectedString->Contains(DTSTEST_STRING_DOLLAR))
            commandString = commandString->Substring(0, commandString->IndexOf(DTSTEST_CHAR_SEMICOLON))->Trim();
        }                               // end of if (StringSet(commandString) && commandString->Contains(DTSTEST_STRING_SEMICOLON))
        //--------------------------------------------------------------------
        // Process and remove the delay string, if present
        //--------------------------------------------------------------------
        String ^delayString = String::Empty;
        int delay = commentLineOnly ? 0 : defaultDelay;
        if (StringSet(commandString))
        {
            if (Char::IsNumber(commandString[0]))
            {
                bool delaySpecifiedOnly = GUI_NO;
                if (commandString->Contains(DTSTEST_STRING_COLON))
                {
                    array <Char> ^colonDelimiter = gcnew array <Char> {DTSTEST_CHAR_COLON};
                    array <String ^> ^colonlessStrings = commandString->Split(
                        colonDelimiter,
                        StringSplitOptions::RemoveEmptyEntries);
                    String ^preCommandString = colonlessStrings[0]->Trim();
                    if (colonlessStrings->Length > 1)
                    {
                        delayString = preCommandString;
                        commandString = commandString->Substring(
                            commandString->IndexOf(DTSTEST_CHAR_COLON) + 1)->Trim();
                        if (!StringSet(commandString))
                            delaySpecifiedOnly = GUI_YES;
                    }
                    else
                    {
                        delayString = preCommandString;
                        commandString = String::Empty;
                    }
                    delete [] colonlessStrings;
                    delete [] colonDelimiter;
                }
                else
                {
                    //--------------------------------------------------------
                    // No colons in the command string
                    //--------------------------------------------------------
                    if (commandString->Contains(DTSTEST_STRING_SPACE))
                    {
                        array <Char> ^spaceDelimiter = gcnew array <Char> {DTSTEST_CHAR_SPACE};
                        array <String ^> ^spacelessStrings = commandString->Split(
                            spaceDelimiter,
                            StringSplitOptions::RemoveEmptyEntries);
                        String ^preCommandString = spacelessStrings[0]->Trim();
                        if (preCommandString->Length > 2)
                        {
                            delayString = preCommandString;
                            commandString = commandString->Substring(
                                preCommandString->Length)->Trim();
                        }
                        delete [] spacelessStrings;
                        delete [] spaceDelimiter;
                    }
                    else
                    {
                        delayString = commandString;
                        commandString = String::Empty;
                        delaySpecifiedOnly = GUI_YES;
                    }
                }
            }                           // end of if (Char::IsNumber(commandString[0]))
            else
            {
                //------------------------------------------------------------
                // No delay is specified, so use the default delay
                //------------------------------------------------------------
            }
        }                               // end of if (StringSet(commandString))
        if (StringSet(delayString))
        {
            bool isDecimalInteger = DTSTest_ParseAndConvertStringToInteger(
                delayString,
                &delay);
            if (!isDecimalInteger || (delay < 0))
                delay = defaultDelay;
        }
        if (delay > 0)
        {
            Thread::Sleep(delay);
            RecordVerboseEvent(
                "{0} : Delayed for {1:D} ms",
                functionName, delay);
        }
        generalCSVEntry->loggedCSVDelayString = String::Concat(delay);
        //--------------------------------------------------------------------
        // At this point only the command string remains, if present
        //--------------------------------------------------------------------
//        scriptCommandString = commandString;
        generalCSVEntry->loggedCSVCommandString = commandString;
//if (DTSTest_ExperimentsEnabled && !commentLineOnly)
//    Modal("delay = {0:D} ms = '{1}'\ncommand = '{2}'\nexpected = '{3}'\ninstr comment = '{4}'",
//        delay, generalCSVEntry->loggedCSVDelayString,
//        generalCSVEntry->loggedCSVCommandString,
//        generalCSVEntry->loggedCSVExpectedString,
//        generalCSVEntry->loggedCSVInstructionalCommentString);
    }                                   // end of if (StringSet(scriptCommandString))
    RecordBasicEvent("{0} concluded", functionName);
    return commandString;
}                                       // end of DTSTest_ScriptParseLineForCommandString()
//----------------------------------------------------------------------------
// DTSTest_ScriptProcessAddComment
//
// Processes the specified comment string
//
// Called by:   DTSTest_HomeAddCommentButtonClicked
//              DTSTest_HomeTextBoxAcceptEnterKey
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_ScriptProcessAddComment(
    String          ^commentString)
{
    String          ^functionName = _T("DTSTest_ScriptProcessAddComment");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0} called", functionName);
    commentString = commentString->Trim();
    if (StringSet(commentString))
    {
        commentString = String::Concat(
            "# ",
            commentString, Environment::NewLine);
        bool originalPrependState = DTSTest_PrependDateAndTime;
        DTSTest_PrependDateAndTime = GUI_NO;
        DTSTest_CommandDialogueAppendLine(commentString);
        homeClearCommandDialogueButton->Enabled = GUI_YES;
        testingClearCommandDialogueButton->Enabled = GUI_YES;
        //--------------------------------------------------------------------
        // Create the CSV entry for the comment alone
        //--------------------------------------------------------------------
        if (!StringSet(generalCSVFileString))
            DTSTest_FileInitializeCSVHeader(generalCSVEntry);
        commentString = commentString->Substring(1)->Trim();
        generalCSVEntry->loggedCSVInstructionalCommentString = commentString;
        DTSTest_FileCreateCSVEntry(generalCSVEntry, GUI_CSV_REGULAR_ENTRY);
        DTSTest_PrependDateAndTime = originalPrependState;
        homeAddCommentBox->Clear();
    }
    RecordBasicEvent("{0} concluded", functionName);
}                                       // end of DTSTest_ScriptProcessAddComment()
//----------------------------------------------------------------------------
// DTSTest_ScriptProcessBaudRateChangeString
//
// Processes the specified baud rate change directive string
//
// Called by:   DTSTest_ReturnScriptCommandInterpretationString
//              DTSTest_ScriptTranslateCommandString
//----------------------------------------------------------------------------
    String ^ DTSTest_GUIClass::
DTSTest_ScriptProcessBaudRateChangeString(
    String          ^scriptCommandString)
{
    String          ^interpretationString = String::Empty;
    String          ^functionName = _T("DTSTest_ScriptProcessBaudRateChangeString");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0} called", functionName);
    if (StringSet(scriptCommandString))
    {
        array <Char> ^colonDelimiter = gcnew array <Char> {DTSTEST_CHAR_COLON, DTSTEST_CHAR_SPACE};
        array <String ^> ^colonlessSpacelessStrings = scriptCommandString->Split(
            colonDelimiter,
            StringSplitOptions::RemoveEmptyEntries);
        String ^directiveString = colonlessSpacelessStrings[0]->Trim();
        String ^directiveModifierString = String::Empty;
        if (colonlessSpacelessStrings->Length > 1)
        {
            //----------------------------------------------------------------
            // Directive modifier possibly specified
            //----------------------------------------------------------------
            directiveModifierString = colonlessSpacelessStrings[1]->Trim();
        }
        int targetBaudRate = 0;
        if (StringSet(directiveModifierString))
        {
            bool isDecimalInteger = DTSTest_ParseAndConvertStringToInteger(
                directiveModifierString,
                &targetBaudRate);
            if (!isDecimalInteger)
                targetBaudRate = DTSTEST_FAILURE;
        }
        bool willChangeBaudRate = GUI_NO;
        if (targetBaudRate)
        {
            if ((targetBaudRate == 1200) || (targetBaudRate == 2400))
            {
                if ((targetBaudRate == 1200) && DTSTest_BaudRateSetTo2400)
                {
                    willChangeBaudRate = GUI_YES;
                }
                if ((targetBaudRate == 2400) && !DTSTest_BaudRateSetTo2400)
                {
                    willChangeBaudRate = GUI_YES;
                }
            }
            else
            {
                DTSTest_PromptOKModal(
                    "Invalid Data Rate",
                    "Only specify 1200 or 2400 baud");
            }
        }                               // end of if (StringSet(baudRateString))
        else
        {
            willChangeBaudRate = GUI_YES;
        }
        if (willChangeBaudRate)
        {
            DTSTest_SwitchBaudRate();
            generalCSVEntry->loggedCSVInterpretationString = String::Concat(
                _T("Data rate changed to "),
                (DTSTest_BaudRateSetTo2400 ? _T("2400") : _T("1200")),
                _T(" baud"));
            interpretationString += String::Concat(
                _T("    => "),
                generalCSVEntry->loggedCSVInterpretationString);
        }
        else
        {
            interpretationString += _T("    => Data rate unchanged");
        }
    }                                   // end of if (StringSet(scriptCommandString))
    RecordBasicEvent("{0} concluded", functionName);
    return interpretationString;
}                                       // end of DTSTest_ScriptProcessBaudRateChangeString()
//----------------------------------------------------------------------------
// DTSTest_ScriptProcessLine
//
// Processes the specified command string
//
// Called by:   DTSTest_ProcessCommandLine
//              DTSTest_ScriptRunMainControlScriptThread
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_ScriptProcessLine(
    String          ^scriptLineString,
    bool            testingContext)
{
    String          ^functionName = _T("DTSTest_ScriptProcessLine");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0} called", functionName);
    generalCSVEntry->scriptLineNumber++;
    scriptLineString = scriptLineString->Trim();
//    if (StringSet(scriptLineString))
    {
        DTSTest_CommandDialogueAppendLine(
            String::Concat(scriptLineString, Environment::NewLine));
        scriptLineString = DTSTest_ScriptParseLineForCommandString(
            scriptLineString,
            DTSTest_TestingDelay,
            testingContext);
        String ^interpretationString = DTSTest_ReturnScriptCommandInterpretationString(
            scriptLineString,
            testingContext);
        if (StringSet(scriptLineString))
            DTSTest_FileCreateCSVEntry(generalCSVEntry, GUI_CSV_REGULAR_ENTRY);
        if (StringSet(interpretationString))
            interpretationString += Environment::NewLine;
        if (StringSet(scriptLineString))
        {
            bool originalDateAndTimeState = DTSTest_PrependDateAndTime;
            DTSTest_PrependDateAndTime = GUI_NO;
            DTSTest_CommandDialogueAppendLine(interpretationString);
            DTSTest_PrependDateAndTime = originalDateAndTimeState;
        }
    }
    RecordBasicEvent("{0} concluded", functionName);
}                                       // end of DTSTest_ScriptProcessLine()
//----------------------------------------------------------------------------
// DTSTest_ScriptProcessMainControlScript
//
// Processes the specified string as a main control script thread one line at
// a time
//
// Called by:   DTSTest_HomeLoopControlScriptButtonClicked
//              DTSTest_HomeRerunControlScriptButtonClicked
//              DTSTest_ScriptPromptForMainControlScriptFile
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_ScriptProcessMainControlScript(
    String          ^controlScriptString)
{
    //------------------------------------------------------------------------
    if (StringSet(controlScriptString))
    {
        DTSTest_ControlScriptRunning = GUI_YES;
        Thread ^runScriptThread =
            gcnew Thread(gcnew ParameterizedThreadStart(this, &DTSTest_GUIClass::DTSTest_ScriptRunMainControlScriptThread));
        runScriptThread->Start(controlScriptString);
    }
}                                       // end of DTSTest_ScriptProcessMainControlScript()
//----------------------------------------------------------------------------
// DTSTest_ScriptPromptForMainControlScriptFile
//
// Prompts for the name of a script file, then loads the file into memory
//
// Called by:   DTSTest_HomeLoadControlScriptFileButtonClicked
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_ScriptPromptForMainControlScriptFile(void)
{
    bool            fileLocated = GUI_NO;
    bool            promptResult = GUI_ACCEPT;
    String          ^scriptFilePathString = String::Empty;
    String          ^functionName = _T("DTSTest_ScriptPromptForMainControlScriptFile");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0} called", functionName);
    if (StringSet(DTSTest_GeneralInfo->mainScript->controlScriptFilePath))
        scriptFilePathString = DTSTest_GeneralInfo->mainScript->controlScriptFilePath;
    else
        scriptFilePathString = Environment::GetFolderPath(Environment::SpecialFolder::Recent);
    do
    {
        StringBuilder ^scriptFilePathBuilder = gcnew StringBuilder(
            scriptFilePathString,
            DTSTEST_MAXIMUM_FILE_PATH_LENGTH);
        promptResult = DTSTest_PromptForReadFile(
            _T("Select Script File"),
            scriptFilePathBuilder,
            String::Empty,
            GUI_FILE_TYPE_UNKNOWN);
        scriptFilePathString = scriptFilePathBuilder->ToString();
        delete scriptFilePathBuilder;
        if (promptResult == GUI_ACCEPT)
        {
            fileLocated = GUI_YES;
            DTSTest_GeneralInfo->mainScript->controlScriptFilePath = scriptFilePathString;
            homeScriptFilenameLabel->Text = String::Concat(
                _T("Script: "),
                (StringSet(DTSTest_GeneralInfo->mainScript->controlScriptFilePath) ?
                    Path::GetFileName(DTSTest_GeneralInfo->mainScript->controlScriptFilePath) : _T("<none>")));
        }
    }
    while (!fileLocated && (promptResult == GUI_ACCEPT));
    if (fileLocated)
    {
        DTSTest_GeneralInfo->mainScript->controlScriptFilePath = scriptFilePathString;
        String ^controlScript = DTSTest_ScriptLoadControlScriptFile(scriptFilePathString);
        DTSTest_ScriptProcessMainControlScript(controlScript);
    }                                   // end of if (fileLocated)
    RecordBasicEvent("{0} concluded", functionName);
}                                       // end of DTSTest_ScriptPromptForMainControlScriptFile()
//----------------------------------------------------------------------------
// DTSTest_ScriptRunMainControlScriptThread
//
// Processes all the lines of the main control script specified by the context
//
// Called by:   DTSTest_ScriptProcessMainControlScript
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_ScriptRunMainControlScriptThread(
    Object          ^controlScriptContext)
{
    String          ^border = GUI_TEXT_FILE_BORDER;
    String          ^halfBorder = GUI_TEXT_FILE_HALF_BORDER;
    String          ^controlScript = (String ^) (dynamic_cast <Object ^> (controlScriptContext));
    String          ^functionName = _T("DTSTest_ScriptRunMainControlScriptThread");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0} called", functionName);
    if (DTSTest_ControlScriptRunning && StringSet(controlScript))
    {
        this->Cursor = Cursors::WaitCursor;
        if (!DTSTest_ControlScriptLooping)
            DTSTest_DetermineResultsLog();
        DTSTest_GeneralInfo->mainScript->scriptNumberOfPasses = 0;
        DTSTest_GeneralInfo->mainScript->scriptNumberOfFailures = 0;
        //--------------------------------------------------------------------
        // Remove all commas
        //--------------------------------------------------------------------
        if (controlScript->Contains(DTSTEST_STRING_COMMA))
            controlScript = controlScript->Replace(DTSTEST_STRING_COMMA, String::Empty);
        array <Char> ^lineDelimiters = gcnew array <Char> {DTSTEST_CHAR_CR, DTSTEST_CHAR_LF};
        array <String ^> ^scriptLines = controlScript->Split(
            lineDelimiters,
            StringSplitOptions::RemoveEmptyEntries);
//        PDGICInfo ^pgInfo = DTSTest_GeneralInfo->pgInfo;
        String ^scriptFilePathString = DTSTest_GeneralInfo->mainScript->controlScriptFilePath;
        String ^logHeader = String::Concat(
            border, Environment::NewLine,
            "# Results Log: ", DTSTest_GeneralInfo->mainScript->resultsLogFilePath, Environment::NewLine,
            "# DTSTest v", DTSTEST_PROGRAM_VERSION_STRING,
            "-", DTSTest_BuildNumber, Environment::NewLine,
            "# Operator: ", DTSTest_GeneralInfo->operatorName, Environment::NewLine,
            "# Serial Number: ",
            (StringSet(DTSTest_GeneralInfo->dieSerialNumber) ? DTSTest_GeneralInfo->dieSerialNumber : "None"),
            Environment::NewLine,
            "# Computer: ", Environment::MachineName, Environment::NewLine,
            border, Environment::NewLine);
        bool originalPrependState = DTSTest_PrependDateAndTime;
        DTSTest_PrependDateAndTime = GUI_NO;
        DTSTest_CommandDialogueAppendLine(logHeader);
        DTSTest_PrependDateAndTime = originalPrependState;
        homeClearCommandDialogueButton->Enabled = GUI_YES;
        testingClearCommandDialogueButton->Enabled = GUI_YES;
        logHeader = String::Concat(
            "Start of script ",
            scriptFilePathString,
            Environment::NewLine);
        if (!DTSTest_PrependDateAndTime)
        {
            DateTime dateTime = DateTime::Now;
            logHeader += String::Concat(
                String::Format(
                    " [ {0:D2}-{1:D2}-{2:D4} {3:D2}:{4:D2}:{5:D2} ]",
                    dateTime.Month,
                    dateTime.Day,
                    dateTime.Year,
                    dateTime.Hour,
                    dateTime.Minute,
                    dateTime.Second),
                    Environment::NewLine);
        }
        DTSTest_CommandDialogueAppendLine(logHeader);
        generalLogFileString = String::Empty;
        generalCSVFileString = String::Empty;
        if (DTSTest_GeneralInfo->flags & DTSTEST_GENERAL_CREATE_CSV_LOG_FILE)
        {
            DTSTest_FileInitializeCSVHeader(generalCSVEntry);
        }
        homeRerunControlScriptButton->Enabled = GUI_YES;
        homeRerunControlScriptButton->Text = _T("Pause Control Script");
        homeLoadControlScriptButton->Text = _T("Stop Running");
        do
        {
            DWORD controlScriptAmountCompleted = 0;
            for each (String ^scriptLineString in scriptLines)
            {
                controlScriptAmountCompleted += scriptLineString->Length;
                DTSTest_ScriptProcessLine(
                    scriptLineString,
                    GUI_NO);
                while (DTSTest_ControlScriptPaused)
                {
                    Thread::Sleep(100);
                }
                if (DTSTest_ControlScriptRunning)
                    Thread::Sleep(10);
                else
                    break;
                DTSTest_UpdateHomeProgressBar(
                    controlScriptAmountCompleted,
                    controlScript->Length);
            }
            if (DTSTest_ControlScriptRunning)
            {
                String ^scriptTrailer = String::Concat(
                    "End of script ",
                    scriptFilePathString,
                    Environment::NewLine);
                if (!DTSTest_PrependDateAndTime)
                {
                    DateTime dateTime = DateTime::Now;
                    scriptTrailer += String::Concat(
                        String::Format(
                            " [ {0:D2}-{1:D2}-{2:D4} {3:D2}:{4:D2}:{5:D2} ]",
                            dateTime.Month,
                            dateTime.Day,
                            dateTime.Year,
                            dateTime.Hour,
                            dateTime.Minute,
                            dateTime.Second),
                            Environment::NewLine);
                }
                DTSTest_CommandDialogueAppendLine(scriptTrailer);
                scriptTrailer = String::Concat(
                    "Tests passed = ",
                    DTSTest_GeneralInfo->mainScript->scriptNumberOfPasses, Environment::NewLine,
                    "Tests failed = ",
                    DTSTest_GeneralInfo->mainScript->scriptNumberOfFailures, Environment::NewLine,
//                    border, Environment::NewLine,
//                    "# End of results log ", DTSTest_GeneralInfo->mainScript->resultsLogFilePath, Environment::NewLine,
                    border, Environment::NewLine);
                DTSTest_PrependDateAndTime = GUI_NO;
                DTSTest_CommandDialogueAppendLine(scriptTrailer);
                DTSTest_PrependDateAndTime = originalPrependState;
                //------------------------------------------------------------
                // Save the results log to file
                //------------------------------------------------------------
                DTSTest_AppendLineToDataLog(homeCommandDialogueBox->Text);
                if (DTSTest_GeneralInfo->flags & DTSTEST_GENERAL_CREATE_CSV_LOG_FILE)
                {
                    DTSTest_AppendLineToCSVLog(generalCSVFileString);
                }
            }
            else
            {
                DTSTest_CommandDialogueAppendLine("====> Script execution stopped");
            }
            DTSTest_UpdateHomeProgressBar(0, 0);
            if (!DTSTest_ControlScriptLooping)
                DTSTest_ControlScriptRunning = GUI_NO;
        }
        while (DTSTest_ControlScriptLooping && DTSTest_ControlScriptRunning);
        homeLoadControlScriptButton->Text = _T("Load and Run Control Script");
        homeRerunControlScriptButton->Text = _T("Re-run Control Script");
        delete [] scriptLines;
        delete [] lineDelimiters;
        homeRerunControlScriptButton->Enabled = GUI_YES;
        this->Cursor = Cursors::Default;
    }                                   // end of if (DTSTest_ControlScriptRunning && StringSet(controlScript))
    RecordBasicEvent("{0} concluded", functionName);
}                                       // end of DTSTest_ScriptRunMainControlScriptThread()
//----------------------------------------------------------------------------
// DTSTest_ScriptTranslateCommandString
//
// Translates the specified command string from placeholders and tags to hex
// bytes, then appends a CRC
//
// Returns the translated string or String::Empty if a tag is present but
// invalid
//
// Called by:   DTSTest_ReturnScriptCommandInterpretationString
//
// Note: call DTSTest_ScriptParseLineForCommandString to ensure the delay,
// expected, and comment strings have been removed from the line string
// before passing it to this function
//----------------------------------------------------------------------------
    String ^ DTSTest_GUIClass::
DTSTest_ScriptTranslateCommandString(
    String          ^commandString,
    bool            testingContext)
{
    String          ^translatedString = String::Empty;
    String          ^functionName = _T("DTSTest_ScriptTranslateCommandString");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0}({1}) called", functionName, commandString);
    if (StringSet(commandString))
    {
        bool targetMissing = GUI_YES;
        String ^invalidPlaceholderString = String::Empty;
        bool placeholderErrorPresent = GUI_NO;
        BYTE nodeAddress = 0;
        String ^nodeAddressString = String::Empty;
        String ^placeholderValueString = String::Empty;
        //--------------------------------------------------------------------
        // Parse the command string
        //--------------------------------------------------------------------
        array <Char> ^spaceDelimiters = gcnew array <Char> {DTSTEST_CHAR_SPACE};
        array <String ^> ^spacelessStrings = commandString->Split(
            spaceDelimiters,
            StringSplitOptions::RemoveEmptyEntries);
        int numberOfCommandStrings = spacelessStrings->Length;
        for (int count = 0; count < spacelessStrings->Length; count++)
            spacelessStrings[count] = spacelessStrings[count]->Trim();
        if (commandString->Contains(DTSTEST_STRING_DOLLAR))
        {
            //----------------------------------------------------------------
            // The line contains placeholders, so replace them if possible
            //----------------------------------------------------------------
            array <String ^> ^invalidPlaceholderStringArray = gcnew array <String ^>
                {"$4", "$5", "$6", "$7", "$8", "$9"};
            for each (String ^placeholderString in invalidPlaceholderStringArray)
            {
                if (commandString->Contains(placeholderString))
                {
                    translatedString += String::Concat(
                        (StringSet(translatedString) ? Environment::NewLine : String::Empty),
                        _T("    => !!! '"),
                        placeholderString,
                        _T("' is an invalid placeholder"));
                    invalidPlaceholderString = placeholderString;
                    break;
                }
            }
            delete [] invalidPlaceholderStringArray;
//            if (!placeholderErrorPresent)
            {
                bool replacementFound = GUI_NO;
                String ^missingReplacement = String::Empty;
                bool goodPlaceholderFormat = GUI_YES;
                for (int count = 0; count < spacelessStrings->Length; count++)
                {
                    if (spacelessStrings[count]->Contains(DTSTEST_STRING_DOLLAR))
                    {
                        if (spacelessStrings[count]->Length > 1)
                        {
                            missingReplacement = spacelessStrings[count];
    //                        for (int offset = 0; offset < DTSTEST_MAXIMUM_NUMBER_OF_PLACEHOLDERS; offset++)
                            {
    //                            int index = offset + 1;
                                String ^placeholder = String::Empty; // String::Concat(DTSTEST_STRING_DOLLAR, index);
                                if (testingContext)
                                {
                                    //----------------------------------------
                                    // Originated in the testing interface
                                    //----------------------------------------
                                    TestEntry ^testEntry = DTSTest_TestEntryArray[DTSTest_CurrentEntryNumber];
                                    PDGICInfo ^pgInfo = DTSTest_GeneralInfo->pgInfo;
                                    placeholder = _T("$1");
                                    if (StringICompare(spacelessStrings[count], placeholder) == 0)
                                    {
                                        if (count == 0)
                                            targetMissing = GUI_NO;
                                        if (testEntry->placeholder1Value)
                                        {
                                            SensorInfo ^sensor = pgInfo->sensorInfoArray[testEntry->placeholder1Value];
                                            nodeAddress = testEntry->placeholder1Value;
                                            replacementFound = GUI_YES;
                                            placeholderValueString = String::Format(
                                                "{0:X2}", testEntry->placeholder1Value);
                                            spacelessStrings[count] = spacelessStrings[count]->Replace(
                                                placeholder, placeholderValueString);
                                            nodeAddressString = placeholderValueString;
                                        }
                                    }
                                    placeholder = _T("$2");
                                    if (StringICompare(spacelessStrings[count], placeholder) == 0)
                                    {
                                        if (count == 0)
                                            targetMissing = GUI_NO;
                                        if (testEntry->placeholder2Value)
                                        {
                                            SensorInfo ^sensor = pgInfo->sensorInfoArray[testEntry->placeholder2Value];
                                            nodeAddress = testEntry->placeholder2Value;
                                            replacementFound = GUI_YES;
                                            placeholderValueString = String::Format(
                                                "{0:X2}", testEntry->placeholder2Value);
                                            spacelessStrings[count] = spacelessStrings[count]->Replace(
                                                placeholder, placeholderValueString);
                                            nodeAddressString = placeholderValueString;
                                        }
                                    }
                                    placeholder = _T("$3");
                                    if (StringICompare(spacelessStrings[count], placeholder) == 0)
                                    {
                                        if (count == 0)
                                            targetMissing = GUI_NO;
                                        if (testEntry->placeholder3Value)
                                        {
                                            SensorInfo ^sensor = pgInfo->sensorInfoArray[testEntry->placeholder3Value];
                                            nodeAddress = testEntry->placeholder3Value;
                                            replacementFound = GUI_YES;
                                            placeholderValueString = String::Format(
                                                "{0:X2}", testEntry->placeholder3Value);
                                            spacelessStrings[count] = spacelessStrings[count]->Replace(
                                                placeholder, placeholderValueString);
                                            nodeAddressString = placeholderValueString;
                                        }
                                    }
                                }
                                else
                                {
                                    //----------------------------------------
                                    // Originated in the main interface
                                    //----------------------------------------
                                    placeholder = _T("$1");
                                    if (StringICompare(spacelessStrings[count], placeholder) == 0)
                                    {
                                        if (count == 0)
                                            targetMissing = GUI_NO;
                                        if (DTSTest_GeneralInfo->mainScript->placeholder1Value)
                                        {
                                            nodeAddress = DTSTest_GeneralInfo->mainScript->placeholder1Value;
                                            replacementFound = GUI_YES;
                                            placeholderValueString = String::Format(
                                                "{0:X2}", DTSTest_GeneralInfo->mainScript->placeholder1Value);
                                            spacelessStrings[count] = spacelessStrings[count]->Replace(
                                                placeholder, placeholderValueString);
                                            nodeAddressString = placeholderValueString;
                                        }
                                    }
                                    placeholder = _T("$2");
                                    if (StringICompare(spacelessStrings[count], placeholder) == 0)
                                    {
                                        if (count == 0)
                                            targetMissing = GUI_NO;
                                        if (DTSTest_GeneralInfo->mainScript->placeholder2Value)
                                        {
                                            nodeAddress = DTSTest_GeneralInfo->mainScript->placeholder2Value;
                                            replacementFound = GUI_YES;
                                            placeholderValueString = String::Format(
                                                "{0:X2}", DTSTest_GeneralInfo->mainScript->placeholder2Value);
                                            spacelessStrings[count] = spacelessStrings[count]->Replace(
                                                placeholder, placeholderValueString);
                                            nodeAddressString = placeholderValueString;
                                        }
                                    }
                                    placeholder = _T("$3");
                                    if (StringICompare(spacelessStrings[count], placeholder) == 0)
                                    {
                                        translatedString += String::Concat(
                                            (StringSet(translatedString) ? Environment::NewLine : String::Empty),
                                            _T("    => !!! '"),
                                            placeholder,
                                            _T("' is an invalid placeholder"));
                                        invalidPlaceholderString = placeholder;
                                    }
                                }       // end of else of if (testingContext)
                            }           // end of for (int offset = 0; ...)
                        }               // end of if (spacelessStrings[count]->Length > 1)
                        else
                        {
                            goodPlaceholderFormat = GUI_NO;
                        }
                    }                   // end of if (spacelessStrings[count]->Contains(DTSTEST_STRING_DOLLAR))
                }                       // end of for (int count = 0; ...)
                if (!StringSet(invalidPlaceholderString))
                {
                    if (goodPlaceholderFormat)
                    {
                        if (!replacementFound)
                        {
                            translatedString += String::Concat(
                                (StringSet(translatedString) ? Environment::NewLine : String::Empty),
                                _T("    => !!! No replacement for '"),
                                missingReplacement,
                                _T("' found"));
                            generalCSVEntry->loggedCSVInterpretationString = _T("Invalid placeholder");
                            placeholderErrorPresent = GUI_YES;
                        }
                    }
                    else
                    {
                        translatedString += String::Concat(
                            (StringSet(translatedString) ? Environment::NewLine : String::Empty),
                            _T("    => !!! '"),
                            commandString,
                            _T("' has an invalid placeholder format"));
                        generalCSVEntry->loggedCSVInterpretationString = _T("Invalid placeholder");
                        placeholderErrorPresent = GUI_YES;
                    }
                }                       // end of if (!StringSet(invalidPlaceholderString))
            }                           // end of if (!placeholderErrorPresent)
        }                               // end of if (commandString->Contains(DTSTEST_STRING_DOLLAR))
        else
        {
            //----------------------------------------------------------------
            // Numerical node address specified
            //----------------------------------------------------------------
            BYTE nodeInteger = 0;
            bool isDecimalInteger = DTSTest_ParseAndConvertHexStringToByte(
                spacelessStrings[0],
                &nodeInteger);
            if (isDecimalInteger)
            {
                nodeAddress = nodeInteger;
                targetMissing = GUI_NO;
            }
        }
        if (StringSet(invalidPlaceholderString) || targetMissing)
            placeholderErrorPresent = GUI_YES;
        bool calculateCRC = DTSTest_CalculateCRCs;
        bool atLeastOneCommandTagIsValid = GUI_NO;
        bool atLeastOneCommandTagIsInvalid = GUI_NO;
        bool commandRequiresTarget = GUI_NO;
        bool commandNotRecognizedForSensorType = GUI_NO;
        //--------------------------------------------------------------------
        // Check the remaining strings for command tags and proper formatting
        //--------------------------------------------------------------------
        for (int count = 0; count < spacelessStrings->Length; count++)
        {
            bool commandTagIsValid = GUI_NO;
            //----------------------------------------------------------------
            // Prepend a zero to the remaining command strings as needed
            //----------------------------------------------------------------
            if (spacelessStrings[count]->Length == 1)
            {
                if (isxdigit(spacelessStrings[count][0]))
                    spacelessStrings[count] = String::Concat(
                        DTSTEST_STRING_0, spacelessStrings[count]);
            }
//            else
            {
                //------------------------------------------------------------
                // Process this string as a command tag if it is longer than
                // two characters
                //------------------------------------------------------------
                if (spacelessStrings[count]->Length > 2)
                {
                    calculateCRC = GUI_YES;
                    DWORD sensorType = DTSTEST_SENSOR_TYPE_UNKNOWN;
                    PDGICInfo ^pgInfo = DTSTest_GeneralInfo->pgInfo;
//                    //--------------------------------------------------------
//                    // Check for placeholderErrorPresent only to test further
//                    // for a valid command tag, if present
//                    //--------------------------------------------------------
//                    if (nodeAddress || placeholderErrorPresent || targetMissing)
                    {
                        nodeAddressString = String::Format("{0:X2}", nodeAddress);
                        SensorInfo ^sensor = pgInfo->sensorInfoArray[nodeAddress];
                        if (nodeAddress)
                            sensorType = sensor->sensorType;
                        String ^sensorTypeString = String::Empty;
                        switch (sensorType)
                        {
                            case DTSTEST_SENSOR_TYPE_GAUGE :                    // 0x01
                                sensorTypeString = _T("Gauge");
                                break;
                            case DTSTEST_SENSOR_TYPE_DTS :                      // 0x02
                                sensorTypeString = _T("DTS");
                                break;
                            case DTSTEST_SENSOR_TYPE_DPS :                      // 0x04
                                sensorTypeString = _T("DPS");
                                break;
                            default :
                                sensorTypeString = _T("(unknown device type)");
                                break;
                        }
                        if (spacelessStrings[count]->StartsWith("all", StringComparison::OrdinalIgnoreCase))
                        {
                            commandTagIsValid = GUI_YES;
                            commandRequiresTarget = GUI_YES;
                            if (sensorType == DTSTEST_SENSOR_TYPE_GAUGE)
                                spacelessStrings[count] = _T("04 00 00 00 40");
                            else
                                spacelessStrings[count] = _T("04 00 00 00 0A");
                            generalCSVEntry->loggedCSVInterpretationString = String::Concat(
                                _T("All "), sensorTypeString, _T(" data"));
                        }
                        if (spacelessStrings[count]->StartsWith("pre", StringComparison::OrdinalIgnoreCase))
                        {
                            commandTagIsValid = GUI_YES;
                            commandRequiresTarget = GUI_YES;
                            if (sensorType == DTSTEST_SENSOR_TYPE_GAUGE)
                                spacelessStrings[count] = _T("04 00 00 00 02");
                            else
                                spacelessStrings[count] = _T("04 00 02 00 02");
                            generalCSVEntry->loggedCSVInterpretationString = String::Concat(
                                sensorTypeString, _T(" pressure"));
                        }
                        if (spacelessStrings[count]->StartsWith("tem", StringComparison::OrdinalIgnoreCase))
                        {
                            commandTagIsValid = GUI_YES;
                            commandRequiresTarget = GUI_YES;
                            if (sensorType == DTSTEST_SENSOR_TYPE_GAUGE)
                                spacelessStrings[count] = _T("04 00 02 00 02");
                            else
                                spacelessStrings[count] = _T("04 00 04 00 02");
                            generalCSVEntry->loggedCSVInterpretationString = String::Concat(
                                sensorTypeString, _T(" temperature"));
                        }
                        if (spacelessStrings[count]->StartsWith("pnt", StringComparison::OrdinalIgnoreCase) ||
                            spacelessStrings[count]->StartsWith("tnp", StringComparison::OrdinalIgnoreCase))
                        {
                            commandTagIsValid = GUI_YES;
                            commandRequiresTarget = GUI_YES;
                            if (sensorType == DTSTEST_SENSOR_TYPE_GAUGE)
                                spacelessStrings[count] = _T("04 00 00 00 04");
                            else
                                spacelessStrings[count] = _T("04 00 02 00 04");
                            generalCSVEntry->loggedCSVInterpretationString = String::Concat(
                                sensorTypeString, _T(" pres & temp"));
                        }
                        if (spacelessStrings[count]->StartsWith("sta", StringComparison::OrdinalIgnoreCase))
                        {
                            commandTagIsValid = GUI_YES;
                            commandRequiresTarget = GUI_YES;
                            if (sensorType == DTSTEST_SENSOR_TYPE_GAUGE)
                                spacelessStrings[count] = _T("04 00 0C 00 02");
                            else
                                spacelessStrings[count] = _T("04 00 00 00 01");
                            generalCSVEntry->loggedCSVInterpretationString = String::Concat(
                                sensorTypeString, _T(" status"));
                        }
                        if (spacelessStrings[count]->StartsWith("otp", StringComparison::OrdinalIgnoreCase))
                        {
                            commandTagIsValid = GUI_YES;
                            commandRequiresTarget = GUI_YES;
                            if (sensorType == DTSTEST_SENSOR_TYPE_GAUGE)
                                commandNotRecognizedForSensorType = GUI_YES;
                            else
                                spacelessStrings[count] = _T("04 00 08 00 02");
                            generalCSVEntry->loggedCSVInterpretationString = String::Concat(
                                sensorTypeString, _T(" OTP"));
                        }
                        if (spacelessStrings[count]->StartsWith("chi", StringComparison::OrdinalIgnoreCase) ||
                            spacelessStrings[count]->StartsWith("ven", StringComparison::OrdinalIgnoreCase))
                        {
                            commandTagIsValid = GUI_YES;
                            commandRequiresTarget = GUI_YES;
                            if (sensorType == DTSTEST_SENSOR_TYPE_GAUGE)
                            {
                                spacelessStrings[count] = _T("04 00 2C 00 0D");
                                generalCSVEntry->loggedCSVInterpretationString = String::Concat(
                                    sensorTypeString, _T(" vendor ID"));
                            }
                            else
                            {
                                spacelessStrings[count] = _T("04 00 01 00 01");
                                generalCSVEntry->loggedCSVInterpretationString = String::Concat(
                                    sensorTypeString, _T(" chip ID"));
                            }
                        }
                        if (spacelessStrings[count]->StartsWith("adc", StringComparison::OrdinalIgnoreCase))
                        {
                            commandTagIsValid = GUI_YES;
                            commandRequiresTarget = GUI_YES;
                            if (sensorType == DTSTEST_SENSOR_TYPE_GAUGE)
                                spacelessStrings[count] = _T("04 00 08 00 04");
                            else
                                spacelessStrings[count] = _T("04 00 06 00 02");
                            generalCSVEntry->loggedCSVInterpretationString = String::Concat(
                                sensorTypeString, _T(" ADC registers"));
                        }
                        if (spacelessStrings[count]->StartsWith("typ", StringComparison::OrdinalIgnoreCase))
                        {
                            commandTagIsValid = GUI_YES;
                            commandRequiresTarget = GUI_YES;
                            if (sensorType == DTSTEST_SENSOR_TYPE_GAUGE)
                                spacelessStrings[count] = _T("04 00 20 00 01");
                            else
                                commandNotRecognizedForSensorType = GUI_YES;
                            generalCSVEntry->loggedCSVInterpretationString = String::Concat(
                                sensorTypeString, _T(" type"));
                        }
                        if (spacelessStrings[count]->StartsWith("ver", StringComparison::OrdinalIgnoreCase))
                        {
                            commandTagIsValid = GUI_YES;
                            commandRequiresTarget = GUI_YES;
                            if (sensorType == DTSTEST_SENSOR_TYPE_GAUGE)
                                spacelessStrings[count] = _T("04 00 24 00 01");
                            else
                                commandNotRecognizedForSensorType = GUI_YES;
                            generalCSVEntry->loggedCSVInterpretationString = String::Concat(
                                sensorTypeString, _T(" version"));
                        }
                        if (spacelessStrings[count]->StartsWith("hol", StringComparison::OrdinalIgnoreCase))
                        {
                            commandTagIsValid = GUI_YES;
                            commandRequiresTarget = GUI_YES;
                            if (sensorType == DTSTEST_SENSOR_TYPE_GAUGE)
                                spacelessStrings[count] = _T("04 00 26 00 04");
                            else
                                commandNotRecognizedForSensorType = GUI_YES;
                            generalCSVEntry->loggedCSVInterpretationString = String::Concat(
                                sensorTypeString, _T(" holding registers"));
                        }
                        if (spacelessStrings[count]->StartsWith("fla", StringComparison::OrdinalIgnoreCase))
                        {
                            commandTagIsValid = GUI_YES;
                            commandRequiresTarget = GUI_YES;
                            if (sensorType == DTSTEST_SENSOR_TYPE_GAUGE)
                                spacelessStrings[count] = _T("04 00 2A 00 01");
                            else
                                commandNotRecognizedForSensorType = GUI_YES;
                            generalCSVEntry->loggedCSVInterpretationString = String::Concat(
                                sensorTypeString, _T(" flag"));
                        }
                        if (spacelessStrings[count]->StartsWith("pow", StringComparison::OrdinalIgnoreCase))
                        {
                            calculateCRC = GUI_NO;
                            commandTagIsValid = GUI_YES;
                            commandRequiresTarget = GUI_YES;
                            if (sensorType == DTSTEST_SENSOR_TYPE_GAUGE)
                            {
                                DTSTest_PDGICEnablePowerToAllGaugeBarges(pgInfo);
                                if (pgInfo->powerToBargesEnabled)
                                    generalCSVEntry->loggedCSVInterpretationString = String::Concat(
                                        sensorTypeString, _T(" power enabled"));
                                else
                                    translatedString += String::Concat(
                                        (StringSet(translatedString) ? Environment::NewLine : String::Empty),
                                        _T("    => !!! Gauge power from '"),
                                        placeholderValueString,
                                        "' could not be enabled");
                            }
                            else
                                commandNotRecognizedForSensorType = GUI_YES;
                        }
                        if (spacelessStrings[count]->StartsWith("nop", StringComparison::OrdinalIgnoreCase))
                        {
                            calculateCRC = GUI_NO;
                            commandTagIsValid = GUI_YES;
                            commandRequiresTarget = GUI_YES;
                            if (sensorType == DTSTEST_SENSOR_TYPE_GAUGE)
                            {
                                BYTE originaNodeAddress = pgInfo->nodeAddress;
                                pgInfo->nodeAddress = nodeAddress;
                                DTSTest_PDGICDisablePowerToAllGaugeBarges(pgInfo);
                                pgInfo->nodeAddress = originaNodeAddress;
                                if (pgInfo->powerToBargesEnabled)
                                    translatedString += String::Concat(
                                        (StringSet(translatedString) ? Environment::NewLine : String::Empty),
                                        _T("    => !!! Gauge power from '"),
                                        nodeAddressString,
                                        "' could not be disabled");
                                else
                                    generalCSVEntry->loggedCSVInterpretationString = String::Concat(
                                        sensorTypeString, _T(" power disabled"));
                            }
                            else
                                commandNotRecognizedForSensorType = GUI_YES;
                        }
                    }                   // end of if (nodeAddress || placeholderErrorPresent)
                    //--------------------------------------------------------
                    // Commands that are node address-independent
                    //--------------------------------------------------------
                    if (spacelessStrings[count]->StartsWith("syn", StringComparison::OrdinalIgnoreCase))
                    {
                        targetMissing = GUI_NO;
                        commandTagIsValid = GUI_YES;
                        spacelessStrings[0] = _T("FE 06 00 0A 00 01");
                        generalCSVEntry->loggedCSVInterpretationString = _T("Sync");
                        if (spacelessStrings->Length > 1)
                        {
                            for (int offset = 1; offset < spacelessStrings->Length; offset++)
                                spacelessStrings[offset] = String::Empty;
                            break;
                        }
                    }
                    if (spacelessStrings[count]->StartsWith("bau", StringComparison::OrdinalIgnoreCase))
                    {
                        targetMissing = GUI_NO;
                        commandTagIsValid = GUI_YES;
                        translatedString += DTSTest_ScriptProcessBaudRateChangeString(
                            commandString);
                        break;
                    }                   // end of if (spacelessStrings[count]->StartsWith("bau", ...))
                    if (commandTagIsValid)
                    {
                        if (commandNotRecognizedForSensorType)
                        {
                            translatedString += String::Concat(
                                (StringSet(translatedString) ? Environment::NewLine : String::Empty),
                                _T("    => !!! Command '"),
                                spacelessStrings[count],
                                "' is not recognized for ",
                                ((sensorType == DTSTEST_SENSOR_TYPE_GAUGE) ? "gauge " : ((sensorType == DTSTEST_SENSOR_TYPE_DTS) ? "DTS " : "DPS ")),
                                nodeAddressString);
                            generalCSVEntry->loggedCSVInterpretationString = String::Concat(
                                _T("Invalid "),
                                ((sensorType == DTSTEST_SENSOR_TYPE_GAUGE) ? "gauge " : ((sensorType == DTSTEST_SENSOR_TYPE_DTS) ? "DTS " : "DPS ")),
                                _T(" command"));
                        }               // end of if (commandNotRecognizedForSensorType)
                        else
                        {
                            atLeastOneCommandTagIsValid = GUI_YES;
                        }
                    }                   // end of if (commandTagIsValid)
                    else
                    {
                        translatedString += String::Concat(
                            (StringSet(translatedString) ? Environment::NewLine : String::Empty),
                            _T("    => !!! Command '"),
                            spacelessStrings[count],
                            "' is not recognized");
                        generalCSVEntry->loggedCSVInterpretationString = _T("Invalid command");
                    }
                }                       // end of if (spacelessStrings[count]->Length > 2)
                else
                {
                    //--------------------------------------------------------
                    // Process the commands whose tags are two characters long
                    // or less
                    //--------------------------------------------------------
                    if (spacelessStrings[count]->StartsWith("br", StringComparison::OrdinalIgnoreCase))
                    {
                        targetMissing = GUI_NO;
                        commandTagIsValid = GUI_YES;
                        translatedString += DTSTest_ScriptProcessBaudRateChangeString(
                            commandString);
                        break;
                    }                   // end of if (spacelessStrings[count]->StartsWith("bau", ...))
                    if (spacelessStrings[count]->StartsWith("id", StringComparison::OrdinalIgnoreCase))
                    {
                        calculateCRC = GUI_YES;
                        targetMissing = GUI_NO;
                        commandTagIsValid = GUI_YES;
                        spacelessStrings[count] = _T("00 11");
                        generalCSVEntry->loggedCSVInterpretationString = _T("Return device ID");
                        break;
                    }                   // end of if (spacelessStrings[count]->StartsWith("bau", ...))
                    if ((spacelessStrings[count]->Length != 2) ||
                        (!spacelessStrings[count]->Contains(DTSTEST_STRING_DOLLAR) &&
                            (!isxdigit(spacelessStrings[count][0]) ||
                            !isxdigit(spacelessStrings[count][1]))))
                    {
                        translatedString += String::Concat(
                            (StringSet(translatedString) ? Environment::NewLine : String::Empty),
                            _T("    => !!! Command '"),
                            spacelessStrings[count],
                            "' is not recognized");
                        generalCSVEntry->loggedCSVInterpretationString = _T("Invalid command");
                    }
                }
            }
        }                               // end of for (int count = 0; ...)
        if (targetMissing && commandRequiresTarget && !commandNotRecognizedForSensorType)
        {
            translatedString += String::Concat(
                (StringSet(translatedString) ? Environment::NewLine : String::Empty),
                _T("    => !!! Command '"),
                commandString,
                "' is missing the target node (MODBUS address)");
            generalCSVEntry->loggedCSVInterpretationString = _T("Invalid command");
        }
        //--------------------------------------------------------------------
        // Reconstruct the command string
        //--------------------------------------------------------------------
        if (!StringSet(translatedString) || !translatedString->Contains("=>"))
        {
            translatedString = String::Join(DTSTEST_STRING_SPACE, spacelessStrings);
            array <String ^> ^newSpacelessStrings = translatedString->Split(
                spaceDelimiters,
                StringSplitOptions::RemoveEmptyEntries);
            translatedString = String::Join(DTSTEST_STRING_SPACE, newSpacelessStrings);
            if (calculateCRC)
            {
                //------------------------------------------------------------
                // Append the CRC to the command string
                //------------------------------------------------------------
                translatedString = DTSTest_ScriptCalculateAndAppendCRC(
                    translatedString);
            }
        }
        delete [] spacelessStrings;
        delete [] spaceDelimiters;
    }                                   // end of if (StringSet(commandString))
    RecordBasicEvent("{0} concluded", functionName);
    return translatedString;
}                                       // end of DTSTest_ScriptTranslateCommandString()
//----------------------------------------------------------------------------
#endif      // SCRIPTING_CPP
//============================================================================
// End of Scripting.cpp
//============================================================================
