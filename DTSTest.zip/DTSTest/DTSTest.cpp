//============================================================================
// DTSTest.cpp
//
// DTSTest software
//
// Copyright (C) 2014 - 2016 Quartzdyne, Inc.  All rights reserved.
//
// No part of this source code may be reproduced or transmitted in any form or
// by any means, electronic or mechanical, including photocopying, recording,
// or any information storage and retrieval system, without express written
// permission from Quartzdyne, Inc.  Further, no use of this source code is
// permitted in any form or means without a valid, written license agreement
// with Quartzdyne, Inc.  While every reasonable precaution has been taken in
// the preparation of this source code, Quartzdyne, Inc., assumes no
// responsibility for errors, omissions, or damages from the use of the source
// code contained herein.
//
// NEITHER QUARTZDYNE, INC., ANY MEMBER OF QUARTZDYNE, INC., NOR ANY PERSON OR
// ORGANIZATION ACTING ON BEHALF OF THEM MAKES ANY WARRANTY OR REPRESENTATION
// WHATSOEVER, EXPRESS OR IMPLIED, INCLUDING ANY WARRANTY OF MERCHANTABILITY
// OR FITNESS FOR ANY PURPOSE WITH RESPECT TO THE SOURCE CODE OR ASSUMES ANY
// LIABILITY WHATSOEVER WITH RESPECT TO ANY USE OF THE SOURCE CODE OR ANY
// PORTION THEREOF OR WITH RESPECT TO ANY DAMAGES THAT MAY RESULT FROM SUCH
// USE.
//
// Noji Ratzlaff
//
// See DTSTest.log for a complete history of all updates, changes, and revisions
// of this source and other files and policies regarding DTSTest software
//
// Updated 01-14-2016
//============================================================================
#include    "stdafx.h"
#ifndef     DTSTEST_CPP
#define     DTSTEST_CPP
#include    "DTSTest.h"
//----------------------------------------------------------------------------
// DTSTest_Main
//
// Main program entry point (this is the WinMain function)
//
// Returns: 0           Success
//          nonzero     Failure
//
// Note:    [STAThread] indicates that the program (Windows Forms, in general)
//          uses the single-threaded apartment (STA) model, which is required
//          for several necessary features, including the ShowDialog() method
//          for several classes.
//----------------------------------------------------------------------------
[STAThread]
    int APIENTRY
DTSTest_Main(
    HINSTANCE       instanceHandle,
    HINSTANCE       previousInstance,
    LPTSTR          commandLine,
    int             displayMode)        // maximize, minimize, or normal
{
    DWORD           mainStatus = DTSTEST_SUCCESS;
    HANDLE          mutexHandle;
    //------------------------------------------------------------------------
    UNREFERENCED_PARAMETER(instanceHandle);
    UNREFERENCED_PARAMETER(previousInstance);
    UNREFERENCED_PARAMETER(displayMode);
    DTSTest_SetCommandLineFlags(commandLine);
    if (OpenMutex(SYNCHRONIZE, DTSTEST_YES, DTSTEST_MUTEX_STRING))
    {
        DTSTest_ModalMessage(
            DTSTEST_YES,
            GUI_MODAL_ICON_CRITICAL,
            "DTSTest_Main",
            "DTSTest is already running");
    }
    else
    {
        mutexHandle = CreateMutex(NULL, DTSTEST_YES, DTSTEST_MUTEX_STRING);
        if (mainStatus == DTSTEST_SUCCESS)
        {
            //----------------------------------------------------------------
            // Run the entire program from a single Form class
            //----------------------------------------------------------------
            Application::Run(gcnew DTSTest_GUIClass);
        }
        ReleaseMutex(mutexHandle);
    }
    return (int) mainStatus;
}                                       // end of DTSTest_Main()
//----------------------------------------------------------------------------
// DTSTest_CaptureCommandLine
//
// Retrieves the command line, if present
//
// Called by:   DTSTest_InitializeDTSTest
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_CaptureCommandLine(void)
{
    //------------------------------------------------------------------------
    if (DTSTest_GeneralInfo->flags & DTSTEST_GENERAL_ALLOCATED)
    {
        array <String ^> ^parameters = Environment::GetCommandLineArgs();
        if (parameters->Length > 1)
            DTSTest_GeneralInfo->commandLine = String::Join(
                " ", parameters, 1, (parameters->Length - 1));
        else
            DTSTest_GeneralInfo->commandLine = String::Empty;
    }
    else
    {
        DTSTest_DisplayModalMessage(
            DTSTEST_YES,
            GUI_MODAL_ICON_ERROR,
            "DTSTest_CaptureCommandLine",
            "Serious: General info not allocated");
    }
}                                       // end of DTSTest_CaptureCommandLine()
//----------------------------------------------------------------------------
// DTSTest_Finalize
//
// Saves the config data, concludes the running logs, and releases resources
//
// Called by:   DTSTest_Start
//              DTSTest_CheckForCurrentSoftwareVersion
//              DTSTest_ShutDownSoftware
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_Finalize(
    String          ^finalEventEntry)
{
    String          ^functionName = _T("DTSTest_Finalize");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0} called", functionName);
    DTSTest_SaveConfigData();
    RecordBasicEvent("{0} concluded", functionName);
    DTSTest_ConcludeGeneralLogs(finalEventEntry);
    DTSTest_FreeGeneralElements();
}                                       // end of DTSTest_Finalize()
//----------------------------------------------------------------------------
// DTSTest_FreeGeneralElements
//
// Frees the memory previously allocated for all unmanaged general elements
//
// Called by:   DTSTest_Finalize
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_FreeGeneralElements(void)
{
    //------------------------------------------------------------------------
    if (DTSTest_GeneralInfo)
    {
        delete generalCSVEntry;
        delete DTSTest_GeneralInfo;
    }
}                                       // end of DTSTest_FreeGeneralElements()
//----------------------------------------------------------------------------
// DTSTest_InitializeDTSTest
//
// Initializes the DTSTest system
//
// Returns  0       : Success
//          nonzero : Failure
//
// Called by:   DTSTest_Start
//----------------------------------------------------------------------------
    DWORD DTSTest_GUIClass::
DTSTest_InitializeDTSTest(void)
{
    DWORD           status = DTSTEST_SUCCESS;
    String          ^functionName = _T("DTSTest_InitializeDTSTest");
    //------------------------------------------------------------------------
    DTSTest_InitializeProgramComponents();
    DTSTest_CaptureCommandLine();
    DTSTest_StartTime = GetTickCount();
    DTSTest_SetBuildNumber();
    if (status == DTSTEST_SUCCESS)
    {
        ModalD("Loc 4 : Before DTSTest_EstablishErrorLog");
        DTSTest_EstablishErrorLog();
        ModalD("Loc 5 : Between DTSTest_EstablishErrorLog and DTSTest_EstablishEventLog");
        DTSTest_EstablishEventLog(String::Format("{0} called", functionName));
        ModalD("Loc 6 : Between DTSTest_EstablishEventLog and DTSTest_ProcessCommandLineParameters");
        status = DTSTest_ProcessCommandLineParameters();
        ModalD("Loc 7 : DTSTest_ProcessCommandLineParameters returned status 0x{0:X8}", status);
        if (status == DTSTEST_SUCCESS)
        {
            if (DTSTest_DetailedMessagesEnabled)
            {
                DTSTest_VerboseMessagesEnabled = DTSTEST_YES;
            }
            if (DTSTest_VerboseMessagesEnabled)
            {
                DTSTest_BasicMessagesEnabled = DTSTEST_YES;
                DTSTest_ErrorMessagesEnabled = DTSTEST_YES;
            }
            if (DTSTest_StackTracesEnabled)
                DTSTest_ErrorMessagesEnabled = DTSTEST_YES;
            //----------------------------------------------------------------
            // Apply the initial settings
            //----------------------------------------------------------------
            DTSTest_GeneralInfo->flags |= DTSTEST_GENERAL_INITIAL_SETTINGS;
            DTSTest_GeneralInfo->persistentFlags |= DTSTEST_GENERAL_DEFAULT_PERSISTENT_FLAGS;
            //----------------------------------------------------------------
            // Discover and record the Windows environment
            //----------------------------------------------------------------
            DTSTest_GetWindowsEnvironment();
            DTSTest_LogTesterInfo();
            ModalD("Loc 8 : Between DTSTest_GetWindowsEnvironment and DTSTest_ScanForDevices");
            //----------------------------------------------------------------
            // The software is fully operational, so check whether the
            // hardware is present
            //----------------------------------------------------------------
            DTSTest_ScanForDevices();
            ModalD("Loc 9 : Between DTSTest_ScanForDevices and DTSTest_RetrieveConfigData");
            //----------------------------------------------------------------
            // Populate the program with configuration information from the
            // the config file, if it is present
            //----------------------------------------------------------------
            DTSTest_RetrieveConfigData();
            if (status == DTSTEST_SUCCESS)
            {
                DTSTest_DetermineResultsLog();
                DTSTest_PDGICRetrieveCurrentReadings();
                RecordVerboseEvent("Pre-GUI initialization completed successfully");
            }
        }
    }
    ModalD("Loc 10 : End of {0}, and status = 0x{1:X8}", functionName, status);
    RecordVerboseEvent("{0} concluded, returning 0x{1:X8}", functionName, status);
    return status;
}                                       // end of DTSTest_InitializeDTSTest()
//----------------------------------------------------------------------------
// DTSTest_InitializeProgramComponents
//
// Initializes program components needed before the GUI is constructed
//
// Called by:   DTSTest_InitializeDTSTest
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_InitializeProgramComponents(void)
{
    //------------------------------------------------------------------------
    DTSTest_GeneralInfo = gcnew GeneralInfo;
    //------------------------------------------------------------------------
    // Apply the initial settings
    //------------------------------------------------------------------------
    DTSTest_GeneralInfo->flags = DTSTEST_GENERAL_ALLOCATED | DTSTEST_GENERAL_INITIAL_SETTINGS;
    DTSTest_GeneralInfo->persistentFlags = DTSTEST_GENERAL_DEFAULT_PERSISTENT_FLAGS;
    //------------------------------------------------------------------------
    // Initialize general fields
    //------------------------------------------------------------------------
    DTSTest_GeneralInfo->commandLine = String::Empty;
    DTSTest_GeneralInfo->configFilePath = String::Empty;
    DTSTest_GeneralInfo->generalUsePath = String::Empty;
    DTSTest_GeneralInfo->logDirectory = String::Empty;
    DTSTest_GeneralInfo->errorLogPath = String::Empty;
    DTSTest_GeneralInfo->eventLogPath = String::Empty;
    DTSTest_GeneralInfo->windowsVersion = String::Empty;
    DTSTest_GeneralInfo->emailAddress = String::Empty;
    DTSTest_GeneralInfo->emailCCAddress = String::Empty;
    DTSTest_GeneralInfo->textMessageToNumber = String::Empty;
    DTSTest_GeneralInfo->textMessageCCNumber = String::Empty;
    DTSTest_GeneralInfo->emailMessageToAddress = String::Empty;
    DTSTest_GeneralInfo->emailMessageCCAddress = String::Empty;
    DTSTest_GeneralInfo->searchString = String::Empty;
    DTSTest_GeneralInfo->serialPortsSearchedArray = gcnew array <String ^> (DTSTEST_MAXIMUM_NUMBER_OF_PORTS);
    Script ^mainScript = gcnew Script;
    mainScript->controlScriptString = String::Empty;
    mainScript->controlScriptIsLoaded = GUI_NO;
    mainScript->controlScriptFilePath = String::Empty;
    mainScript->resultsLogFilePath = String::Empty;
    mainScript->placeholder1String = String::Empty;
    mainScript->placeholder1Value = 0;
    mainScript->placeholder2String = String::Empty;
    mainScript->placeholder2Value = 0;
    mainScript->placeholder3String = String::Empty;
    mainScript->placeholder3Value = 0;
    mainScript->scriptNumberOfFailures = 0;
    mainScript->scriptNumberOfPasses = 0;
    DTSTest_GeneralInfo->mainScript = mainScript;
    for (int portNumber = 0; portNumber < DTSTEST_MAXIMUM_NUMBER_OF_PORTS; portNumber++)
    {
        DTSTest_GeneralInfo->serialPortsSearchedArray[portNumber] = String::Empty;
    }
    DTSTest_GeneralInfo->serialPortsSearchedCount = 0;
    CoefficientInfo ^defaultCoefficientInfo = gcnew CoefficientInfo;
    defaultCoefficientInfo->cffFilePath = String::Empty;
    defaultCoefficientInfo->cftFilePath = String::Empty;
    defaultCoefficientInfo->hexFilePath = String::Empty;
    defaultCoefficientInfo->cof2FilePath = String::Empty;
    defaultCoefficientInfo->coefficientData =
        (CoefficientDataFormat *) malloc(sizeof(CoefficientDataFormat));
    if (defaultCoefficientInfo->coefficientData)
        ClearBuffer(defaultCoefficientInfo->coefficientData, sizeof(CoefficientDataFormat));
    else
        defaultCoefficientInfo->coefficientData = (CoefficientDataFormat *) 0;
    defaultCoefficientInfo->coefficientDataLoaded = GUI_NO;
    DTSTest_GeneralInfo->defaultCoefficientInfo = defaultCoefficientInfo;
    PDGICInfo ^pgInfo = gcnew PDGICInfo;
    pgInfo->port = nullptr;
    pgInfo->portName = String::Empty;
    pgInfo->modelName = String::Empty;
    pgInfo->serialNumber = 0;
    pgInfo->firmwareVersion = 0;
    pgInfo->maximumNumberOfSlots = 0;
    pgInfo->channelPowerEnabled = GUI_NO;
    pgInfo->configuredToRequestTransducerData = GUI_NO;
    pgInfo->numberOfRegistersToTransfer = 0;
    pgInfo->numberOfBytesRead = 0;
    pgInfo->writeData = 0;
//    pgInfo->controlScriptIsLoaded = GUI_NO;
//    pgInfo->currentControlScriptPathName = String::Empty;
//    pgInfo->currentControlScript = String::Empty;
    pgInfo->commandArray = gcnew array <unsigned char> (PDGIC_MODBUS_MAXIMUM_COMMAND_LENGTH);
    pgInfo->responseArray = gcnew array <unsigned char> (PDGIC_MODBUS_MAXIMUM_RESPONSE_LENGTH);
    pgInfo->atLeastOneSensorPresent = GUI_NO;
    pgInfo->numberOfSensors = 0;
    pgInfo->sensorInfoArray = gcnew array <SensorInfo ^> (DTSTEST_MAXIMUM_NUMBER_OF_SENSORS);
    for (int sensorNumber = 0; sensorNumber < DTSTEST_MAXIMUM_NUMBER_OF_SENSORS; sensorNumber++)
    {
        SensorInfo ^sensor = gcnew SensorInfo;
        sensor->measurementsValid = GUI_NO;
        sensor->addBias = GUI_NO;               // This MUST be set to NO initially
        sensor->nodeAddress = (BYTE) sensorNumber;
        sensor->sensorNumber = sensorNumber;
        sensor->sensorPresent = GUI_NO;
        sensor->sensorIdentified = GUI_NO;
        switch (sensorNumber)
        {
            case 0x00 :
                sensor->sensorType = DTSTEST_SENSOR_TYPE_BROADCAST_GAUGE;
                break;
            case 0xFE :
                sensor->sensorType = DTSTEST_SENSOR_TYPE_BROADCAST_BARGE;
                break;
            default :
                sensor->sensorType = DTSTEST_SENSOR_TYPE_UNKNOWN;
                break;
        }
        sensor->hardwareIDString = String::Empty;
        sensor->pressurePSI = 0.0;
        sensor->temperatureCelsius = 0.0;
        sensor->pressureFrequency = 0.0;
        sensor->temperatureFrequency = 0.0;
        sensor->numberOfSamples = 0;
        sensor->currentPressureCount = 0;
        sensor->currentPressureFrequency = 0.0;
        sensor->currentPressurePSI = 0.0;
        sensor->totalPressurePSI = 0.0;
        sensor->pressurePSIBias = 0.0;
        sensor->currentTemperatureCount = 0;
        sensor->currentTemperatureFrequency = 0.0;
        sensor->currentTemperatureCelsius = 0.0;
        sensor->totalTemperatureCelsius = 0.0;
        sensor->temperatureCelsiusBias = 0.0;
        CoefficientInfo ^coefficientInfo = gcnew CoefficientInfo;
        coefficientInfo->cffFilePath = String::Empty;
        coefficientInfo->cftFilePath = String::Empty;
        coefficientInfo->hexFilePath = String::Empty;
        coefficientInfo->cof2FilePath = String::Empty;
        coefficientInfo->coefficientData =
            (CoefficientDataFormat *) malloc(sizeof(CoefficientDataFormat));
        if (coefficientInfo->coefficientData)
            ClearBuffer(coefficientInfo->coefficientData, sizeof(CoefficientDataFormat));
        else
            coefficientInfo->coefficientData = (CoefficientDataFormat *) 0;
        coefficientInfo->coefficientDataLoaded = GUI_NO;
        sensor->coefficientInfo = coefficientInfo;
        pgInfo->sensorInfoArray[sensorNumber] = sensor;
    }                               // end of for (int sensorNumber = 0; ...)
    DTSTest_GeneralInfo->pgInfo = pgInfo;
    Calibrate ^calibrate = gcnew Calibrate;
    calibrate->nodeAddress = DTSTEST_SENSOR_ADDRESS_NONE;
    calibrate->hybridSerialNumberString = String::Empty;
    calibrate->jigSerialNumberString = String::Empty;
    calibrate->pressureAmbientCount = 0;
    calibrate->temperatureAmbientCount = 0;
    calibrate->temperature100Count = 0;
    calibrate->temperature150Count = 0;
    calibrate->temperature175Count = 0;
    calibrate->temperature200Count = 0;
    calibrate->temperature225Count = 0;
    calibrate->coefficientData =
        (CoefficientDataFormat *) malloc(sizeof(CoefficientDataFormat));
    ClearBuffer(calibrate->coefficientData, sizeof(CoefficientDataFormat));
    DTSTest_GeneralInfo->calibrate = calibrate;
    //------------------------------------------------------------------------
    // Initialize the CSV entry information structure
    //------------------------------------------------------------------------
    generalCSVEntry = gcnew CSVEntryInfo;
    //------------------------------------------------------------------------
    // Initialize CSV fields
    //------------------------------------------------------------------------
    generalCSVEntry->scriptLineNumber = 0;
    generalCSVEntry->scriptLineNumberString = String::Empty;
    generalCSVEntry->loggedCSVEntryString = String::Empty;
    generalCSVEntry->logCSVDate = GUI_YES;
    generalCSVEntry->loggedCSVDateString = String::Empty;
    generalCSVEntry->logCSVTime = GUI_YES;
    generalCSVEntry->loggedCSVTimeString = String::Empty;
    generalCSVEntry->logCSVHardwareID = GUI_YES;
    generalCSVEntry->loggedCSVHardwareIDString = String::Empty;
    generalCSVEntry->logCSVState = GUI_YES;
    generalCSVEntry->loggedCSVStateString = String::Empty;
    generalCSVEntry->logCSVBaudRateState = GUI_YES;
    generalCSVEntry->loggedCSVBaudRateStateString = DTSTEST_STRING_1200_BAUD;
    generalCSVEntry->logCSVCRCState = GUI_YES;
    generalCSVEntry->loggedCSVCRCStateString = DTSTEST_STRING_CRC_OFF;
    generalCSVEntry->logCSVSyncState = GUI_YES;
    generalCSVEntry->loggedCSVSyncStateString = String::Empty;
    generalCSVEntry->logCSVFreshState = GUI_YES;
    generalCSVEntry->loggedCSVFreshStateString = String::Empty;
    generalCSVEntry->logCSVCableLengthState = GUI_YES;
    generalCSVEntry->loggedCSVCableLengthStateString = String::Empty;
    generalCSVEntry->logCSVTempState = GUI_YES;
    generalCSVEntry->loggedCSVTempStateString = String::Empty;
    generalCSVEntry->logCSVVoltageState = GUI_YES;
    generalCSVEntry->loggedCSVVoltageStateString = String::Empty;
    generalCSVEntry->logCSVInput = GUI_YES;
    generalCSVEntry->loggedCSVInputString = String::Empty;
    generalCSVEntry->logCSVDelay = GUI_YES;
    generalCSVEntry->loggedCSVDelayString = String::Empty;
    generalCSVEntry->logCSVAddress = GUI_YES;
    generalCSVEntry->loggedCSVAddressString = String::Empty;
    generalCSVEntry->logCSVCommand = GUI_YES;
    generalCSVEntry->loggedCSVCommandString = String::Empty;
    generalCSVEntry->logCSVSent = GUI_YES;
    generalCSVEntry->loggedCSVSentString = String::Empty;
    generalCSVEntry->logCSVReply = GUI_YES;
    generalCSVEntry->loggedCSVReplyString = String::Empty;
    generalCSVEntry->logCSVExpected = GUI_YES;
    generalCSVEntry->loggedCSVExpectedString = String::Empty;
    generalCSVEntry->logCSVPrefix = GUI_YES;
    generalCSVEntry->loggedCSVPrefixString = String::Empty;
    generalCSVEntry->logCSVStatus = GUI_YES;
    generalCSVEntry->loggedCSVStatusString = String::Empty;
    generalCSVEntry->logCSVChipID = GUI_YES;
    generalCSVEntry->loggedCSVChipIDString = String::Empty;
    generalCSVEntry->logCSVOTP = GUI_YES;
    generalCSVEntry->loggedCSVOTPString = String::Empty;
    generalCSVEntry->logCSVPressureCount = GUI_YES;
    generalCSVEntry->loggedCSVPressureCountHexString = String::Empty;
    generalCSVEntry->loggedCSVPressureCountDecimalString = String::Empty;
    generalCSVEntry->logCSVPressureActual = GUI_YES;
    generalCSVEntry->loggedCSVPressureActualString = String::Empty;
    generalCSVEntry->logCSVTemperatureCount = GUI_YES;
    generalCSVEntry->loggedCSVTemperatureCountHexString = String::Empty;
    generalCSVEntry->loggedCSVTemperatureCountDecimalString = String::Empty;
    generalCSVEntry->logCSVTemperatureActual = GUI_YES;
    generalCSVEntry->loggedCSVTemperatureActualString = String::Empty;
    generalCSVEntry->logCSVType = GUI_YES;
    generalCSVEntry->loggedCSVTypeString = String::Empty;
    generalCSVEntry->logCSVVersion = GUI_YES;
    generalCSVEntry->loggedCSVVersionString = String::Empty;
    generalCSVEntry->logCSVHolding = GUI_YES;
    generalCSVEntry->loggedCSVHoldingString = String::Empty;
    generalCSVEntry->logCSVVendor = GUI_YES;
    generalCSVEntry->loggedCSVVendorString = String::Empty;
    generalCSVEntry->logCSVRemaining = GUI_YES;
    generalCSVEntry->loggedCSVRemainingString = String::Empty;
    generalCSVEntry->logCSVInterpretation = GUI_YES;
    generalCSVEntry->loggedCSVInterpretationString = String::Empty;
    generalCSVEntry->logCSVResult = GUI_YES;
    generalCSVEntry->loggedCSVResultString = String::Empty;
    generalCSVEntry->logCSVError = GUI_YES;
    generalCSVEntry->loggedCSVErrorString = String::Empty;
    generalCSVEntry->logCSVComment = GUI_YES;
    generalCSVEntry->loggedCSVCommentString = String::Empty;
    generalCSVEntry->logCSVInstructionalComment = GUI_YES;
    generalCSVEntry->loggedCSVInstructionalCommentString = String::Empty;
    //------------------------------------------------------------------------
    // Retrieve the background images and sounds needed for the program
    //------------------------------------------------------------------------
    DTSTest_LoadImagesAndSounds();
    //------------------------------------------------------------------------
    // Create, initialize, and display the "Please Wait . . ." window
    //------------------------------------------------------------------------
    DTSTest_PleaseWait(GUI_PLEASE_WAIT_INSTALL, nullptr);
    DTSTest_PleaseWait(
        GUI_PLEASE_WAIT_DISPLAY_NEW_TITLE,
        "Searching For Devices");
    //------------------------------------------------------------------------
    // Initialize other components
    //------------------------------------------------------------------------
    DTSTest_MonthStringArray = gcnew array <String ^>
        {
            _T("Unknown"), _T("Jan"), _T("Feb"), _T("Mar"), _T("Apr"), _T("May"),
            _T("Jun"), _T("Jul"), _T("Aug"), _T("Sep"), _T("Oct"), _T("Nov"), _T("Dec")
        };
//    DTSTest_ScriptPlaceholderArray = gcnew array <ScriptPlaceholder ^> (DTSTEST_MAXIMUM_NUMBER_OF_PLACEHOLDERS);
//    for (int offset = 0; offset < DTSTEST_MAXIMUM_NUMBER_OF_PLACEHOLDERS; offset++)
//    {
//        DTSTest_ScriptPlaceholderArray[offset] = gcnew ScriptPlaceholder;
//    }
    DTSTest_TestEntryArray = gcnew array <TestEntry ^> (DTSTEST_MAXIMUM_NUMBER_OF_TEST_ENTRIES);
    for (int offset = 0; offset < DTSTEST_MAXIMUM_NUMBER_OF_TEST_ENTRIES; offset++)
    {
        DTSTest_TestEntryArray[offset] = gcnew TestEntry;
        DTSTest_TestEntryArray[offset]->entrySelectedForTesting = GUI_NO;
        DTSTest_TestEntryArray[offset]->placeholder1Value = 0x00;
        DTSTest_TestEntryArray[offset]->placeholder2Value = 0x00;
        DTSTest_TestEntryArray[offset]->placeholder3Value = 0x00;
        DTSTest_TestEntryArray[offset]->primaryDeviceTypeString = String::Empty;
        DTSTest_TestEntryArray[offset]->entryControlScriptPath = String::Empty;
        DTSTest_TestEntryArray[offset]->entryControlScriptFile = String::Empty;
        DTSTest_TestEntryArray[offset]->entryCommandString = String::Empty;
        DTSTest_TestEntryArray[offset]->entryCommandReplacedString = String::Empty;
        DTSTest_TestEntryArray[offset]->coefficientDataLoaded = GUI_NO;
        DTSTest_TestEntryArray[offset]->allTestsCompleted = GUI_YES;
        DTSTest_TestEntryArray[offset]->allTestsPassed = GUI_NO;
        DTSTest_TestEntryArray[offset]->entryTestResults = 0;
    }
    DTSTest_SerialPortNameStringArray = gcnew array <String ^> (1);
}                                       // end of DTSTest_InitializeProgramComponents()
//----------------------------------------------------------------------------
// DTSTest_PerformCommandLineTasks
//
// Performs non-GUI tasks directed by the command-line parameters not already
// completed during command-line parsing
//
// Called by:   DTSTest_Main
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_PerformCommandLineTasks(void)
{
    String          ^functionName = _T("DTSTest_PerformCommandLineTasks");
    //------------------------------------------------------------------------
    RecordVerboseEvent("{0} called", functionName);
    RecordVerboseEvent("{0} concluded", functionName);
}                                       // end of DTSTest_PerformCommandLineTasks()
//----------------------------------------------------------------------------
// DTSTest_ProcessCommandLineParameters
//
// Parses the command line for basic acceptability
//
// The following command-line parameters are recognized:
//
//      /h or /help         Brings up the Help page in the default browser
//      /cfg                Loads configuration information on startup (/cfg- prevents)
//      /gui                Presents the graphical user interface (/gui- for command-line only)
//      /evta               Logs all events on startup
//      /evtb               Logs basic events on startup
//      /evtv               Logs verbose events on startup
//      /evtd               Logs detailed events on startup
//      /gui                Display the graphical user interface windows (/gui- prevents)
//      /mb                 Enables 'basic' modal messages on startup (/mb- disables)
//      /md                 Enables 'detailed' modal messages on startup (/md- disables)
//      /me                 Enables 'error' modal messages on startup (/me- disables)
//      /mv                 Enables 'verbose' modal messages on startup (/mv- disables)
//      /mx                 Enables 'experimental' modal messages on startup (/mx- disables)
//      /m0                 Disables all modal messages on startup
//      /x                  Starts the software in Expert Mode (/x- disables)
//      /?                  Displays only the program usage window
//
// Returns: 0       = Success
//          nonzero = Failure
//
// Note:    This function is called at the start of the program, right after
//          the creation of the error and event log files
//
// Called by:   DTSTest_InitializeDTSTest
//----------------------------------------------------------------------------
    DWORD DTSTest_GUIClass::
DTSTest_ProcessCommandLineParameters(void)
{
    bool            displayUsage = DTSTEST_NO;
    DWORD           status = DTSTEST_SUCCESS;
    String          ^functionName = _T("DTSTest_ProcessCommandLineParameters");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0} called", functionName);
    if (StringSet(DTSTest_GeneralInfo->commandLine))
    {
        ModalV("Processing command line\n{0}", DTSTest_GeneralInfo->commandLine);
        array <Char> ^lineDelimiters = gcnew array <Char> {' '};
        array <String ^> ^parameters = DTSTest_GeneralInfo->commandLine->ToLower()->Split(
            lineDelimiters,
            StringSplitOptions::RemoveEmptyEntries);
        //--------------------------------------------------------------------
        // All these parameters are assumed converted to lowercase
        //--------------------------------------------------------------------
        for each (String ^parameter in parameters)
        {
            int index = Array::IndexOf(parameters, parameter);
            if (StringSet(parameter))
            {
                ModalV("Checking parameter {0:D} = {1}", index, parameter);
                //------------------------------------------------------------
                // These are the acceptable command-line parameter prefixes
                //------------------------------------------------------------
                if ((parameter[0] == '/') || (parameter[0] == '-'))
                {
                    String ^optionString = parameter->Substring(1);
                    //--------------------------------------------------------
                    // Handle the multiple-hyphen or multiple-slash
                    // command-line parameter styles
                    //--------------------------------------------------------
                    while ((optionString->Length > 1) &&
                        ((optionString[0] == '/') || (optionString[0] == '-')))
                    {
                        optionString = optionString->Substring(1);
                    }
                    switch (optionString[0])
                    {
                        case 'c' :
                            {
                                if (optionString->Contains("cfg"))
                                {
                                    //----------------------------------------
                                    // Load / don't load config
                                    //----------------------------------------
                                    if (StringICompare(optionString, "cfg-"))
                                        DTSTest_GeneralInfo->flags &= ~DTSTEST_GENERAL_CONFIG_DONT_LOAD;
                                    else
                                        DTSTest_GeneralInfo->flags |= DTSTEST_GENERAL_CONFIG_DONT_LOAD;
                                }
                                else
                                {
                                    status = DTSTEST_ERROR_INVALID_PARAMETER;
                                }
                            }           // end of case 'c'
                            break;
                        case 'e' :
                            {
                                if (optionString->Contains("evt"))
                                {
                                    //----------------------------------------
                                    // Start logging events
                                    //----------------------------------------
                                    if (optionString->Length > 3)
                                    {
                                        switch (optionString[3])
                                        {
                                            case 'a' :
                                                RecordDetailedEvent(
                                                    "    Program command line: {0}",
                                                    DTSTest_GeneralInfo->commandLine);
                                                break;
                                            case 'b' :
                                                RecordBasicEvent(
                                                    "    Program command line: {0}",
                                                    DTSTest_GeneralInfo->commandLine);
                                            case 'd' :
                                                RecordDetailedEvent(
                                                    "    Program command line: {0}",
                                                    DTSTest_GeneralInfo->commandLine);
                                                break;
                                            case 'v' :
                                                RecordVerboseEvent(
                                                    "    Program command line: {0}",
                                                    DTSTest_GeneralInfo->commandLine);
                                                break;
                                            default :
                                                status = DTSTEST_ERROR_INVALID_PARAMETER;
                                                break;
                                        }
                                    }
                                    else
                                    {
                                        RecordBasicEvent(
                                            "    Program command line: {0}",
                                            DTSTest_GeneralInfo->commandLine);
                                    }
                                }
                                else
                                {
                                    status = DTSTEST_ERROR_INVALID_PARAMETER;
                                }
                            }           // end of case 'e'
                            break;
                        case 'g' :
                            {
                                if (optionString->Contains("gui"))
                                {
                                    //----------------------------------------
                                    // Run / don't run the GUI
                                    //----------------------------------------
                                    if (StringICompare(optionString, "gui-"))
                                        DTSTest_CommandLineOnly = DTSTEST_NO;
                                    else
                                        DTSTest_CommandLineOnly = DTSTEST_YES;
                                }
                                else
                                {
                                    status = DTSTEST_ERROR_INVALID_PARAMETER;
                                }
                            }           // end of case 'g'
                            break;
                        case 'm' :
                            //------------------------------------------------
                            // These are already processed in
                            // DTSTest_SetCommandLineFlags
                            //------------------------------------------------
                            {
                                if (optionString->Length > 1)
                                {
                                    switch (optionString[1])
                                    {
                                        case '0' :
                                        case 'b' :
                                        case 'd' :
                                        case 'e' :
                                        case 's' :
                                        case 'v' :
                                        case 'x' :
                                            break;
                                        default :
                                            status = DTSTEST_ERROR_INVALID_PARAMETER;
                                            break;
                                    }
                                }
                                else
                                {
                                    status = DTSTEST_ERROR_INVALID_PARAMETER;
                                }
                            }           // end of case 'm'
                            break;
                        case 'x' :
                            {
                                //--------------------------------------------
                                // Invoke / revoke Expert Mode
                                //--------------------------------------------
                                if (optionString->Length > 1)
                                {
                                    if (StringICompare(optionString, "x-") == 0)
                                        DTSTest_GeneralInfo->flags &= ~DTSTEST_GENERAL_EXPERT_MODE;
                                    else
                                        status = DTSTEST_ERROR_INVALID_PARAMETER;
                                }
                                else
                                {
                                    DTSTest_GeneralInfo->flags |= DTSTEST_GENERAL_EXPERT_MODE;
                                }
                            }           // end of case 'x'
                            break;
                        case 'h' :
                            {
                                if (optionString->Length > 1)
                                {
                                    if (StringICompare(optionString, "help"))
                                        status = DTSTEST_ERROR_INVALID_PARAMETER;
                                }
                                if (status == DTSTEST_SUCCESS)
                                {
                                    System::Diagnostics::Process::Start(DTSTEST_HELP_URL);
                                }
                            }           // end of case 'h'
                        case '?' :
                            displayUsage = DTSTEST_YES;
                            break;
                        default :
                            status = DTSTEST_ERROR_INVALID_PARAMETER;
                            break;
                    }                   // end of switch (*optionPtr)
                }                       // end of if ((parameter[0] == '/') || (parameter[0] == '-'))
                else
                {
                    if (parameter[0] == '?')
                    {
                        displayUsage = DTSTEST_YES;
                    }
                    else
                    {
                        status = DTSTEST_ERROR_INVALID_PARAMETER;
                    }
                }
            }                           // end of if (optionPtr && strlen(optionPtr))
            if (status == DTSTEST_ERROR_INVALID_PARAMETER)
            {
                Modal("Invalid Command-line Parameter:\n{0}", parameter);
                //------------------------------------------------------------
                // An invalid parameter is not fatal to program function, so
                // clear the error and allow the program to continue, but
                // display the Usage
                //------------------------------------------------------------
                status = DTSTEST_SUCCESS;
                displayUsage = DTSTEST_YES;
            }
        }                               // end of for each (String ^parameter in parameters)
        if (displayUsage)
        {
            ModalT("DTSTest Command-line Usage",
                "The acceptable command-line parameters for DTSTest are\n\n"
                "    /m0    Turn off all modal messages\n"
                "    /mb    Enable basic modal messages (/mb- disables)\n"
                "    /md    Enable detailed modal messages (/md- disables)\n"
                "    /me    Enable error modal messages (/me- disables)\n"
                "    /ms    Enable modal error stack traces (/ms- disables)\n"
                "    /mv    Enable verbose modal messages (/mv- disables)\n"
                "    /mx    Enable experimental modal messages (/mx- disables)\n"
                "    /evta  Start logging all events\n"
                "    /evtb  Start logging basic events (also /evt)\n"
                "    /evtv  Start logging verbose events\n"
                "    /evtd  Start logging detailed events\n"
                "    /cfg   Load config information on startup (/cfg- prevents)\n"
                "    /gui   Display the user interface (/gui- for command-line only)\n"
                "    /x     Start up in Expert Mode (/x- disables)\n"
                "    /h     Display this usage, along with the online Help\n"
                "    /?     Display this usage window only");
        }
        delete [] parameters;
        delete [] lineDelimiters;
    }                                   // end of if (StringSet(DTSTest_GeneralInfo->commandLine))
    RecordVerboseEvent("{0} concluded, returning 0x{1:X8}", functionName, status);
    return status;
}                                       // end of DTSTest_ProcessCommandLineParameters()
//----------------------------------------------------------------------------
// DTSTest_ScanForDevices
//
// Scans the system for a Fluke ScopeMeter and a WellDynamics PDGIC
//
// Called by:   DTSTest_InitializeDTSTest
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_ScanForDevices(void)
{
    int             attempts = 3;
    DWORD           status = DTSTEST_SUCCESS;
    String          ^functionName = _T("DTSTest_ScanForDevices");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0} called", functionName);
//Modal("About to initialize PDGIC");
    status = DTSTest_PDGICInitializeEnvironment();
    if (status == DTSTEST_SUCCESS)
    {
    }
    else
    {
        DTSTest_PromptOKModal(functionName,
            "Unable to locate a DTS or DPS device on this computer");
//            "Unable to locate a PDGIC device on this computer\nError = 0x{0:X8}", status);
        DTSTest_GeneralInfo->flags |= DTSTEST_GENERAL_SCAN_COMPLETED;
    }
    RecordBasicEvent("{0} concluded with status = 0x{1:X8}", functionName, status);
}                                       // end of DTSTest_ScanForDevices()
//----------------------------------------------------------------------------
// DTSTest_SetBuildNumber
//
// Set the build number, using the following decimal military time format:
//      YYMMDDHHMM
//
// Called by:   DTSTest_InitializeDTSTest
//
// Note:    This function must reside in a file, or be called by a function
//          that resides in a file, that is guaranteed to be recompiled with
//          every build attempt
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_SetBuildNumber(void)
{
    int             dayValue;
    int             hourValue;
    int             minuteValue;
    int             monthValue;
    int             yearValue;
    String          ^dateString = __DATE__; // Nov 22 2011
    String          ^timeString = __TIME__; // 08:05:07 / 13:48:27
    //------------------------------------------------------------------------
    if (dateString[4] == ' ')
        dateString = String::Concat(
            dateString->Substring(0, 4),
            DTSTEST_STRING_0,
            dateString->Substring(5));
    hourValue = Convert::ToInt32(timeString->Substring(0, 2));
    minuteValue = Convert::ToInt32(timeString->Substring(3, 2));
    dayValue = Convert::ToInt32(dateString->Substring(4, 2));
    yearValue = Convert::ToInt32(dateString->Substring(9, 2));
    for each (String ^monthString in DTSTest_MonthStringArray)
    {
        if (StringICompare(dateString->Substring(0, 3), monthString) == 0)
        {
            monthValue = Array::IndexOf(DTSTest_MonthStringArray, monthString);
            break;
        }
    }
    DTSTest_BuildNumber = (DWORD)
        (yearValue * 100000000L) +
        (monthValue * 1000000L) +
        (dayValue * 10000L) +
        (hourValue * 100L) +
        minuteValue;
}                                       // end of DTSTest_SetBuildNumber()
//----------------------------------------------------------------------------
// DTSTest_SetCommandLineFlags
//
// Sets the most fundamental program flags according to the command line
//
// Called by:   DTSTest_Main
//----------------------------------------------------------------------------
    void
DTSTest_SetCommandLineFlags(
    LPTSTR          commandLine)
{
    //------------------------------------------------------------------------
    if (commandLine)
    {
        String ^commandLineString = gcnew String(commandLine);
        if (StringSet(commandLineString))
        {
            //----------------------------------------------------------------
            // Split up and parse the command line only for the purposes of
            // this function, which can include a software update
            //----------------------------------------------------------------
            array <String ^> ^parameters = Environment::GetCommandLineArgs();
            for each (String ^optionString in parameters)
            {
                optionString = optionString->ToLower();
                if (!optionString->EndsWith(".exe"))
                {
                    if (optionString->Contains("/evt"))
                    {
                        if ((StringICompare(optionString, "/evta") == 0) ||
                            (StringICompare(optionString, "/evtd") == 0))
                        {
                            DTSTest_EventLogBasicEnabled =
                                DTSTest_EventLogVerboseEnabled =
                                DTSTest_EventLogDetailedEnabled = DTSTEST_YES;
                        }
                        else
                            if (StringICompare(optionString, "/evtv") == 0)
                            {
                                DTSTest_EventLogBasicEnabled =
                                    DTSTest_EventLogVerboseEnabled = DTSTEST_YES;
                            }
                            else
                                if ((StringICompare(optionString, "/evt") == 0) ||
                                    (StringICompare(optionString, "/evtb") == 0))
                                {
                                    DTSTest_EventLogBasicEnabled = DTSTEST_YES;
                                }
                    }                   // end of if (optionString->Contains("/evt"))
                    if (optionString->Contains("/gui"))
                    {
                        if (StringICompare(optionString, "/gui-") == 0)
                            DTSTest_CommandLineOnly = DTSTEST_YES;
                    }                   // end of if (optionString->Contains("/gui"))
                    if (optionString->Contains("/m"))
                    {
                        if (StringICompare(optionString, "/m0") == 0)
                        {
                            DTSTest_BasicMessagesEnabled = DTSTEST_NO;
                            DTSTest_ErrorMessagesEnabled = DTSTEST_NO;
                            DTSTest_VerboseMessagesEnabled = DTSTEST_NO;
                            DTSTest_DetailedMessagesEnabled = DTSTEST_NO;
                            DTSTest_StackTracesEnabled = DTSTEST_NO;
                            DTSTest_ExpMessagesEnabled = DTSTEST_NO;
                        }
                        else
                        {
                            if (optionString->Contains("/mb"))
                            {
                                DTSTest_BasicMessagesEnabled =
                                    StringICompare(optionString, "/mb-") ? DTSTEST_YES : DTSTEST_NO;
                            }
                            if (optionString->Contains("/md"))
                            {
                                DTSTest_DetailedMessagesEnabled =
                                    StringICompare(optionString, "/md-") ? DTSTEST_YES : DTSTEST_NO;
                            }
                            if (optionString->Contains("/me"))
                            {
                                DTSTest_ErrorMessagesEnabled =
                                    StringICompare(optionString, "/me-") ? DTSTEST_YES : DTSTEST_NO;
                            }
                            if (optionString->Contains("/ms"))
                            {
                                DTSTest_StackTracesEnabled =
                                    StringICompare(optionString, "/ms-") ? DTSTEST_YES : DTSTEST_NO;
                            }
                            if (optionString->Contains("/mv"))
                            {
                                DTSTest_VerboseMessagesEnabled =
                                    StringICompare(optionString, "/mv-") ? DTSTEST_YES : DTSTEST_NO;
                            }
                            if (optionString->Contains("/mx"))
                            {
                                DTSTest_ExpMessagesEnabled =
                                    StringICompare(optionString, "/mx-") ? DTSTEST_YES : DTSTEST_NO;
                            }
                        }               // end of else of if (optionString->Contains("/m0"))
                    }                   // end of if (optionString->Contains("/m"))
                    if (optionString->Contains("/u"))
                    {
                        //----------------------------------------------------
                        // Software update is in progress
                        //----------------------------------------------------
                        String ^updateFile = String::Concat(
                            Application::StartupPath, "\\", DTSTEST_SW_UPDATE_FILENAME);
                        if (File::Exists(updateFile))
                        {
                            StreamReader ^textReader = File::OpenText(updateFile);
                            String ^oldProgram = textReader->ReadLine();
                            String ^newProgram = textReader->ReadLine();
                            String ^originalCommandLine = textReader->ReadLine();
                            textReader->Close();
                            if (StringICompare(Application::ExecutablePath, oldProgram))
                            {
                                //--------------------------------------------
                                // This is a program not named DTSTest.exe
                                //
                                // At this point, newProgram == Application::ExecutablePath
                                //--------------------------------------------
                                DTSTest_SoftwareUpdateInProgress = DTSTEST_YES;
                                if (File::Exists(oldProgram))
                                    File::Delete(oldProgram);
                                File::Copy(Application::ExecutablePath, oldProgram);
                                Thread::Sleep(1000);
                                ProcessStartInfo ^startNewAppCommand = gcnew ProcessStartInfo(oldProgram);
                                startNewAppCommand->WindowStyle = ProcessWindowStyle::Hidden;
                                startNewAppCommand->Arguments = _T("/u");
                                startNewAppCommand->CreateNoWindow = DTSTEST_YES;
                                startNewAppCommand->UseShellExecute = DTSTEST_NO;
                                System::Diagnostics::Process::Start(startNewAppCommand);
                                //--------------------------------------------
                                // Exit this program
                                //--------------------------------------------
                                exit(0);
                            }
                            else
                            {
                                //--------------------------------------------
                                // This program name is DTSTest.exe
                                //--------------------------------------------
                                ClearBuffer(commandLine, commandLineString->Length);
                                if (File::Exists(updateFile))
                                    File::Delete(updateFile);
                                if (File::Exists(newProgram))
                                    File::Delete(newProgram);
                                if (StringSet(originalCommandLine))
                                {
                                    pin_ptr <const wchar_t> widePtr = PtrToStringChars(originalCommandLine);
                                    wcscpy_s(
                                        commandLine,
                                        DTSTEST_MAXIMUM_VERSION_STRING_SIZE,
                                        widePtr);
                                }
                                DTSTest_SetCommandLineFlags(commandLine);
                                DTSTest_SoftwareUpdateInProgress = DTSTEST_NO;
                            }
                            Thread::Sleep(2000);
                            delete originalCommandLine;
                            delete newProgram;
                            delete oldProgram;
                        }               // end of if (File::Exists(updateFile))
                        delete updateFile;
                    }                   // end of if (optionString->Contains("/u"))
                    if (optionString->Contains("?"))
                    {
                        DTSTest_CommandLineOnly = DTSTEST_YES;
                    }
                }                       // end of if (!optionString->ToLower()->EndsWith(".exe"))
            }                           // end of for each (String ^optionString in parameters)
            if (DTSTest_DetailedMessagesEnabled)
            {
                DTSTest_VerboseMessagesEnabled = DTSTEST_YES;
            }
            if (DTSTest_VerboseMessagesEnabled)
            {
                DTSTest_BasicMessagesEnabled = DTSTEST_YES;
                DTSTest_ErrorMessagesEnabled = DTSTEST_YES;
            }
            if (DTSTest_StackTracesEnabled)
                DTSTest_ErrorMessagesEnabled = DTSTEST_YES;
            if (DTSTest_DetailedMessagesEnabled)
                DModalD("Loc 1 : Command line = '{0}'", commandLineString);
            else
                if (DTSTest_VerboseMessagesEnabled)
                    DModalV("Loc 1 : Command line = '{0}'", commandLineString);
                else
                    if (DTSTest_ExpMessagesEnabled)
                        DModalX("Loc 1 : Command line = '{0}'", commandLineString);
            delete [] parameters;
        }                               // end of if (StringSet(commandLineString))
    }                                   // end of if (commandLine)
}                                       // end of DTSTest_SetCommandLineFlags()
//----------------------------------------------------------------------------
#endif      // DTSTEST_CPP
//============================================================================
// End of DTSTest.cpp
//============================================================================
