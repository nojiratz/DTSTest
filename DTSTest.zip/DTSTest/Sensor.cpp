//============================================================================
// Sensor.cpp
//
// The methods used to communicate with gauges, DTS units, and DPS units
//
// Copyright (C) 2014 - 2016 Quartzdyne, Inc.  All rights reserved.
//
// No part of this source code may be reproduced or transmitted in any form or
// by any means, electronic or mechanical, including photocopying, recording,
// or any information storage and retrieval system, without express written
// permission from Quartzdyne, Inc.  Further, no use of this source code is
// permitted in any form or means without a valid, written license agreement
// with Quartzdyne, Inc.  While every reasonable precaution has been taken in
// the preparation of this source code, Quartzdyne, Inc., assumes no
// responsibility for errors, omissions, or damages from the use of the source
// code contained herein.
//
// NEITHER QUARTZDYNE, INC., ANY MEMBER OF QUARTZDYNE, INC., NOR ANY PERSON OR
// ORGANIZATION ACTING ON BEHALF OF THEM MAKES ANY WARRANTY OR REPRESENTATION
// WHATSOEVER, EXPRESS OR IMPLIED, INCLUDING ANY WARRANTY OF MERCHANTABILITY
// OR FITNESS FOR ANY PURPOSE WITH RESPECT TO THE SOURCE CODE OR ASSUMES ANY
// LIABILITY WHATSOEVER WITH RESPECT TO ANY USE OF THE SOURCE CODE OR ANY
// PORTION THEREOF OR WITH RESPECT TO ANY DAMAGES THAT MAY RESULT FROM SUCH
// USE.
//
// Noji Ratzlaff
//
// See DTSTest.log for a complete history of all updates, changes, and revisions
// of this source and other files and policies regarding DTSTest software
//
// Updated 01-14-2016
//============================================================================
#include    "stdafx.h"
#ifndef     SENSOR_CPP
#define     SENSOR_CPP
#include    "Sensor.h"
//----------------------------------------------------------------------------
// DTSTest_CalculatePressureBias
//
// Returns the pressure bias, based on the specified pressure
// reading and the ideal ambient pressure, minus a random offset
//----------------------------------------------------------------------------
    double DTSTest_GUIClass::
DTSTest_CalculatePressureBias(
    double          pressureValuePSI)
{
    DateTime        dateTime = DateTime::Now;
    String          ^functionName = _T("DTSTest_CalculatePressureBias");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0}({1:F3} psi) called", functionName, pressureValuePSI);
    Thread::Sleep(7);
    Random ^randomValue = gcnew Random();
    double randomDouble = randomValue->NextDouble();
    double ideal = DTSTEST_DEFAULT_PRESSURE_BIAS - ((((double) dateTime.Millisecond) * randomDouble) / 1000.0);
    double pressureBias = ideal - pressureValuePSI;
    RecordBasicEvent("{0} concluded, with bias = {1:F3} psi", functionName, pressureBias);
    return pressureBias;
}                                       // end of DTSTest_CalculatePressureBias()
//----------------------------------------------------------------------------
// DTSTest_CalculateTemperatureBias
//
// Returns the sampling temperature bias, based on the specified temperature
// reading and the ideal ambient temperature
//----------------------------------------------------------------------------
    double DTSTest_GUIClass::
DTSTest_CalculateTemperatureBias(
    double          temperatureValueCelsius)
{
    DateTime        dateTime = DateTime::Now;
    String          ^functionName = _T("DTSTest_CalculateTemperatureBias");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0}({1:F3} �C) called", functionName, temperatureValueCelsius);
    Thread::Sleep(13);
    Random ^randomValue = gcnew Random();
    double randomDouble = randomValue->NextDouble();
    double ideal = DTSTEST_DEFAULT_TEMPERATURE_BIAS - ((((double) dateTime.Millisecond) * randomDouble) / 1000.0);
    double temperatureBias = ideal - temperatureValueCelsius;
    RecordBasicEvent("{0} concluded, with bias = {1:F3} �C", functionName, temperatureBias);
    return temperatureBias;
}                                       // end of DTSTest_CalculateTemperatureBias()
//----------------------------------------------------------------------------
// DTSTest_LoadDefaultCoefficientData
//
// Loads the default coefficient data into the global default coefficient data
// buffer
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_LoadDefaultCoefficientData(void)
{
    String          ^functionName = _T("DTSTest_LoadDefaultCoefficientData");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0} called", functionName);
    CoefficientInfo ^defaultCoefficientInfo = DTSTest_GeneralInfo->defaultCoefficientInfo;
    if (defaultCoefficientInfo)
    {
        String ^filePathString = GUI_DEFAULT_COEFFICIENT_HEX_FILE;
        if (File::Exists(filePathString))
        {
            char *filePath = (char *) malloc(DTSTEST_MAXIMUM_FILE_PATH_LENGTH);
            if (filePath)
            {
                DTSTest_ConvertString(
                    filePathString,
                    filePath,
                    DTSTEST_MAXIMUM_FILE_PATH_LENGTH);
                BYTE *coefficientData = (LPBYTE) defaultCoefficientInfo->coefficientData;
                DWORD status = QD_ReadCoefficientDataFromHexFile(
                    (LPBYTE) filePath,
                    (LPBYTE) coefficientData);
                if (status == QD_SUCCESS)
                {
                    RecordBasicEvent("    Default coefficient data loaded from {0}",
                        filePathString);
                    defaultCoefficientInfo->hexFilePath = filePathString;
                    defaultCoefficientInfo->coefficientDataLoaded = GUI_YES;
                }
                else
                {
                    DTSTest_RecordAndModalErrorEvent(
                        "QD_ReadCoefficientDataFromHexFile returned status 0x{0:X8} while analyzing file\n{1}",
                        status, filePathString);
                }
                free((void *) filePath);
            }                           // end of if (filePath)
        }                               // end of if (File::Exists(filePathString))
        else
        {
            RecordErrorEvent("    File is not found:\n    {0}", filePathString);
        }
    }                                   // end of if (defaultCoefficientInfo)
    RecordBasicEvent("{0} concluded", functionName);
}                                       // end of DTSTest_LoadDefaultCoefficientData()
//----------------------------------------------------------------------------
// DTSTest_SensorCalibrateReadings
//
// Determines whether the specified barge is present, then retrieves some
// general information about it, if it does
//
// Returns: 0       = Success
//          nonzero = Failure
//----------------------------------------------------------------------------
    DWORD DTSTest_GUIClass::
DTSTest_SensorCalibrateReadings(
    SensorInfo      ^sensor)
{
    DWORD           status = DTSTEST_SUCCESS;
    String          ^functionName = _T("DTSTest_SensorCalibrateReadings");
    //------------------------------------------------------------------------
    if (sensor)
    {
        RecordBasicEvent("{0}({1:X2}) called", functionName, sensor->nodeAddress);
        //--------------------------------------------------------------------
        // If coefficient data is not already installed for this sensor, use
        // the default coefficient data
        //--------------------------------------------------------------------
        if (!sensor->coefficientInfo->coefficientDataLoaded)
        {
            memcpy_s(
                (void *) sensor->coefficientInfo->coefficientData,
                sizeof(CoefficientDataFormat),
                (void *) DTSTest_GeneralInfo->defaultCoefficientInfo->coefficientData,
                sizeof(CoefficientDataFormat));
            sensor->coefficientInfo->coefficientDataLoaded = GUI_YES;
            sensor->coefficientInfo->hexFilePath = DTSTest_GeneralInfo->defaultCoefficientInfo->hexFilePath;
        }
        //--------------------------------------------------------------------
        // Recalculate and replace the bias values
        //--------------------------------------------------------------------
        bool originalAddBiasState = sensor->addBias;
        sensor->addBias = GUI_NO;
        status = DTSTest_SensorRetrieveMeasurements(sensor);
        if (status == DTSTEST_SUCCESS)
        {
            double currentPressurePSI = sensor->currentPressurePSI;
            double currentTemperatureCelsius = sensor->currentTemperatureCelsius;
            sensor->pressurePSIBias = DTSTest_CalculatePressureBias(currentPressurePSI);
            sensor->currentPressurePSI = currentPressurePSI;
            sensor->currentPressurePSI += (DTSTest_NormalizeReadings ? sensor->pressurePSIBias : 0);
            sensor->temperatureCelsiusBias = DTSTest_CalculateTemperatureBias(currentTemperatureCelsius);
            sensor->currentTemperatureCelsius = currentTemperatureCelsius;
            sensor->currentTemperatureCelsius += (DTSTest_NormalizeReadings ? sensor->temperatureCelsiusBias : 0);
            RecordVerboseEvent("    Sensor {0:X2} ({1}) returned {2:F3} psi (bias {3:F3}) and {4:F3} �C (bias {5:F3})",
                sensor->nodeAddress,
                sensor->hardwareIDString,
                currentPressurePSI,
                sensor->pressurePSIBias,
                currentTemperatureCelsius,
                sensor->temperatureCelsiusBias);
            sensor->addBias = originalAddBiasState;
        }
    }                                   // end of if (sensor)
    else
    {
        status = DTSTEST_ERROR_SENSOR_POINTER_INVALID;                          // 0x000000E0
    }
    RecordBasicEvent("{0} concluded, returning 0x{1:X8}", functionName, status);
    return status;
}                                       // end of DTSTest_SensorCalibrateReadings()
//----------------------------------------------------------------------------
// DTSTest_SensorEnableGaugeToolhead
//
// Enables the toolhead interface for the specified gauge
//
// Returns: 0       = Success
//          nonzero = Failure
//----------------------------------------------------------------------------
    DWORD DTSTest_GUIClass::
DTSTest_SensorEnableGaugeToolhead(
    SensorInfo      ^sensor)
{
    DWORD           status = DTSTEST_SUCCESS;
    String          ^functionName = _T("DTSTest_SensorEnableGaugeToolhead");
    //------------------------------------------------------------------------
    if (sensor)
    {
        RecordBasicEvent("            {0}({1:X2}) called", functionName, sensor->nodeAddress);
        if (sensor->sensorType != DTSTEST_SENSOR_TYPE_GAUGE)
        {
            status = DTSTest_SensorRetrieveType(sensor);
        }
        if (sensor->sensorType == DTSTEST_SENSOR_TYPE_GAUGE)
        {
            PDGICInfo ^pgInfo = DTSTest_GeneralInfo->pgInfo;
            //----------------------------------------------------------------
            // Store the original node address
            //----------------------------------------------------------------
            BYTE originalNodeAddress = pgInfo->nodeAddress;
            pgInfo->nodeAddress = sensor->nodeAddress;
            //----------------------------------------------------------------
            // Set up a MODBUS command to write to the holding register
            //----------------------------------------------------------------
            pgInfo->commandArray[1] = MODBUS_COMMAND_WRITE_SINGLE_REGISTER;     // 0x06
            pgInfo->startingRegisterOffset = 0x0000;
            pgInfo->writeData = DTSTEST_GAUGE_TOOLHEAD_PASSWORD;                // 0x411
            DTSTest_PDGICSendCommand(pgInfo);
            if (!DTSTest_PDGICSuccessfulReply)
            {
                //------------------------------------------------------------
                // Wait 100 ms, then retry
                //------------------------------------------------------------
                Thread::Sleep(100);
                DTSTest_PDGICSendCommand(pgInfo);
                if (!DTSTest_PDGICSuccessfulReply)
                {
                    status = DTSTEST_ERROR_MODBUS_COMMAND_FAILED;               // 0x000000B0
                }
            }
            //----------------------------------------------------------------
            // Restore the original node address
            //----------------------------------------------------------------
            pgInfo->nodeAddress = originalNodeAddress;
        }                               // end of if (sensor->sensorType == DTSTEST_SENSOR_TYPE_GAUGE)
        else
        {
            status = DTSTEST_ERROR_SENSOR_TYPE_INCORRECT;                       // 0x000000E1
        }
    }                                   // end of if (sensor)
    else
    {
        status = DTSTEST_ERROR_SENSOR_POINTER_INVALID;                          // 0x000000E0
    }
    RecordBasicEvent("            {0} concluded, returning 0x{1:X8}", functionName, status);
    return status;
}                                       // end of DTSTest_SensorEnableGaugeToolhead()
//----------------------------------------------------------------------------
// DTSTest_SensorPresent
//
// Determines whether the specified sensor is present in MODBUS space
//----------------------------------------------------------------------------
    bool DTSTest_GUIClass::
DTSTest_SensorPresent(
    SensorInfo      ^sensor)
{
    bool            isPresent = GUI_NO;
    DWORD           status = DTSTEST_SUCCESS;
    String          ^functionName = _T("DTSTest_SensorPresent");
    //------------------------------------------------------------------------
    if (sensor)
    {
        RecordBasicEvent("{0}({1:X2}) called", functionName, sensor->nodeAddress);
        if (sensor->nodeAddress)
        {
            PDGICInfo ^pgInfo = DTSTest_GeneralInfo->pgInfo;
            //----------------------------------------------------------------
            // Store the original node address
            //----------------------------------------------------------------
            BYTE originalNodeAddress = pgInfo->nodeAddress;
            pgInfo->nodeAddress = sensor->nodeAddress;
            //----------------------------------------------------------------
            // Set up a MODBUS command to read the first word
            //----------------------------------------------------------------
            pgInfo->commandArray[1] = MODBUS_COMMAND_READ_INPUT_REGISTERS;      // 0x04
            pgInfo->startingRegisterOffset = 0x00;
            pgInfo->numberOfRegistersToTransfer = 1;
            DTSTest_PDGICSendCommand(pgInfo);
            if (DTSTest_PDGICSuccessfulReply)
            {
                isPresent = GUI_YES;
            }                           // end of if (DTSTest_PDGICSuccessfulReply)
            else
            {
                status = DTSTEST_ERROR_MODBUS_COMMAND_FAILED;                   // 0x000000B0
            }
            //----------------------------------------------------------------
            // Restore the original node address
            //----------------------------------------------------------------
            pgInfo->nodeAddress = originalNodeAddress;
        }                               // end of if (sensor->nodeAddress)
    }                                   // end of if (sensor)
    else
    {
        status = DTSTEST_ERROR_SENSOR_POINTER_INVALID;                          // 0x000000E0
    }
    RecordBasicEvent("{0} concluded, returning 0x{1:X8} (0x{2:X2} {3} present)",
        functionName, status, sensor->nodeAddress, (isPresent ? "IS" : "is NOT"));
    return isPresent;
}                                       // end of DTSTest_SensorPresent()
//----------------------------------------------------------------------------
// DTSTest_SensorPromptAndCalibrate
//
// Prompts for a sensor, then performs a desktop calibration by calculating
// coefficients for the sensor, then prompts again to save them to in file
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_SensorPromptAndCalibrate(void)
{
    int             nodeAddress = DTSTEST_SENSOR_ADDRESS_NONE;
    bool            modalResponse = GUI_CANCEL;
    String          ^functionName = _T("DTSTest_SensorPromptAndCalibrate");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0} called", functionName);
    Calibrate ^calibrate = DTSTest_GeneralInfo->calibrate;
    Form ^sensorCalibrationModal = gcnew Form;
    sensorCalibrationModal->Size = Drawing::Size(320, 350);
    sensorCalibrationModal->Text = _T("Calibrate Sensor");
    sensorCalibrationModal->Icon = DTSTest_SoftwareIcon;
//        sensorCalibrationModal->BackgroundImage = gcnew Bitmap(GUI_BG_WOOD_PANEL, GUI_YES);
    sensorCalibrationModal->FormBorderStyle = ::FormBorderStyle::FixedDialog;
    sensorCalibrationModal->StartPosition = FormStartPosition::CenterScreen;
    sensorCalibrationModal->TopMost = GUI_YES;
    //--------------------------------------------------------------------
    // Prevent the user from changing its appearance
    //--------------------------------------------------------------------
    sensorCalibrationModal->MaximizeBox = GUI_NO;
    sensorCalibrationModal->MinimizeBox = GUI_NO;
    sensorCalibrationModal->HelpButton = GUI_NO;
    //--------------------------------------------------------------------
    // Hybrid serial number label
    //--------------------------------------------------------------------
    Label ^sensorHybridSerialNumberLabel = gcnew Label;
    sensorHybridSerialNumberLabel->Text = _T("Hybrid serial number :");
    sensorHybridSerialNumberLabel->Font = gcnew Drawing::Font(
        FontFamily::GenericSansSerif,
        10.0F,
        FontStyle::Bold);
    sensorHybridSerialNumberLabel->Location = Point(10, 14);
    sensorHybridSerialNumberLabel->Size = Drawing::Size(146, GUI_INFO_LABEL_HEIGHT);
    sensorHybridSerialNumberLabel->BackColor = Color::Transparent;
    sensorHybridSerialNumberLabel->TextAlign = Drawing::ContentAlignment::MiddleLeft;
    sensorCalibrationModal->Controls->Add(sensorHybridSerialNumberLabel);
    //--------------------------------------------------------------------
    // Hybrid serial number text box
    //--------------------------------------------------------------------
    TextBox ^sensorHybridSerialNumberTextBox = gcnew TextBox;
    if (StringSet(calibrate->hybridSerialNumberString))
        sensorHybridSerialNumberTextBox->Text = calibrate->hybridSerialNumberString;
    sensorHybridSerialNumberTextBox->Font = gcnew Drawing::Font(
        FontFamily::GenericSansSerif,
        8.0F,
        FontStyle::Bold);
    sensorHybridSerialNumberTextBox->Size = Drawing::Size(
        80, GUI_REGULAR_TEXT_BOX_HEIGHT);
    sensorHybridSerialNumberTextBox->Location = Point(
        sensorHybridSerialNumberLabel->Right + 2,
        sensorHybridSerialNumberLabel->Top - 2);
    sensorHybridSerialNumberTextBox->Multiline = GUI_NO;
    sensorHybridSerialNumberTextBox->AcceptsReturn = GUI_NO;
    sensorHybridSerialNumberTextBox->AcceptsTab = GUI_NO;
    sensorHybridSerialNumberTextBox->WordWrap = GUI_NO;
    sensorHybridSerialNumberTextBox->ReadOnly = GUI_NO;
    sensorHybridSerialNumberTextBox->MaxLength = 12;
    sensorHybridSerialNumberTextBox->TextAlign = HorizontalAlignment::Left;
    sensorHybridSerialNumberTextBox->BackColor = Color::Lavender;
    sensorHybridSerialNumberTextBox->CharacterCasing = CharacterCasing::Upper;
    sensorHybridSerialNumberTextBox->Validating +=
        gcnew CancelEventHandler(this, &DTSTest_GUIClass::DTSTest_ValidateSensorHybridSerialNumber);
    sensorCalibrationModal->Controls->Add(sensorHybridSerialNumberTextBox);
    //------------------------------------------------------------------------
    // Hybrid serial number area tool tip
    //------------------------------------------------------------------------
    ToolTip ^sensorHybridSerialNumberAreaToolTip = gcnew ToolTip;
    sensorHybridSerialNumberAreaToolTip->ShowAlways = GUI_YES;
    sensorHybridSerialNumberAreaToolTip->AutoPopDelay = 10000;   // let stand for ten seconds
    sensorHybridSerialNumberAreaToolTip->ToolTipTitle =
        _T("Hybrid Serial Number");
    String ^sensorHybridSerialNumberAreaToolTipText = String::Concat(
        "Serial number of the hybrid circuit", Environment::NewLine,
        "board in the sensor in the form", Environment::NewLine,
        "HSSSSS-NNN, in which SSSSS is the", Environment::NewLine,
        "hybrid serial number, and NNN is the", Environment::NewLine,
        "node address in decimal");
    sensorHybridSerialNumberAreaToolTip->SetToolTip(sensorHybridSerialNumberLabel, sensorHybridSerialNumberAreaToolTipText);
    sensorHybridSerialNumberAreaToolTip->SetToolTip(sensorHybridSerialNumberTextBox, sensorHybridSerialNumberAreaToolTipText);
    delete sensorHybridSerialNumberAreaToolTipText;
    //--------------------------------------------------------------------
    // Device node address hex label
    //--------------------------------------------------------------------
    sensorDeviceNodeAddressHexLabel = gcnew Label;
    sensorDeviceNodeAddressHexLabel->Font = gcnew Drawing::Font(
        FontFamily::GenericSansSerif,
        10.0F,
        FontStyle::Bold);
    sensorDeviceNodeAddressHexLabel->Location = Point(
        sensorHybridSerialNumberTextBox->Right + 10,
        sensorHybridSerialNumberLabel->Top);
    sensorDeviceNodeAddressHexLabel->Size = Drawing::Size(
        40, GUI_INFO_LABEL_HEIGHT);
    sensorDeviceNodeAddressHexLabel->BackColor = Color::Transparent;
    sensorDeviceNodeAddressHexLabel->TextAlign = Drawing::ContentAlignment::MiddleRight;
    sensorCalibrationModal->Controls->Add(sensorDeviceNodeAddressHexLabel);
    if (calibrate->nodeAddress)
    {
        sensorDeviceNodeAddressHexLabel->Visible = GUI_YES;
        sensorDeviceNodeAddressHexLabel->Text = String::Format(
            "0x{0:X2}", calibrate->nodeAddress);
        nodeAddress = calibrate->nodeAddress;
    }
    else
        sensorDeviceNodeAddressHexLabel->Visible = GUI_NO;
    //------------------------------------------------------------------------
    // Device node address hex label tool tip
    //------------------------------------------------------------------------
    ToolTip ^sensorDeviceNodeAddressHexLabelToolTip = gcnew ToolTip;
    sensorDeviceNodeAddressHexLabelToolTip->ShowAlways = GUI_YES;
    sensorDeviceNodeAddressHexLabelToolTip->AutoPopDelay = 10000;   // display for ten seconds
    sensorDeviceNodeAddressHexLabelToolTip->ToolTipTitle =
        _T("Device Node Address");
    String ^sensorDeviceNodeAddressHexLabelToolTipText = String::Concat(
        "Hexadecimal value of the node address", Environment::NewLine,
        "for the specified hybrid serial number");
    sensorDeviceNodeAddressHexLabelToolTip->SetToolTip(sensorDeviceNodeAddressHexLabel, sensorDeviceNodeAddressHexLabelToolTipText);
    delete sensorDeviceNodeAddressHexLabelToolTipText;
    //--------------------------------------------------------------------
    // Jig serial number label
    //--------------------------------------------------------------------
    Label ^sensorJigSerialNumberLabel = gcnew Label;
    sensorJigSerialNumberLabel->Text = _T("Jig serial number :");
    sensorJigSerialNumberLabel->Font = gcnew Drawing::Font(
        FontFamily::GenericSansSerif,
        10.0F,
        FontStyle::Bold);
    GUI_PositionBelow(sensorJigSerialNumberLabel, sensorHybridSerialNumberLabel, 10);
    sensorJigSerialNumberLabel->Size = sensorHybridSerialNumberLabel->Size;
    sensorJigSerialNumberLabel->BackColor = Color::Transparent;
    sensorJigSerialNumberLabel->TextAlign = Drawing::ContentAlignment::MiddleLeft;
    sensorCalibrationModal->Controls->Add(sensorJigSerialNumberLabel);
    //--------------------------------------------------------------------
    // Jig serial number text box
    //--------------------------------------------------------------------
    TextBox ^sensorJigSerialNumberTextBox = gcnew TextBox;
    if (StringSet(calibrate->jigSerialNumberString))
        sensorJigSerialNumberTextBox->Text = calibrate->jigSerialNumberString;
    sensorJigSerialNumberTextBox->Font = gcnew Drawing::Font(
        FontFamily::GenericSansSerif,
        8.0F,
        FontStyle::Bold);
    sensorJigSerialNumberTextBox->Size = Drawing::Size(
        50, GUI_REGULAR_TEXT_BOX_HEIGHT);
    sensorJigSerialNumberTextBox->Location = Point(
        sensorJigSerialNumberLabel->Right + 2,
        sensorJigSerialNumberLabel->Top - 2);
    sensorJigSerialNumberTextBox->Multiline = GUI_NO;
    sensorJigSerialNumberTextBox->AcceptsReturn = GUI_NO;
    sensorJigSerialNumberTextBox->AcceptsTab = GUI_NO;
    sensorJigSerialNumberTextBox->WordWrap = GUI_NO;
    sensorJigSerialNumberTextBox->ReadOnly = GUI_NO;
    sensorJigSerialNumberTextBox->MaxLength = 6;
    sensorJigSerialNumberTextBox->TextAlign = HorizontalAlignment::Left;
    sensorJigSerialNumberTextBox->BackColor = Color::Lavender;
    sensorJigSerialNumberTextBox->CharacterCasing = CharacterCasing::Upper;
    sensorJigSerialNumberTextBox->Validating +=
        gcnew CancelEventHandler(this, &DTSTest_GUIClass::DTSTest_ValidateSensorJigSerialNumber);
    sensorCalibrationModal->Controls->Add(sensorJigSerialNumberTextBox);
    //------------------------------------------------------------------------
    // Jig serial number area tool tip
    //------------------------------------------------------------------------
    ToolTip ^sensorJigSerialNumberAreaToolTip = gcnew ToolTip;
    sensorJigSerialNumberAreaToolTip->ShowAlways = GUI_YES;
    sensorJigSerialNumberAreaToolTip->AutoPopDelay = 10000;   // display for ten seconds
    sensorJigSerialNumberAreaToolTip->ToolTipTitle =
        _T("Jig Serial Number");
    String ^sensorJigSerialNumberAreaToolTipText = String::Concat(
        "Serial number of the jig that holds", Environment::NewLine,
        "the sensor in the form ZNN, in which", Environment::NewLine,
        "Z is H or P, and NN is the jig number");
    sensorJigSerialNumberAreaToolTip->SetToolTip(sensorJigSerialNumberLabel, sensorJigSerialNumberAreaToolTipText);
    sensorJigSerialNumberAreaToolTip->SetToolTip(sensorJigSerialNumberTextBox, sensorJigSerialNumberAreaToolTipText);
    delete sensorJigSerialNumberAreaToolTipText;
    //--------------------------------------------------------------------
    // Counts label
    //--------------------------------------------------------------------
    Label ^sensorCountsLabel = gcnew Label;
    sensorCountsLabel->Text = _T("Counts");
    sensorCountsLabel->Font = gcnew Drawing::Font(
        FontFamily::GenericSansSerif,
        10.0F,
        FontStyle::Bold);
    sensorCountsLabel->Size = Drawing::Size(60, GUI_INFO_LABEL_HEIGHT);
    sensorCountsLabel->Location = Point(
        ((sensorCalibrationModal->Width - 190 - sensorCountsLabel->Width) / 2) + 190,
        sensorJigSerialNumberTextBox->Bottom + 6);
    sensorCountsLabel->BackColor = Color::Transparent;
    sensorCountsLabel->TextAlign = Drawing::ContentAlignment::MiddleCenter;
    sensorCalibrationModal->Controls->Add(sensorCountsLabel);
    //------------------------------------------------------------------------
    // Ambient Temperature button
    //------------------------------------------------------------------------
    sensorSnapshotAmbientTemperatureButton = gcnew Button;
    sensorSnapshotAmbientTemperatureButton->Font = gcnew Drawing::Font(
        FontFamily::GenericSansSerif,
        10.0F,
        FontStyle::Bold);
    sensorSnapshotAmbientTemperatureButton->Text = _T("Ambient Temperature");
    GUI_PositionBelow(sensorSnapshotAmbientTemperatureButton, sensorJigSerialNumberLabel, 30);
    sensorSnapshotAmbientTemperatureButton->Size = Drawing::Size(
        180, GUI_REGULAR_BUTTON_HEIGHT);
    GUI_SetButtonInterfaceProperties(sensorSnapshotAmbientTemperatureButton);
    sensorSnapshotAmbientTemperatureButton->Click +=
        gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_SensorSnapshotAmbientTemperatureClicked);
    sensorCalibrationModal->Controls->Add(sensorSnapshotAmbientTemperatureButton);
    sensorSnapshotAmbientTemperatureButton->Enabled = GUI_NO;
    //------------------------------------------------------------------------
    // Ambient Temperature button tool tip
    //------------------------------------------------------------------------
    ToolTip ^sensorSnapshotAmbientTemperatureButtonToolTip = gcnew ToolTip;
    sensorSnapshotAmbientTemperatureButtonToolTip->ShowAlways = GUI_YES;
    sensorSnapshotAmbientTemperatureButtonToolTip->AutoPopDelay = 10000;   // display for ten seconds
    sensorSnapshotAmbientTemperatureButtonToolTip->ToolTipTitle =
        _T("Ambient Temperature");
    String ^sensorSnapshotAmbientTemperatureButtonToolTipText = String::Concat(
        "Click when you're ready to take a", Environment::NewLine,
        "reading of counts at ambient pressure", Environment::NewLine,
        "and temperature");
    sensorSnapshotAmbientTemperatureButtonToolTip->SetToolTip(
        sensorSnapshotAmbientTemperatureButton,
        sensorSnapshotAmbientTemperatureButtonToolTipText);
    delete sensorSnapshotAmbientTemperatureButtonToolTipText;
    //--------------------------------------------------------------------
    // Ambient count label
    //--------------------------------------------------------------------
    sensorAmbientCountLabel = gcnew Label;
    if (calibrate->temperatureAmbientCount)
        sensorAmbientCountLabel->Text = String::Format(
            "{0:X8}", calibrate->temperatureAmbientCount);
    else
        sensorAmbientCountLabel->Text = _T("--  --  --  --");
    sensorAmbientCountLabel->Font = gcnew Drawing::Font(
        FontFamily::GenericSansSerif,
        10.0F,
        FontStyle::Bold);
    sensorAmbientCountLabel->Size = Drawing::Size(82, GUI_INFO_LABEL_HEIGHT);
    sensorAmbientCountLabel->Location = Point(
        ((sensorCalibrationModal->Width - 190 - sensorAmbientCountLabel->Width) / 2) + 190,
        sensorSnapshotAmbientTemperatureButton->Top + 4);
    sensorAmbientCountLabel->BackColor = Color::Transparent;
    sensorAmbientCountLabel->TextAlign = Drawing::ContentAlignment::MiddleCenter;
    sensorCalibrationModal->Controls->Add(sensorAmbientCountLabel);
    //------------------------------------------------------------------------
    // 100 �C button
    //------------------------------------------------------------------------
    sensorSnapshot100TemperatureButton = gcnew Button;
    sensorSnapshot100TemperatureButton->Tag = calibrate->nodeAddress;
    sensorSnapshot100TemperatureButton->Font = gcnew Drawing::Font(
        FontFamily::GenericSansSerif,
        10.0F,
        FontStyle::Bold);
    sensorSnapshot100TemperatureButton->Text = _T("100 �C");
    GUI_PositionBelow(sensorSnapshot100TemperatureButton, sensorSnapshotAmbientTemperatureButton, 4);
    sensorSnapshot100TemperatureButton->Size = sensorSnapshotAmbientTemperatureButton->Size;
    GUI_SetButtonInterfaceProperties(sensorSnapshot100TemperatureButton);
    sensorSnapshot100TemperatureButton->Click +=
        gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_SensorSnapshot100TemperatureClicked);
    sensorCalibrationModal->Controls->Add(sensorSnapshot100TemperatureButton);
    sensorSnapshot100TemperatureButton->Enabled = GUI_NO;
    //------------------------------------------------------------------------
    // 100 �C button tool tip
    //------------------------------------------------------------------------
    ToolTip ^sensorSnapshot100TemperatureButtonToolTip = gcnew ToolTip;
    sensorSnapshot100TemperatureButtonToolTip->ShowAlways = GUI_YES;
    sensorSnapshot100TemperatureButtonToolTip->AutoPopDelay = 10000;   // display for ten seconds
    sensorSnapshot100TemperatureButtonToolTip->ToolTipTitle =
        _T("100 �C");
    String ^sensorSnapshot100TemperatureButtonToolTipText = String::Concat(
        "Click when you're ready to take a", Environment::NewLine,
        "reading of counts at ambient pressure", Environment::NewLine,
        "and temperature and 100 �C");
    sensorSnapshot100TemperatureButtonToolTip->SetToolTip(
        sensorSnapshot100TemperatureButton,
        sensorSnapshot100TemperatureButtonToolTipText);
    delete sensorSnapshot100TemperatureButtonToolTipText;
    //--------------------------------------------------------------------
    // 100 �C count label
    //--------------------------------------------------------------------
    sensor100CountLabel = gcnew Label;
    if (calibrate->temperature100Count)
        sensor100CountLabel->Text = String::Format(
            "{0:X8}", calibrate->temperature100Count);
    else
        sensor100CountLabel->Text = _T("--  --  --  --");
    sensor100CountLabel->Font = gcnew Drawing::Font(
        FontFamily::GenericSansSerif,
        10.0F,
        FontStyle::Bold);
    sensor100CountLabel->Size = sensorAmbientCountLabel->Size;
    sensor100CountLabel->Location = Point(
        sensorAmbientCountLabel->Left,
        sensorSnapshot100TemperatureButton->Top + 4);
    sensor100CountLabel->BackColor = Color::Transparent;
    sensor100CountLabel->TextAlign = Drawing::ContentAlignment::MiddleCenter;
    sensorCalibrationModal->Controls->Add(sensor100CountLabel);
    //------------------------------------------------------------------------
    // 150 �C button
    //------------------------------------------------------------------------
    sensorSnapshot150TemperatureButton = gcnew Button;
    sensorSnapshot150TemperatureButton->Tag = calibrate->nodeAddress;
    sensorSnapshot150TemperatureButton->Font = gcnew Drawing::Font(
        FontFamily::GenericSansSerif,
        10.0F,
        FontStyle::Bold);
    sensorSnapshot150TemperatureButton->Text = _T("150 �C");
    GUI_PositionBelow(sensorSnapshot150TemperatureButton, sensorSnapshot100TemperatureButton, 4);
    sensorSnapshot150TemperatureButton->Size = sensorSnapshot100TemperatureButton->Size;
    GUI_SetButtonInterfaceProperties(sensorSnapshot150TemperatureButton);
    sensorSnapshot150TemperatureButton->Click +=
        gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_SensorSnapshot150TemperatureClicked);
    sensorCalibrationModal->Controls->Add(sensorSnapshot150TemperatureButton);
    sensorSnapshot150TemperatureButton->Enabled = GUI_NO;
    //------------------------------------------------------------------------
    // 150 �C button tool tip
    //------------------------------------------------------------------------
    ToolTip ^sensorSnapshot150TemperatureButtonToolTip = gcnew ToolTip;
    sensorSnapshot150TemperatureButtonToolTip->ShowAlways = GUI_YES;
    sensorSnapshot150TemperatureButtonToolTip->AutoPopDelay = 10000;   // display for ten seconds
    sensorSnapshot150TemperatureButtonToolTip->ToolTipTitle =
        _T("150 �C");
    String ^sensorSnapshot150TemperatureButtonToolTipText = String::Concat(
        "Click when you're ready to take a", Environment::NewLine,
        "reading of counts at ambient pressure", Environment::NewLine,
        "and temperature and 150 �C");
    sensorSnapshot150TemperatureButtonToolTip->SetToolTip(
        sensorSnapshot150TemperatureButton,
        sensorSnapshot150TemperatureButtonToolTipText);
    delete sensorSnapshot150TemperatureButtonToolTipText;
    //--------------------------------------------------------------------
    // 150 �C count label
    //--------------------------------------------------------------------
    sensor150CountLabel = gcnew Label;
    if (calibrate->temperature150Count)
        sensor150CountLabel->Text = String::Format(
            "{0:X8}", calibrate->temperature150Count);
    else
        sensor150CountLabel->Text = _T("--  --  --  --");
    sensor150CountLabel->Font = gcnew Drawing::Font(
        FontFamily::GenericSansSerif,
        10.0F,
        FontStyle::Bold);
    sensor150CountLabel->Size = sensor100CountLabel->Size;
    sensor150CountLabel->Location = Point(
        sensor100CountLabel->Left,
        sensorSnapshot150TemperatureButton->Top + 4);
    sensor150CountLabel->BackColor = Color::Transparent;
    sensor150CountLabel->TextAlign = Drawing::ContentAlignment::MiddleCenter;
    sensorCalibrationModal->Controls->Add(sensor150CountLabel);
    //------------------------------------------------------------------------
    // 175 �C button
    //------------------------------------------------------------------------
    sensorSnapshot175TemperatureButton = gcnew Button;
    sensorSnapshot175TemperatureButton->Tag = calibrate->nodeAddress;
    sensorSnapshot175TemperatureButton->Font = gcnew Drawing::Font(
        FontFamily::GenericSansSerif,
        10.0F,
        FontStyle::Bold);
    sensorSnapshot175TemperatureButton->Text = _T("175 �C");
    GUI_PositionBelow(sensorSnapshot175TemperatureButton, sensorSnapshot150TemperatureButton, 4);
    sensorSnapshot175TemperatureButton->Size = sensorSnapshot150TemperatureButton->Size;
    GUI_SetButtonInterfaceProperties(sensorSnapshot175TemperatureButton);
    sensorSnapshot175TemperatureButton->Click +=
        gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_SensorSnapshot175TemperatureClicked);
    sensorCalibrationModal->Controls->Add(sensorSnapshot175TemperatureButton);
    sensorSnapshot175TemperatureButton->Enabled = GUI_NO;
    //------------------------------------------------------------------------
    // 175 �C button tool tip
    //------------------------------------------------------------------------
    ToolTip ^sensorSnapshot175TemperatureButtonToolTip = gcnew ToolTip;
    sensorSnapshot175TemperatureButtonToolTip->ShowAlways = GUI_YES;
    sensorSnapshot175TemperatureButtonToolTip->AutoPopDelay = 10000;   // display for ten seconds
    sensorSnapshot175TemperatureButtonToolTip->ToolTipTitle =
        _T("175 �C");
    String ^sensorSnapshot175TemperatureButtonToolTipText = String::Concat(
        "Click when you're ready to take a", Environment::NewLine,
        "reading of counts at ambient pressure", Environment::NewLine,
        "and temperature and 175 �C");
    sensorSnapshot175TemperatureButtonToolTip->SetToolTip(
        sensorSnapshot175TemperatureButton,
        sensorSnapshot175TemperatureButtonToolTipText);
    delete sensorSnapshot175TemperatureButtonToolTipText;
    //--------------------------------------------------------------------
    // 175 �C count label
    //--------------------------------------------------------------------
    sensor175CountLabel = gcnew Label;
    if (calibrate->temperature175Count)
        sensor175CountLabel->Text = String::Format(
            "{0:X8}", calibrate->temperature175Count);
    else
        sensor175CountLabel->Text = _T("--  --  --  --");
    sensor175CountLabel->Font = gcnew Drawing::Font(
        FontFamily::GenericSansSerif,
        10.0F,
        FontStyle::Bold);
    sensor175CountLabel->Size = sensor150CountLabel->Size;
    sensor175CountLabel->Location = Point(
        sensor150CountLabel->Left,
        sensorSnapshot175TemperatureButton->Top + 4);
    sensor175CountLabel->BackColor = Color::Transparent;
    sensor175CountLabel->TextAlign = Drawing::ContentAlignment::MiddleCenter;
    sensorCalibrationModal->Controls->Add(sensor175CountLabel);
    //------------------------------------------------------------------------
    // 200 �C button
    //------------------------------------------------------------------------
    sensorSnapshot200TemperatureButton = gcnew Button;
    sensorSnapshot200TemperatureButton->Tag = calibrate->nodeAddress;
    sensorSnapshot200TemperatureButton->Font = gcnew Drawing::Font(
        FontFamily::GenericSansSerif,
        10.0F,
        FontStyle::Bold);
    sensorSnapshot200TemperatureButton->Text = _T("200 �C");
    GUI_PositionBelow(sensorSnapshot200TemperatureButton, sensorSnapshot175TemperatureButton, 4);
    sensorSnapshot200TemperatureButton->Size = sensorSnapshot175TemperatureButton->Size;
    GUI_SetButtonInterfaceProperties(sensorSnapshot200TemperatureButton);
    sensorSnapshot200TemperatureButton->Click +=
        gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_SensorSnapshot200TemperatureClicked);
    sensorCalibrationModal->Controls->Add(sensorSnapshot200TemperatureButton);
    sensorSnapshot200TemperatureButton->Enabled = GUI_NO;
    //------------------------------------------------------------------------
    // 200 �C button tool tip
    //------------------------------------------------------------------------
    ToolTip ^sensorSnapshot200TemperatureButtonToolTip = gcnew ToolTip;
    sensorSnapshot200TemperatureButtonToolTip->ShowAlways = GUI_YES;
    sensorSnapshot200TemperatureButtonToolTip->AutoPopDelay = 10000;   // display for ten seconds
    sensorSnapshot200TemperatureButtonToolTip->ToolTipTitle =
        _T("200 �C");
    String ^sensorSnapshot200TemperatureButtonToolTipText = String::Concat(
        "Click when you're ready to take a", Environment::NewLine,
        "reading of counts at ambient pressure", Environment::NewLine,
        "and temperature and 200 �C");
    sensorSnapshot200TemperatureButtonToolTip->SetToolTip(
        sensorSnapshot200TemperatureButton,
        sensorSnapshot200TemperatureButtonToolTipText);
    delete sensorSnapshot200TemperatureButtonToolTipText;
    //--------------------------------------------------------------------
    // 200 �C count label
    //--------------------------------------------------------------------
    sensor200CountLabel = gcnew Label;
    if (calibrate->temperature200Count)
        sensor200CountLabel->Text = String::Format(
            "{0:X8}", calibrate->temperature200Count);
    else
        sensor200CountLabel->Text = _T("--  --  --  --");
    sensor200CountLabel->Font = gcnew Drawing::Font(
        FontFamily::GenericSansSerif,
        10.0F,
        FontStyle::Bold);
    sensor200CountLabel->Size = sensor175CountLabel->Size;
    sensor200CountLabel->Location = Point(
        sensor175CountLabel->Left,
        sensorSnapshot200TemperatureButton->Top + 4);
    sensor200CountLabel->BackColor = Color::Transparent;
    sensor200CountLabel->TextAlign = Drawing::ContentAlignment::MiddleCenter;
    sensorCalibrationModal->Controls->Add(sensor200CountLabel);
    //------------------------------------------------------------------------
    // 225 �C button
    //------------------------------------------------------------------------
    sensorSnapshot225TemperatureButton = gcnew Button;
    sensorSnapshot225TemperatureButton->Tag = calibrate->nodeAddress;
    sensorSnapshot225TemperatureButton->Font = gcnew Drawing::Font(
        FontFamily::GenericSansSerif,
        10.0F,
        FontStyle::Bold);
    sensorSnapshot225TemperatureButton->Text = _T("225 �C");
    GUI_PositionBelow(sensorSnapshot225TemperatureButton, sensorSnapshot200TemperatureButton, 4);
    sensorSnapshot225TemperatureButton->Size = sensorSnapshot200TemperatureButton->Size;
    GUI_SetButtonInterfaceProperties(sensorSnapshot225TemperatureButton);
    sensorSnapshot225TemperatureButton->Click +=
        gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_SensorSnapshot225TemperatureClicked);
    sensorCalibrationModal->Controls->Add(sensorSnapshot225TemperatureButton);
    sensorSnapshot225TemperatureButton->Enabled = GUI_NO;
    //------------------------------------------------------------------------
    // 225 �C button tool tip
    //------------------------------------------------------------------------
    ToolTip ^sensorSnapshot225TemperatureButtonToolTip = gcnew ToolTip;
    sensorSnapshot225TemperatureButtonToolTip->ShowAlways = GUI_YES;
    sensorSnapshot225TemperatureButtonToolTip->AutoPopDelay = 10000;   // display for ten seconds
    sensorSnapshot225TemperatureButtonToolTip->ToolTipTitle =
        _T("225 �C");
    String ^sensorSnapshot225TemperatureButtonToolTipText = String::Concat(
        "Click when you're ready to take a", Environment::NewLine,
        "reading of counts at ambient pressure", Environment::NewLine,
        "and temperature and 225 �C");
    sensorSnapshot225TemperatureButtonToolTip->SetToolTip(
        sensorSnapshot225TemperatureButton,
        sensorSnapshot225TemperatureButtonToolTipText);
    delete sensorSnapshot225TemperatureButtonToolTipText;
    //--------------------------------------------------------------------
    // 225 �C count label
    //--------------------------------------------------------------------
    sensor225CountLabel = gcnew Label;
    if (calibrate->temperature225Count)
        sensor225CountLabel->Text = String::Format(
            "{0:X8}", calibrate->temperature225Count);
    else
        sensor225CountLabel->Text = _T("--  --  --  --");
    sensor225CountLabel->Font = gcnew Drawing::Font(
        FontFamily::GenericSansSerif,
        10.0F,
        FontStyle::Bold);
    sensor225CountLabel->Size = sensor200CountLabel->Size;
    sensor225CountLabel->Location = Point(
        sensor200CountLabel->Left,
        sensorSnapshot225TemperatureButton->Top + 4);
    sensor225CountLabel->BackColor = Color::Transparent;
    sensor225CountLabel->TextAlign = Drawing::ContentAlignment::MiddleCenter;
    sensorCalibrationModal->Controls->Add(sensor225CountLabel);
    //------------------------------------------------------------------------
    // Counts tool tip
    //------------------------------------------------------------------------
    ToolTip ^sensorCountsLabelToolTip = gcnew ToolTip;
    sensorCountsLabelToolTip->ShowAlways = GUI_YES;
    sensorCountsLabelToolTip->AutoPopDelay = 10000;   // display for ten seconds
    sensorCountsLabelToolTip->ToolTipTitle =
        _T("Counts");
    String ^sensorCountsLabelToolTipText = String::Concat(
        "The frequency counts for the particular", Environment::NewLine,
        "temperatures selected");
    sensorCountsLabelToolTip->SetToolTip(sensorCountsLabel, sensorCountsLabelToolTipText);
    sensorCountsLabelToolTip->SetToolTip(sensorAmbientCountLabel, sensorCountsLabelToolTipText);
    sensorCountsLabelToolTip->SetToolTip(sensor100CountLabel, sensorCountsLabelToolTipText);
    sensorCountsLabelToolTip->SetToolTip(sensor150CountLabel, sensorCountsLabelToolTipText);
    sensorCountsLabelToolTip->SetToolTip(sensor175CountLabel, sensorCountsLabelToolTipText);
    sensorCountsLabelToolTip->SetToolTip(sensor200CountLabel, sensorCountsLabelToolTipText);
    sensorCountsLabelToolTip->SetToolTip(sensor225CountLabel, sensorCountsLabelToolTipText);
    delete sensorCountsLabelToolTipText;
    //------------------------------------------------------------------------
    // Generate Coefficients button
    //------------------------------------------------------------------------
    sensorGenerateCoefficientsButton = gcnew Button;
    sensorGenerateCoefficientsButton->Text = _T("Generate Coefficients");
    sensorGenerateCoefficientsButton->Font = gcnew Drawing::Font(
        FontFamily::GenericSansSerif,
        10.0F,
        FontStyle::Bold);
    sensorGenerateCoefficientsButton->Location = Point(
        sensorSnapshot225TemperatureButton->Left,
        sensorCalibrationModal->Height - 70);
    sensorGenerateCoefficientsButton->Size = sensorSnapshot225TemperatureButton->Size;
    sensorGenerateCoefficientsButton->BackgroundImage = gcnew Bitmap(GUI_BG_SAND, GUI_YES);
    sensorGenerateCoefficientsButton->DialogResult = Windows::Forms::DialogResult::OK;
    sensorGenerateCoefficientsButton->KeyPress +=
        gcnew KeyPressEventHandler(this, &DTSTest_GUIClass::DTSTest_PromptKeyPressed);
    sensorCalibrationModal->Controls->Add(sensorGenerateCoefficientsButton);
    sensorCalibrationModal->AcceptButton = sensorGenerateCoefficientsButton;     // button when user presses Enter
    sensorGenerateCoefficientsButton->Enabled = GUI_NO;
    //------------------------------------------------------------------------
    // Cancel button to accept the input
    //------------------------------------------------------------------------
    Button ^cancelButton = gcnew Button;
    cancelButton->Text = _T("Cancel");
    cancelButton->Font = gcnew Drawing::Font(
        FontFamily::GenericSansSerif,
        10.0F,
        FontStyle::Bold);
    cancelButton->Size = Drawing::Size(60, GUI_REGULAR_BUTTON_HEIGHT);
    cancelButton->Location = Point(
        sensorGenerateCoefficientsButton->Right + 50,
        sensorGenerateCoefficientsButton->Top);
    cancelButton->BackgroundImage = gcnew Bitmap(GUI_BG_SAND, GUI_YES);
    cancelButton->DialogResult = Windows::Forms::DialogResult::Cancel;
    cancelButton->KeyPress +=
        gcnew KeyPressEventHandler(this, &DTSTest_GUIClass::DTSTest_PromptKeyPressed);
    sensorCalibrationModal->Controls->Add(cancelButton);
    sensorCalibrationModal->CancelButton = cancelButton;     // button when user presses Esc
    //------------------------------------------------------------------------
    // Display the window and query the user
    //------------------------------------------------------------------------
    DTSTest_ModalKeyStroke = 0;
    sensorCalibrationModal->ShowDialog();
    //------------------------------------------------------------------------
    // A button was clicked, or Enter, Esc, or Space was pressed
    //------------------------------------------------------------------------
    if (sensorCalibrationModal->DialogResult == Windows::Forms::DialogResult::OK)
        modalResponse = GUI_ACCEPT;
    else
        modalResponse = GUI_CANCEL;
    if (modalResponse == GUI_CANCEL)
        DTSTest_ModalKeyStroke = GUI_KEY_ESC;
    //------------------------------------------------------------------------
    // Dispose of the window components
    //------------------------------------------------------------------------
    delete sensorCalibrationModal;
    if (modalResponse == GUI_ACCEPT)
    {
        nodeAddress = calibrate->nodeAddress;
        String ^sensorHybridSerialNumberString = calibrate->hybridSerialNumberString;
        String ^sensorJigSerialNumberString = calibrate->jigSerialNumberString;
        if (StringSet(sensorHybridSerialNumberString) && StringSet(sensorJigSerialNumberString))
        {
//Modal("HSN = '{0}' and jig = '{1}'\nNode 0x{2:X2}  Pressure = {3:X8}\n    Ambient = {4:X8}\n    100 = {5:X8}\n    150 = {6:X8}\n    175 = {7:X8}\n    200 = {8:X8}\n    225 = {9:X8}",
//    calibrate->hybridSerialNumberString, calibrate->jigSerialNumberString, calibrate->nodeAddress,
//    calibrate->pressureAmbientCount, calibrate->temperatureAmbientCount,
//    calibrate->temperature100Count, calibrate->temperature150Count,
//    calibrate->temperature175Count, calibrate->temperature200Count, calibrate->temperature225Count);
            //----------------------------------------------------------------
            // Replace the 'H' in the serial number with a '7' for the filename
            //----------------------------------------------------------------
            String ^hybridFilename = String::Concat(
                calibrate->hybridSerialNumberString->Replace("H", "7")->Substring(0, 6), _T(".exe"));
            if (StringSet(calibrate->hexFilePathString))
            {
                calibrate->hexFilePathString = String::Concat(
                    Path::GetDirectoryName(calibrate->hexFilePathString),
                    DTSTEST_STRING_BACKSLASH,
                    hybridFilename);
            }
            else
            {
                PDGICInfo ^pgInfo = DTSTest_GeneralInfo->pgInfo;
                SensorInfo ^sensor = pgInfo->sensorInfoArray[nodeAddress];
                if (sensor && StringSet(sensor->coefficientInfo->hexFilePath))
                {
                    calibrate->hexFilePathString = String::Concat(
                        Path::GetDirectoryName(sensor->coefficientInfo->hexFilePath),
                        DTSTEST_STRING_BACKSLASH,
                        hybridFilename);
                }
                else
                {
                    calibrate->hexFilePathString = String::Concat(
                        Path::GetDirectoryName(DTSTest_GeneralInfo->defaultCoefficientInfo->hexFilePath),
                        DTSTEST_STRING_BACKSLASH,
                        hybridFilename);
                }
            }
            StringBuilder ^hexFilePathBuilder = gcnew StringBuilder(
                calibrate->hexFilePathString,
                DTSTEST_MAXIMUM_FILE_PATH_LENGTH);
            bool proceedToSaveFile = DTSTest_PromptForSaveFile(
                "Save Coefficient Hex File",
                hexFilePathBuilder,
                calibrate->hexFilePathString,
                GUI_FILE_TYPE_HEX);
            calibrate->hexFilePathString = hexFilePathBuilder->ToString();
            DTSTest_GeneralInfo->searchString = calibrate->hexFilePathString;
            if (proceedToSaveFile)
            {
                CoefficientFormatDef *coefficientData = (CoefficientFormatDef *)
                    malloc(sizeof(CoefficientFormatDef));
                if (coefficientData)
                {
                    //--------------------------------------------------------
                    // Use the default hex file as a template
                    //--------------------------------------------------------
                    memcpy_s(
                        (void *) coefficientData,
                        sizeof(CoefficientDataFormat),
                        (void *) DTSTest_GeneralInfo->defaultCoefficientInfo->coefficientData,
                        sizeof(CoefficientDataFormat));
                    CoefficientFormatDef *format = coefficientData;
                    //--------------------------------------------------------
                    // Convert the serial number to big-endian format
                    //--------------------------------------------------------
                    String ^hybridString = Path::GetFileNameWithoutExtension(hybridFilename);
                    int integerSerialNumber = 0;
                    for (int index = 4; index >= 0; index -= 2)
                    {
                        if (isdigit((BYTE) hybridString[index]) && isdigit((BYTE) hybridString[index + 1]))
                        {
                            integerSerialNumber |= ((AtoX(hybridString[index]) << 4) | AtoX(hybridString[index + 1]));
                            integerSerialNumber <<= 8;
                        }
                    }
                    format->serialNumber = integerSerialNumber | QD_QUARTZDYNE_ID;
                    //--------------------------------------------------------
                    // Part number = jig number + node address
                    //--------------------------------------------------------
                    DTSTest_ConvertString(
                        calibrate->jigSerialNumberString,
                        format->partNumber,
                        4);
                    format->partNumber[3] = (char) (nodeAddress / 100) + 0x30;
                    format->partNumber[4] = (char) ((nodeAddress % 100) / 10) + 0x30;
                    format->partNumber[5] = (char) (nodeAddress % 10) + 0x30;
                    //--------------------------------------------------------
                    // Calibration date
                    //--------------------------------------------------------
                    DateTime dateTime = DateTime::Now;
                    format->calibrationYear = ((((dateTime.Year % 100) >= 10) ? (0x10 + (dateTime.Year % 10)) : (dateTime.Year % 100)) << 8) + 0x20;
                    format->calibrationMonth = (dateTime.Month >= 10) ? (0x10 + (dateTime.Month % 10)) : dateTime.Month % 10;
                    format->calibrationDate = (dateTime.Day >= 10) ? (0x10 + (dateTime.Day % 10)) : dateTime.Day % 10;
                    //--------------------------------------------------------
                    // Minima and maxima
                    //--------------------------------------------------------
                    format->minimumPressure = 0;
                    format->maximumPressure = 0;
                    format->minimumTemperature = 5;
                    format->maximumTemperature = 45;
                    //--------------------------------------------------------
                    // Assume fit orders of
                    //      Pressure Fit : pressure = 3, temperature = 3
                    //      Temperature Fit : temperature = 3, pressure = 0
                    //--------------------------------------------------------
                    int numberOfPressureCoefficients =
                        (format->pressure1FitOrder + 1) * (format->temperature1FitOrder + 1);
                    int numberOfTemperatureCoefficients =
                        (format->pressure2FitOrder + 1) * (format->temperature2FitOrder + 1);
                    //--------------------------------------------------------
                    // TODO: Fill pressureCoefficients with valid data for psi
                    // and temperatureCoefficients with valid data for �C
                    //--------------------------------------------------------
                    DWORD pressureCoefficients[QD_MAXIMUM_NUMBER_OF_COEFFICIENTS];
                    DWORD temperatureCoefficients[QD_MAXIMUM_NUMBER_OF_COEFFICIENTS];
                    for (int index = 0; index < numberOfPressureCoefficients; index++)
                    {
                        DWORD integerValue = (DWORD) pressureCoefficients[index];
                        (*(DWORD *) &format->coefficients1[index * 4]) =
                            DTSTest_ReverseIntegerValue(integerValue);
                    }
                    for (int index = 0; index < numberOfTemperatureCoefficients; index++)
                    {
                        DWORD integerValue = (DWORD) temperatureCoefficients[index];
                        (*(DWORD *) &format->coefficients2[index * 4]) =
                            DTSTest_ReverseIntegerValue(integerValue);
                    }
                    //--------------------------------------------------------
                    // Checksum
                    //--------------------------------------------------------
                    BYTE *coefficientBytes = (BYTE *) coefficientData;
                    BYTE checksum = 0;
                    for (int index = 0; index < sizeof(CoefficientFormatDef) - 1; index++)
                    {
                        checksum += (BYTE) coefficientBytes[index];
                    }
                    format->checksum = (~checksum + 1) & 0xFF;
                    //--------------------------------------------------------
                    // Saved the file data to the specified file
                    //--------------------------------------------------------
                    char *hexFilePath = (char *)
                        malloc(DTSTEST_MAXIMUM_FILE_PATH_LENGTH);
                    if (hexFilePath)
                    {
                        ClearBuffer(hexFilePath, DTSTEST_MAXIMUM_FILE_PATH_LENGTH);
                        DTSTest_ConvertString(
                            calibrate->hexFilePathString,
                            hexFilePath,
                            DTSTEST_MAXIMUM_FILE_PATH_LENGTH);
                        DWORD status = QD_WriteCoefficientDataToHexFile(
                            (LPBYTE) coefficientData,
                            (LPBYTE) hexFilePath);
                        if (status == DTSTEST_SUCCESS)
                        {
                            DTSTest_PromptOKModal(
                                "Coefficient Hex File Created",
                                "Coefficient data saved in\n{0}",
                                calibrate->hexFilePathString);
                        }
                        else
                        {
                            RecordBasicEvent("    {0} : QD_WriteCoefficientDataToHexFile returned error 0x{1:X8}",
                                functionName, status);
                        }
                        free((void *) hexFilePath);
                    }                   // end of if (hexFilePath)
                    free((void *) coefficientData);
                }                       // end of if (coefficientData)
            }                           // end of if (proceedToSaveFile)
        }                               // end of if (StringSet(sensorHybridSerialNumberString) && StringSet(sensorJigSerialNumberString))
    }                                   // end of if (modalResponse == GUI_ACCEPT)
    RecordBasicEvent("{0} concluded", functionName);
}                                       // end of DTSTest_SensorPromptAndCalibrate()
//----------------------------------------------------------------------------
// DTSTest_SensorRetrieveBargeInformation
//
// Determines whether the specified barge is present, then retrieves some
// general information about it, if it is
//
// Returns: 0       = Success
//          nonzero = Failure
//----------------------------------------------------------------------------
    DWORD DTSTest_GUIClass::
DTSTest_SensorRetrieveBargeInformation(
    SensorInfo      ^sensor)
{
    bool            toolheadEnabled = GUI_NO;
    DWORD           status = DTSTEST_SUCCESS;
    String          ^functionName = _T("DTSTest_SensorRetrieveBargeInformation");
    //------------------------------------------------------------------------
    if (sensor)
    {
        RecordBasicEvent("            {0}({1:X2}) called", functionName, sensor->nodeAddress);
        if (!(sensor->sensorType & DTSTEST_SENSOR_TYPE_BARGE))
        {
            status = DTSTest_SensorRetrieveType(sensor);
        }
        if (sensor->sensorType & DTSTEST_SENSOR_TYPE_BARGE)
        {
            PDGICInfo ^pgInfo = DTSTest_GeneralInfo->pgInfo;
            //----------------------------------------------------------------
            // Store the original node address
            //----------------------------------------------------------------
            BYTE originalNodeAddress = pgInfo->nodeAddress;
            pgInfo->nodeAddress = sensor->nodeAddress;
            //----------------------------------------------------------------
            // Set up a MODBUS command to read the four holding registers
            //----------------------------------------------------------------
            pgInfo->commandArray[1] = MODBUS_COMMAND_READ_INPUT_REGISTERS;      // 0x04
            pgInfo->startingRegisterOffset = DTSTEST_BARGE_CHIP_ID_ADDRESS;     // 1
            pgInfo->numberOfRegistersToTransfer = 1;
            DTSTest_PDGICSendCommand(pgInfo);
            if (!DTSTest_PDGICSuccessfulReply)
            {
                //------------------------------------------------------------
                // Wait 100 ms, then retry
                //------------------------------------------------------------
                Thread::Sleep(100);
                RecordBasicEvent("            {0}({1:X2}) retry",
                    functionName, pgInfo->nodeAddress);
                DTSTest_PDGICSendCommand(pgInfo);
                if (!DTSTest_PDGICSuccessfulReply)
                {
                    status = DTSTEST_ERROR_MODBUS_COMMAND_FAILED;               // 0x000000B0
                }
            }
            if (DTSTest_PDGICSuccessfulReply && (status == DTSTEST_SUCCESS))
            {
                sensor->sensorPresent = GUI_YES;
                pgInfo->atLeastOneSensorPresent = GUI_YES;
                pgInfo->atLeastOneBargePresent = GUI_YES;
                if (pgInfo->responseArray[3] != 0xD9)
                    DTSTest_RecordAndModalErrorEvent(
                        "Mismatch in device type:\n    Barge = {0:X2}  Presumed = 0xD9",
                        pgInfo->responseArray[3]);
            }                           // end of if (DTSTest_PDGICSuccessfulReply && (status == DTSTEST_SUCCESS))
            else
            {
                if (status == DTSTEST_SUCCESS)
                    status = DTSTEST_ERROR_MODBUS_COMMAND_FAILED;               // 0x000000B0
            }
            //----------------------------------------------------------------
            // Restore the original node address
            //----------------------------------------------------------------
            pgInfo->nodeAddress = originalNodeAddress;
        }                               // end of if (sensor->sensorType & DTSTEST_SENSOR_TYPE_BARGE)
        else
        {
            status = DTSTEST_ERROR_SENSOR_TYPE_INCORRECT;                       // 0x000000E1
        }
    }                                   // end of if (sensor)
    else
    {
        status = DTSTEST_ERROR_SENSOR_POINTER_INVALID;                          // 0x000000E0
    }
    RecordBasicEvent("            {0} concluded, returning 0x{1:X8}", functionName, status);
    return status;
}                                       // end of DTSTest_SensorRetrieveBargeInformation()
//----------------------------------------------------------------------------
// DTSTest_SensorRetrieveCounts
//
// Retrieves pressure and temperature counts from the specified sensor
//
// Returns: 0       = Success
//          nonzero = Failure
//----------------------------------------------------------------------------
    DWORD DTSTest_GUIClass::
DTSTest_SensorRetrieveCounts(
    SensorInfo      ^sensor)
{
    DWORD           status = DTSTEST_SUCCESS;
    String          ^functionName = _T("DTSTest_SensorRetrieveCounts");
    //------------------------------------------------------------------------
    if (sensor)
    {
        RecordBasicEvent("            {0}({1:X2}) called", functionName, sensor->nodeAddress);
        PDGICInfo ^pgInfo = DTSTest_GeneralInfo->pgInfo;
        //--------------------------------------------------------------------
        // Store the original node address
        //--------------------------------------------------------------------
        BYTE originalNodeAddress = pgInfo->nodeAddress;
        pgInfo->nodeAddress = sensor->nodeAddress;
        //--------------------------------------------------------------------
        // Set up a MODBUS command to read the pressure and temperature words
        //--------------------------------------------------------------------
        pgInfo->commandArray[1] = MODBUS_COMMAND_READ_INPUT_REGISTERS;          // 0x04
        if (sensor->sensorType == DTSTEST_SENSOR_TYPE_GAUGE)
            pgInfo->startingRegisterOffset = DTSTEST_GAUGE_PRESSURE_ADDRESS;    // 0
        else
            pgInfo->startingRegisterOffset = DTSTEST_BARGE_PRESSURE_ADDRESS;    // 2
        pgInfo->numberOfRegistersToTransfer = 4;
        DTSTest_PDGICSendCommand(pgInfo);
        if (!DTSTest_PDGICSuccessfulReply)
        {
            //----------------------------------------------------------------
            // Wait 100 ms, then retry
            //----------------------------------------------------------------
            Thread::Sleep(100);
            DTSTest_PDGICSendCommand(pgInfo);
            if (!DTSTest_PDGICSuccessfulReply)
            {
                status = DTSTEST_ERROR_MODBUS_COMMAND_FAILED;                   // 0x000000B0
            }
        }
        if (DTSTest_PDGICSuccessfulReply && (status == DTSTEST_SUCCESS))
        {
            sensor->measurementsValid = GUI_YES;
            sensor->currentPressureCount = (DWORD)
                (pgInfo->responseArray[3] << 24) | (pgInfo->responseArray[4] << 16) | (pgInfo->responseArray[5] << 8) | pgInfo->responseArray[6];
            sensor->currentPressureFrequency = (float)
                (sensor->currentPressureCount * DTSTEST_FREQUENCY_MULTIPLIER);
            sensor->currentTemperatureCount = (DWORD)
                (pgInfo->responseArray[7] << 24) | (pgInfo->responseArray[8] << 16) | (pgInfo->responseArray[9] << 8) | pgInfo->responseArray[10];
            sensor->currentTemperatureFrequency = (float)
                (sensor->currentTemperatureCount * DTSTEST_FREQUENCY_MULTIPLIER);
        }                               // end of if (DTSTest_PDGICSuccessfulReply && (status == DTSTEST_SUCCESS))
        else
        {
            if (status == DTSTEST_SUCCESS)
                status = DTSTEST_ERROR_MODBUS_COMMAND_FAILED;                   // 0x000000B0
        }
        //--------------------------------------------------------------------
        // Restore the original node address
        //--------------------------------------------------------------------
        pgInfo->nodeAddress = originalNodeAddress;
    }                                   // end of if (sensor)
    else
    {
        status = DTSTEST_ERROR_SENSOR_POINTER_INVALID;                          // 0x000000E0
    }
    RecordBasicEvent("            {0} concluded, returning 0x{1:X8}", functionName, status);
    return status;
}                                       // end of DTSTest_SensorRetrieveCounts()
//----------------------------------------------------------------------------
// DTSTest_SensorRetrieveGaugeInformation
//
// Determines whether the specified gauge is present, then retrieves some
// general information about it, if it does
//
// Returns: 0       = Success
//          nonzero = Failure
//----------------------------------------------------------------------------
    DWORD DTSTest_GUIClass::
DTSTest_SensorRetrieveGaugeInformation(
    SensorInfo      ^sensor)
{
    bool            toolheadEnabled = GUI_NO;
    DWORD           status = DTSTEST_SUCCESS;
    String          ^functionName = _T("DTSTest_SensorRetrieveGaugeInformation");
    //------------------------------------------------------------------------
    if (sensor)
    {
        RecordBasicEvent("            {0}({1:X2}) called", functionName, sensor->nodeAddress);
        if (sensor->sensorType != DTSTEST_SENSOR_TYPE_GAUGE)
        {
            status = DTSTest_SensorRetrieveType(sensor);
        }
        if (sensor->sensorType == DTSTEST_SENSOR_TYPE_GAUGE)
        {
            PDGICInfo ^pgInfo = DTSTest_GeneralInfo->pgInfo;
            //----------------------------------------------------------------
            // Store the original node address
            //----------------------------------------------------------------
            BYTE originalNodeAddress = pgInfo->nodeAddress;
            pgInfo->nodeAddress = sensor->nodeAddress;
            status = DTSTest_SensorEnableGaugeToolhead(sensor);
            if (status == DTSTEST_SUCCESS)
                toolheadEnabled = GUI_YES;
            else
                status = DTSTEST_SUCCESS;
            //----------------------------------------------------------------
            // Set up a MODBUS command to read the four holding registers
            //----------------------------------------------------------------
            pgInfo->commandArray[1] = MODBUS_COMMAND_READ_INPUT_REGISTERS;      // 0x04
            pgInfo->startingRegisterOffset = DTSTEST_GAUGE_HOLDING_0_ADDRESS;   // 36 = 0x24
            pgInfo->numberOfRegistersToTransfer = 4;
            DTSTest_PDGICSendCommand(pgInfo);
            if (!DTSTest_PDGICSuccessfulReply)
            {
                //------------------------------------------------------------
                // Wait 100 ms, then retry
                //------------------------------------------------------------
                Thread::Sleep(100);
                RecordBasicEvent("            {0}({1:X2}) retry",
                    functionName, pgInfo->nodeAddress);
                DTSTest_PDGICSendCommand(pgInfo);
                if (!DTSTest_PDGICSuccessfulReply)
                {
                    status = DTSTEST_ERROR_MODBUS_COMMAND_FAILED;               // 0x000000B0
                }
            }
            if (DTSTest_PDGICSuccessfulReply && (status == DTSTEST_SUCCESS))
            {
                sensor->sensorPresent = GUI_YES;
                pgInfo->atLeastOneSensorPresent = GUI_YES;
                pgInfo->atLeastOneGaugePresent = GUI_YES;
                if (pgInfo->responseArray[6] != pgInfo->nodeAddress)
                    DTSTest_RecordAndModalErrorEvent(
                        "Mismatch in gauge node addresses:\n    Gauge = {0:X2}  Presumed = {1:X2}",
                        pgInfo->responseArray[6], pgInfo->nodeAddress);
                WORD baudRateRx = (WORD) (pgInfo->responseArray[7] << 8) | pgInfo->responseArray[8];
                WORD baudRateTx = (WORD) (pgInfo->responseArray[9] << 8) | pgInfo->responseArray[10];
                sensor->currentBaudRateRx = (baudRateRx == 0x2E) ? 1200 : ((baudRateRx == 0x17) ? 2400 : 4800);
                sensor->currentBaudRateTx = (baudRateTx == 0x2ED) ? 1200 : ((baudRateTx == 0x176) ? 2400 : 4800);
                if (sensor->currentBaudRateRx != sensor->currentBaudRateTx)
                    DTSTest_RecordAndModalErrorEvent(
                        "Mismatch in gauge baud rates:\n    Rx = {0:D}  Tx = {1:D}",
                        sensor->currentBaudRateRx, sensor->currentBaudRateTx);
                if (toolheadEnabled)
                {
                    WORD toolheadPassword = (WORD) (pgInfo->responseArray[3] << 8) | pgInfo->responseArray[4];
                    if (toolheadPassword != DTSTEST_GAUGE_TOOLHEAD_PASSWORD)
                        DTSTest_RecordAndModalErrorEvent(
                            "Mismatch in gauge toolhead password:\n    Gauge = {0:X4}  Presumed = {1:X4}",
                            toolheadPassword, DTSTEST_GAUGE_TOOLHEAD_PASSWORD);
                }
            }                           // end of if (DTSTest_PDGICSuccessfulReply && (status == DTSTEST_SUCCESS))
            else
            {
                if (status == DTSTEST_SUCCESS)
                    status = DTSTEST_ERROR_MODBUS_COMMAND_FAILED;               // 0x000000B0
            }
            //----------------------------------------------------------------
            // Restore the original node address
            //----------------------------------------------------------------
            pgInfo->nodeAddress = originalNodeAddress;
        }                               // end of if (sensor->sensorType == DTSTEST_SENSOR_TYPE_GAUGE)
        else
        {
            status = DTSTEST_ERROR_SENSOR_TYPE_INCORRECT;                       // 0x000000E1
        }
    }                                   // end of if (sensor)
    else
    {
        status = DTSTEST_ERROR_SENSOR_POINTER_INVALID;                          // 0x000000E0
    }
    RecordBasicEvent("            {0} concluded, returning 0x{1:X8}", functionName, status);
    return status;
}                                       // end of DTSTest_SensorRetrieveGaugeInformation()
//----------------------------------------------------------------------------
// DTSTest_SensorRetrieveMeasurements
//
// Retrieves pressure and temperature measurements from the specified sensor
//
// Returns: 0       = Success
//          nonzero = Failure
//----------------------------------------------------------------------------
    DWORD DTSTest_GUIClass::
DTSTest_SensorRetrieveMeasurements(
    SensorInfo      ^sensor)
{
    DWORD           status = DTSTEST_SUCCESS;
    String          ^functionName = _T("DTSTest_SensorRetrieveMeasurements");
    //------------------------------------------------------------------------
    if (sensor)
    {
        RecordBasicEvent("            {0}({1:X2}) called", functionName, sensor->nodeAddress);
        DTSTest_SensorRetrieveCounts(sensor);
        PDGICInfo ^pgInfo = DTSTest_GeneralInfo->pgInfo;
        if (sensor->coefficientInfo->coefficientDataLoaded)
        {
            double pressureValuePSI = 0.0;
            double temperatureValueCelsius = 0.0;
            status = QD_CalculatePressureAndTemperature(
                (LPBYTE) sensor->coefficientInfo->coefficientData,
                sensor->currentPressureCount,
                sensor->currentTemperatureCount,
                &pressureValuePSI,
                &temperatureValueCelsius);
            if (status == QD_SUCCESS)
            {
                sensor->currentPressurePSI = pressureValuePSI;
                sensor->currentTemperatureCelsius = temperatureValueCelsius;
                if (sensor->addBias)
                {
                    sensor->currentPressurePSI += (DTSTest_NormalizeReadings ? sensor->pressurePSIBias : 0);
                    sensor->currentTemperatureCelsius += (DTSTest_NormalizeReadings ? sensor->temperatureCelsiusBias : 0);
                }
            }
        }                               // end of if (sensor->coefficientInfo->coefficientDataLoaded)
    }                                   // end of if (sensor)
    else
    {
        status = DTSTEST_ERROR_SENSOR_POINTER_INVALID;                          // 0x000000E0
    }
    RecordBasicEvent("            {0} concluded, returning 0x{1:X8}", functionName, status);
    return status;
}                                       // end of DTSTest_SensorRetrieveMeasurements()
//----------------------------------------------------------------------------
// DTSTest_SensorRetrieveType
//
// Retrieves the type of the specified sensor
//
// Returns: 0       = Success
//          nonzero = Failure
//----------------------------------------------------------------------------
    DWORD DTSTest_GUIClass::
DTSTest_SensorRetrieveType(
    SensorInfo      ^sensor)
{
    DWORD           status = DTSTEST_SUCCESS;
    DWORD           sensorType = DTSTEST_SENSOR_TYPE_UNKNOWN;
    String          ^functionName = _T("DTSTest_SensorRetrieveType");
    //------------------------------------------------------------------------
    if (sensor)
    {
        RecordBasicEvent("            {0}({1:X2}) called", functionName, sensor->nodeAddress);
        switch (sensor->nodeAddress)
        {
            case DTSTEST_SENSOR_ADDRESS_NONE :                                  // 0x00
                sensor->sensorType = DTSTEST_SENSOR_TYPE_UNKNOWN;
                sensor->hardwareIDString = String::Empty;
                break;
            case DTSTEST_SENSOR_ADDRESS_BROADCAST :                             // 0xFE
                sensor->sensorType = DTSTEST_SENSOR_TYPE_BROADCAST_GAUGE;
                sensor->hardwareIDString = _T("BCast");
                break;
            default :
                {
                    sensor->hardwareIDString = DTSTEST_STRING_UNKNOWN;
                    PDGICInfo ^pgInfo = DTSTest_GeneralInfo->pgInfo;
                    //--------------------------------------------------------
                    // Store the original node address
                    //--------------------------------------------------------
                    BYTE originalNodeAddress = pgInfo->nodeAddress;
                    pgInfo->nodeAddress = sensor->nodeAddress;
                    //--------------------------------------------------------
                    // Set up a MODBUS command to read the gauge vendor prefix
                    //--------------------------------------------------------
                    pgInfo->commandArray[1] = MODBUS_COMMAND_READ_INPUT_REGISTERS;      // 0x04
                    pgInfo->startingRegisterOffset = SENSOR_GAUGE_VENDOR_PREFIX_ADDRESS;// 0x2B = 43
                    pgInfo->numberOfRegistersToTransfer = 1;
                    DTSTest_PDGICSendCommand(pgInfo);
                    if (DTSTest_PDGICSuccessfulReply)
                    {
                        if (pgInfo->responseArray[1] == 0x84)
                        {
                            //------------------------------------------------
                            // This is a DTS or DPS
                            //------------------------------------------------
                            Thread::Sleep(100);
                            pgInfo->commandArray[1] = MODBUS_COMMAND_READ_INPUT_REGISTERS;  // 0x04
                            pgInfo->startingRegisterOffset = DTSTEST_BARGE_CHIP_ID_ADDRESS; // 1
                            pgInfo->numberOfRegistersToTransfer = 1;
                            DTSTest_PDGICSendCommand(pgInfo);
                            if (DTSTest_PDGICSuccessfulReply)
                            {
                                WORD bargeChipID = (pgInfo->responseArray[3] << 8) | pgInfo->responseArray[4];
                                if ((bargeChipID & 0xFFF0) == DTSTEST_SENSOR_CHIPSET_DTS)
                                {
                                    sensorType = DTSTEST_SENSOR_TYPE_DTS;
                                    sensor->hardwareIDString = _T("DTS"); // String::Format("{0:X4}", bargeChipID);
                                }
                                if ((bargeChipID & 0xFFF0) == DTSTEST_SENSOR_CHIPSET_DPS)
                                {
                                    sensorType = DTSTEST_SENSOR_TYPE_DPS;
                                    sensor->hardwareIDString = _T("DPS"); // String::Format("{0:X4}", bargeChipID);
                                }
                            }
                        }
                        else
                        {
                            //------------------------------------------------
                            // This is a gauge, so ensure the vendor prefix is
                            // correct
                            //------------------------------------------------
                            WORD gaugeVendorID = (pgInfo->responseArray[3] << 8) | pgInfo->responseArray[4];
                            if (gaugeVendorID == 0x001A)
                            {
                                sensorType = DTSTEST_SENSOR_TYPE_GAUGE;
                                sensor->hardwareIDString = _T("ROC-X");
                            }
                        }
                    }                   // end of if (DTSTest_PDGICSuccessfulReply)
                    else
                    {
                        status = DTSTEST_ERROR_MODBUS_COMMAND_FAILED;           // 0x000000B0
                    }
                    sensor->sensorType = sensorType;
                    //--------------------------------------------------------
                    // Restore the original node address
                    //--------------------------------------------------------
                    pgInfo->nodeAddress = originalNodeAddress;
                }
                break;
        }                               // end of switch (sensor->nodeAddress)
    }                                   // end of if (sensor)
    else
    {
        status = DTSTEST_ERROR_SENSOR_POINTER_INVALID;                          // 0x000000E0
    }
    RecordBasicEvent("            {0} concluded, returning 0x{1:X8}", functionName, status);
    return status;
}                                       // end of DTSTest_SensorRetrieveType()
//----------------------------------------------------------------------------
// DTSTest_SensorReturnMeasurementsString
//
// Returns a string of the formatted pressure and temperature measurements for
// the specified sensor
//----------------------------------------------------------------------------
    String ^ DTSTest_GUIClass::
DTSTest_SensorReturnMeasurementsString(
    SensorInfo      ^sensor)
{
    String          ^measurementsString = String::Empty;
    String          ^functionName = _T("DTSTest_SensorReturnMeasurementsString");
    //------------------------------------------------------------------------
    if (sensor)
    {
        DWORD status = DTSTest_SensorRetrieveMeasurements(sensor);
        if (status == DTSTEST_SUCCESS)
        {
            measurementsString = String::Format(
                "{0:F3} psi / {1:F3} �C",
                sensor->currentPressurePSI,
                sensor->currentTemperatureCelsius);
        }                               // end of if (status == DTSTEST_SUCCESS)
        else
        {
            measurementsString = String::Format("error 0x{0:X8}", status);
        }
    }                                   // end of if (sensor)
    return measurementsString;
}                                       // end of DTSTest_SensorReturnMeasurementsString()
//----------------------------------------------------------------------------
// DTSTest_SensorSetGaugeRxBaudRate
//
// Sets the specified gauge to the specified Rx baud rate
//
// Returns: 0       = Success
//          nonzero = Failure
//----------------------------------------------------------------------------
    DWORD DTSTest_GUIClass::
DTSTest_SensorSetGaugeRxBaudRate(
    SensorInfo      ^sensor,
    int             targetBaudRate)
{
    DWORD           status = DTSTEST_SUCCESS;
    String          ^functionName = _T("DTSTest_SensorSetGaugeRxBaudRate");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0}({1:D}) called", functionName, targetBaudRate);
    if (sensor)
    {
        if ((targetBaudRate != 1200) && (targetBaudRate != 2400) && (targetBaudRate != 4800))
            status = DTSTEST_ERROR_INVALID_DATA_RATE;                           // 0x00000009
        if (status == DTSTEST_SUCCESS)
        {
            PDGICInfo ^pgInfo = DTSTest_GeneralInfo->pgInfo;
            //----------------------------------------------------------------
            // Store the original node address
            //----------------------------------------------------------------
            BYTE originalNodeAddress = pgInfo->nodeAddress;
            pgInfo->nodeAddress = sensor->nodeAddress;
            pgInfo->commandArray[1] = MODBUS_COMMAND_WRITE_SINGLE_REGISTER;     // 0x06
            pgInfo->startingRegisterOffset = 0x0002;
//            pgInfo->writeData = (targetBaudRate == 1200) ? 0x002E : 0x0016;
            switch (targetBaudRate)
            {
                case 1200 : pgInfo->writeData = 0x002E;
                    break;
                case 2400 : pgInfo->writeData = 0x0016;
                    break;
                case 4800 : pgInfo->writeData = 0x000B;
                    break;
                default :
                    status = DTSTEST_ERROR_INVALID_DATA_RATE;                   // 0x00000009
                    break;
            }
            DTSTest_PDGICSendCommand(pgInfo);
            if (DTSTest_PDGICSuccessfulReply && (status == DTSTEST_SUCCESS))
            {
                //------------------------------------------------------------
                // Warning: must NOT set the port baud rate here
                //------------------------------------------------------------
            }
            else
            {
                if (status == DTSTEST_SUCCESS)
                    status = DTSTEST_ERROR_MODBUS_COMMAND_FAILED;               // 0x000000B0
            }
            //----------------------------------------------------------------
            // Restore the original node address
            //----------------------------------------------------------------
            pgInfo->nodeAddress = originalNodeAddress;
        }                               // end of if (status == DTSTEST_SUCCESS)
    }                                   // end of if (sensor)
    else
    {
        status = DTSTEST_ERROR_SENSOR_POINTER_INVALID;                          // 0x000000E0
    }
    RecordBasicEvent("{0} concluded, returning 0x{1:X8}", functionName, status);
    return status;
}                                       // end of DTSTest_SensorSetGaugeRxBaudRate()
//----------------------------------------------------------------------------
// DTSTest_SensorSetGaugeTxBaudRate
//
// Sets the specified gauge to the specified Tx baud rate
//
// Returns: 0       = Success
//          nonzero = Failure
//----------------------------------------------------------------------------
    DWORD DTSTest_GUIClass::
DTSTest_SensorSetGaugeTxBaudRate(
    SensorInfo      ^sensor,
    int             targetBaudRate)
{
    DWORD           status = DTSTEST_SUCCESS;
    String          ^functionName = _T("DTSTest_SensorSetGaugeTxBaudRate");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0}({1:D}) called", functionName, targetBaudRate);
    if (sensor)
    {
        if ((targetBaudRate != 1200) && (targetBaudRate != 2400) && (targetBaudRate != 4800))
            status = DTSTEST_ERROR_INVALID_DATA_RATE;                           // 0x00000009
        if (status == DTSTEST_SUCCESS)
        {
            PDGICInfo ^pgInfo = DTSTest_GeneralInfo->pgInfo;
            //----------------------------------------------------------------
            // Store the original node address
            //----------------------------------------------------------------
            BYTE originalNodeAddress = pgInfo->nodeAddress;
            pgInfo->nodeAddress = sensor->nodeAddress;
            pgInfo->commandArray[1] = MODBUS_COMMAND_WRITE_SINGLE_REGISTER;     // 0x06
            pgInfo->startingRegisterOffset = 0x0003;
//            pgInfo->writeData = (targetBaudRate == 1200) ? 0x02ED : 0x0176;
            switch (targetBaudRate)
            {
                case 1200 : pgInfo->writeData = 0x02ED;
                    break;
                case 2400 : pgInfo->writeData = 0x0176;
                    break;
                case 4800 : pgInfo->writeData = 0x00BB;
                    break;
                default :
                    status = DTSTEST_ERROR_INVALID_DATA_RATE;                   // 0x00000009
                    break;
            }
            DTSTest_PDGICSendCommand(pgInfo);
            if (DTSTest_PDGICSuccessfulReply && (status == DTSTEST_SUCCESS))
            {
                if (pgInfo->baudRate != targetBaudRate)
                    pgInfo->baudRate = targetBaudRate;
            }
            else
            {
                if (status == DTSTEST_SUCCESS)
                    status = DTSTEST_ERROR_MODBUS_COMMAND_FAILED;               // 0x000000B0
            }
            //----------------------------------------------------------------
            // Restore the original node address
            //----------------------------------------------------------------
            pgInfo->nodeAddress = originalNodeAddress;
        }                               // end of if (status == DTSTEST_SUCCESS)
    }                                   // end of if (sensor)
    else
    {
        status = DTSTEST_ERROR_SENSOR_POINTER_INVALID;                          // 0x000000E0
    }
    RecordBasicEvent("{0} concluded, returning 0x{1:X8}", functionName, status);
    return status;
}                                       // end of DTSTest_SensorSetGaugeTxBaudRate()
//----------------------------------------------------------------------------
// DTSTest_SensorSnapshotAmbientTemperatureClicked
//
// Event that handles the click of the Ambient Temperature button
//
// Called by:   DTSTest_SensorPromptAndCalibrate
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_SensorSnapshotAmbientTemperatureClicked(
    Object          ^sender,
    EventArgs       ^evt)
{
    String          ^functionName = _T("DTSTest_SensorSnapshotAmbientTemperatureClicked");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0} called", functionName);
    Calibrate ^calibrate = DTSTest_GeneralInfo->calibrate;
    int nodeAddress = calibrate->nodeAddress;
    if (nodeAddress)
    {
        PDGICInfo ^pgInfo = DTSTest_GeneralInfo->pgInfo;
        SensorInfo ^sensor = pgInfo->sensorInfoArray[nodeAddress];
        if (sensor)
        {
            DWORD status = DTSTest_SensorRetrieveCounts(sensor);
            if (status == DTSTEST_SUCCESS)
            {
                calibrate->pressureAmbientCount = sensor->currentPressureCount;
                calibrate->temperatureAmbientCount = sensor->currentTemperatureCount;
                sensorAmbientCountLabel->Text = String::Format(
                    "{0:X8}", calibrate->temperatureAmbientCount);
                if (calibrate->pressureAmbientCount &&
                    calibrate->temperatureAmbientCount &&
                    calibrate->temperature100Count &&
                    calibrate->temperature150Count &&
                    calibrate->temperature175Count &&
                    calibrate->temperature200Count &&
                    calibrate->temperature225Count)
                    sensorGenerateCoefficientsButton->Enabled = GUI_YES;
            }
            else
                sensorAmbientCountLabel->Text = DTSTEST_STRING_INVALID;
        }                               // end of if (sensor)
    }                                   // end of if (nodeAddress)
    RecordBasicEvent("{0} concluded", functionName);
}                                       // end of DTSTest_SensorSnapshotAmbientTemperatureClicked()
//----------------------------------------------------------------------------
// DTSTest_SensorSnapshot100TemperatureClicked
//
// Event that handles the click of the 100 �C Temperature button
//
// Called by:   DTSTest_SensorPromptAndCalibrate
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_SensorSnapshot100TemperatureClicked(
    Object          ^sender,
    EventArgs       ^evt)
{
    String          ^functionName = _T("DTSTest_SensorSnapshot100TemperatureClicked");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0} called", functionName);
    Calibrate ^calibrate = DTSTest_GeneralInfo->calibrate;
    int nodeAddress = calibrate->nodeAddress;
    if (nodeAddress)
    {
        PDGICInfo ^pgInfo = DTSTest_GeneralInfo->pgInfo;
        SensorInfo ^sensor = pgInfo->sensorInfoArray[nodeAddress];
        if (sensor)
        {
            DWORD status = DTSTest_SensorRetrieveCounts(sensor);
            if (status == DTSTEST_SUCCESS)
            {
                calibrate->temperature100Count = sensor->currentTemperatureCount;
                sensor100CountLabel->Text = String::Format(
                    "{0:X8}", calibrate->temperature100Count);
                if (calibrate->pressureAmbientCount &&
                    calibrate->temperatureAmbientCount &&
                    calibrate->temperature100Count &&
                    calibrate->temperature150Count &&
                    calibrate->temperature175Count &&
                    calibrate->temperature200Count &&
                    calibrate->temperature225Count)
                    sensorGenerateCoefficientsButton->Enabled = GUI_YES;
            }
            else
                sensor100CountLabel->Text = DTSTEST_STRING_INVALID;
        }                               // end of if (sensor)
    }                                   // end of if (nodeAddress)
    RecordBasicEvent("{0} concluded", functionName);
}                                       // end of DTSTest_SensorSnapshot100TemperatureClicked()
//----------------------------------------------------------------------------
// DTSTest_SensorSnapshot150TemperatureClicked
//
// Event that handles the click of the 150 �C Temperature button
//
// Called by:   DTSTest_SensorPromptAndCalibrate
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_SensorSnapshot150TemperatureClicked(
    Object          ^sender,
    EventArgs       ^evt)
{
    String          ^functionName = _T("DTSTest_SensorSnapshot150TemperatureClicked");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0} called", functionName);
    Calibrate ^calibrate = DTSTest_GeneralInfo->calibrate;
    int nodeAddress = calibrate->nodeAddress;
    if (nodeAddress)
    {
        PDGICInfo ^pgInfo = DTSTest_GeneralInfo->pgInfo;
        SensorInfo ^sensor = pgInfo->sensorInfoArray[nodeAddress];
        if (sensor)
        {
            DWORD status = DTSTest_SensorRetrieveCounts(sensor);
            if (status == DTSTEST_SUCCESS)
            {
                calibrate->temperature150Count = sensor->currentTemperatureCount;
                sensor150CountLabel->Text = String::Format(
                    "{0:X8}", calibrate->temperature150Count);
                if (calibrate->pressureAmbientCount &&
                    calibrate->temperatureAmbientCount &&
                    calibrate->temperature100Count &&
                    calibrate->temperature150Count &&
                    calibrate->temperature175Count &&
                    calibrate->temperature200Count &&
                    calibrate->temperature225Count)
                    sensorGenerateCoefficientsButton->Enabled = GUI_YES;
            }
            else
                sensor150CountLabel->Text = DTSTEST_STRING_INVALID;
        }                               // end of if (sensor)
    }                                   // end of if (nodeAddress)
    RecordBasicEvent("{0} concluded", functionName);
}                                       // end of DTSTest_SensorSnapshot150TemperatureClicked()
//----------------------------------------------------------------------------
// DTSTest_SensorSnapshot175TemperatureClicked
//
// Event that handles the click of the 175 �C Temperature button
//
// Called by:   DTSTest_SensorPromptAndCalibrate
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_SensorSnapshot175TemperatureClicked(
    Object          ^sender,
    EventArgs       ^evt)
{
    String          ^functionName = _T("DTSTest_SensorSnapshot175TemperatureClicked");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0} called", functionName);
    Calibrate ^calibrate = DTSTest_GeneralInfo->calibrate;
    int nodeAddress = calibrate->nodeAddress;
    if (nodeAddress)
    {
        PDGICInfo ^pgInfo = DTSTest_GeneralInfo->pgInfo;
        SensorInfo ^sensor = pgInfo->sensorInfoArray[nodeAddress];
        if (sensor)
        {
            DWORD status = DTSTest_SensorRetrieveCounts(sensor);
            if (status == DTSTEST_SUCCESS)
            {
                calibrate->temperature175Count = sensor->currentTemperatureCount;
                sensor175CountLabel->Text = String::Format(
                    "{0:X8}", calibrate->temperature175Count);
                if (calibrate->pressureAmbientCount &&
                    calibrate->temperatureAmbientCount &&
                    calibrate->temperature100Count &&
                    calibrate->temperature150Count &&
                    calibrate->temperature175Count &&
                    calibrate->temperature200Count &&
                    calibrate->temperature225Count)
                    sensorGenerateCoefficientsButton->Enabled = GUI_YES;
            }
            else
                sensor175CountLabel->Text = DTSTEST_STRING_INVALID;
        }                               // end of if (sensor)
    }                                   // end of if (nodeAddress)
    RecordBasicEvent("{0} concluded", functionName);
}                                       // end of DTSTest_SensorSnapshot175TemperatureClicked()
//----------------------------------------------------------------------------
// DTSTest_SensorSnapshot200TemperatureClicked
//
// Event that handles the click of the 200 �C Temperature button
//
// Called by:   DTSTest_SensorPromptAndCalibrate
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_SensorSnapshot200TemperatureClicked(
    Object          ^sender,
    EventArgs       ^evt)
{
    String          ^functionName = _T("DTSTest_SensorSnapshot200TemperatureClicked");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0} called", functionName);
    Calibrate ^calibrate = DTSTest_GeneralInfo->calibrate;
    int nodeAddress = calibrate->nodeAddress;
    if (nodeAddress)
    {
        PDGICInfo ^pgInfo = DTSTest_GeneralInfo->pgInfo;
        SensorInfo ^sensor = pgInfo->sensorInfoArray[nodeAddress];
        if (sensor)
        {
            DWORD status = DTSTest_SensorRetrieveCounts(sensor);
            if (status == DTSTEST_SUCCESS)
            {
                calibrate->temperature200Count = sensor->currentTemperatureCount;
                sensor200CountLabel->Text = String::Format(
                    "{0:X8}", calibrate->temperature200Count);
                if (calibrate->pressureAmbientCount &&
                    calibrate->temperatureAmbientCount &&
                    calibrate->temperature100Count &&
                    calibrate->temperature150Count &&
                    calibrate->temperature175Count &&
                    calibrate->temperature200Count &&
                    calibrate->temperature225Count)
                    sensorGenerateCoefficientsButton->Enabled = GUI_YES;
            }
            else
                sensor200CountLabel->Text = DTSTEST_STRING_INVALID;
        }                               // end of if (sensor)
    }                                   // end of if (nodeAddress)
    RecordBasicEvent("{0} concluded", functionName);
}                                       // end of DTSTest_SensorSnapshot200TemperatureClicked()
//----------------------------------------------------------------------------
// DTSTest_SensorSnapshot225TemperatureClicked
//
// Event that handles the click of the 225 �C Temperature button
//
// Called by:   DTSTest_SensorPromptAndCalibrate
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_SensorSnapshot225TemperatureClicked(
    Object          ^sender,
    EventArgs       ^evt)
{
    String          ^functionName = _T("DTSTest_SensorSnapshot225TemperatureClicked");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0} called", functionName);
    Calibrate ^calibrate = DTSTest_GeneralInfo->calibrate;
    int nodeAddress = calibrate->nodeAddress;
    if (nodeAddress)
    {
        PDGICInfo ^pgInfo = DTSTest_GeneralInfo->pgInfo;
        SensorInfo ^sensor = pgInfo->sensorInfoArray[nodeAddress];
        if (sensor)
        {
            DWORD status = DTSTest_SensorRetrieveCounts(sensor);
            if (status == DTSTEST_SUCCESS)
            {
                calibrate->temperature225Count = sensor->currentTemperatureCount;
                sensor225CountLabel->Text = String::Format(
                    "{0:X8}", calibrate->temperature225Count);
                if (calibrate->pressureAmbientCount &&
                    calibrate->temperatureAmbientCount &&
                    calibrate->temperature100Count &&
                    calibrate->temperature150Count &&
                    calibrate->temperature175Count &&
                    calibrate->temperature200Count &&
                    calibrate->temperature225Count)
                    sensorGenerateCoefficientsButton->Enabled = GUI_YES;
            }
            else
                sensor225CountLabel->Text = DTSTEST_STRING_INVALID;
        }                               // end of if (sensor)
    }                                   // end of if (nodeAddress)
    RecordBasicEvent("{0} concluded", functionName);
}                                       // end of DTSTest_SensorSnapshot225TemperatureClicked()
//----------------------------------------------------------------------------
// DTSTest_ValidateSensorHybridSerialNumber
//
// Handles changes of the sensor Hybrid Serial Number field
//
// Called by:   DTSTest_SensorPromptAndCalibrate
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_ValidateSensorHybridSerialNumber(
    Object          ^sender,
    CancelEventArgs ^evt)
{
    String          ^hybridSerialNumberString = (String ^) (dynamic_cast <TextBox ^> (sender))->Text;
    String          ^functionName = _T("DTSTest_ValidateSensorHybridSerialNumber");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0} called", functionName);
    Calibrate ^calibrate = DTSTest_GeneralInfo->calibrate;
    calibrate->hybridSerialNumberString = hybridSerialNumberString;
    evt->Cancel = GUI_NO;
    if ((hybridSerialNumberString->Length == 9) ||
        (hybridSerialNumberString->Length == 10))
    {
        String ^nodeAddressDecimalString = hybridSerialNumberString->Substring(
            hybridSerialNumberString->Length - 3);
        int nodeAddress = 0;
        bool isCorrectFormat = DTSTest_ParseAndConvertStringToInteger(
            nodeAddressDecimalString,
            &nodeAddress);
        if (isCorrectFormat)
        {
            sensorDeviceNodeAddressHexLabel->Text = String::Format(
                "0x{0:X2}", nodeAddress);
            sensorDeviceNodeAddressHexLabel->Visible = GUI_YES;
            PDGICInfo ^pgInfo = DTSTest_GeneralInfo->pgInfo;
            SensorInfo ^sensor = pgInfo->sensorInfoArray[nodeAddress];
            if (sensor)
            {
                if (DTSTest_SensorPresent(sensor))
                {
                    calibrate->nodeAddress = nodeAddress;
                    calibrate->hybridSerialNumberStringIsValid = GUI_YES;
                    if (calibrate->jigSerialNumberStringIsValid)
                    {
                        sensorSnapshotAmbientTemperatureButton->Enabled = GUI_YES;
                        sensorSnapshot100TemperatureButton->Enabled = GUI_YES;
                        sensorSnapshot150TemperatureButton->Enabled = GUI_YES;
                        sensorSnapshot175TemperatureButton->Enabled = GUI_YES;
                        sensorSnapshot200TemperatureButton->Enabled = GUI_YES;
                        sensorSnapshot225TemperatureButton->Enabled = GUI_YES;
                        if (calibrate->pressureAmbientCount &&
                            calibrate->temperatureAmbientCount &&
                            calibrate->temperature100Count &&
                            calibrate->temperature150Count &&
                            calibrate->temperature175Count &&
                            calibrate->temperature200Count &&
                            calibrate->temperature225Count)
                            sensorGenerateCoefficientsButton->Enabled = GUI_YES;
                    }
                }
                else
                {
                    DTSTest_PromptOKModal(
                        "Missing Device",
                        "Device 0x{0:X2} (decimal {0:D}) is not\nfound in the current configuration",
                        nodeAddress);
                    calibrate->hybridSerialNumberStringIsValid = GUI_NO;
                }
            }
        }
        else
            sensorDeviceNodeAddressHexLabel->Visible = GUI_NO;
    }
    else
        sensorDeviceNodeAddressHexLabel->Visible = GUI_NO;
    RecordBasicEvent("{0} concluded: Accept '{1}'",
        functionName, hybridSerialNumberString);
}                                       // end of DTSTest_ValidateSensorHybridSerialNumber()
//----------------------------------------------------------------------------
// DTSTest_ValidateSensorJigSerialNumber
//
// Handles changes of the sensor Jig Serial Number field
//
// Called by:   DTSTest_SensorPromptAndCalibrate
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_ValidateSensorJigSerialNumber(
    Object          ^sender,
    CancelEventArgs ^evt)
{
    String          ^jigSerialNumberString = (String ^) (dynamic_cast <TextBox ^> (sender))->Text;
    String          ^functionName = _T("DTSTest_ValidateSensorJigSerialNumber");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0} called", functionName);
    Calibrate ^calibrate = DTSTest_GeneralInfo->calibrate;
    calibrate->jigSerialNumberString = jigSerialNumberString;
    evt->Cancel = GUI_NO;
    if (jigSerialNumberString->Length == 3)
    {
        calibrate->jigSerialNumberStringIsValid = GUI_YES;
        if (calibrate->hybridSerialNumberStringIsValid)
        {
            sensorSnapshotAmbientTemperatureButton->Enabled = GUI_YES;
            sensorSnapshot100TemperatureButton->Enabled = GUI_YES;
            sensorSnapshot150TemperatureButton->Enabled = GUI_YES;
            sensorSnapshot175TemperatureButton->Enabled = GUI_YES;
            sensorSnapshot200TemperatureButton->Enabled = GUI_YES;
            sensorSnapshot225TemperatureButton->Enabled = GUI_YES;
            if (calibrate->pressureAmbientCount &&
                calibrate->temperatureAmbientCount &&
                calibrate->temperature100Count &&
                calibrate->temperature150Count &&
                calibrate->temperature175Count &&
                calibrate->temperature200Count &&
                calibrate->temperature225Count)
                sensorGenerateCoefficientsButton->Enabled = GUI_YES;
        }
    }
    RecordBasicEvent("{0} concluded: Accept '{1}'",
        functionName, jigSerialNumberString);
}                                       // end of DTSTest_ValidateSensorJigSerialNumber()
//----------------------------------------------------------------------------
// DTSTest_ReverseIntegerValue
//
// Reverses the little-endian byte-order representation of the specified
// integer value
//
// Note:    The input value must be a 32-bit value
//----------------------------------------------------------------------------
    DWORD
DTSTest_ReverseIntegerValue(
    DWORD           forwardValue)
{
    DWORD           reverseValue;
    //------------------------------------------------------------------------
    reverseValue = (DWORD)
        (((forwardValue & 0x000000FF) << 24) |
         ((forwardValue & 0x0000FF00) << 8) |
         ((forwardValue & 0x00FF0000) >> 8) |
         ((forwardValue & 0xFF000000) >> 24));
    return reverseValue;
}                                       // end of DTSTest_ReverseIntegerValue()
//----------------------------------------------------------------------------
#endif      // SENSOR_CPP
//============================================================================
// End of Sensor.cpp
//============================================================================
