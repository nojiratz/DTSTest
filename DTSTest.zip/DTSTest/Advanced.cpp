//============================================================================
// Advanced.cpp
//
// The methods provided for advanced (expert) tasks
//
// Copyright (C) 2014 - 2016 Quartzdyne, Inc.  All rights reserved.
//
// No part of this source code may be reproduced or transmitted in any form or
// by any means, electronic or mechanical, including photocopying, recording,
// or any information storage and retrieval system, without express written
// permission from Quartzdyne, Inc.  Further, no use of this source code is
// permitted in any form or means without a valid, written license agreement
// with Quartzdyne, Inc.  While every reasonable precaution has been taken in
// the preparation of this source code, Quartzdyne, Inc., assumes no
// responsibility for errors, omissions, or damages from the use of the source
// code contained herein.
//
// NEITHER QUARTZDYNE, INC., ANY MEMBER OF QUARTZDYNE, INC., NOR ANY PERSON OR
// ORGANIZATION ACTING ON BEHALF OF THEM MAKES ANY WARRANTY OR REPRESENTATION
// WHATSOEVER, EXPRESS OR IMPLIED, INCLUDING ANY WARRANTY OF MERCHANTABILITY
// OR FITNESS FOR ANY PURPOSE WITH RESPECT TO THE SOURCE CODE OR ASSUMES ANY
// LIABILITY WHATSOEVER WITH RESPECT TO ANY USE OF THE SOURCE CODE OR ANY
// PORTION THEREOF OR WITH RESPECT TO ANY DAMAGES THAT MAY RESULT FROM SUCH
// USE.
//
// Noji Ratzlaff
//
// See DTSTest.log for a complete history of all updates, changes, and revisions
// of this source and other files and policies regarding DTSTest software
//
// Updated 01-14-2016
//============================================================================
#include    "stdafx.h"
#ifndef     ADVANCED_CPP
#define     ADVANCED_CPP
#include    "Advanced.h"
//----------------------------------------------------------------------------
// DTSTest_AdvancedBasicMessagesChecked
//
// Handles the check of the Basic Messages box
//
// Called by:   DTSTest_AdvancedControlsSetUpWindow
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_AdvancedBasicMessagesChecked(
    Object          ^sender,
    EventArgs       ^evt)
{
    //------------------------------------------------------------------------
    DTSTest_BasicMessagesEnabled = (DTSTest_BasicMessagesEnabled ? GUI_NO : GUI_YES);
    RecordBasicEvent(
        "Basic Messages {0}",
        (DTSTest_BasicMessagesEnabled ? "checked" : "un-checked"));
    DTSTest_UpdateMessageChecks();
}                                       // end of DTSTest_AdvancedBasicMessagesChecked()
//----------------------------------------------------------------------------
// DTSTest_AdvancedCalibrateSensorButtonClicked
//
// Handles the click of the Calibrate Sensor button
//
// Called by:   DTSTest_AdvancedControlsSetUpWindow
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_AdvancedCalibrateSensorButtonClicked(
    Object          ^sender,
    EventArgs       ^evt)
{
    //------------------------------------------------------------------------
    RecordBasicEvent("Calibrate Sensor button clicked");
    DTSTest_SensorPromptAndCalibrate();
}                                       // end of DTSTest_AdvancedCalibrateSensorButtonClicked()
//----------------------------------------------------------------------------
// DTSTest_AdvancedControlsCloseWindow
//
// Event that closes the Advanced Controls display window
//
// Called by:   DTSTest_AdvancedControlsSetUpWindow
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_AdvancedControlsCloseWindow(
    Object          ^sender,
    EventArgs       ^evt)
{
    //------------------------------------------------------------------------
    RecordBasicEvent("Advanced Controls window closed");
    if (advancedControlsWindow)
    {
        advancedControlsWindow->Hide();
    }
}                                       // end of DTSTest_AdvancedControlsCloseWindow()
//----------------------------------------------------------------------------
// DTSTest_AdvancedControlsClosingWindow
//
// Handles the closing of the Advanced Controls window by the red X
//
// Called by:   DTSTest_AdvancedControlsSetUpWindow
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_AdvancedControlsClosingWindow(
    Object          ^sender,
    FormClosingEventArgs
                    ^evt)
{
    //------------------------------------------------------------------------
    evt->Cancel = GUI_YES;              // cancel the closing of the window
    RecordBasicEvent("Advanced Controls window closed");
    if (advancedControlsWindow)
    {
        advancedControlsWindow->Hide();
    }
}                                       // end of DTSTest_AdvancedControlsClosingWindow()
//----------------------------------------------------------------------------
// DTSTest_AdvancedControlsSetUpWindow
//
// Displays advanced program controls for expert users in a new window
//
// Called by:   DTSTest_InstallUtilities
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_AdvancedControlsSetUpWindow(void)
{
    int             zeroValue = 0;
    String          ^functionName = _T("DTSTest_AdvancedControlsSetUpWindow");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0} called", functionName);
    if (DTSTest_GeneralInfo)
    {
        //--------------------------------------------------------------------
        // Create a new window form each time this is called, due to the
        // dynamic nature of the program values
        //--------------------------------------------------------------------
        advancedControlsWindow = gcnew Form;
        advancedControlsWindow->SuspendLayout();
        //--------------------------------------------------------------------
        // Set its properties
        //--------------------------------------------------------------------
        advancedControlsWindow->MaximizeBox = GUI_NO;
        advancedControlsWindow->HelpButton = GUI_NO;
        //--------------------------------------------------------------------
        // Set its icon
        //--------------------------------------------------------------------
        advancedControlsWindow->Icon = DTSTest_SoftwareIcon;
        //--------------------------------------------------------------------
        // Set the background image
        //--------------------------------------------------------------------
    //        advancedControlsWindow->BackgroundImage = whiteSandBackground;
        //--------------------------------------------------------------------
        // Set the title and border style
        //--------------------------------------------------------------------
        advancedControlsWindow->Text = _T("DTSTest Advanced Controls");
        advancedControlsWindow->FormBorderStyle = ::FormBorderStyle::Fixed3D;
        //--------------------------------------------------------------------
        // Set the dimensions of the Advanced Controls window
        //--------------------------------------------------------------------
        advancedControlsWindow->Size = Drawing::Size(
            GUI_ADVANCED_CONTROLS_WINDOW_WIDTH,
            GUI_ADVANCED_CONTROLS_WINDOW_HEIGHT);
        //--------------------------------------------------------------------
        // Serial Port combo label
        //--------------------------------------------------------------------
        PDGICInfo ^pgInfo = DTSTest_GeneralInfo->pgInfo;
        Label ^advancedSerialPortLabel = gcnew Label;
        advancedSerialPortLabel->Text = _T("Serial Port:");
        advancedSerialPortLabel->Location = Point(10, 20);
        advancedSerialPortLabel->Size = Drawing::Size(60, GUI_INFO_LABEL_HEIGHT);
        advancedSerialPortLabel->BackColor = Color::Transparent;
        advancedSerialPortLabel->TextAlign = Drawing::ContentAlignment::MiddleLeft;
        advancedSerialPortLabel->MouseEnter +=
            gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_AdvancedSerialPortAreaMouseEntered);
        advancedSerialPortLabel->MouseLeave +=
            gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_AnyObjectMouseExited);
        advancedControlsWindow->Controls->Add(advancedSerialPortLabel);
        //--------------------------------------------------------------------
        // Serial Port combo box
        //--------------------------------------------------------------------
        advancedSerialPortCombo = gcnew ComboBox;
        advancedSerialPortCombo->Location = Point(
            advancedSerialPortLabel->Right + 2,
            advancedSerialPortLabel->Top - 2);
        advancedSerialPortCombo->Size = Drawing::Size(
            80, GUI_REGULAR_COMBO_BOX_HEIGHT);
        advancedSerialPortCombo->MaxDropDownItems = DTSTest_SerialPortNameStringArray->Length;
        advancedSerialPortCombo->FormattingEnabled = GUI_YES;
        array <String ^> ^portNameStringArray = gcnew array <String ^>(DTSTest_SerialPortNameStringArray->Length);
        for (int offset = 0; offset < DTSTest_SerialPortNameStringArray->Length; offset++)
            portNameStringArray[offset] = String::Concat(_T("  "), DTSTest_SerialPortNameStringArray[offset]);
        advancedSerialPortCombo->Items->AddRange(portNameStringArray);
        if (StringSet(pgInfo->portName))
        {
            advancedSerialPortCombo->Text = String::Concat(_T("  "), pgInfo->portName);
        }
        else
        {
            advancedSerialPortCombo->Text = portNameStringArray[0];
            pgInfo->portName = advancedSerialPortCombo->Text->Trim();
        }
        delete [] portNameStringArray;
        advancedSerialPortCombo->BackColor = Color::Lavender;
        GUI_DisplayHandCursorOnHover(advancedSerialPortCombo);
        advancedSerialPortCombo->PreviewKeyDown +=
            gcnew PreviewKeyDownEventHandler(this, &DTSTest_GUIClass::DTSTest_ComboBoxAcceptEnterKey);
        advancedSerialPortCombo->KeyDown +=
            gcnew KeyEventHandler(this, &DTSTest_GUIClass::DTSTest_AdvancedSerialPortComboProcessEnterKey);
        advancedSerialPortCombo->SelectedIndexChanged +=
            gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_AdvancedSerialPortComboProcessSelection);
        advancedSerialPortCombo->MouseEnter +=
            gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_AdvancedSerialPortAreaMouseEntered);
        advancedSerialPortCombo->MouseLeave +=
            gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_AnyObjectMouseExited);
        advancedControlsWindow->Controls->Add(advancedSerialPortCombo);
        //--------------------------------------------------------------------
        // Work Around DTS Bad CRC Error check box
        //--------------------------------------------------------------------
        CheckBox ^advancedWorkAroundDTSBadCRCErrorCheck = gcnew CheckBox;
        advancedWorkAroundDTSBadCRCErrorCheck->Text = _T("Work around DTS bad CRC error");
        advancedWorkAroundDTSBadCRCErrorCheck->Location = Point(
            advancedSerialPortLabel->Left,
            advancedSerialPortLabel->Bottom + 8);
        advancedWorkAroundDTSBadCRCErrorCheck->Size = Drawing::Size(
            190, GUI_REGULAR_CHECK_BOX_HEIGHT);
        GUI_SetObjectInterfaceProperties(advancedWorkAroundDTSBadCRCErrorCheck);
        advancedWorkAroundDTSBadCRCErrorCheck->Click +=
            gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_AdvancedWorkAroundDTSBadCRCErrorChecked);
        if (DTSTest_WorkAroundDTSBadCRCError)
            advancedWorkAroundDTSBadCRCErrorCheck->Checked = GUI_YES;
        advancedControlsWindow->Controls->Add(advancedWorkAroundDTSBadCRCErrorCheck);
        //--------------------------------------------------------------------
        // Work Around Bad DTS CRC Error check box tool tip
        //--------------------------------------------------------------------
        ToolTip ^advancedWorkAroundDTSBadCRCErrorCheckToolTip = gcnew ToolTip;
        advancedWorkAroundDTSBadCRCErrorCheckToolTip->ShowAlways = GUI_YES;
        advancedWorkAroundDTSBadCRCErrorCheckToolTip->AutoPopDelay = 10000;     // let stand for ten seconds
        advancedWorkAroundDTSBadCRCErrorCheckToolTip->ToolTipTitle =
            _T("Work Around DTS Bad CRC Error");
        String ^advancedWorkAroundDTSBadCRCErrorCheckToolTipText = String::Concat(
            "If checked, this works around the bug in the DTS,", Environment::NewLine,
            "in which a request following a command with a bad", Environment::NewLine,
            "CRC will fail, by sending the same DTS target a", Environment::NewLine,
            "'dummy' read");
        advancedWorkAroundDTSBadCRCErrorCheckToolTip->SetToolTip(advancedWorkAroundDTSBadCRCErrorCheck, advancedWorkAroundDTSBadCRCErrorCheckToolTipText);
        delete advancedWorkAroundDTSBadCRCErrorCheckToolTipText;
        //--------------------------------------------------------------------
        // Calibrate Sensor button
        //--------------------------------------------------------------------
        Button ^advancedCalibrateSensorButton = gcnew Button;
        advancedCalibrateSensorButton->Text = _T("Calibrate Sensor");
        advancedCalibrateSensorButton->Location = Point(10, 120);
        advancedCalibrateSensorButton->Size = Drawing::Size(180, GUI_REGULAR_BUTTON_HEIGHT);
        GUI_SetButtonInterfaceProperties(advancedCalibrateSensorButton);
        advancedCalibrateSensorButton->Click +=
            gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_AdvancedCalibrateSensorButtonClicked);
        advancedControlsWindow->Controls->Add(advancedCalibrateSensorButton);
        //--------------------------------------------------------------------
        // Calibrate Sensor button tool tip
        //--------------------------------------------------------------------
        ToolTip ^advancedCalibrateSensorButtonToolTip = gcnew ToolTip;
        advancedCalibrateSensorButtonToolTip->ShowAlways = GUI_YES;
        advancedCalibrateSensorButtonToolTip->AutoPopDelay = 10000;   // let stand for ten seconds
        advancedCalibrateSensorButtonToolTip->ToolTipTitle =
            _T("Calibrate Sensor");
        String ^advancedCalibrateSensorButtonToolTipText = String::Concat(
            "Creates a set of coefficients for a selected", Environment::NewLine,
            "sensor by performing a 'desktop calibration'", Environment::NewLine,
            "on the unit, based on a variety of temperature", Environment::NewLine,
            "readings under ambient pressure.");
        advancedCalibrateSensorButtonToolTip->SetToolTip(advancedCalibrateSensorButton, advancedCalibrateSensorButtonToolTipText);
        delete advancedCalibrateSensorButtonToolTipText;
        //--------------------------------------------------------------------
        // Keep Port Open check box
        //--------------------------------------------------------------------
        CheckBox ^advancedKeepPortOpenCheck = gcnew CheckBox;
        advancedKeepPortOpenCheck->Text = _T("Keep communication port open");
        advancedKeepPortOpenCheck->Location = Point(
            advancedSerialPortLabel->Left,
            advancedControlsWindow->Bottom - 70);
        advancedKeepPortOpenCheck->Size = Drawing::Size(
            180, GUI_REGULAR_CHECK_BOX_HEIGHT);
        GUI_SetObjectInterfaceProperties(advancedKeepPortOpenCheck);
        advancedKeepPortOpenCheck->Click +=
            gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_AdvancedKeepPortOpenChecked);
        advancedControlsWindow->Controls->Add(advancedKeepPortOpenCheck);
        //--------------------------------------------------------------------
        // Keep Port Open check box tool tip
        //--------------------------------------------------------------------
        ToolTip ^advancedKeepPortOpenCheckToolTip = gcnew ToolTip;
        advancedKeepPortOpenCheckToolTip->ShowAlways = GUI_YES;
        advancedKeepPortOpenCheckToolTip->AutoPopDelay = 10000;     // let stand for ten seconds
        advancedKeepPortOpenCheckToolTip->ToolTipTitle =
            _T("Keep Port Open");
        String ^advancedKeepPortOpenCheckToolTipText = String::Concat(
            "By default the software closes the MODBUS serial", Environment::NewLine,
            "port after each transaction, but this option will", Environment::NewLine,
            "force the port to remain open, thus reducing the", Environment::NewLine,
            "overhead associated with opening and closing the", Environment::NewLine,
            "port repeatedly.");
        advancedKeepPortOpenCheckToolTip->SetToolTip(advancedKeepPortOpenCheck, advancedKeepPortOpenCheckToolTipText);
        delete advancedKeepPortOpenCheckToolTipText;
        //--------------------------------------------------------------------
        // Basic messages check box
        //--------------------------------------------------------------------
        advancedBasicMessagesCheck = gcnew CheckBox;
        advancedBasicMessagesCheck->Text = _T("Enable basic modal messages");
        advancedBasicMessagesCheck->Location = Point(340, 90);
        advancedBasicMessagesCheck->Size = Drawing::Size(
            200, GUI_REGULAR_CHECK_BOX_HEIGHT);
        GUI_SetObjectInterfaceProperties(advancedBasicMessagesCheck);
        advancedBasicMessagesCheck->Click +=
            gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_AdvancedBasicMessagesChecked);
        advancedControlsWindow->Controls->Add(advancedBasicMessagesCheck);
        //--------------------------------------------------------------------
        // Basic messages check box tool tip
        //--------------------------------------------------------------------
        ToolTip ^advancedBasicMessagesCheckToolTip = gcnew ToolTip;
        advancedBasicMessagesCheckToolTip->ShowAlways = GUI_YES;
        advancedBasicMessagesCheckToolTip->AutoPopDelay = 10000;    // let stand for ten seconds
        advancedBasicMessagesCheckToolTip->ToolTipTitle =
            _T("Basic Modal Messages");
        String ^advancedBasicMessagesCheckToolTipText = String::Concat(
            "Enables or disables the modal display", Environment::NewLine,
            "of the most general (basic and usual)", Environment::NewLine,
            "messages, as determined by the software.");
        advancedBasicMessagesCheckToolTip->SetToolTip(advancedBasicMessagesCheck, advancedBasicMessagesCheckToolTipText);
        delete advancedBasicMessagesCheckToolTipText;
        //--------------------------------------------------------------------
        // Error messages check box
        //--------------------------------------------------------------------
        advancedErrorMessagesCheck = gcnew CheckBox;
        advancedErrorMessagesCheck->Text = _T("Enable error modal messages");
        GUI_PositionAndSizeBelow(advancedErrorMessagesCheck, advancedBasicMessagesCheck, 4);
        GUI_SetObjectInterfaceProperties(advancedErrorMessagesCheck);
        advancedErrorMessagesCheck->Click +=
            gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_AdvancedErrorMessagesChecked);
        advancedErrorMessagesCheck->MouseEnter +=
            gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_AdvancedErrorMessagesCheckMouseEntered);
        advancedErrorMessagesCheck->MouseLeave +=
            gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_AnyObjectMouseExited);
        advancedControlsWindow->Controls->Add(advancedErrorMessagesCheck);
        //--------------------------------------------------------------------
        // Verbose messages check box
        //--------------------------------------------------------------------
        advancedVerboseMessagesCheck = gcnew CheckBox;
        advancedVerboseMessagesCheck->Text = _T("Enable verbose modal messages");
        GUI_PositionAndSizeBelow(advancedVerboseMessagesCheck, advancedErrorMessagesCheck, 4);
        GUI_SetObjectInterfaceProperties(advancedVerboseMessagesCheck);
        advancedVerboseMessagesCheck->Click +=
            gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_AdvancedVerboseMessagesChecked);
        advancedVerboseMessagesCheck->MouseEnter +=
            gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_AdvancedVerboseMessagesCheckMouseEntered);
        advancedVerboseMessagesCheck->MouseLeave +=
            gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_AnyObjectMouseExited);
        advancedControlsWindow->Controls->Add(advancedVerboseMessagesCheck);
        //--------------------------------------------------------------------
        // Detailed messages check box
        //--------------------------------------------------------------------
        advancedDetailedMessagesCheck = gcnew CheckBox;
        advancedDetailedMessagesCheck->Text = _T("Enable detailed modal messages");
        GUI_PositionAndSizeBelow(advancedDetailedMessagesCheck, advancedVerboseMessagesCheck, 4);
        GUI_SetObjectInterfaceProperties(advancedDetailedMessagesCheck);
        advancedDetailedMessagesCheck->Click +=
            gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_AdvancedDetailedMessagesChecked);
        advancedDetailedMessagesCheck->MouseEnter +=
            gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_AdvancedDetailedMessagesCheckMouseEntered);
        advancedDetailedMessagesCheck->MouseLeave +=
            gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_AnyObjectMouseExited);
        advancedControlsWindow->Controls->Add(advancedDetailedMessagesCheck);
        //--------------------------------------------------------------------
        // Experimental messages check box
        //--------------------------------------------------------------------
        advancedExpMessagesCheck = gcnew CheckBox;
        advancedExpMessagesCheck->Text = _T("Enable experimental messages");
        GUI_PositionAndSizeBelow(advancedExpMessagesCheck, advancedDetailedMessagesCheck, 4);
        GUI_SetObjectInterfaceProperties(advancedExpMessagesCheck);
        advancedExpMessagesCheck->Click +=
            gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_AdvancedExpMessagesChecked);
        advancedExpMessagesCheck->MouseEnter +=
            gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_AdvancedExpMessagesCheckMouseEntered);
        advancedExpMessagesCheck->MouseLeave +=
            gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_AnyObjectMouseExited);
        advancedControlsWindow->Controls->Add(advancedExpMessagesCheck);
        //--------------------------------------------------------------------
        // Reset All Messages button
        //--------------------------------------------------------------------
        Button ^advancedClearMessagesButton = gcnew Button;
        advancedClearMessagesButton->Text = _T("Reset All Modal Messages");
        GUI_PositionBelow(advancedClearMessagesButton, advancedExpMessagesCheck, 2);
        advancedClearMessagesButton->Size = Drawing::Size(180, GUI_REGULAR_BUTTON_HEIGHT);
        GUI_SetButtonInterfaceProperties(advancedClearMessagesButton);
        advancedClearMessagesButton->Click +=
            gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_AdvancedResetAllMessagesButtonClicked);
        advancedControlsWindow->Controls->Add(advancedClearMessagesButton);
        //--------------------------------------------------------------------
        // Reset All Messages button tool tip
        //--------------------------------------------------------------------
        ToolTip ^advancedClearMessagesButtonToolTip = gcnew ToolTip;
        advancedClearMessagesButtonToolTip->ShowAlways = GUI_YES;
        advancedClearMessagesButtonToolTip->AutoPopDelay = 10000;   // let stand for ten seconds
        advancedClearMessagesButtonToolTip->ToolTipTitle =
            _T("Reset All Modal Messages");
        String ^advancedClearMessagesButtonToolTipText = String::Concat(
            "Clears the settings to enable modal", Environment::NewLine,
            "messages.");
        advancedClearMessagesButtonToolTip->SetToolTip(advancedClearMessagesButton, advancedClearMessagesButtonToolTipText);
        delete advancedClearMessagesButtonToolTipText;
        //--------------------------------------------------------------------
        // Display Stack Traces check box
        //--------------------------------------------------------------------
        advancedEnableStackTracesCheck = gcnew CheckBox;
        advancedEnableStackTracesCheck->Text = _T("Display stack traces with errors");
        GUI_PositionBelow(advancedEnableStackTracesCheck, advancedClearMessagesButton, 4);
        advancedEnableStackTracesCheck->Size = advancedExpMessagesCheck->Size;
        GUI_SetObjectInterfaceProperties(advancedEnableStackTracesCheck);
        advancedEnableStackTracesCheck->Click +=
            gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_AdvancedEnableStackTracesChecked);
        advancedEnableStackTracesCheck->MouseEnter +=
            gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_AdvancedEnableStackTracesCheckMouseEntered);
        advancedEnableStackTracesCheck->MouseLeave +=
            gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_AnyObjectMouseExited);
        advancedControlsWindow->Controls->Add(advancedEnableStackTracesCheck);
        //--------------------------------------------------------------------
        // Enable Experiments check box
        //--------------------------------------------------------------------
        advancedEnableExperimentsCheck = gcnew CheckBox;
        advancedEnableExperimentsCheck->Text = _T("Enable experiments");
        GUI_PositionBelow(advancedEnableExperimentsCheck, advancedEnableStackTracesCheck, 4);
        advancedEnableExperimentsCheck->Size = Drawing::Size(124, GUI_REGULAR_CHECK_BOX_HEIGHT);
        GUI_SetObjectInterfaceProperties(advancedEnableExperimentsCheck);
        advancedEnableExperimentsCheck->Click +=
            gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_AdvancedEnableExperimentsChecked);
        advancedEnableExperimentsCheck->MouseEnter +=
            gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_AdvancedEnableExperimentsAreaMouseEntered);
        advancedEnableExperimentsCheck->MouseLeave +=
            gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_AnyObjectMouseExited);
        advancedControlsWindow->Controls->Add(advancedEnableExperimentsCheck);
        //--------------------------------------------------------------------
        // Experiment number box
        //--------------------------------------------------------------------
        advancedExperimentNumberBox = gcnew TextBox;
        advancedExperimentNumberBox->Location = Point(
            advancedEnableExperimentsCheck->Right + 2,
            advancedEnableExperimentsCheck->Top - 2);
        advancedExperimentNumberBox->Size = Drawing::Size(
            30, GUI_REGULAR_TEXT_BOX_HEIGHT);
        advancedExperimentNumberBox->Multiline = GUI_NO;
        advancedExperimentNumberBox->AcceptsReturn = GUI_NO;
        advancedExperimentNumberBox->AcceptsTab = GUI_NO;
        advancedExperimentNumberBox->WordWrap = GUI_NO;
        advancedExperimentNumberBox->TextAlign = HorizontalAlignment::Right;
        advancedExperimentNumberBox->BackColor = Color::White;
        advancedExperimentNumberBox->Validating +=
            gcnew CancelEventHandler(this, &DTSTest_GUIClass::DTSTest_ValidateExperimentNumberValue);
        advancedExperimentNumberBox->MouseEnter +=
            gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_AdvancedEnableExperimentsAreaMouseEntered);
        advancedExperimentNumberBox->MouseLeave +=
            gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_AnyObjectMouseExited);
        advancedControlsWindow->Controls->Add(advancedExperimentNumberBox);
        //--------------------------------------------------------------------
        // Perform Experiments button
        //--------------------------------------------------------------------
        advancedExpOneButton = gcnew Button;
        advancedExpOneButton->Text = _T("Perform Experiments");
        GUI_PositionBelow(advancedExpOneButton, advancedEnableExperimentsCheck, 2);
        advancedExpOneButton->Size = advancedClearMessagesButton->Size;
        GUI_SetButtonInterfaceProperties(advancedExpOneButton);
        advancedExpOneButton->Click +=
            gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_AdvancedExpOneButtonClicked);
        advancedExpOneButton->MouseEnter +=
            gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_AdvancedExpOneButtonMouseEntered);
        advancedExpOneButton->MouseLeave +=
            gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_AnyObjectMouseExited);
        advancedExpOneButton->Visible = DTSTest_ExperimentsEnabled ? GUI_YES : GUI_NO;
        advancedControlsWindow->Controls->Add(advancedExpOneButton);
        //--------------------------------------------------------------------
        // Don't Save Config File check box
        //--------------------------------------------------------------------
        advancedDontSaveConfigCheck = gcnew CheckBox;
        advancedDontSaveConfigCheck->Text = _T("Don't save program config file upon exit");
        advancedDontSaveConfigCheck->Location = Point(
            advancedControlsWindow->Width - 245, 10);
        advancedDontSaveConfigCheck->Size =
            Drawing::Size(222, GUI_REGULAR_CHECK_BOX_HEIGHT);
        GUI_SetObjectInterfaceProperties(advancedDontSaveConfigCheck);
        advancedDontSaveConfigCheck->Click +=
            gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_ConfigFileSaveDontSaveAreaClicked);
        advancedDontSaveConfigCheck->MouseEnter +=
            gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_ConfigFileSaveDontSaveAreaMouseEntered);
        advancedDontSaveConfigCheck->MouseLeave +=
            gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_AnyObjectMouseExited);
        advancedControlsWindow->Controls->Add(advancedDontSaveConfigCheck);
        //--------------------------------------------------------------------
        // Delete Config File check box
        //--------------------------------------------------------------------
        advancedDeleteConfigCheck = gcnew CheckBox;
        advancedDeleteConfigCheck->Text = _T("Delete program config file upon exit");
        GUI_PositionAndSizeBelow(advancedDeleteConfigCheck, advancedDontSaveConfigCheck, 4);
        GUI_SetObjectInterfaceProperties(advancedDeleteConfigCheck);
        advancedDeleteConfigCheck->Click +=
            gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_AdvancedDeleteConfigChecked);
        advancedDeleteConfigCheck->MouseEnter +=
            gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_AdvancedDeleteConfigCheckMouseEntered);
        advancedDeleteConfigCheck->MouseLeave +=
            gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_AnyObjectMouseExited);
        advancedControlsWindow->Controls->Add(advancedDeleteConfigCheck);
        //--------------------------------------------------------------------
        // Send Text on Errors check box
        //--------------------------------------------------------------------
        advancedSendTextErrorMessageCheck = gcnew CheckBox;
        advancedSendTextErrorMessageCheck->Text = _T("Send text messages when errors occur");
        GUI_PositionAndSizeBelow(advancedSendTextErrorMessageCheck, advancedDeleteConfigCheck, 44);
        GUI_SetObjectInterfaceProperties(advancedSendTextErrorMessageCheck);
        advancedSendTextErrorMessageCheck->Click +=
            gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_AdvancedSendTextErrorMessageChecked);
        advancedSendTextErrorMessageCheck->MouseEnter +=
            gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_AdvancedSendTextErrorMessageCheckMouseEntered);
        advancedSendTextErrorMessageCheck->MouseLeave +=
            gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_AnyObjectMouseExited);
        advancedControlsWindow->Controls->Add(advancedSendTextErrorMessageCheck);
        //--------------------------------------------------------------------
        // Text Message To Number box
        //--------------------------------------------------------------------
        advancedTextMessageToNumberLabel = gcnew Label;
        advancedTextMessageToNumberLabel->Text = _T("To:");
        advancedTextMessageToNumberLabel->Location = Point(
            advancedSendTextErrorMessageCheck->Left,
            advancedSendTextErrorMessageCheck->Bottom + 6);
        advancedTextMessageToNumberLabel->Size = Drawing::Size(24, GUI_REGULAR_LABEL_HEIGHT);
        advancedTextMessageToNumberLabel->BackColor = Color::Transparent;
        advancedControlsWindow->Controls->Add(advancedTextMessageToNumberLabel);
        advancedTextMessageToNumberBox = gcnew TextBox;
        advancedTextMessageToNumberBox->Text = DTSTest_GeneralInfo->textMessageToNumber;
        advancedTextMessageToNumberBox->Location = Point(
            advancedTextMessageToNumberLabel->Right + 2,
            advancedTextMessageToNumberLabel->Top - 2);
        advancedTextMessageToNumberBox->Size = Drawing::Size(
            194,
            GUI_REGULAR_TEXT_BOX_HEIGHT);
        advancedTextMessageToNumberBox->Multiline = GUI_NO;
        advancedTextMessageToNumberBox->AcceptsReturn = GUI_NO;
        advancedTextMessageToNumberBox->AcceptsTab = GUI_NO;
        advancedTextMessageToNumberBox->WordWrap = GUI_NO;
        advancedTextMessageToNumberBox->TextAlign = HorizontalAlignment::Left;
        advancedTextMessageToNumberBox->BackColor = Color::White;
        advancedTextMessageToNumberBox->Validating +=
            gcnew CancelEventHandler(this, &DTSTest_GUIClass::DTSTest_ValidateTextMessageNumbers);
        advancedTextMessageToNumberBox->MouseEnter +=
            gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_AdvancedTextMessageToNumberBoxMouseEntered);
        advancedTextMessageToNumberBox->MouseLeave +=
            gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_AnyObjectMouseExited);
        advancedControlsWindow->Controls->Add(advancedTextMessageToNumberBox);
        //--------------------------------------------------------------------
        // Text Message CC Number box
        //--------------------------------------------------------------------
        advancedTextMessageCCNumberLabel = gcnew Label;
        advancedTextMessageCCNumberLabel->Text = _T("CC:");
        advancedTextMessageCCNumberLabel->Location = Point(
            advancedTextMessageToNumberLabel->Left,
            advancedTextMessageToNumberLabel->Bottom + 12);
        advancedTextMessageCCNumberLabel->Size = Drawing::Size(24, GUI_REGULAR_LABEL_HEIGHT);
        advancedTextMessageCCNumberLabel->BackColor = Color::Transparent;
        advancedControlsWindow->Controls->Add(advancedTextMessageCCNumberLabel);
        advancedTextMessageCCNumberBox = gcnew TextBox;
        advancedTextMessageCCNumberBox->Text = DTSTest_GeneralInfo->textMessageCCNumber;
        advancedTextMessageCCNumberBox->Location = Point(
            advancedTextMessageCCNumberLabel->Right + 2,
            advancedTextMessageCCNumberLabel->Top - 2);
        advancedTextMessageCCNumberBox->Size = advancedTextMessageToNumberBox->Size;
        advancedTextMessageCCNumberBox->Multiline = GUI_NO;
        advancedTextMessageCCNumberBox->AcceptsReturn = GUI_NO;
        advancedTextMessageCCNumberBox->AcceptsTab = GUI_NO;
        advancedTextMessageCCNumberBox->WordWrap = GUI_NO;
        advancedTextMessageCCNumberBox->TextAlign = HorizontalAlignment::Left;
        advancedTextMessageCCNumberBox->BackColor = Color::White;
        advancedTextMessageCCNumberBox->Validating +=
            gcnew CancelEventHandler(this, &DTSTest_GUIClass::DTSTest_ValidateTextMessageNumbers);
        advancedTextMessageCCNumberBox->MouseEnter +=
            gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_AdvancedTextMessageCCNumberBoxMouseEntered);
        advancedTextMessageCCNumberBox->MouseLeave +=
            gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_AnyObjectMouseExited);
        advancedControlsWindow->Controls->Add(advancedTextMessageCCNumberBox);
        //--------------------------------------------------------------------
        // Send Email on Errors check box
        //--------------------------------------------------------------------
        advancedSendEmailErrorMessageCheck = gcnew CheckBox;
        advancedSendEmailErrorMessageCheck->Text = _T("Send emails when errors occur");
        advancedSendEmailErrorMessageCheck->Location = Point(
            advancedSendTextErrorMessageCheck->Left,
            advancedTextMessageCCNumberBox->Bottom + 6);
        advancedSendEmailErrorMessageCheck->Size = advancedEnableStackTracesCheck->Size;
        GUI_SetObjectInterfaceProperties(advancedSendEmailErrorMessageCheck);
        advancedSendEmailErrorMessageCheck->Click +=
            gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_AdvancedSendEmailErrorMessageChecked);
        advancedSendEmailErrorMessageCheck->MouseEnter +=
            gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_AdvancedSendEmailErrorMessageCheckMouseEntered);
        advancedSendEmailErrorMessageCheck->MouseLeave +=
            gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_AnyObjectMouseExited);
        advancedControlsWindow->Controls->Add(advancedSendEmailErrorMessageCheck);
        //--------------------------------------------------------------------
        // Email Message To Address box
        //--------------------------------------------------------------------
        advancedEmailMessageToAddressLabel = gcnew Label;
        advancedEmailMessageToAddressLabel->Text = _T("To:");
        advancedEmailMessageToAddressLabel->Location = Point(
            advancedSendEmailErrorMessageCheck->Left,
            advancedSendEmailErrorMessageCheck->Bottom + 6);
        advancedEmailMessageToAddressLabel->Size = Drawing::Size(24, GUI_REGULAR_LABEL_HEIGHT);
        advancedEmailMessageToAddressLabel->BackColor = Color::Transparent;
        advancedControlsWindow->Controls->Add(advancedEmailMessageToAddressLabel);
        advancedEmailMessageToAddressBox = gcnew TextBox;
        advancedEmailMessageToAddressBox->Text = DTSTest_GeneralInfo->emailMessageToAddress;
        advancedEmailMessageToAddressBox->Location = Point(
            advancedEmailMessageToAddressLabel->Right + 2,
            advancedEmailMessageToAddressLabel->Top - 2);
        advancedEmailMessageToAddressBox->Size = Drawing::Size(
            194,
            GUI_REGULAR_TEXT_BOX_HEIGHT);
        advancedEmailMessageToAddressBox->Multiline = GUI_NO;
        advancedEmailMessageToAddressBox->AcceptsReturn = GUI_NO;
        advancedEmailMessageToAddressBox->AcceptsTab = GUI_NO;
        advancedEmailMessageToAddressBox->WordWrap = GUI_NO;
        advancedEmailMessageToAddressBox->TextAlign = HorizontalAlignment::Left;
        advancedEmailMessageToAddressBox->BackColor = Color::White;
        advancedEmailMessageToAddressBox->Validating +=
            gcnew CancelEventHandler(this, &DTSTest_GUIClass::DTSTest_ValidateEmailMessageAddresses);
        advancedEmailMessageToAddressBox->MouseEnter +=
            gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_AdvancedEmailMessageToAddressBoxMouseEntered);
        advancedEmailMessageToAddressBox->MouseLeave +=
            gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_AnyObjectMouseExited);
        advancedControlsWindow->Controls->Add(advancedEmailMessageToAddressBox);
        //--------------------------------------------------------------------
        // Email Message CC Address box
        //--------------------------------------------------------------------
        advancedEmailMessageCCAddressLabel = gcnew Label;
        advancedEmailMessageCCAddressLabel->Text = _T("CC:");
        advancedEmailMessageCCAddressLabel->Location = Point(
            advancedEmailMessageToAddressLabel->Left,
            advancedEmailMessageToAddressLabel->Bottom + 12);
        advancedEmailMessageCCAddressLabel->Size = Drawing::Size(24, GUI_REGULAR_LABEL_HEIGHT);
        advancedEmailMessageCCAddressLabel->BackColor = Color::Transparent;
        advancedControlsWindow->Controls->Add(advancedEmailMessageCCAddressLabel);
        advancedEmailMessageCCAddressBox = gcnew TextBox;
        advancedEmailMessageCCAddressBox->Text = DTSTest_GeneralInfo->emailMessageCCAddress;
        advancedEmailMessageCCAddressBox->Location = Point(
            advancedEmailMessageCCAddressLabel->Right + 2,
            advancedEmailMessageCCAddressLabel->Top - 2);
        advancedEmailMessageCCAddressBox->Size = advancedEmailMessageToAddressBox->Size;
        advancedEmailMessageCCAddressBox->Multiline = GUI_NO;
        advancedEmailMessageCCAddressBox->AcceptsReturn = GUI_NO;
        advancedEmailMessageCCAddressBox->AcceptsTab = GUI_NO;
        advancedEmailMessageCCAddressBox->WordWrap = GUI_NO;
        advancedEmailMessageCCAddressBox->TextAlign = HorizontalAlignment::Left;
        advancedEmailMessageCCAddressBox->BackColor = Color::White;
        advancedEmailMessageCCAddressBox->Validating +=
            gcnew CancelEventHandler(this, &DTSTest_GUIClass::DTSTest_ValidateEmailMessageAddresses);
        advancedEmailMessageCCAddressBox->MouseEnter +=
            gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_AdvancedEmailMessageCCAddressBoxMouseEntered);
        advancedEmailMessageCCAddressBox->MouseLeave +=
            gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_AnyObjectMouseExited);
        advancedControlsWindow->Controls->Add(advancedEmailMessageCCAddressBox);
        //--------------------------------------------------------------------
        // Add a Close button
        //--------------------------------------------------------------------
        Button ^closeButton = gcnew Button;
        closeButton->Text = _T("Close");
        closeButton->Location = Point(
            advancedControlsWindow->Right - 100,
            advancedControlsWindow->Bottom - 70);
        closeButton->Size = Drawing::Size(
            GUI_CLOSE_BUTTON_WIDTH,
            GUI_REGULAR_BUTTON_HEIGHT);
        GUI_SetButtonInterfaceProperties(closeButton);
        closeButton->DialogResult = System::Windows::Forms::DialogResult::OK;
        closeButton->Click +=
            gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_AdvancedControlsCloseWindow);
        advancedControlsWindow->Controls->Add(closeButton);
        //------------------------------------------------------------------------
        // Handle the closing of the window by any other way
        //------------------------------------------------------------------------
        advancedControlsWindow->FormClosing +=
            gcnew FormClosingEventHandler(this, &DTSTest_GUIClass::DTSTest_AdvancedControlsClosingWindow);
        //--------------------------------------------------------------------
        // Set the remaining window properties
        //--------------------------------------------------------------------
        advancedControlsWindow->AcceptButton = closeButton;
        advancedControlsWindow->CancelButton = closeButton;
        //--------------------------------------------------------------------
        // Finally, hide the new window
        //--------------------------------------------------------------------
        advancedControlsWindow->ResumeLayout();
        advancedControlsWindow->Hide();
    }                                   // end of if (DTSTest_GeneralInfo)
    RecordBasicEvent("{0} concluded", functionName);
}                                       // end of DTSTest_AdvancedControlsSetUpWindow()
//----------------------------------------------------------------------------
// DTSTest_AdvancedDeleteConfigChecked
//
// Handles the check of the Delete Config File On Exit box
//
// Called by:   DTSTest_AdvancedControlsSetUpWindow
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_AdvancedDeleteConfigChecked(
    Object          ^sender,
    EventArgs       ^evt)
{
    //------------------------------------------------------------------------
    if (DTSTest_GeneralInfo->flags & DTSTEST_GENERAL_CONFIG_DELETE_ON_EXIT)
        DTSTest_GeneralInfo->flags &= ~DTSTEST_GENERAL_CONFIG_DELETE_ON_EXIT;
    else
        DTSTest_GeneralInfo->flags |= DTSTEST_GENERAL_CONFIG_DELETE_ON_EXIT;
    RecordBasicEvent(
        "Delete Config File on Exit {0}",
        ((DTSTest_GeneralInfo->flags & DTSTEST_GENERAL_CONFIG_DELETE_ON_EXIT) ? "checked" : "un-checked"));
    DTSTest_UpdateMessageChecks();
}                                       // end of DTSTest_AdvancedDeleteConfigChecked()
//----------------------------------------------------------------------------
// DTSTest_AdvancedDetailedMessagesChecked
//
// Handles the check of the Detailed Messages box
//
// Called by:   DTSTest_AdvancedControlsSetUpWindow
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_AdvancedDetailedMessagesChecked(
    Object          ^sender,
    EventArgs       ^evt)
{
    //------------------------------------------------------------------------
    DTSTest_DetailedMessagesEnabled = (DTSTest_DetailedMessagesEnabled ? GUI_NO : GUI_YES);
    RecordBasicEvent(
        "Detailed Messages {0}",
        (DTSTest_DetailedMessagesEnabled ? "checked" : "un-checked"));
    if (DTSTest_DetailedMessagesEnabled)
    {
        DTSTest_VerboseMessagesEnabled = GUI_YES;
        DTSTest_BasicMessagesEnabled = GUI_YES;
        DTSTest_ErrorMessagesEnabled = GUI_YES;
    }
    DTSTest_UpdateMessageChecks();
}                                       // end of DTSTest_AdvancedDetailedMessagesChecked()
//----------------------------------------------------------------------------
// DTSTest_AdvancedEnableExperimentsChecked
//
// Handles the check of the Enable Experiments box
//
// Called by:   DTSTest_AdvancedControlsSetUpWindow
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_AdvancedEnableExperimentsChecked(
    Object          ^sender,
    EventArgs       ^evt)
{
    //------------------------------------------------------------------------
    DTSTest_ExperimentsEnabled = (DTSTest_ExperimentsEnabled ? GUI_NO : GUI_YES);
    RecordBasicEvent(
        "Experiments {0}",
        (DTSTest_ExperimentsEnabled ? "checked" : "un-checked"));
    DTSTest_UpdateMessageChecks();
}                                       // end of DTSTest_AdvancedEnableExperimentsChecked()
//----------------------------------------------------------------------------
// DTSTest_AdvancedEnableStackTracesChecked
//
// Handles the check of the Enable Stack Traces box
//
// Called by:   DTSTest_AdvancedControlsSetUpWindow
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_AdvancedEnableStackTracesChecked(
    Object          ^sender,
    EventArgs       ^evt)
{
    //------------------------------------------------------------------------
    DTSTest_StackTracesEnabled = (DTSTest_StackTracesEnabled ? GUI_NO : GUI_YES);
    if (DTSTest_StackTracesEnabled && !DTSTest_ErrorMessagesEnabled)
        DTSTest_ErrorMessagesEnabled = GUI_YES;
    RecordBasicEvent(
        "Stack Traces {0}",
        (DTSTest_StackTracesEnabled ? "checked" : "un-checked"));
    DTSTest_UpdateMessageChecks();
}                                       // end of DTSTest_AdvancedEnableStackTracesChecked()
//----------------------------------------------------------------------------
// DTSTest_AdvancedErrorMessagesChecked
//
// Handles the check of the Error Messages box
//
// Called by:   DTSTest_AdvancedControlsSetUpWindow
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_AdvancedErrorMessagesChecked(
    Object          ^sender,
    EventArgs       ^evt)
{
    //------------------------------------------------------------------------
    DTSTest_ErrorMessagesEnabled = (DTSTest_ErrorMessagesEnabled ? GUI_NO : GUI_YES);
    if (DTSTest_StackTracesEnabled && !DTSTest_ErrorMessagesEnabled)
        DTSTest_StackTracesEnabled = GUI_NO;
    RecordBasicEvent(
        "Error Messages {0}",
        (DTSTest_ErrorMessagesEnabled ? "checked" : "un-checked"));
    DTSTest_UpdateMessageChecks();
}                                       // end of DTSTest_AdvancedErrorMessagesChecked()
//----------------------------------------------------------------------------
// DTSTest_AdvancedExpMessagesChecked
//
// Handles the check of the Exp Messages box
//
// Called by:   DTSTest_AdvancedControlsSetUpWindow
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_AdvancedExpMessagesChecked(
    Object          ^sender,
    EventArgs       ^evt)
{
    //------------------------------------------------------------------------
    DTSTest_ExpMessagesEnabled = (DTSTest_ExpMessagesEnabled ? GUI_NO : GUI_YES);
    RecordBasicEvent(
        "Experimental Messages {0}",
        (DTSTest_ExpMessagesEnabled ? "checked" : "un-checked"));
    DTSTest_UpdateMessageChecks();
}                                       // end of DTSTest_AdvancedExpMessagesChecked()
//----------------------------------------------------------------------------
// DTSTest_AdvancedExpOneButtonClicked
//
// Handles the click of the Perform Experiments button
//
// Called by:   DTSTest_AdvancedControlsSetUpWindow
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_AdvancedExpOneButtonClicked(
    Object          ^sender,
    EventArgs       ^evt)
{
    //------------------------------------------------------------------------
    RecordBasicEvent("Perform Experiments button clicked");
    DTSTest_PerformExperiments();
}                                       // end of DTSTest_AdvancedExpOneButtonClicked()
//----------------------------------------------------------------------------
// DTSTest_AdvancedKeepPortOpenChecked
//
// Handles the check of the Keep Port Open box
//
// Called by:   DTSTest_AdvancedControlsSetUpWindow
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_AdvancedKeepPortOpenChecked(
    Object          ^sender,
    EventArgs       ^evt)
{
    //------------------------------------------------------------------------
    DTSTest_KeepPortOpen = (DTSTest_KeepPortOpen ? GUI_NO : GUI_YES);
    RecordBasicEvent(
        "Keep Port Open {0}",
        (DTSTest_KeepPortOpen ? "checked" : "un-checked"));
}                                       // end of DTSTest_AdvancedKeepPortOpenChecked()
//----------------------------------------------------------------------------
// DTSTest_AdvancedResetAllMessagesButtonClicked
//
// Handles the click of the Reset All Modal Messages button
//
// Called by:   DTSTest_AdvancedControlsSetUpWindow
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_AdvancedResetAllMessagesButtonClicked(
    Object          ^sender,
    EventArgs       ^evt)
{
    //------------------------------------------------------------------------
    RecordBasicEvent("Reset All Modal Messages button clicked");
    DTSTest_BasicMessagesEnabled = GUI_NO;
    DTSTest_ErrorMessagesEnabled = GUI_NO;
    DTSTest_VerboseMessagesEnabled = GUI_NO;
    DTSTest_DetailedMessagesEnabled = GUI_NO;
    DTSTest_ExpMessagesEnabled = GUI_NO;
    DTSTest_UpdateMessageChecks();
}                                       // end of DTSTest_AdvancedResetAllMessagesButtonClicked()
//----------------------------------------------------------------------------
// DTSTest_AdvancedResetAllUserAddressesButtonClicked
//
// Handles the click of the Reset All User Addresses button
//
// Called by:   DTSTest_AdvancedControlsSetUpWindow
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_AdvancedResetAllUserAddressesButtonClicked(
    Object          ^sender,
    EventArgs       ^evt)
{
    PDGICInfo       ^pgInfo = DTSTest_GeneralInfo->pgInfo;
    //------------------------------------------------------------------------
    RecordBasicEvent("Reset All User Addresses button clicked");
//    //------------------------------------------------------------------------
//    // User gauge 1
//    //------------------------------------------------------------------------
//    pgInfo->userGaugeNodeAddress1 = DTSTEST_USER_GAUGE_DEFAULT_VALUE;
//    advancedUserGauge1Box->Text = String::Format("{0:X2}", pgInfo->userGaugeNodeAddress1);
//    pgInfo->sensorInfoArray[pgInfo->userGaugeNodeAddress1]->sensorPresent = GUI_NO;
//    samplingStartStopUserGauge1Button->Text = _T("Start Sampling Gauge XX");
//    samplingStartStopUserGauge1Button->Enabled = GUI_NO;
//    //------------------------------------------------------------------------
//    // User gauge 2
//    //------------------------------------------------------------------------
//    pgInfo->userGaugeNodeAddress2 = DTSTEST_USER_GAUGE_DEFAULT_VALUE;
//    advancedUserGauge2Box->Text = String::Format("{0:X2}", pgInfo->userGaugeNodeAddress2);
//    pgInfo->sensorInfoArray[pgInfo->userGaugeNodeAddress2]->sensorPresent = GUI_NO;
//    samplingStartStopUserGauge2Button->Text = _T("Start Sampling Gauge XX");
//    samplingStartStopUserGauge2Button->Enabled = GUI_NO;
//    //------------------------------------------------------------------------
//    // User gauge 3
//    //------------------------------------------------------------------------
//    pgInfo->userGaugeNodeAddress3 = DTSTEST_USER_GAUGE_DEFAULT_VALUE;
//    advancedUserGauge3Box->Text = String::Format("{0:X2}", pgInfo->userGaugeNodeAddress3);
//    pgInfo->sensorInfoArray[pgInfo->userGaugeNodeAddress3]->sensorPresent = GUI_NO;
//    samplingStartStopUserGauge3Button->Text = _T("Start Sampling Gauge XX");
//    samplingStartStopUserGauge3Button->Enabled = GUI_NO;
//    //------------------------------------------------------------------------
//    // User barge 1
//    //------------------------------------------------------------------------
//    pgInfo->userBargeNodeAddress1 = DTSTEST_USER_BARGE_DEFAULT_VALUE;
//    advancedUserBarge1Box->Text = String::Format("{0:X2}", pgInfo->userBargeNodeAddress1);
//    pgInfo->sensorInfoArray[pgInfo->userBargeNodeAddress1]->sensorPresent = GUI_NO;
//    samplingStartStopUserBarge1Button->Text = _T("Start Sampling Barge XX");
//    samplingStartStopUserBarge1Button->Enabled = GUI_NO;
//    //------------------------------------------------------------------------
//    // User barge 2
//    //------------------------------------------------------------------------
//    pgInfo->userBargeNodeAddress2 = DTSTEST_USER_BARGE_DEFAULT_VALUE;
//    advancedUserBarge2Box->Text = String::Format("{0:X2}", pgInfo->userBargeNodeAddress2);
//    pgInfo->sensorInfoArray[pgInfo->userBargeNodeAddress2]->sensorPresent = GUI_NO;
//    samplingStartStopUserBarge2Button->Text = _T("Start Sampling Barge XX");
//    samplingStartStopUserBarge2Button->Enabled = GUI_NO;
//    //------------------------------------------------------------------------
//    // User barge 3
//    //------------------------------------------------------------------------
//    pgInfo->userBargeNodeAddress3 = DTSTEST_USER_BARGE_DEFAULT_VALUE;
//    advancedUserBarge3Box->Text = String::Format("{0:X2}", pgInfo->userBargeNodeAddress3);
//    pgInfo->sensorInfoArray[pgInfo->userBargeNodeAddress3]->sensorPresent = GUI_NO;
//    samplingStartStopUserBarge3Button->Text = _T("Start Sampling Barge XX");
//    samplingStartStopUserBarge3Button->Enabled = GUI_NO;
//    //------------------------------------------------------------------------
//    // User barge 4
//    //------------------------------------------------------------------------
//    pgInfo->userBargeNodeAddress4 = DTSTEST_USER_BARGE_DEFAULT_VALUE;
//    advancedUserBarge4Box->Text = String::Format("{0:X2}", pgInfo->userBargeNodeAddress4);
//    pgInfo->sensorInfoArray[pgInfo->userBargeNodeAddress4]->sensorPresent = GUI_NO;
//    samplingStartStopUserBarge4Button->Text = _T("Start Sampling Barge XX");
//    samplingStartStopUserBarge4Button->Enabled = GUI_NO;
//    //------------------------------------------------------------------------
//    // User barge 5
//    //------------------------------------------------------------------------
//    pgInfo->userBargeNodeAddress5 = DTSTEST_USER_BARGE_DEFAULT_VALUE;
//    advancedUserBarge5Box->Text = String::Format("{0:X2}", pgInfo->userBargeNodeAddress5);
//    pgInfo->sensorInfoArray[pgInfo->userBargeNodeAddress5]->sensorPresent = GUI_NO;
//    samplingStartStopUserBarge5Button->Text = _T("Start Sampling Barge XX");
//    samplingStartStopUserBarge5Button->Enabled = GUI_NO;
//    //------------------------------------------------------------------------
//    // User barge 6
//    //------------------------------------------------------------------------
//    pgInfo->userBargeNodeAddress6 = DTSTEST_USER_BARGE_DEFAULT_VALUE;
//    advancedUserBarge6Box->Text = String::Format("{0:X2}", pgInfo->userBargeNodeAddress6);
//    pgInfo->sensorInfoArray[pgInfo->userBargeNodeAddress6]->sensorPresent = GUI_NO;
//    samplingStartStopUserBarge6Button->Text = _T("Start Sampling Barge XX");
//    samplingStartStopUserBarge6Button->Enabled = GUI_NO;
    //------------------------------------------------------------------------
    // General start / stop buttons
    //------------------------------------------------------------------------
//    samplingStartStopAllButton->Enabled = GUI_NO;
//    samplingStartStopAllGaugesButton->Enabled = GUI_NO;
//    samplingStartStopAllBargesButton->Enabled = GUI_NO;
}                                       // end of DTSTest_AdvancedResetAllUserAddressesButtonClicked()
//----------------------------------------------------------------------------
// DTSTest_AdvancedSendEmailErrorMessageChecked
//
// Handles the check of the Send Email Messages on Errors checkbox
//
// Called by:   DTSTest_AdvancedControlsSetUpWindow
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_AdvancedSendEmailErrorMessageChecked(
    Object          ^sender,
    EventArgs       ^evt)
{
    //------------------------------------------------------------------------
    DTSTest_SendEmailErrorMessagesEnabled = (DTSTest_SendEmailErrorMessagesEnabled ? GUI_NO : GUI_YES);
    RecordBasicEvent(
        "Sending Email Messages on Errors {0}",
        (DTSTest_SendEmailErrorMessagesEnabled ? "checked" : "un-checked"));
    DTSTest_UpdateMessageChecks();
}                                       // end of DTSTest_AdvancedSendEmailErrorMessageChecked()
//----------------------------------------------------------------------------
// DTSTest_AdvancedSendTextErrorMessageChecked
//
// Handles the check of the Send Text Messages on Errors checkbox
//
// Called by:   DTSTest_AdvancedControlsSetUpWindow
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_AdvancedSendTextErrorMessageChecked(
    Object          ^sender,
    EventArgs       ^evt)
{
    //------------------------------------------------------------------------
    DTSTest_SendTextErrorMessagesEnabled = (DTSTest_SendTextErrorMessagesEnabled ? GUI_NO : GUI_YES);
    RecordBasicEvent(
        "Sending Text Messages on Errors {0}",
        (DTSTest_SendTextErrorMessagesEnabled ? "checked" : "un-checked"));
    DTSTest_UpdateMessageChecks();
}                                       // end of DTSTest_AdvancedSendTextErrorMessageChecked()
//----------------------------------------------------------------------------
// DTSTest_AdvancedSerialPortComboProcessEnterKey
//
// Processes the result of accepting the Enter key in the advanced Serial Port
// Combo box
//
// Called by:   DTSTest_AdvancedControlsSetUpWindow
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_AdvancedSerialPortComboProcessEnterKey(
    Object          ^sender,
    KeyEventArgs    ^evt)
{
    //------------------------------------------------------------------------
    if (evt->KeyCode == Keys::Enter)
    {
        RecordBasicEvent(
            "Advanced Serial Port Box Enter Key pressed for {0}",
            advancedSerialPortCombo->Text->Trim());
        PDGICInfo ^pgInfo = DTSTest_GeneralInfo->pgInfo;
        pgInfo->portName =
            DTSTest_SerialPortNameStringArray[advancedSerialPortCombo->FindString(advancedSerialPortCombo->Text)];
        pgInfo->PDGICPresent = GUI_YES;
        pgInfo->modelName = _T("PDGIC");
        evt->SuppressKeyPress = GUI_YES;
    }
}                                       // end of DTSTest_AdvancedSerialPortComboProcessEnterKey()
//----------------------------------------------------------------------------
// DTSTest_AdvancedSerialPortComboProcessSelection
//
// Processes the result of selecting an item in the advanced Serial Port Combo
// box
//
// Called by:   DTSTest_AdvancedControlsSetUpWindow
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_AdvancedSerialPortComboProcessSelection(
    Object          ^sender,
    EventArgs       ^evt)
{
    //------------------------------------------------------------------------
    RecordBasicEvent(
        "Advanced Serial Port Box item selected for {0}",
        advancedSerialPortCombo->Text->Trim());
    PDGICInfo ^pgInfo = DTSTest_GeneralInfo->pgInfo;
    pgInfo->portName =
        DTSTest_SerialPortNameStringArray[advancedSerialPortCombo->FindString(advancedSerialPortCombo->Text)];
    pgInfo->PDGICPresent = GUI_YES;
    pgInfo->modelName = _T("PDGIC");
}                                       // end of DTSTest_AdvancedSerialPortComboProcessSelection()
//----------------------------------------------------------------------------
// DTSTest_AdvancedVerboseMessagesChecked
//
// Handles the check of the Verbose Messages box
//
// Called by:   DTSTest_AdvancedControlsSetUpWindow
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_AdvancedVerboseMessagesChecked(
    Object          ^sender,
    EventArgs       ^evt)
{
    //------------------------------------------------------------------------
    DTSTest_VerboseMessagesEnabled = (DTSTest_VerboseMessagesEnabled ? GUI_NO : GUI_YES);
    RecordBasicEvent(
        "Verbose Messages {0}",
        (DTSTest_VerboseMessagesEnabled ? "checked" : "un-checked"));
    if (DTSTest_VerboseMessagesEnabled)
    {
        DTSTest_BasicMessagesEnabled = GUI_YES;
        DTSTest_ErrorMessagesEnabled = GUI_YES;
    }
    DTSTest_UpdateMessageChecks();
}                                       // end of DTSTest_AdvancedVerboseMessagesChecked()
//----------------------------------------------------------------------------
// DTSTest_AdvancedWorkAroundDTSBadCRCErrorChecked
//
// Handles the check of the Waork Around Bad DTS CRC Error box
//
// Called by:   DTSTest_AdvancedControlsSetUpWindow
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_AdvancedWorkAroundDTSBadCRCErrorChecked(
    Object          ^sender,
    EventArgs       ^evt)
{
    //------------------------------------------------------------------------
    DTSTest_WorkAroundDTSBadCRCError = (DTSTest_WorkAroundDTSBadCRCError ? GUI_NO : GUI_YES);
    RecordBasicEvent(
        "DTS Bad CRC Error Workaround {0}",
        (DTSTest_WorkAroundDTSBadCRCError ? "checked" : "un-checked"));
}                                       // end of DTSTest_AdvancedWorkAroundDTSBadCRCErrorChecked()
//----------------------------------------------------------------------------
// DTSTest_ProgramInfoDisplayWindow
//
// Displays program information for expert users in a new window
//
// Called by:   DTSTest_ToolStripProgInfoDropDownClicked
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_ProgramInfoDisplayWindow(void)
{
    int             lapsedDays;
    int             lapsedHours;
    int             lapsedMinutes;
    int             lapsedSeconds;
    int             lapsedMilliseconds;
    DWORD           previousBottomLine;
    DWORD           messageFlags = 0;
    String          ^measurementsString = String::Empty;
    SensorInfo      ^sensor = nullptr;
    PDGICInfo       ^pgInfo = DTSTest_GeneralInfo->pgInfo;
    DateTime        dateTime = DateTime::Now;
    String          ^functionName = _T("DTSTest_ProgramInfoDisplayWindow");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0} called", functionName);
    if (DTSTest_GeneralInfo)
    {
        //--------------------------------------------------------------------
        // Create a new window form each time this is called, due to the
        // dynamic nature of the program values
        //--------------------------------------------------------------------
        pInfoWindow = gcnew Form;
        pInfoWindow->SuspendLayout();
        //--------------------------------------------------------------------
        // Set its properties
        //--------------------------------------------------------------------
        pInfoWindow->MaximizeBox = GUI_NO;
    //        pInfoWindow->MinimizeBox = GUI_NO;
        pInfoWindow->HelpButton = GUI_NO;
//        pInfoWindow->TopMost = GUI_YES;
        //--------------------------------------------------------------------
        // Set its icon
        //--------------------------------------------------------------------
        pInfoWindow->Icon = DTSTest_SoftwareIcon;
        //--------------------------------------------------------------------
        // Set the background image
        //--------------------------------------------------------------------
    //        pInfoWindow->BackgroundImage = whiteSandBackground;
        //--------------------------------------------------------------------
        // Set the title and border style
        //--------------------------------------------------------------------
        pInfoWindow->Text = _T("DTSTest Program Information");
        pInfoWindow->FormBorderStyle = ::FormBorderStyle::Fixed3D;
        //--------------------------------------------------------------------
        // Create the general group box
        //--------------------------------------------------------------------
        GroupBox ^pInfoGeneralGroupBox = gcnew GroupBox;
        pInfoGeneralGroupBox->Text = _T("General Program Information");
        pInfoGeneralGroupBox->Location = Point(10, 10);
        pInfoGeneralGroupBox->BackColor = Color::Transparent;
        pInfoWindow->Controls->Add(pInfoGeneralGroupBox);
        //--------------------------------------------------------------------
        // Program name
        //--------------------------------------------------------------------
        Label ^pInfoProgramNameLabel = gcnew Label;
        pInfoProgramNameLabel->Text = String::Concat("Name: ", GUI_HOME_WINDOW_TITLE);
        pInfoProgramNameLabel->Location = Point(10, 20);
        pInfoProgramNameLabel->Size = Drawing::Size(300, GUI_INFO_LABEL_HEIGHT);
        pInfoProgramNameLabel->BackColor = Color::Transparent;
        //--------------------------------------------------------------------
        // Program version and build
        //--------------------------------------------------------------------
        Label ^pInfoProgramVersionAndBuildLabel = gcnew Label;
        pInfoProgramVersionAndBuildLabel->Text = String::Format(
            "Version: {0}    Build {1:D} = {1:X8}",
            DTSTEST_PROGRAM_VERSION_STRING, DTSTest_BuildNumber);
        GUI_PositionAndSizeBelow(pInfoProgramVersionAndBuildLabel, pInfoProgramNameLabel, 2);
        //--------------------------------------------------------------------
        // Current date and time
        //--------------------------------------------------------------------
        Label ^pInfoThisMomentLabel = gcnew Label;
        DTSTest_TimeElapsed(
            GetTickCount() - DTSTest_StartTime,
            &lapsedDays,
            &lapsedHours,
            &lapsedMinutes,
            &lapsedSeconds,
            &lapsedMilliseconds);
        pInfoThisMomentLabel->Text = String::Format(
            "Now: {0:D2} {1} {2:D4} {3:D2}:{4:D2}:{5:D2} [ up {6:D} d {7:D} h {8:D} m {9:D} s ]",
            dateTime.Day,
            DTSTest_MonthStringArray[dateTime.Month],
            dateTime.Year,
            dateTime.Hour,
            dateTime.Minute,
            dateTime.Second,
            lapsedDays,
            lapsedHours,
            lapsedMinutes,
            lapsedSeconds);
        GUI_PositionAndSizeBelow(pInfoThisMomentLabel, pInfoProgramVersionAndBuildLabel, 2);
        //--------------------------------------------------------------------
        // Program author
        //--------------------------------------------------------------------
        Label ^pInfoProgramAuthorLabel = gcnew Label;
        pInfoProgramAuthorLabel->Text = String::Concat(
            "Author: ", DTSTEST_PROGRAM_AUTHOR);
        GUI_PositionAndSizeBelow(pInfoProgramAuthorLabel, pInfoThisMomentLabel, 2);
        //--------------------------------------------------------------------
        // The program startup path
        //--------------------------------------------------------------------
        Label ^pInfoStartupPathLabel = gcnew Label;
        GUI_PositionBelow(pInfoStartupPathLabel, pInfoProgramAuthorLabel, 2);
        pInfoStartupPathLabel->Size = Drawing::Size(
            600,
            GUI_INFO_LABEL_HEIGHT);
        String ^startupPathCaption = _T("Startup Path: ");
        String ^startupPath = DTSTest_LimitFilePathStringWidth(
            Application::ExecutablePath,
            pInfoStartupPathLabel->Width - DTSTest_StringWidth(startupPathCaption));
        pInfoStartupPathLabel->Text = String::Concat(startupPathCaption, startupPath);
        delete startupPath;
        delete startupPathCaption;
        //--------------------------------------------------------------------
        // Program command-line parameters
        //--------------------------------------------------------------------
        Label ^pInfoCommandLineParametersLabel = gcnew Label;
        GUI_PositionAndSizeBelow(pInfoCommandLineParametersLabel, pInfoStartupPathLabel, 2);
        String ^clpPathCaption = _T("Command-line Parameters: ");
        String ^clpPath;
        if (StringSet(DTSTest_GeneralInfo->commandLine))
        {
            clpPath = DTSTest_LimitFilePathStringWidth(
                DTSTest_GeneralInfo->commandLine,
                pInfoCommandLineParametersLabel->Width - DTSTest_StringWidth(clpPathCaption));
        }
        else
        {
            clpPath = DTSTEST_STRING_NONE;
        }
        pInfoCommandLineParametersLabel->Text = String::Concat(clpPathCaption, clpPath);
        delete clpPath;
        delete clpPathCaption;
        pInfoCommandLineParametersLabel->BackColor = Color::Transparent;
       //--------------------------------------------------------------------
        // The general use path
        //--------------------------------------------------------------------
        Label ^pInfoGeneralUsePathLabel = gcnew Label;
        GUI_PositionAndSizeBelow(pInfoGeneralUsePathLabel, pInfoCommandLineParametersLabel, 2);
        String ^usePathCaption = _T("General Use Path: ");
        String ^usePath;
        if (DTSTest_GeneralInfo->flags & DTSTEST_GENERAL_USE_PATH_SPECIFIED)
        {
            usePath = DTSTest_LimitFilePathStringWidth(
                DTSTest_GeneralInfo->generalUsePath,
                pInfoGeneralUsePathLabel->Width - DTSTest_StringWidth(usePathCaption));
        }
        else
        {
            usePath = DTSTEST_STRING_NONE;
        }
        pInfoGeneralUsePathLabel->Text = String::Concat(usePathCaption, usePath);
        delete usePath;
        delete usePathCaption;
        //--------------------------------------------------------------------
        // The config file path
        //--------------------------------------------------------------------
        Label ^pInfoConfigFilePathLabel = gcnew Label;
        GUI_PositionAndSizeBelow(pInfoConfigFilePathLabel, pInfoGeneralUsePathLabel, 2);
        String ^cfgPathCaption = _T("Config File Path: ");
        String ^cfgPath;
        if (DTSTest_GeneralInfo->flags & DTSTEST_GENERAL_CONFIG_FILE_SPECIFIED)
        {
            cfgPath = DTSTest_LimitFilePathStringWidth(
                DTSTest_GeneralInfo->configFilePath,
                pInfoConfigFilePathLabel->Width - DTSTest_StringWidth(cfgPathCaption));
        }
        else
        {
            cfgPath = DTSTEST_STRING_NONE;
        }
        pInfoConfigFilePathLabel->Text = String::Concat(cfgPathCaption, cfgPath);
        delete cfgPath;
        delete cfgPathCaption;
        //--------------------------------------------------------------------
        // The error log file path
        //--------------------------------------------------------------------
        Label ^pInfoErrorLogFilePathLabel = gcnew Label;
        GUI_PositionAndSizeBelow(pInfoErrorLogFilePathLabel, pInfoConfigFilePathLabel, 2);
        String ^errPathCaption = _T("Error Log File Path: ");
        String ^errPath;
        if (DTSTest_GeneralInfo->flags & DTSTEST_GENERAL_ERROR_LOG_SPECIFIED)
        {
            errPath = DTSTest_LimitFilePathStringWidth(
                DTSTest_GeneralInfo->errorLogPath,
                pInfoErrorLogFilePathLabel->Width - DTSTest_StringWidth(errPathCaption));
        }
        else
        {
            errPath = DTSTEST_STRING_NONE;
        }
        pInfoErrorLogFilePathLabel->Text = String::Concat(errPathCaption, errPath);
        delete errPath;
        delete errPathCaption;
        //--------------------------------------------------------------------
        // The event log file path
        //--------------------------------------------------------------------
        Label ^pInfoEventLogFilePathLabel = gcnew Label;
        GUI_PositionAndSizeBelow(pInfoEventLogFilePathLabel, pInfoErrorLogFilePathLabel, 2);
        String ^evtPathCaption = _T("Event Log File Path: ");
        String ^evtPath;
        if (DTSTest_GeneralInfo->flags & DTSTEST_GENERAL_EVENT_LOG_SPECIFIED)
        {
            evtPath = DTSTest_LimitFilePathStringWidth(
                DTSTest_GeneralInfo->eventLogPath,
                pInfoEventLogFilePathLabel->Width - DTSTest_StringWidth(evtPathCaption));
        }
        else
        {
            evtPath = DTSTEST_STRING_NONE;
        }
        pInfoEventLogFilePathLabel->Text =
            String::Concat(evtPathCaption, evtPath);
        delete evtPath;
        delete evtPathCaption;
        //--------------------------------------------------------------------
        // The control script file path
        //--------------------------------------------------------------------
        Label ^pInfoControlScriptFilePathLabel = gcnew Label;
        GUI_PositionAndSizeBelow(pInfoControlScriptFilePathLabel, pInfoEventLogFilePathLabel, 2);
        String ^csPathCaption = _T("Control Script File Path: ");
        String ^csPath = DTSTest_LimitFilePathStringWidth(
            DTSTest_GeneralInfo->mainScript->controlScriptFilePath,
            pInfoControlScriptFilePathLabel->Width - DTSTest_StringWidth(csPathCaption));
        pInfoControlScriptFilePathLabel->Text =
            String::Concat(csPathCaption, csPath);
        delete csPath;
        delete csPathCaption;
        //--------------------------------------------------------------------
        // The results log file path
        //--------------------------------------------------------------------
        Label ^pInfoResultsLogFilePathLabel = gcnew Label;
        GUI_PositionAndSizeBelow(pInfoResultsLogFilePathLabel, pInfoControlScriptFilePathLabel, 2);
        String ^rlPathCaption = _T("Results Log File Path: ");
        String ^rlPath = DTSTest_LimitFilePathStringWidth(
            DTSTest_GeneralInfo->mainScript->resultsLogFilePath,
            pInfoResultsLogFilePathLabel->Width - DTSTest_StringWidth(rlPathCaption));
        pInfoResultsLogFilePathLabel->Text =
            String::Concat(rlPathCaption, rlPath);
        delete rlPath;
        delete rlPathCaption;
        //--------------------------------------------------------------------
        // From email address
        //--------------------------------------------------------------------
        Label ^pInfoEmailFromAddressLabel = gcnew Label;
        pInfoEmailFromAddressLabel->Text = String::Concat(
            "Email From Address: ",
            StringSet(DTSTest_GeneralInfo->emailAddress) ?
                DTSTest_GeneralInfo->emailAddress : DTSTEST_STRING_NONE);
        GUI_PositionBelow(pInfoEmailFromAddressLabel, pInfoResultsLogFilePathLabel, 2);
        pInfoEmailFromAddressLabel->Size = pInfoProgramNameLabel->Size;
        //--------------------------------------------------------------------
        // Email message To address
        //--------------------------------------------------------------------
        Label ^pInfoEmailMessageToAddressLabel = gcnew Label;
        pInfoEmailMessageToAddressLabel->Text = String::Concat(
            "Email To Address: ",
            StringSet(DTSTest_GeneralInfo->emailMessageToAddress) ?
                DTSTest_GeneralInfo->emailMessageToAddress : DTSTEST_STRING_NONE);
        GUI_PositionAndSizeBelow(pInfoEmailMessageToAddressLabel, pInfoEmailFromAddressLabel, 2);
        //--------------------------------------------------------------------
        // Text message To number
        //--------------------------------------------------------------------
        Label ^pInfoTextMessageToNumberLabel = gcnew Label;
        pInfoTextMessageToNumberLabel->Text = String::Concat(
            "Text To Number: ",
            StringSet(DTSTest_GeneralInfo->textMessageToNumber) ?
                DTSTest_GeneralInfo->textMessageToNumber : DTSTEST_STRING_NONE);
        GUI_PositionBelow(pInfoTextMessageToNumberLabel, pInfoEmailMessageToAddressLabel, 2);
        pInfoTextMessageToNumberLabel->Size = pInfoProgramNameLabel->Size;
        //--------------------------------------------------------------------
        // The general flags
        //--------------------------------------------------------------------
        Label ^pInfoGeneralFlagsLabel = gcnew Label;
        pInfoGeneralFlagsLabel->Text = String::Format(
            "Flags: {0:X8}", DTSTest_GeneralInfo->flags);
        GUI_PositionBelow(pInfoGeneralFlagsLabel, pInfoTextMessageToNumberLabel, 2);
        pInfoGeneralFlagsLabel->Size = Drawing::Size(
            130,
            GUI_INFO_LABEL_HEIGHT);
        //--------------------------------------------------------------------
        // The general persistent flags
        //--------------------------------------------------------------------
        Label ^pInfoGeneralPersistentFlagsLabel = gcnew Label;
        pInfoGeneralPersistentFlagsLabel->Text = String::Format(
            "Persist: {0:X8}", DTSTest_GeneralInfo->persistentFlags);
        pInfoGeneralPersistentFlagsLabel->Location = Point(
            pInfoGeneralFlagsLabel->Right,
            pInfoGeneralFlagsLabel->Top);
        pInfoGeneralPersistentFlagsLabel->Size = Drawing::Size(
            120,
            GUI_INFO_LABEL_HEIGHT);
        pInfoGeneralPersistentFlagsLabel->BackColor = Color::Transparent;
        //--------------------------------------------------------------------
        // The general default persistent flags
        //--------------------------------------------------------------------
        Label ^pInfoGeneralDefaultPersistentFlagsLabel = gcnew Label;
        pInfoGeneralDefaultPersistentFlagsLabel->Text = String::Format(
            "Default: {0:X8}", DTSTEST_GENERAL_DEFAULT_PERSISTENT_FLAGS);
        pInfoGeneralDefaultPersistentFlagsLabel->Location = Point(
            pInfoGeneralPersistentFlagsLabel->Right,
            pInfoGeneralFlagsLabel->Top);
        pInfoGeneralDefaultPersistentFlagsLabel->Size = Drawing::Size(
            130,
            GUI_INFO_LABEL_HEIGHT);
        pInfoGeneralDefaultPersistentFlagsLabel->BackColor = Color::Transparent;
        //--------------------------------------------------------------------
        // The last string searched
        //--------------------------------------------------------------------
        Label ^pInfoLastStringSearchedLabel = gcnew Label;
        pInfoLastStringSearchedLabel->Location = Point(
            pInfoProgramNameLabel->Right + 10,
            pInfoProgramNameLabel->Top);
        pInfoLastStringSearchedLabel->Size = Drawing::Size(
            290,
            GUI_INFO_LABEL_HEIGHT);
        String ^searchStringCaption = _T("Most recent search string: ");
        String ^searchString;
        if (StringSet(DTSTest_GeneralInfo->searchString))
        {
            searchString = DTSTest_LimitFilePathStringWidth(
                DTSTest_GeneralInfo->searchString,
                pInfoLastStringSearchedLabel->Width - DTSTest_StringWidth(searchStringCaption));
        }
        else
        {
            searchString = DTSTEST_STRING_NONE;
        }
        pInfoLastStringSearchedLabel->Text = String::Concat(
            searchStringCaption,
            searchString);
        delete searchString;
        delete searchStringCaption;
        pInfoLastStringSearchedLabel->BackColor = Color::Transparent;
        //--------------------------------------------------------------------
        // The Silicon Labs driver version
        //--------------------------------------------------------------------
        DWORD lowerVersion;
        DWORD upperVersion;
        Label ^pInfoDriverVersionLabel = gcnew Label;
        QD_GetUSBDriverVersion(&upperVersion, &lowerVersion);
        pInfoDriverVersionLabel->Text = String::Format(
            "Silicon Labs USB Driver Version: {0:X}.{1:X}.{2:X}.{3:X}",
            ((upperVersion >> 16) & 0xFFFF), (upperVersion & 0xFFFF),
            ((lowerVersion >> 16) & 0xFFFF), (lowerVersion & 0xFFFF));
        GUI_PositionAndSizeBelow(pInfoDriverVersionLabel, pInfoLastStringSearchedLabel, 2);
        //--------------------------------------------------------------------
        // The Silicon Labs DLL version
        //--------------------------------------------------------------------
        Label ^pInfoUSBDLLVersionLabel = gcnew Label;
        QD_GetUSBDLLVersion(&upperVersion, &lowerVersion);
        pInfoUSBDLLVersionLabel->Text = String::Format(
            "Silicon Labs DLL Version: {0:X}.{1:X}.{2:X}.{3:X}",
            ((upperVersion >> 16) & 0xFFFF), (upperVersion & 0xFFFF),
            ((lowerVersion >> 16) & 0xFFFF), (lowerVersion & 0xFFFF));
        GUI_PositionAndSizeBelow(pInfoUSBDLLVersionLabel, pInfoDriverVersionLabel, 2);
        //--------------------------------------------------------------------
        // The qdUSB.dll version
        //--------------------------------------------------------------------
        BYTE buildVersion;
        BYTE majorVersion;
        BYTE minorVersion;
        Label ^pInfoQDDLLVersionLabel = gcnew Label;
        QD_GetQDDLLVersion((LPBYTE) &majorVersion, (LPBYTE) &minorVersion, (LPBYTE) &buildVersion);
        pInfoQDDLLVersionLabel->Text = String::Format(
            "QCOM DLL Version: {0:D}.{1:D}.{2:D}",
            majorVersion, minorVersion, buildVersion);
        GUI_PositionAndSizeBelow(pInfoQDDLLVersionLabel, pInfoUSBDLLVersionLabel, 2);
        //--------------------------------------------------------------------
        // Email message CC address
        //--------------------------------------------------------------------
        Label ^pInfoEmailMessageCCAddressLabel = gcnew Label;
        pInfoEmailMessageCCAddressLabel->Text = String::Concat(
            "Email CC Address: ",
            StringSet(DTSTest_GeneralInfo->emailMessageCCAddress) ?
                DTSTest_GeneralInfo->emailMessageCCAddress : DTSTEST_STRING_NONE);
        pInfoEmailMessageCCAddressLabel->Location = Point(
            pInfoLastStringSearchedLabel->Left,
            pInfoEmailMessageToAddressLabel->Top);
        pInfoEmailMessageCCAddressLabel->Size = pInfoLastStringSearchedLabel->Size;
        pInfoEmailMessageCCAddressLabel->BackColor = Color::Transparent;
        //--------------------------------------------------------------------
        // Text message CC number
        //--------------------------------------------------------------------
        Label ^pInfoTextMessageCCNumberLabel = gcnew Label;
        pInfoTextMessageCCNumberLabel->Text = String::Concat(
            "Text CC Number: ",
            StringSet(DTSTest_GeneralInfo->textMessageCCNumber) ?
                DTSTest_GeneralInfo->textMessageCCNumber : DTSTEST_STRING_NONE);
        pInfoTextMessageCCNumberLabel->Location = Point(
            pInfoEmailMessageCCAddressLabel->Left,
            pInfoTextMessageToNumberLabel->Top);
        pInfoTextMessageCCNumberLabel->Size = pInfoLastStringSearchedLabel->Size;
        pInfoTextMessageCCNumberLabel->BackColor = Color::Transparent;
        //--------------------------------------------------------------------
        // The Windows version
        //--------------------------------------------------------------------
        Label ^pInfoWindowsVersionLabel = gcnew Label;
        pInfoWindowsVersionLabel->Text = String::Concat(
            "OS : ", DTSTest_GeneralInfo->windowsVersion);
        pInfoWindowsVersionLabel->Location = Point(
            pInfoGeneralUsePathLabel->Right + 10,
            pInfoProgramNameLabel->Top);
        pInfoWindowsVersionLabel->Size = Drawing::Size(220, GUI_INFO_LABEL_HEIGHT);
        pInfoWindowsVersionLabel->BackColor = Color::Transparent;
        //--------------------------------------------------------------------
        // Memory information
        //--------------------------------------------------------------------
        Label ^pInfoClientMemoryLabel = gcnew Label;
        MEMORYSTATUSEX memory;
        memory.dwLength = sizeof(MEMORYSTATUSEX);
        GlobalMemoryStatusEx(&memory);
        pInfoClientMemoryLabel->Text = String::Format(
            "Avail Memory : {0:D} MB / {1:D} MB",
                (memory.ullAvailPhys / 1000000),
                (memory.ullTotalPhys / 1000000));
        GUI_PositionAndSizeBelow(pInfoClientMemoryLabel, pInfoWindowsVersionLabel, 2);
        //--------------------------------------------------------------------
        // Disk space information
        //--------------------------------------------------------------------
        Label ^pInfoDiskSpaceLabel = gcnew Label;
        DriveInfo ^driveInfo = gcnew DriveInfo(Environment::CurrentDirectory);
        pInfoDiskSpaceLabel->Text = String::Format(
            "Avail Storage : {0:D} MB / {1:D} MB",
                (driveInfo->AvailableFreeSpace / 1000000),
                (driveInfo->TotalSize / 1000000));
        GUI_PositionAndSizeBelow(pInfoDiskSpaceLabel, pInfoClientMemoryLabel, 2);
        delete driveInfo;
        //--------------------------------------------------------------------
        // Port Name
        //--------------------------------------------------------------------
        Label ^pInfoPortNameLabel = gcnew Label;
        pInfoPortNameLabel->Text = String::Concat(
            "Host Serial Port : ",
            StringSet(pgInfo->portName) ? pgInfo->portName : _T("Unknown"));
        GUI_PositionAndSizeBelow(pInfoPortNameLabel, pInfoDiskSpaceLabel,
            pInfoDiskSpaceLabel->Height + 4);
        //--------------------------------------------------------------------
        // DTS Baud Rate
        //--------------------------------------------------------------------
        Label ^pInfoDTSBaudRateLabel = gcnew Label;
        pInfoDTSBaudRateLabel->Text = String::Concat(
            _T("DTS Baud Rate : "),
            DTSTest_BaudRateSetTo2400 ? _T("2400") : _T("1200"));
        GUI_PositionAndSizeBelow(pInfoDTSBaudRateLabel, pInfoPortNameLabel, 2);
        //--------------------------------------------------------------------
        // The message flag states in a single bitmapped flag
        //--------------------------------------------------------------------
        Label ^pInfoMessageFlagsLabel = gcnew Label;
        if (DTSTest_BasicMessagesEnabled)
            messageFlags |= GUI_MODAL_BASIC;
        if (DTSTest_ErrorMessagesEnabled)
            messageFlags |= GUI_MODAL_ERROR;
        if (DTSTest_VerboseMessagesEnabled)
            messageFlags |= GUI_MODAL_VERBOSE;
        if (DTSTest_DetailedMessagesEnabled)
            messageFlags |= GUI_MODAL_DETAILED;
        if (DTSTest_ExpMessagesEnabled)
            messageFlags |= GUI_MODAL_EXP;
        if (DTSTest_StackTracesEnabled)
            messageFlags |= GUI_MODAL_STACK;
        if (DTSTest_SendTextErrorMessagesEnabled)
            messageFlags |= GUI_MODAL_TEXT;
        if (DTSTest_SendEmailErrorMessagesEnabled)
            messageFlags |= GUI_MODAL_EMAIL;
        if (DTSTest_EventLogBasicEnabled)
            messageFlags |= GUI_ELOG_BASIC;
        if (DTSTest_EventLogVerboseEnabled)
            messageFlags |= GUI_ELOG_VERBOSE;
        if (DTSTest_EventLogDetailedEnabled)
            messageFlags |= GUI_ELOG_DETAILED;
        if (DTSTest_ExperimentsEnabled)
            messageFlags |= GUI_EXPERIMENTS_BASIC;
        pInfoMessageFlagsLabel->Text = String::Format(
            "Message Flags: {0:X8}", messageFlags);
        pInfoMessageFlagsLabel->Location = Point(
            pInfoGeneralDefaultPersistentFlagsLabel->Right,
            pInfoGeneralDefaultPersistentFlagsLabel->Top);
        pInfoMessageFlagsLabel->Size = Drawing::Size(170, GUI_INFO_LABEL_HEIGHT);
        pInfoMessageFlagsLabel->BackColor = Color::Transparent;
        //--------------------------------------------------------------------
        // Set the dimensions of the general group box
        //--------------------------------------------------------------------
        pInfoGeneralGroupBox->Size = Drawing::Size(
            GUI_PROGRAM_INFO_GROUP_BOX_WIDTH,
            pInfoGeneralDefaultPersistentFlagsLabel->Bottom + 10);
        previousBottomLine = pInfoGeneralGroupBox->Bottom;
        pInfoWindow->Size = Drawing::Size(
            pInfoGeneralGroupBox->Width + 30,
            previousBottomLine + 90);
        //--------------------------------------------------------------------
        // Add the components to the general Program Info group box
        //--------------------------------------------------------------------
        array <Label ^> ^pInfoLabels =
        {
            pInfoProgramNameLabel,              pInfoLastStringSearchedLabel,       pInfoWindowsVersionLabel,
            pInfoProgramVersionAndBuildLabel,   pInfoDriverVersionLabel,            pInfoClientMemoryLabel,
            pInfoThisMomentLabel,               pInfoUSBDLLVersionLabel,            pInfoDiskSpaceLabel,
            pInfoProgramAuthorLabel,            pInfoQDDLLVersionLabel,
            pInfoStartupPathLabel,                                                  pInfoPortNameLabel,
            pInfoCommandLineParametersLabel,                                        //pInfoGauge2DPresentLabel,
            pInfoGeneralUsePathLabel,                                               //pInfoGauge3EPresentLabel,
            pInfoConfigFilePathLabel,                                               //pInfoBargeB4PresentLabel,
            pInfoErrorLogFilePathLabel,                                             //pInfoBargeC9PresentLabel,
            pInfoEventLogFilePathLabel,                                             //pInfoBargeE2PresentLabel,
            pInfoControlScriptFilePathLabel,                                        //pInfoBarge02PresentLabel,
            pInfoResultsLogFilePathLabel,                                           pInfoDTSBaudRateLabel,
            pInfoEmailFromAddressLabel,
            pInfoEmailMessageToAddressLabel,    pInfoEmailMessageCCAddressLabel,
            pInfoTextMessageToNumberLabel,      pInfoTextMessageCCNumberLabel,
            pInfoGeneralFlagsLabel,             pInfoGeneralPersistentFlagsLabel,   pInfoGeneralDefaultPersistentFlagsLabel,     pInfoMessageFlagsLabel
        };
        pInfoGeneralGroupBox->Controls->AddRange(pInfoLabels);
        //--------------------------------------------------------------------
        // Add a Close button
        //--------------------------------------------------------------------
        Button ^closeButton = gcnew Button;
        closeButton->Text = _T("Close");
        closeButton->Location = Point(
            pInfoWindow->Right - 100,
            pInfoWindow->Bottom - 70);
        closeButton->Size = Drawing::Size(
            GUI_CLOSE_BUTTON_WIDTH,
            GUI_REGULAR_BUTTON_HEIGHT);
        GUI_SetButtonInterfaceProperties(closeButton);
        closeButton->DialogResult = System::Windows::Forms::DialogResult::OK;
        closeButton->Click +=
            gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_ProgramInfoCloseWindow);
        pInfoWindow->Controls->Add(closeButton);
        //--------------------------------------------------------------------
        // Set the remaining window properties
        //--------------------------------------------------------------------
        pInfoWindow->AcceptButton = closeButton;
        pInfoWindow->CancelButton = closeButton;
        //--------------------------------------------------------------------
        // Finally, display the new window
        //--------------------------------------------------------------------
        pInfoWindow->ShowDialog();
        pInfoWindow->ResumeLayout();
    }                                   // end of if (DTSTest_GeneralInfo)
    RecordBasicEvent("{0} concluded", functionName);
}                                       // end of DTSTest_ProgramInfoDisplayWindow()
//----------------------------------------------------------------------------
#endif      // ADVANCED_CPP
//============================================================================
// End of Advanced.cpp
//============================================================================
