//============================================================================
// mtRecord.h
//
// Header for mtRecord.cpp, which defines functions that front-end TI calls
//
// Copyright (C) 2016 - 2016 Quartzdyne, Inc.  All rights reserved.
//
// No part of this source code may be reproduced or transmitted in any form or
// by any means, electronic or mechanical, including photocopying, recording,
// or any information storage and retrieval system, without express written
// permission from Quartzdyne, Inc.  Further, no use of this source code is
// permitted in any form or means without a valid, written license agreement
// with Quartzdyne, Inc.  While every reasonable precaution has been taken in
// the preparation of this source code, Quartzdyne, Inc., assumes no
// responsibility for errors, omissions, or damages from the use of the source
// code contained herein.
//
// NEITHER QUARTZDYNE, INC., ANY MEMBER OF QUARTZDYNE, INC., NOR ANY PERSON OR
// ORGANIZATION ACTING ON BEHALF OF THEM MAKES ANY WARRANTY OR REPRESENTATION
// WHATSOEVER, EXPRESS OR IMPLIED, INCLUDING ANY WARRANTY OF MERCHANTABILITY
// OR FITNESS FOR ANY PURPOSE WITH RESPECT TO THE SOURCE CODE OR ASSUMES ANY
// LIABILITY WHATSOEVER WITH RESPECT TO ANY USE OF THE SOURCE CODE OR ANY
// PORTION THEREOF OR WITH RESPECT TO ANY DAMAGES THAT MAY RESULT FROM SUCH
// USE.
//
// Noji Ratzlaff
//
// See mtRecord.log for a complete history of all updates, changes, and revisions
// of this source and other files and policies regarding the mtRecord interface
//
// Updated 03-21-2016
//============================================================================
#pragma once
#ifndef     MTRECORD_H     // provided for legacy compilers, but unnecessary for
#define     MTRECORD_H     // recent compilers, due to the preceding pragma
//----------------------------------------------------------------------------
// Include appropriate headers
//----------------------------------------------------------------------------
#include    <windows.h>
//----------------------------------------------------------------------------
// Type definitions
//----------------------------------------------------------------------------
typedef
    struct _CoefficientDataFormat
        CoefficientFormatDef;
//----------------------------------------------------------------------------
// C declaration space
//----------------------------------------------------------------------------
#ifdef      __cplusplus
extern "C"
{
#endif
//----------------------------------------------------------------------------
// Substitutions
//----------------------------------------------------------------------------
#define     DLLImport                   __declspec(dllimport)
//----------------------------------------------------------------------------
// Low-level function prototypes (DLL only)
//----------------------------------------------------------------------------
//DLLImport DWORD TI_Close(
//                    HANDLE          toolHandle);
//DLLImport DWORD TI_GetNumberOfUnits(
//                    DWORD           *numberOfUnits);
//DLLImport DWORD TI_Open(
//                    DWORD           unitNumber,
//                    HANDLE          *toolHandle);
//----------------------------------------------------------------------------
// Prototypes of MT USB DLL functions
//----------------------------------------------------------------------------
DLLImport DWORD MT_CalculatePressureAndTemperature(                 // 3.27
                    LPBYTE          coefficientData,
                    DWORD           pressureCount,
                    DWORD           temperatureCount,
                    DOUBLE          *pressurePSI,
                    DOUBLE          *temperatureCelsius);
DLLImport DWORD MT_CalculatePressureOrTemperature(                  // 3.8
                    BYTE            PorT,
                    LPBYTE          coefficientData,
                    DWORD           pressureCount,
                    DWORD           temperatureCount,
                    DOUBLE          *result);
DLLImport WORD  MT_CalculateWordCRC(
                    LPBYTE          dataBuffer,
                    DWORD           dataLength);
DLLImport DWORD MT_Close(                                           // 3.3
                    HANDLE          toolHandle);
DLLImport bool  MT_CoefficientDataIsValid(                          // 3.28
                    LPBYTE          coefficientData);
DLLImport bool  MT_CoefficientHexFileDataIsValid(                   // 3.29
                    LPBYTE          hexFileData);
DLLImport bool  MT_DataIsInHexFileFormat(                           // 3.30
                    LPBYTE          hexFileData);
DLLImport DWORD MT_GetFirmwareInformation(                          // 3.31
                    HANDLE          toolHandle,
                    LPBYTE          majorVersion,
                    LPBYTE          minorVersion,
                    LPBYTE          firmwareID);
DLLImport DWORD MT_GetHardwareInformation(                          // 3.32
                    HANDLE          toolHandle,
                    LPBYTE          hardwareType);
DLLImport DWORD MT_GetNumberOfTools(void);                          // 3.1
DLLImport DWORD MT_GetPressureAndTemperature(                       // 3.9
                    HANDLE          toolHandle,
                    LPBYTE          coefficientData,
                    DOUBLE          *pressurePSI,
                    DOUBLE          *temperatureCelsius);
DLLImport DWORD MT_GetPressureCount(                                // 3.14
                    HANDLE          toolHandle,
                    LPDWORD         pressureCount);
DLLImport DWORD MT_GetQDDLLVersion(                                 // 3.41
                    LPBYTE          majorVersion,
                    LPBYTE          minorVersion,
                    LPBYTE          buildVersion);
DLLImport DWORD MT_GetTemperatureCount(                             // 3.15
                    HANDLE          toolHandle,
                    LPDWORD         temperatureCount);
DLLImport DWORD MT_GetTransducerCounts(                             // 3.52
                    HANDLE          toolHandle,
                    LPDWORD         pressureCount,
                    LPDWORD         temperatureCount);
DLLImport bool  MT_HexFileFormatIsValid(                            // 3.33
                    LPBYTE          hexFileData);
DLLImport DWORD MT_Open(                                            // 3.3
                    DWORD           unitNumber,
                    HANDLE          *toolHandle);
DLLImport DWORD MT_Read(                                            // 3.34
                    HANDLE          toolHandle,
                    LPBYTE          readBuffer,
                    DWORD           numberOfBytesToRead,
                    LPDWORD         bytesRead);
DLLImport DWORD MT_ReadCoefficientDataFromHexFile(                  // A1 3.12
                    LPBYTE          pathName,
                    LPBYTE          coefficientData);
DLLImport DWORD MT_SetFirmwareMode(                                 // 3.22
                    HANDLE          toolHandle,
                    BYTE            mode);
DLLImport DWORD MT_UnFormatHexFileData(                             // Undocumented
                    LPBYTE          formattedData,
                    LPBYTE          unformattedData);
DLLImport DWORD MT_WaitForReply(                                    // 3.37
                    HANDLE          toolHandle,
                    DWORD           bytesExpected);
DLLImport DWORD MT_Write(                                           // 3.38
                    HANDLE          toolHandle,
                    LPBYTE          writeBuffer,
                    DWORD           numberOfBytesToWrite,
                    LPDWORD         bytesWritten);
//----------------------------------------------------------------------------
// Partially written
//----------------------------------------------------------------------------
DLLImport DWORD MT_GetFlashMemoryStartingAddress(                   // Undocumented
                    HANDLE          toolHandle,
                    LPDWORD         startingAddress);
DLLImport DWORD MT_GetToolSerialNumber(                             // Undocumented
                    DWORD           unitNumber,
                    LPBYTE          serialNumber);
DLLImport DWORD MT_GetRecorderStatus(                               // 3.19
                    HANDLE          toolHandle,
                    LPBYTE          statusValue);
DLLImport DWORD MT_ReadBlockFromFlashMemory(                        // 3.36
                    HANDLE          toolHandle,
                    LPBYTE          flashMemoryBuffer);
DLLImport DWORD MT_ReadFromFlashMemory(                             // 3.35
                    HANDLE          toolHandle,
                    DWORD           flashMemoryAddress,
                    DWORD           numberOfBytes,
                    LPBYTE          flashMemoryBuffer);
DLLImport DWORD MT_SetFlashMemoryStartingAddress(                   // Undocumented
                    HANDLE          toolHandle,
                    DWORD           startingAddress);
DLLImport DWORD MT_SetHardwareInformation(                          // Undocumented
                    HANDLE          toolHandle,
                    DWORD           hardwareType);
DLLImport DWORD MT_WriteLineToFlashMemory(                          // 3.40
                    HANDLE          toolHandle,
                    LPBYTE          flashMemoryBuffer);
DLLImport DWORD MT_WriteToFlashMemory(                              // 3.39
                    HANDLE          toolHandle,
                    DWORD           flashMemoryAddress,
                    DWORD           numberOfBytes,
                    LPBYTE          flashMemoryBuffer);
//----------------------------------------------------------------------------
// Obsolete
//----------------------------------------------------------------------------
DLLImport DWORD MT_ReadCoefficientDataFromDevice(                   // B1 3.49
                    HANDLE          toolHandle,
                    LPBYTE          coefficientData);
DLLImport DWORD MT_ReadCoefficientDataFromModulePage(               // B4 3.50
                    HANDLE          toolHandle,
                    BYTE            pageNumber,
                    LPBYTE          coefficientData);
DLLImport DWORD MT_ReadCoefficientDataFromSourcePage(               // B1 3.13
                    HANDLE          toolHandle,
                    BYTE            targetDevice,
                    BYTE            pageNumber,
                    LPBYTE          coefficientData);
DLLImport DWORD MT_WriteCoefficientDataToDevice(                    // B1 3.57
                    HANDLE          toolHandle,
                    LPBYTE          coefficientData);
DLLImport DWORD MT_WriteCoefficientDataToModulePage(                // B4 3.59
                    HANDLE          toolHandle,
                    BYTE            pageNumber,
                    LPBYTE          coefficientData);
DLLImport DWORD MT_WriteCoefficientDataToTargetPage(                // B1 3.14
                    HANDLE          toolHandle,
                    BYTE            targetDevice,
                    BYTE            pageNumber,
                    LPBYTE          coefficientData);
//----------------------------------------------------------------------------
// Prototypes of experimental QD USB DLL functions
//----------------------------------------------------------------------------
//----------------------------------------------------------------------------
// Prototypes of deprecated QD USB DLL functions (included for backward-compatibility)
//----------------------------------------------------------------------------
//----------------------------------------------------------------------------
// DLL variables
//----------------------------------------------------------------------------
DLLImport DWORD MT_DLLStatus;
DLLImport bool  MT_DLLErrorEncountered;
DLLImport bool  MT_DLLMessagesEnabled;
#ifdef      __cplusplus
}
#endif
//----------------------------------------------------------------------------
// Predetermined definitions
//----------------------------------------------------------------------------
//#define     MT_STATUS_SUCCESS                                   0x00
//#define     MT_STATUS_INITIALIZE                                0x01
//#define     MT_MODE_SWITCH_PRESSED                              0x00
//#define     MT_MODE_SWITCH_NOT_PRESSED                          0x01
//#define     MT_DISABLE_TRANSDUCER_POWER                         0x00
//#define     MT_ENABLE_TRANSDUCER_POWER                          0x01
//#define     MT_READ_ADC_CHANNEL_CURRENT                         0x03
//#define     MT_READ_ADC_CHANNEL_VOLTAGE                         0x04
//#define     MT_DEVICE_TRANSDUCER                                0
//#define     MT_DEVICE_MODULE                                    1
//#define     MT_TRANSDUCER_TYPE_ABSENT                           0
//#define     MT_TRANSDUCER_TYPE_FREQUENCY                        1
//#define     MT_TRANSDUCER_TYPE_DIGITAL_NOMEM                    5
//#define     MT_TRANSDUCER_CHIP_ID_LENGTH                        4
//#define     MT_TRANSDUCER_CHIP_SMT_FPGA                         2
//#define     MT_TRANSDUCER_CHIP_HYBRID_FPGA                      5
//#define     MT_TRANSDUCER_CHIP_ASIC                             9
//#define     MT_BYTES_PER_QMEM_PAGE                              256
//#define     MT_NUMBER_OF_LOWER_QMEM_PAGES                       4
//#define     MT_MAXIMUM_NUMBER_OF_QMEM_PAGES                     64
#define     MT_COEFFICIENT_DATA_SIZE                            256
#define     MT_QUARTZDYNE_ID                                    0x0D
#define     MT_QUARTZDYNE_CF_TYPE_BIG_ENDIAN                    0x010D
#define     MT_QUARTZDYNE_CF_TYPE_LITTLE_ENDIAN                 0x040D
#define     MT_QUARTZDYNE_CF_VERSION_123                        0x2301
#define     MT_QUARTZDYNE_CF_VERSION_100                        0x0001
#define     MT_MAXIMUM_TRANSFER_SIZE                            768
#define     MT_FLASH_MEMORY_READ_BLOCK_LENGTH                   256
#define     MT_FLASH_MEMORY_WRITE_LINE_LENGTH                   32
////----------------------------------------------------------------------------
//// Product string entities
////----------------------------------------------------------------------------
//#define     MT_MAXIMUM_PRODUCT_STRING_SIZE                      256
//#define     MT_MAXIMUM_SERIAL_NUMBER_SIZE                       MT_MAXIMUM_PRODUCT_STRING_SIZE
//#define     MT_RETURN_SERIAL_NUMBER                             0
//#define     MT_RETURN_DESCRIPTION                               1
//#define     MT_RETURN_COMPANY                                   2
//#define     MT_RETURN_VID                                       3
//#define     MT_RETURN_PID                                       4
//#define     MT_RETURN_AUTHOR                                    5
////----------------------------------------------------------------------------
//// Receive Queue status
////----------------------------------------------------------------------------
//#define     MT_QUEUE_NO_OVERRUN                                 0x00
//#define     MT_QUEUE_EMPTY                                      0x00
//#define     MT_QUEUE_OVERRUN                                    0x01
//#define     MT_QUEUE_READY                                      0x02
//----------------------------------------------------------------------------
// Hardware limits
//----------------------------------------------------------------------------
#define     MT_MINIMUM_I2C_DATA_RATE                            33.3
#define     MT_MAXIMUM_I2C_DATA_RATE                            100.0
#define     MT_MINIMUM_CADENCE_TIMER_MS                         250
#define     MT_MAXIMUM_CADENCE_TIMER_MS                         2000
#define     MT_MAXIMUM_NUMBER_OF_COEFFICIENTS                   25
//----------------------------------------------------------------------------
// Custom definitions
//----------------------------------------------------------------------------
#define     MT_CALCULATE_PRESSURE_PSI                           0
#define     MT_CALCULATE_TEMPERATURE_CELSIUS                    1
#define     MT_DEFAULT_COEFFICIENT_PAGE_NUMBER                  0
#define     MT_GET_BOTH_COUNTS                                  0x00
#define     MT_GET_PRESSURE_COUNTS                              0x01
#define     MT_GET_TEMPERATURE_COUNTS                           0x02
#define     MT_COMMAND_BUFFER_SIZE                              16
#define     MT_COEFFICIENT_DATA_HEX_FILE_SIZE                   733
#define     MT_MAXIMUM_FORMATTED_HEX_DATA_LINE_SIZE             530
#define     MT_CHECK_RECEIVE_QUEUE_TIMEOUT                      500
#define     MT_MAXIMUM_MODAL_STRING_SIZE                        256
#define     MT_MAXIMUM_ERROR_STRING_SIZE                        MT_MAXIMUM_MODAL_STRING_SIZE
//----------------------------------------------------------------------------
// Hardware types
//----------------------------------------------------------------------------
#define     MT_HARDWARE_TYPE_PIEZO                              0x00
#define     MT_HARDWARE_TYPE_QUARTZ                             0x01
//----------------------------------------------------------------------------
// Firmware-related definitions
//----------------------------------------------------------------------------
#define     MT_SET_APPLICATION_MODE                             0x00
#define     MT_SET_BOOT_LOADER_MODE                             0x01
#define     MT_FIRMWARE_QUARTZDYNE_ID                           0x21
//----------------------------------------------------------------------------
// Unit status register (mask) definitions
//----------------------------------------------------------------------------
#define     MT_SREG_TRANSDUCER_TYPE_MASK                        0x07
#define     MT_SREG_TRANSDUCER_PRESENT                          0x08
#define     MT_SREG_TRANSDUCER_OVER_CURRENT                     0x10
#define     MT_SREG_TRANSDUCER_POWER_STATE                      0x20
#define     MT_SREG_HIGH_SIDE_SWITCH_PRESENCE                   0x40
#define     MT_SREG_ERROR_PRESENCE                              0x80
//----------------------------------------------------------------------------
// Status and error definitions (values 0x00000001 through 0x0000000F line up
// with those in SiUSBXp.h)
//
// The lower word 0x0000FFFF is used for error codes
//
// The third byte* 0x00FF0000 is used for loci within a function
//
// The fourth byte 0xFF000000 is the function number
//
//      Function numbers 0x01000000 through 0x0F000000 inclusive are reserved
//      for general or global DLL elements (16 maximum)
//
//      Function numbers 0x10000000 through 0x5F000000 inclusive are reserved
//      for regular DLL functions (80 maximum)
//
//      Function numbers 0xD0000000 through 0xFF000000 inclusive are reserved
//      for deprecated DLL functions (48 maximum)
//----------------------------------------------------------------------------
#define     MT_SUCCESS                                          0x00000000
#define     MT_FAILURE                                          -1
#define     MT_ERROR_NO_ERROR                                   MT_SUCCESS
#define     MT_ERROR_INVALID_HANDLE                             0x00000001
#define     MT_ERROR_READ_ERROR                                 0x00000002
#define     MT_ERROR_RECEIVE_QUEUE_NOT_READY                    0x00000003
#define     MT_ERROR_WRITE_ERROR                                0x00000004
#define     MT_ERROR_RESET_ERROR                                0x00000005
#define     MT_ERROR_INVALID_PARAMETER                          0x00000006
#define     MT_ERROR_INVALID_REQUEST_LENGTH                     0x00000007
#define     MT_ERROR_DEVICE_IO_FAILED                           0x00000008
#define     MT_ERROR_INVALID_DATA_RATE                          0x00000009
#define     MT_ERROR_FUNCTION_NOT_SUPPORTED                     0x0000000A
#define     MT_ERROR_GLOBAL_DATA_ERROR                          0x0000000B
#define     MT_ERROR_SYSTEM_ERROR                               0x0000000C
#define     MT_ERROR_READ_TIMED_OUT                             0x0000000D
#define     MT_ERROR_WRITE_TIMED_OUT                            0x0000000E
#define     MT_ERROR_IO_PENDING                                 0x0000000F
#define     MT_ERROR_CHECKSUM_ERROR                             0x00000010
#define     MT_ERROR_XD_PRESSURE_COUNT_ZERO                     0x00000011
#define     MT_ERROR_XD_TEMPERATURE_COUNT_ZERO                  0x00000012
#define     MT_ERROR_XD_BOTH_COUNTS_ZERO                        0x00000013
#define     MT_ERROR_MEMORY_ALLOCATION_FAILED                   0x00000014
#define     MT_ERROR_FILE_OPEN_FAILURE                          0x00000015
#define     MT_ERROR_ADC_COUNT_ZERO                             0x00000016
#define     MT_ERROR_FILE_SIZE_MISMATCH                         0x00000017
#define     MT_ERROR_INVALID_HEX_FILE_DATA                      0x00000018
#define     MT_ERROR_INCORRECT_DATA_SIZE                        0x00000019
#define     MT_ERROR_INVALID_FIRMWARE_PAGE                      0x0000001A
#define     MT_ERROR_UNIT_NOT_READY                             0x0000001B
#define     MT_ERROR_CADENCE_TIMER_ZERO                         0x0000001C
#define     MT_ERROR_DATA_RATE_ZERO                             0x0000001D
#define     MT_ERROR_INVALID_I2C_REPLY                          0x0000001E
#define     MT_ERROR_FIRMWARE_ID_ZERO                           0x0000001F
#define     MT_ERROR_DATA_TRANSFER_FAILURE                      0x00000020
#define     MT_ERROR_DEVICE_TIMED_OUT                           0x00000021
#define     MT_ERROR_RECEIVE_QUEUE_OVERRUN                      0x00000022
#define     MT_ERROR_FIRMWARE_SIGNATURE_NOT_ERASED              0x00000023
#define     MT_ERROR_XD_VOLTAGE_TOO_HIGH                        0x00000024
#define     MT_ERROR_XD_VOLTAGE_TOO_LOW                         0x00000025
#define     MT_ERROR_XD_CURRENT_TOO_HIGH                        0x00000026
#define     MT_ERROR_XD_CURRENT_TOO_LOW                         0x00000027
#define     MT_ERROR_WRITE_ACKNOWLEDGE_FAILED                   0x00000028
#define     MT_ERROR_UNREACHABLE_CONDITION                      0x00000029
#define     MT_ERROR_NULL_POINTER_PARAMETER                     0x0000002A
#define     MT_ERROR_ZERO_LENGTH_STRING_PARAMETER               0x0000002B
#define     MT_ERROR_INVALID_COEFFICIENT_DATA                   0x00000040
#define     MT_ERROR_FILE_NOT_FOUND                             0x00000070
#define     MT_ERROR_INVALID_FILE_NAME                          0x00000071
#define     MT_ERROR_INVALID_FILE_FOUND                         0x00000072
#define     MT_ERROR_NO_DEVICE_FOUND                            0x000000FF
//----------------------------------------------------------------------------
// Error code and locus masks
//----------------------------------------------------------------------------
#define     MT_ERROR_CODE_MASK                                  0x0000FFFF
#define     MT_ERROR_CODE_AND_LOCUS_MASK                        0x00FFFFFF
#define     MT_ERROR_CODE_LOCUS_MASK                            0x00FF0000
#define     MT_ERROR_CODE_FUNCTION_MASK                         0xFF000000
//----------------------------------------------------------------------------
// Status and error detection points (where they are first encountered)
//----------------------------------------------------------------------------
#define     MT_LOCUS_NOT_APPLICABLE                             0x00000000
#define     MT_LOCUS_GENERAL_DLL                                0x01000000
#define     MT_LOCUS_CALCULATE_P_AND_T                          0x10000000
#define     MT_LOCUS_CALCULATE_P_OR_T                           0x11000000
#define         MT_LOCUS_CALCULATE_P_OR_T_1                         0x11010000
#define         MT_LOCUS_CALCULATE_P_OR_T_2                         0x11020000
#define         MT_LOCUS_CALCULATE_P_OR_T_3                         0x11030000
#define         MT_LOCUS_CALCULATE_P_OR_T_4                         0x11040000
#define         MT_LOCUS_CALCULATE_P_OR_T_5                         0x11050000
#define     MT_LOCUS_CLOSE                                      0x14000000
#define         MT_LOCUS_CLOSE_1                                    0x14010000
#define     MT_LOCUS_READ_BLOCK_FROM_FLASH_MEMORY               0x1D000000
#define         MT_LOCUS_READ_BLOCK_FROM_FLASH_MEMORY_1             0x1D010000
#define         MT_LOCUS_READ_BLOCK_FROM_FLASH_MEMORY_2             0x1D012000
#define         MT_LOCUS_READ_BLOCK_FROM_FLASH_MEMORY_3             0x1D013000
#define         MT_LOCUS_READ_BLOCK_FROM_FLASH_MEMORY_4             0x1D014000
#define         MT_LOCUS_READ_BLOCK_FROM_FLASH_MEMORY_5             0x1D015000
#define         MT_LOCUS_READ_BLOCK_FROM_FLASH_MEMORY_6             0x1D016000
#define     MT_LOCUS_GET_NUMBER_OF_TOOLS                        0x1E000000
#define     MT_LOCUS_GET_PRESSURE_AND_TEMPERATURE               0x1F000000
#define     MT_LOCUS_GET_TRANSDUCER_COUNTS                      0x22000000
#define         MT_LOCUS_GET_TRANSDUCER_COUNTS_1                    0x22010000
#define         MT_LOCUS_GET_TRANSDUCER_COUNTS_2                    0x22020000
#define         MT_LOCUS_GET_TRANSDUCER_COUNTS_3                    0x22030000
#define         MT_LOCUS_GET_TRANSDUCER_COUNTS_4                    0x22040000
#define         MT_LOCUS_GET_TRANSDUCER_COUNTS_5                    0x22050000
#define         MT_LOCUS_GET_TRANSDUCER_COUNTS_6                    0x22060000
#define         MT_LOCUS_GET_TRANSDUCER_COUNTS_7                    0x22070000
#define         MT_LOCUS_GET_TRANSDUCER_COUNTS_8                    0x22080000
#define         MT_LOCUS_GET_TRANSDUCER_COUNTS_9                    0x22090000
#define     MT_LOCUS_GET_PRESSURE_COUNT                         0x23000000
#define         MT_LOCUS_GET_PRESSURE_COUNT_1                       0x23010000
#define         MT_LOCUS_GET_PRESSURE_COUNT_2                       0x23020000
#define         MT_LOCUS_GET_PRESSURE_COUNT_3                       0x23030000
#define         MT_LOCUS_GET_PRESSURE_COUNT_4                       0x23040000
#define         MT_LOCUS_GET_PRESSURE_COUNT_5                       0x23050000
#define         MT_LOCUS_GET_PRESSURE_COUNT_6                       0x23060000
#define         MT_LOCUS_GET_PRESSURE_COUNT_7                       0x23070000
#define     MT_LOCUS_GET_TEMPERATURE_COUNT                      0x25000000
#define         MT_LOCUS_GET_TEMPERATURE_COUNT_1                    0x25010000
#define         MT_LOCUS_GET_TEMPERATURE_COUNT_2                    0x25020000
#define         MT_LOCUS_GET_TEMPERATURE_COUNT_3                    0x25030000
#define         MT_LOCUS_GET_TEMPERATURE_COUNT_4                    0x25040000
#define         MT_LOCUS_GET_TEMPERATURE_COUNT_5                    0x25050000
#define         MT_LOCUS_GET_TEMPERATURE_COUNT_6                    0x25060000
#define         MT_LOCUS_GET_TEMPERATURE_COUNT_7                    0x25070000
#define     MT_LOCUS_GET_TOOL_SERIAL_NUMBER                     0x29000000
#define     MT_LOCUS_GET_RECORDER_STATUS                        0x2A000000
#define         MT_LOCUS_GET_RECORDER_STATUS_1                      0x2A010000
#define         MT_LOCUS_GET_RECORDER_STATUS_2                      0x2A020000
#define         MT_LOCUS_GET_RECORDER_STATUS_3                      0x2A030000
#define         MT_LOCUS_GET_RECORDER_STATUS_4                      0x2A040000
#define         MT_LOCUS_GET_RECORDER_STATUS_5                      0x2A050000
#define     MT_LOCUS_GET_TOOL_FIRMWARE_ID                       0x2B000000
#define         MT_LOCUS_GET_TOOL_FIRMWARE_ID_1                     0x2B010000
#define         MT_LOCUS_GET_TOOL_FIRMWARE_ID_2                     0x2B020000
#define         MT_LOCUS_GET_TOOL_FIRMWARE_ID_3                     0x2B030000
#define         MT_LOCUS_GET_TOOL_FIRMWARE_ID_4                     0x2B040000
#define         MT_LOCUS_GET_TOOL_FIRMWARE_ID_5                     0x2B050000
#define         MT_LOCUS_GET_TOOL_FIRMWARE_ID_6                     0x2B060000
#define         MT_LOCUS_GET_TOOL_FIRMWARE_ID_7                     0x2B070000
#define         MT_LOCUS_GET_TOOL_FIRMWARE_ID_8                     0x2B080000
#define     MT_LOCUS_GET_TOOL_HARDWARE_ID                       0x2C000000
#define         MT_LOCUS_GET_TOOL_HARDWARE_ID_1                     0x2C010000
#define         MT_LOCUS_GET_TOOL_HARDWARE_ID_2                     0x2C020000
#define         MT_LOCUS_GET_TOOL_HARDWARE_ID_3                     0x2C030000
#define         MT_LOCUS_GET_TOOL_HARDWARE_ID_4                     0x2C040000
#define         MT_LOCUS_GET_TOOL_HARDWARE_ID_5                     0x2C050000
#define         MT_LOCUS_GET_TOOL_HARDWARE_ID_6                     0x2C060000
#define         MT_LOCUS_GET_TOOL_HARDWARE_ID_7                     0x2C070000
#define     MT_LOCUS_OPEN                                       0x2D000000
#define         MT_LOCUS_OPEN_1                                     0x2D010000
#define         MT_LOCUS_OPEN_2                                     0x2D020000
#define         MT_LOCUS_OPEN_3                                     0x2D030000
#define         MT_LOCUS_OPEN_4                                     0x2D040000
#define         MT_LOCUS_OPEN_5                                     0x2D050000
#define     MT_LOCUS_READ                                       0x2E000000
#define         MT_LOCUS_READ_1                                     0x2E010000
#define         MT_LOCUS_READ_2                                     0x2E020000
#define         MT_LOCUS_READ_3                                     0x2E030000
#define         MT_LOCUS_READ_4                                     0x2E040000
#define         MT_LOCUS_READ_5                                     0x2E050000
#define         MT_LOCUS_READ_6                                     0x2E060000
#define     MT_LOCUS_READ_FROM_FLASH_MEMORY                     0x2F000000
#define         MT_LOCUS_READ_FROM_FLASH_MEMORY_1                   0x2F010000
#define         MT_LOCUS_READ_FROM_FLASH_MEMORY_2                   0x2F020000
#define         MT_LOCUS_READ_FROM_FLASH_MEMORY_3                   0x2F030000
#define     MT_LOCUS_READ_CF_DATA_FROM_HEX_FILE                 0x30000000
#define         MT_LOCUS_READ_CF_DATA_FROM_HEX_FILE_1               0x30010000
#define         MT_LOCUS_READ_CF_DATA_FROM_HEX_FILE_2               0x30020000
#define         MT_LOCUS_READ_CF_DATA_FROM_HEX_FILE_3               0x30030000
#define         MT_LOCUS_READ_CF_DATA_FROM_HEX_FILE_4               0x30040000
#define         MT_LOCUS_READ_CF_DATA_FROM_HEX_FILE_5               0x30050000
#define         MT_LOCUS_READ_CF_DATA_FROM_HEX_FILE_6               0x30060000
#define         MT_LOCUS_READ_CF_DATA_FROM_HEX_FILE_7               0x30070000
#define         MT_LOCUS_READ_CF_DATA_FROM_HEX_FILE_8               0x30080000
#define         MT_LOCUS_READ_CF_DATA_FROM_HEX_FILE_9               0x30090000
#define     MT_LOCUS_READ_CF_DATA_FROM_SOURCE_PAGE              0x31000000
#define     MT_LOCUS_READ_CF_DATA_FROM_MODULE_PAGE              0x32000000
#define     MT_LOCUS_SET_TOOL_HARDWARE_ID                       0x33000000
#define         MT_LOCUS_SET_TOOL_HARDWARE_ID_1                     0x33010000
#define         MT_LOCUS_SET_TOOL_HARDWARE_ID_2                     0x33020000
#define         MT_LOCUS_SET_TOOL_HARDWARE_ID_3                     0x33030000
#define     MT_LOCUS_SET_FIRMWARE_MODE                          0x38000000
#define         MT_LOCUS_SET_FIRMWARE_MODE_1                        0x38010000
#define         MT_LOCUS_SET_FIRMWARE_MODE_2                        0x38020000
#define         MT_LOCUS_SET_FIRMWARE_MODE_3                        0x38030000
#define         MT_LOCUS_SET_FIRMWARE_MODE_4                        0x38040000
#define     MT_LOCUS_WAIT_FOR_REPLY                             0x3E000000
#define         MT_LOCUS_WAIT_FOR_REPLY_1                           0x3E010000
#define     MT_LOCUS_WRITE                                      0x3F000000
#define         MT_LOCUS_WRITE_1                                    0x3F010000
#define         MT_LOCUS_WRITE_2                                    0x3F020000
#define         MT_LOCUS_WRITE_3                                    0x3F030000
#define         MT_LOCUS_WRITE_4                                    0x3F040000
#define         MT_LOCUS_WRITE_5                                    0x3F050000
#define         MT_LOCUS_WRITE_6                                    0x3F060000
#define     MT_LOCUS_WRITE_TO_FLASH_MEMORY                      0x40000000
#define         MT_LOCUS_WRITE_TO_FLASH_MEMORY_1                    0x40010000
#define         MT_LOCUS_WRITE_TO_FLASH_MEMORY_2                    0x40020000
#define         MT_LOCUS_WRITE_TO_FLASH_MEMORY_3                    0x40030000
#define     MT_LOCUS_WRITE_CF_DATA_TO_TARGET_PAGE               0x42000000
#define     MT_LOCUS_GET_FLASH_STARTING_ADDRESS                 0x43000000
#define         MT_LOCUS_GET_FLASH_STARTING_ADDRESS_1               0x43010000
#define         MT_LOCUS_GET_FLASH_STARTING_ADDRESS_2               0x43020000
#define         MT_LOCUS_GET_FLASH_STARTING_ADDRESS_3               0x43030000
#define         MT_LOCUS_GET_FLASH_STARTING_ADDRESS_4               0x43040000
#define         MT_LOCUS_GET_FLASH_STARTING_ADDRESS_5               0x43050000
#define         MT_LOCUS_GET_FLASH_STARTING_ADDRESS_6               0x43060000
#define         MT_LOCUS_GET_FLASH_STARTING_ADDRESS_7               0x43070000
#define     MT_LOCUS_SET_FLASH_STARTING_ADDRESS                 0x44000000
#define         MT_LOCUS_SET_FLASH_STARTING_ADDRESS_1               0x44010000
#define         MT_LOCUS_SET_FLASH_STARTING_ADDRESS_2               0x44020000
#define         MT_LOCUS_SET_FLASH_STARTING_ADDRESS_3               0x44030000
#define         MT_LOCUS_SET_FLASH_STARTING_ADDRESS_4               0x44040000
#define         MT_LOCUS_SET_FLASH_STARTING_ADDRESS_5               0x44050000
#define         MT_LOCUS_SET_FLASH_STARTING_ADDRESS_6               0x44060000
#define         MT_LOCUS_SET_FLASH_STARTING_ADDRESS_7               0x44070000
#define     MT_LOCUS_GET_DLL_VERSION                            0x47000000
#define         MT_LOCUS_GET_DLL_VERSION_1                          0x47010000
//----------------------------------------------------------------------------
// *Applicable to the functions
//
//      MT_ReadCoefficientDataFromDevice
//      MT_ReadCoefficientDataFromModulePage
//      MT_ReadCoefficientDataFromSourcePage
//      MT_WriteCoefficientDataToDevice
//      MT_WriteCoefficientDataToModulePage
//      MT_WriteCoefficientDataToTargetPage
//
// The third byte (0x00FF0000) of the status is mapped as follows:
//
// The highest two bits (0xC0) = device, the lower six bits (0x3F) = pageNumber
//
//      00 000000b = Data to / from the transducer memory page 0  (0x3100XXXX)
//      00 000001b = Data to / from the transducer memory page 1  (0x3101XXXX)
//      00 000010b = Data to / from the transducer memory page 2  (0x3102XXXX)
//          .
//          .
//          .
//      00 111111b = Data to / from the transducer memory page 63  (0x313FXXXX)
//
//      01 000000b = Data to / from the Memory Tool module memory page 0 (0x3140XXXX)
//      01 000001b = Data to / from the Memory Tool module memory page 1 (0x3141XXXX)
//      01 000010b = Data to / from the Memory Tool module memory page 2 (0x3142XXXX)
//          .
//          .
//          .
//      01 111111b = Data to / from the Memory Tool module memory page 63 (0x317FXXXX)
//
// The third (destination) byte will reflect the target device and memory page
// unless over-written by an error locus
////----------------------------------------------------------------------------
//// Coefficient Data Format Structure
////----------------------------------------------------------------------------
//struct _CoefficientDataFormat           // MT_COEFFICIENT_DATA_SIZE (256) bytes
//{
//    WORD        fileType;               // 0x010D           // offset 0x0000    // 0x010D == big endian , 0x040D = little endian
//    WORD        fileVersion;            // 0x2301           // offset 0x0002    // 0x2301 == newer, 0x0001 == older
//    DWORD       serialNumber;           // 0xXXXXXX0D (BCD) // offset 0x0004
//    char        partNumber[8];          // DXBXXX / QSBXXX  // offset 0x0008
//    WORD        calibrationYear;        // 0x2009 (BCD)     // offset 0x0010
//    BYTE        calibrationMonth;       // 0x12 (BCD)       // offset 0x0012
//    BYTE        calibrationDate;        // 0x31 (BCD)       // offset 0x0013
//    char        minimumPressure;        // 0x00 kpsi        // offset 0x0014
//    char        maximumPressure;        // 0x10 kpsi        // offset 0x0015
//    char        minimumTemperature;     // X 5 �C           // offset 0x0016
//    char        maximumTemperature;     // X 5 �C           // offset 0x0017
//    char        calibration1Type;       // 0x01             // offset 0x0018
//    char        prescale1Type;          // 0x03             // offset 0x0019
//    char        pressure1FitOrder;      // 0x03             // offset 0x001A
//    char        temperature1FitOrder;   // 0x03             // offset 0x001B
//    float       scaleFactor1StdUnits;   // 0x39800000       // offset 0x001C
//    float       scaleFactor1AltUnits;   // 0x378D3466       // offset 0x0020
//    long        offset1AlternateUnits;  // 0x00000000       // offset 0x0024
//    char        coefficients1[100];                         // offset 0x0028
//    char        calibration2Type;       // 0x02             // offset 0x008C
//    char        prescale2Type;          // 0x03             // offset 0x008D
//    char        pressure2FitOrder;      // 0x00             // offset 0x008E
//    char        temperature2FitOrder;   // 0x03             // offset 0x008F
//    float       scaleFactor2StdUnits;   // 0x39800000       // offset 0x0090
//    float       scaleFactor2AltUnits;   // 0x39E66666       // offset 0x0094
//    long        offset2AlternateUnits;  // 0x00011C72       // offset 0x0098
//    char        coefficients2[96];                          // offset 0x009C
//    BYTE        endOfFile[3];           // 0x0000FF         // offset 0x00FC
//    BYTE        checksum;                                   // offset 0x00FF
//};                                      // end of struct _CoefficientDataFormat
#endif      // MTRECORD_H
//============================================================================
// End of mtRecord.h
//============================================================================
