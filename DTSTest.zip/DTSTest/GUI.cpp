//============================================================================
// GUI.cpp
//
// A collection of C++ methods, classes, definitions, and other tools for the
// support of the DTSTest Windows graphical user interfaces
//
// Copyright (C) 2014 - 2016 Quartzdyne, Inc.  All rights reserved.
//
// No part of this source code may be reproduced or transmitted in any form or
// by any means, electronic or mechanical, including photocopying, recording,
// or any information storage and retrieval system, without express written
// permission from Quartzdyne, Inc.  Further, no use of this source code is
// permitted in any form or means without a valid, written license agreement
// with Quartzdyne, Inc.  While every reasonable precaution has been taken in
// the preparation of this source code, Quartzdyne, Inc., assumes no
// responsibility for errors, omissions, or damages from the use of the source
// code contained herein.
//
// NEITHER QUARTZDYNE, INC., ANY MEMBER OF QUARTZDYNE, INC., NOR ANY PERSON OR
// ORGANIZATION ACTING ON BEHALF OF THEM MAKES ANY WARRANTY OR REPRESENTATION
// WHATSOEVER, EXPRESS OR IMPLIED, INCLUDING ANY WARRANTY OF MERCHANTABILITY
// OR FITNESS FOR ANY PURPOSE WITH RESPECT TO THE SOURCE CODE OR ASSUMES ANY
// LIABILITY WHATSOEVER WITH RESPECT TO ANY USE OF THE SOURCE CODE OR ANY
// PORTION THEREOF OR WITH RESPECT TO ANY DAMAGES THAT MAY RESULT FROM SUCH
// USE.
//
// Noji Ratzlaff
//
// See DTSTest.log for a complete history of all updates, changes, and revisions
// of this source and other files and policies regarding DTSTest software
//
// Updated 01-14-2016
//============================================================================
#include    "stdafx.h"
#ifndef     GUI_CPP
#define     GUI_CPP
#include    "GUI.h"
//----------------------------------------------------------------------------
// DTSTest_GUIClass
//
// Class constructor
//
// Called by:   DTSTest_Main
//----------------------------------------------------------------------------
    DTSTest_GUIClass::
DTSTest_GUIClass()
{
    //------------------------------------------------------------------------
    // Register the default (unhandled) exception handler before any class
    // methods are called, to catch all exceptions not already handled
    //------------------------------------------------------------------------
    AppDomain::CurrentDomain->UnhandledException +=
        gcnew UnhandledExceptionEventHandler(this, &DTSTest_GUIClass::DTSTest_DefaultExceptionHandler);
    //------------------------------------------------------------------------
    // Register for the event in which the computer is shutting down
    //------------------------------------------------------------------------
    SystemEvents::SessionEnded +=
        gcnew SessionEndedEventHandler(this, &DTSTest_GUIClass::DTSTest_ComputerShuttingDown);
    //------------------------------------------------------------------------
    // Register for the event in which the computer is going into hibernation
    //------------------------------------------------------------------------
    SystemEvents::PowerModeChanged +=
        gcnew PowerModeChangedEventHandler(this, &DTSTest_GUIClass::DTSTest_ComputerGoingToHibernation);
    //------------------------------------------------------------------------
    // Register for the event in which the logged-in user is changing
    //------------------------------------------------------------------------
    SystemEvents::SessionSwitch +=
        gcnew SessionSwitchEventHandler(this, &DTSTest_GUIClass::DTSTest_ComputerUserChanging);
    //------------------------------------------------------------------------
    // Start the GUI
    //------------------------------------------------------------------------
    DTSTest_Start();
}                                       // end of DTSTest_GUIClass
//----------------------------------------------------------------------------
// DTSTest_Start
//
// Starts the DTSTest GUI, the top-most GUI process
//
// Called by:   DTSTest_GUIClass
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_Start(void)
{
    DWORD           mainStatus;
    String          ^functionName = _T("DTSTest_Start");
    //------------------------------------------------------------------------
    mainStatus = DTSTest_InitializeDTSTest();
    if (mainStatus == DTSTEST_SUCCESS)
    {
        if (DTSTest_CommandLineOnly)
        {
            DTSTest_PerformCommandLineTasks();
            //----------------------------------------------------------------
            // Conclude the program
            //----------------------------------------------------------------
            DTSTest_Finalize(String::Concat(functionName, " concluded"));
            //----------------------------------------------------------------
            // Manually exit the program (to terminate the Form process)
            //----------------------------------------------------------------
            Environment::Exit(mainStatus);
        }
        else
        {
            RecordBasicEvent("{0} : Begin GUI initialization", functionName);
            DTSTest_ConstructAndPresentUserInterface();
            RecordBasicEvent("{0} : End GUI initialization", functionName);
        }
    }                                   // end of if (mainStatus == DTSTEST_SUCCESS)
    else
    {
        //--------------------------------------------------------------------
        // Initialization failed, so exit the program (this automatically
        // releases the mutex
        //--------------------------------------------------------------------
        Environment::Exit(mainStatus);
    }
}                                       // end of DTSTest_Start
//----------------------------------------------------------------------------
// DTSTest_ConstructAndPresentUserInterface
//
// Constructs the home window and all associated graphics, then presents them
//
// Called by:   DTSTest_Start
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_ConstructAndPresentUserInterface(void)
{
    String          ^functionName = _T("DTSTest_ConstructAndPresentUserInterface");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0} called", functionName);
    //------------------------------------------------------------------------
    // Initialize global and other program entities
    //------------------------------------------------------------------------
    DTSTest_InitializeGUIComponents();
    //------------------------------------------------------------------------
    // Define the home window
    //------------------------------------------------------------------------
    DTSTest_ConstructHomeWindow();
    //------------------------------------------------------------------------
    // Install the program utilities and their components
    //------------------------------------------------------------------------
    DTSTest_InstallUtilities();
    //------------------------------------------------------------------------
    // Populate the user interface with initial values
    //------------------------------------------------------------------------
    DTSTest_InitializeUserInterface();
    //------------------------------------------------------------------------
    // Remove the "Please wait . . ." window
    //------------------------------------------------------------------------
    DTSTest_PleaseWait(GUI_PLEASE_WAIT_REMOVE, nullptr);
    RecordBasicEvent("{0} concluded", functionName);
}                                       // end of DTSTest_ConstructAndPresentUserInterface()
//----------------------------------------------------------------------------
// DTSTest_ConstructHomeWindow
//
// Displays the home window
//
// Called by:   DTSTest_ConstructAndPresentUserInterface
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_ConstructHomeWindow(void)
{
    String          ^functionName = _T("DTSTest_ConstructHomeWindow");
    //------------------------------------------------------------------------
    RecordBasicEvent("    {0} called", functionName);
//    this->TopMost = GUI_YES;
    this->FormBorderStyle = ::FormBorderStyle::Fixed3D;
    this->MaximizeBox = GUI_NO;
    this->AutoScroll = GUI_YES;
    //------------------------------------------------------------------------
    // Set the home window title
    //------------------------------------------------------------------------
     this->Text = String::Concat(
         GUI_HOME_WINDOW_TITLE, " ", DTSTEST_PROGRAM_VERSION_STRING);
    this->DoubleBuffered = GUI_YES;
    //------------------------------------------------------------------------
    // Display the DTSTest icon
    //------------------------------------------------------------------------
    this->Icon = DTSTest_SoftwareIcon;
    //------------------------------------------------------------------------
    // Set the background
    //------------------------------------------------------------------------
//    this->BackgroundImage = woodGrainBackground;
    //------------------------------------------------------------------------
    // Set the size of the Home window
    //------------------------------------------------------------------------
    this->Width = GUI_HOME_WINDOW_MIN_WIDTH;
    this->Height = GUI_HOME_WINDOW_MIN_HEIGHT;
    //------------------------------------------------------------------------
    // Define the toolbar (actually, a tool strip)
    //------------------------------------------------------------------------
    DTSTest_InstallToolStrip();
    //------------------------------------------------------------------------
    // Define the status bar (actually, a status strip)
    //------------------------------------------------------------------------
    DTSTest_InstallStatusStrip();
    //------------------------------------------------------------------------
    // Install the opening banner, 'Exit' button, and status lights
    //------------------------------------------------------------------------
    DTSTest_InstallHomeWindowGraphics();
    RecordBasicEvent("    {0} concluded", functionName);
}                                       // end of DTSTest_ConstructHomeWindow
//----------------------------------------------------------------------------
// DTSTest_InitializeGUIComponents
//
// Initializes the remaining program entities prior to displaying and running
//
// Called by:   DTSTest_ConstructAndPresentUserInterface
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_InitializeGUIComponents(void)
{
    String          ^functionName = _T("DTSTest_InitializeGUIComponents");
    //------------------------------------------------------------------------
    RecordBasicEvent("    {0} called", functionName);
    //------------------------------------------------------------------------
    // Initialize global managed arrays that are not used in DConfig.cpp
    //------------------------------------------------------------------------
    //------------------------------------------------------------------------
    // Set up the one-second (heartbeat) timer
    //
    // This non-adjustable timer is for anything that needs a one-second
    // interval
    //------------------------------------------------------------------------
    oneSecondTimer = gcnew Windows::Forms::Timer;
    oneSecondTimer->Interval = GUI_ONE_SECOND_INTERVAL;
    oneSecondTimer->Stop();
    oneSecondTimer->Tick +=
        gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_OneSecondTimerElapsed);
    //------------------------------------------------------------------------
    // Set up the loop timer
    //
    // This adjustable timer is used to control the interval at which the
    // program loops the control script
    //------------------------------------------------------------------------
    scriptControlLoopTimer = gcnew Windows::Forms::Timer;
    scriptControlLoopTimer->Stop();
    scriptControlLoopTimer->Tick +=
        gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_ScriptControlLoopTimerElapsed);
    //------------------------------------------------------------------------
    // Initialize the sampling background worker
    //------------------------------------------------------------------------
    samplingEntryBackground = gcnew BackgroundWorker;
    samplingEntryBackground->DoWork +=
        gcnew DoWorkEventHandler(this, &DTSTest_GUIClass::DTSTest_SamplingBackgroundWorker);
    samplingEntryBackground->ProgressChanged +=
        gcnew ProgressChangedEventHandler(this, &DTSTest_GUIClass::DTSTest_SamplingBackgroundWorkerUpdateProgress);
    samplingEntryBackground->RunWorkerCompleted +=
        gcnew RunWorkerCompletedEventHandler(this, &DTSTest_GUIClass::DTSTest_SamplingBackgroundWorkerCompleted);
    samplingEntryBackground->WorkerReportsProgress = GUI_YES;
    samplingEntryBackground->WorkerSupportsCancellation = GUI_YES;
    //------------------------------------------------------------------------
    // Initialize the testing background worker
    //------------------------------------------------------------------------
    testingEntryBackground = gcnew BackgroundWorker;
    testingEntryBackground->DoWork +=
        gcnew DoWorkEventHandler(this, &DTSTest_GUIClass::DTSTest_TestingBackgroundWorker);
    testingEntryBackground->ProgressChanged +=
        gcnew ProgressChangedEventHandler(this, &DTSTest_GUIClass::DTSTest_TestingBackgroundWorkerUpdateProgress);
    testingEntryBackground->RunWorkerCompleted +=
        gcnew RunWorkerCompletedEventHandler(this, &DTSTest_GUIClass::DTSTest_TestingBackgroundWorkerCompleted);
    testingEntryBackground->WorkerReportsProgress = GUI_YES;
    testingEntryBackground->WorkerSupportsCancellation = GUI_YES;
    //------------------------------------------------------------------------
    // Register a method to handle the Closing event
    //------------------------------------------------------------------------
    this->FormClosing +=
        gcnew FormClosingEventHandler(this, &DTSTest_GUIClass::DTSTest_HomeClosingWindow);
    //------------------------------------------------------------------------
    // Other tasks needed prior to user interface construction
    //------------------------------------------------------------------------
    DTSTest_AffirmStartupConditions();
    RecordBasicEvent("    {0} concluded", functionName);
}                                       // end of DTSTest_InitializeGUIComponents()
//----------------------------------------------------------------------------
// DTSTest_InitializeUserInterface
//
// Populates the user interface with initial values
//
// Note:    These are the last lines to execute before going to idle
//
// Called by:   DTSTest_ConstructAndPresentUserInterface
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_InitializeUserInterface(void)
{
    DateTime        dateTime = DateTime::Now;
    String          ^functionName = _T("DTSTest_InitializeUserInterface");
    //------------------------------------------------------------------------
    RecordBasicEvent("        {0} called", functionName);
    //------------------------------------------------------------------------
    // Initialize the status line with the current date-and-time, and a welcome
    //------------------------------------------------------------------------
    if (!(DTSTest_GeneralInfo->flags & DTSTEST_GENERAL_GUI_UP_AND_RUNNING))
    {
        nowTSStatusLabel->Text = String::Format(
            "{0,9} {1:D2} {2} {3:D4} {4:D2}:{5:D2}:{6:D2}",
            dateTime.DayOfWeek,
            dateTime.Day,
            DTSTest_MonthStringArray[dateTime.Month],
            dateTime.Year,
            dateTime.Hour,
            dateTime.Minute,
            dateTime.Second);
        //--------------------------------------------------------------------
        // Record QCOM interaction
        //--------------------------------------------------------------------
        int numberOfModules = QD_GetNumberOfModules();
        RecordBasicEvent("            There {0} {1:D} QCOM module{2} attached",
            ((numberOfModules == 1) ? "is" : "are"),
            numberOfModules,
            ((numberOfModules == 1) ? "" : "s"));
        DTSTest_UpdateHomeProgressBar(0, 0);
        DTSTest_UpdateStatusLine("Welcome to DTSTest");
        //--------------------------------------------------------------------
        // Signal that the GUI is up and running, ready for interaction
        //--------------------------------------------------------------------
        DTSTest_GeneralInfo->flags |= DTSTEST_GENERAL_GUI_UP_AND_RUNNING;
    }
    oneSecondTimer->Start();
    scriptControlLoopTimer->Interval = DTSTEST_MINIMUM_LOOP_TIMER_MS_INTERVAL;  // 100
    //------------------------------------------------------------------------
    // Enable GUI objects that depend on completion of the hardware scan
    //------------------------------------------------------------------------
//    if (DTSTest_GeneralInfo->flags & DTSTEST_GENERAL_SCAN_COMPLETED)
    {
//        DTSTest_ExperimentalEnableUserInterface();
    }
    DTSTest_UpdateMessageChecks();
    RecordBasicEvent("        {0} concluded", functionName);
}                                       // end of DTSTest_InitializeUserInterface()
//----------------------------------------------------------------------------
// DTSTest_InstallHomeWindowGraphics
//
// Presents various controls in the home window
//
// Called by:   DTSTest_ConstructHomeWindow
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_InstallHomeWindowGraphics(void)
{
    DWORD           zeroValue = 0;
    PDGICInfo       ^pgInfo = DTSTest_GeneralInfo->pgInfo;
    String          ^functionName = _T("DTSTest_InstallHomeWindowGraphics");
    //------------------------------------------------------------------------
    RecordBasicEvent("        {0} called", functionName);
    this->SuspendLayout();
    this->Tag = zeroValue;
    //------------------------------------------------------------------------
    // Load and Run Control Script button
    //------------------------------------------------------------------------
    homeLoadControlScriptButton = gcnew Button;
    homeLoadControlScriptButton->Text = _T("Load and Run Control Script");
    homeLoadControlScriptButton->Location = Point(10, 34);
    homeLoadControlScriptButton->Size = Drawing::Size(
        160, GUI_REGULAR_BUTTON_HEIGHT);
    GUI_SetButtonInterfaceProperties(homeLoadControlScriptButton);
    homeLoadControlScriptButton->Click +=
        gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_HomeLoadControlScriptFileButtonClicked);
    homeLoadControlScriptButton->MouseEnter +=
        gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_HomeLoadControlScriptFileButtonMouseEntered);
    homeLoadControlScriptButton->MouseLeave +=
        gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_AnyObjectMouseExited);
    homeLoadControlScriptButton->Enabled = GUI_NO;
    Controls->Add(homeLoadControlScriptButton);
    //------------------------------------------------------------------------
    // Re-run Control Script button
    //------------------------------------------------------------------------
    homeRerunControlScriptButton = gcnew Button;
    homeRerunControlScriptButton->Text = _T("Re-run Control Script");
    GUI_PositionAndSizeBelow(homeRerunControlScriptButton, homeLoadControlScriptButton, 10);
    GUI_SetButtonInterfaceProperties(homeRerunControlScriptButton);
    homeRerunControlScriptButton->Click +=
        gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_HomeRerunControlScriptButtonClicked);
    homeRerunControlScriptButton->MouseEnter +=
        gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_HomeRerunControlScriptButtonMouseEntered);
    homeRerunControlScriptButton->MouseLeave +=
        gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_AnyObjectMouseExited);
    homeRerunControlScriptButton->Enabled =
        DTSTest_GeneralInfo->mainScript->controlScriptIsLoaded ? GUI_YES : GUI_NO;
    Controls->Add(homeRerunControlScriptButton);
    //------------------------------------------------------------------------
    // Loop Control Script File button
    //------------------------------------------------------------------------
    homeLoopControlScriptButton = gcnew Button;
    homeLoopControlScriptButton->Text = _T("Loop Control Script");
    GUI_PositionAndSizeBelow(homeLoopControlScriptButton, homeRerunControlScriptButton, 10);
    GUI_SetButtonInterfaceProperties(homeLoopControlScriptButton);
    homeLoopControlScriptButton->Click +=
        gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_HomeLoopControlScriptButtonClicked);
    homeLoopControlScriptButton->MouseEnter +=
        gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_HomeLoopControlScriptButtonMouseEntered);
    homeLoopControlScriptButton->MouseLeave +=
        gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_AnyObjectMouseExited);
    homeLoopControlScriptButton->Enabled =
        DTSTest_GeneralInfo->mainScript->controlScriptIsLoaded ? GUI_YES : GUI_NO;
    Controls->Add(homeLoopControlScriptButton);
    //------------------------------------------------------------------------
    // Script filename label
    //------------------------------------------------------------------------
    homeScriptFilenameLabel = gcnew Label;
    homeScriptFilenameLabel->Text = String::Concat(
        _T("Script: "),
        (StringSet(DTSTest_GeneralInfo->mainScript->controlScriptFilePath) ?
            Path::GetFileName(DTSTest_GeneralInfo->mainScript->controlScriptFilePath) : _T("< none >")));
    homeScriptFilenameLabel->Location = Point(
        homeLoadControlScriptButton->Right + 10,
        homeLoadControlScriptButton->Top + 6);
    homeScriptFilenameLabel->Size = Drawing::Size(
        276, GUI_REGULAR_LABEL_HEIGHT);
    homeScriptFilenameLabel->BackColor = Color::Transparent;
    homeScriptFilenameLabel->TextAlign = Drawing::ContentAlignment::MiddleLeft;
    homeScriptFilenameLabel->MouseEnter +=
        gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_HomeAddCommentAreaMouseEntered);
    homeScriptFilenameLabel->MouseLeave +=
        gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_AnyObjectMouseExited);
    Controls->Add(homeScriptFilenameLabel);
    //------------------------------------------------------------------------
    // Add Comment label
    //------------------------------------------------------------------------
    Label ^homeAddCommentLabel = gcnew Label;
    homeAddCommentLabel->Text = _T("Add a comment:");
    homeAddCommentLabel->Location = Point(
        homeRerunControlScriptButton->Right + 10,
        homeRerunControlScriptButton->Top + 6);
    homeAddCommentLabel->Size = Drawing::Size(
        92, GUI_REGULAR_LABEL_HEIGHT);
    homeAddCommentLabel->BackColor = Color::Transparent;
    homeAddCommentLabel->TextAlign = Drawing::ContentAlignment::MiddleLeft;
    homeAddCommentLabel->MouseEnter +=
        gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_HomeAddCommentAreaMouseEntered);
    homeAddCommentLabel->MouseLeave +=
        gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_AnyObjectMouseExited);
    Controls->Add(homeAddCommentLabel);
    //------------------------------------------------------------------------
    // Add Comment text box
    //------------------------------------------------------------------------
    homeAddCommentBox = gcnew TextBox;
    homeAddCommentBox->Location = Point(
        homeAddCommentLabel->Right + 2,
        homeRerunControlScriptButton->Top + 4);
    homeAddCommentBox->Size = Drawing::Size(
        192, GUI_REGULAR_TEXT_BOX_HEIGHT);
    homeAddCommentBox->Multiline = GUI_NO;
    homeAddCommentBox->AcceptsReturn = GUI_NO;
    homeAddCommentBox->AcceptsTab = GUI_NO;
    homeAddCommentBox->WordWrap = GUI_NO;
    homeAddCommentBox->TextAlign = HorizontalAlignment::Left;
    homeAddCommentBox->BackColor = Color::LightGray;
    homeAddCommentBox->PreviewKeyDown +=
        gcnew PreviewKeyDownEventHandler(this, &DTSTest_GUIClass::DTSTest_HomeTextBoxAcceptEnterKey);
    homeAddCommentBox->KeyDown +=
        gcnew KeyEventHandler(this, &DTSTest_GUIClass::DTSTest_HomeTextBoxProcessEnterKey);
    homeAddCommentBox->TextChanged +=
        gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_TextChangedAddComment);
    homeAddCommentBox->MouseEnter +=
        gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_HomeAddCommentAreaMouseEntered);
    homeAddCommentBox->MouseLeave +=
        gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_AnyObjectMouseExited);
    Controls->Add(homeAddCommentBox);
    //------------------------------------------------------------------------
    // Add Comment button
    //------------------------------------------------------------------------
    homeAddCommentButton = gcnew Button;
    homeAddCommentButton->Text = _T("Add");
    homeAddCommentButton->Location = Point(
        homeAddCommentBox->Right + 6,
        homeRerunControlScriptButton->Top);
    homeAddCommentButton->Size = Drawing::Size(
        40, GUI_REGULAR_BUTTON_HEIGHT);
    GUI_SetButtonInterfaceProperties(homeAddCommentButton);
    homeAddCommentButton->Click +=
        gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_HomeAddCommentButtonClicked);
    homeAddCommentButton->MouseEnter +=
        gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_HomeAddCommentAreaMouseEntered);
    homeAddCommentButton->MouseLeave +=
        gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_AnyObjectMouseExited);
    if (StringSet(homeAddCommentBox->Text))
        homeAddCommentButton->Enabled = GUI_YES;
    else
        homeAddCommentButton->Enabled = GUI_NO;
    Controls->Add(homeAddCommentButton);
    //------------------------------------------------------------------------
    // Single Command label
    //------------------------------------------------------------------------
    Label ^homeSingleCommandLabel = gcnew Label;
    homeSingleCommandLabel->Text = _T("Single command:");
    homeSingleCommandLabel->Location = Point(
        homeLoopControlScriptButton->Right + 10,
        homeLoopControlScriptButton->Top + 6);
    homeSingleCommandLabel->Size = Drawing::Size(
        92, GUI_REGULAR_LABEL_HEIGHT);
    homeSingleCommandLabel->BackColor = Color::Transparent;
    homeSingleCommandLabel->TextAlign = Drawing::ContentAlignment::MiddleLeft;
    homeSingleCommandLabel->MouseEnter +=
        gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_HomeSingleCommandAreaMouseEntered);
    homeSingleCommandLabel->MouseLeave +=
        gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_AnyObjectMouseExited);
    Controls->Add(homeSingleCommandLabel);
    //------------------------------------------------------------------------
    // Single Command text box
    //------------------------------------------------------------------------
    homeSingleCommandBox = gcnew TextBox;
    homeSingleCommandBox->Location = Point(
        homeSingleCommandLabel->Right + 2,
        homeLoopControlScriptButton->Top + 4);
    homeSingleCommandBox->Size = Drawing::Size(
        192, GUI_REGULAR_TEXT_BOX_HEIGHT);
    homeSingleCommandBox->Multiline = GUI_NO;
    homeSingleCommandBox->AcceptsReturn = GUI_NO;
    homeSingleCommandBox->AcceptsTab = GUI_NO;
    homeSingleCommandBox->WordWrap = GUI_NO;
    homeSingleCommandBox->TextAlign = HorizontalAlignment::Left;
    homeSingleCommandBox->BackColor = Color::LightGray;
    homeSingleCommandBox->CharacterCasing = CharacterCasing::Upper;
    homeSingleCommandBox->PreviewKeyDown +=
        gcnew PreviewKeyDownEventHandler(this, &DTSTest_GUIClass::DTSTest_HomeTextBoxAcceptEnterKey);
    homeSingleCommandBox->KeyDown +=
        gcnew KeyEventHandler(this, &DTSTest_GUIClass::DTSTest_HomeTextBoxProcessEnterKey);
    homeSingleCommandBox->TextChanged +=
        gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_TextChangedSingleCommand);
    homeSingleCommandBox->MouseEnter +=
        gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_HomeSingleCommandAreaMouseEntered);
    homeSingleCommandBox->MouseLeave +=
        gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_AnyObjectMouseExited);
    Controls->Add(homeSingleCommandBox);
    homeSingleCommandBox->Select();
    //------------------------------------------------------------------------
    // Single Command Send button
    //------------------------------------------------------------------------
    homeSingleCommandSendButton = gcnew Button;
    homeSingleCommandSendButton->Text = _T("Send");
    homeSingleCommandSendButton->Location = Point(
        homeSingleCommandBox->Right + 6,
        homeLoopControlScriptButton->Top);
    homeSingleCommandSendButton->Size = Drawing::Size(
        40, GUI_REGULAR_BUTTON_HEIGHT);
    GUI_SetButtonInterfaceProperties(homeSingleCommandSendButton);
    homeSingleCommandSendButton->Click +=
        gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_HomeSingleCommandSendButtonClicked);
    homeSingleCommandSendButton->MouseEnter +=
        gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_HomeSingleCommandAreaMouseEntered);
    homeSingleCommandSendButton->MouseLeave +=
        gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_AnyObjectMouseExited);
    if (StringSet(homeSingleCommandBox->Text) &&
        (DTSTest_GeneralInfo->pgInfo->PDGICPresent ||
        DTSTest_DemoModeEnabled))
    {
        homeSingleCommandSendButton->Enabled = GUI_YES;
    }
    else
    {
        homeSingleCommandSendButton->Enabled = GUI_NO;
    }
    Controls->Add(homeSingleCommandSendButton);
    //------------------------------------------------------------------------
    // Calculate CRCs check box
    //------------------------------------------------------------------------
    homeCalculateCRCsCheck = gcnew CheckBox;
    homeCalculateCRCsCheck->Text = _T("Calculate CRCs");
    homeCalculateCRCsCheck->Location = Point(
        homeAddCommentButton->Right + 20,
        homeAddCommentButton->Top);
    homeCalculateCRCsCheck->Size = Drawing::Size(
        126,
        GUI_REGULAR_CHECK_BOX_HEIGHT);
    GUI_SetObjectInterfaceProperties(homeCalculateCRCsCheck);
    homeCalculateCRCsCheck->Click +=
        gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_HomeCalculateCRCsChecked);
    homeCalculateCRCsCheck->MouseEnter +=
        gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_HomeCalculateCRCsCheckMouseEntered);
    homeCalculateCRCsCheck->MouseLeave +=
        gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_AnyObjectMouseExited);
    if (DTSTest_CalculateCRCs)
        homeCalculateCRCsCheck->Checked = GUI_YES;
    Controls->Add(homeCalculateCRCsCheck);
    //------------------------------------------------------------------------
    // Report CRC Errors check box
    //------------------------------------------------------------------------
    homeReportCRCErrorsCheck = gcnew CheckBox;
    homeReportCRCErrorsCheck->Text = _T("Report CRC errors");
    homeReportCRCErrorsCheck->Location = Point(
        homeCalculateCRCsCheck->Right + 4,
        homeCalculateCRCsCheck->Top);
    homeReportCRCErrorsCheck->Size = Drawing::Size(
        138,
        homeCalculateCRCsCheck->Height);
    GUI_SetObjectInterfaceProperties(homeReportCRCErrorsCheck);
    homeReportCRCErrorsCheck->Click +=
        gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_HomeReportCRCErrorsChecked);
    homeReportCRCErrorsCheck->MouseEnter +=
        gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_HomeReportCRCErrorsCheckMouseEntered);
    homeReportCRCErrorsCheck->MouseLeave +=
        gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_AnyObjectMouseExited);
    if (DTSTest_ReportCRCErrors)
        homeReportCRCErrorsCheck->Checked = GUI_YES;
    Controls->Add(homeReportCRCErrorsCheck);
    //------------------------------------------------------------------------
    // Save CSV Results check box
    //------------------------------------------------------------------------
    homeSaveCSVResultsCheck = gcnew CheckBox;
    homeSaveCSVResultsCheck->Text = _T("Save CSV results");
    GUI_PositionAndSizeBelow(homeSaveCSVResultsCheck, homeCalculateCRCsCheck, 7);
    GUI_SetObjectInterfaceProperties(homeSaveCSVResultsCheck);
    homeSaveCSVResultsCheck->Click +=
        gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_HomeCSVLogChecked);
    homeSaveCSVResultsCheck->MouseEnter +=
        gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_HomeCSVLogCheckMouseEntered);
    homeSaveCSVResultsCheck->MouseLeave +=
        gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_AnyObjectMouseExited);
    if (DTSTest_GeneralInfo->flags & DTSTEST_GENERAL_CREATE_CSV_LOG_FILE)
        homeSaveCSVResultsCheck->Checked = GUI_YES;
    Controls->Add(homeSaveCSVResultsCheck);
    //------------------------------------------------------------------------
    // Placeholder check box
    //------------------------------------------------------------------------
    homeNormalizeReadingsCheck = gcnew CheckBox;
    homeNormalizeReadingsCheck->Text = _T("Normalize readings");
    GUI_PositionAndSizeBelow(homeNormalizeReadingsCheck, homeReportCRCErrorsCheck, 7);
    GUI_SetObjectInterfaceProperties(homeNormalizeReadingsCheck);
    homeNormalizeReadingsCheck->Click +=
        gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_HomeNormalizeReadingsChecked);
    homeNormalizeReadingsCheck->MouseEnter +=
        gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_HomeNormalizeReadingsCheckMouseEntered);
    homeNormalizeReadingsCheck->MouseLeave +=
        gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_AnyObjectMouseExited);
    if (DTSTest_NormalizeReadings)
        homeNormalizeReadingsCheck->Checked = GUI_YES;
    Controls->Add(homeNormalizeReadingsCheck);
    //------------------------------------------------------------------------
    // Prepend Date and Time check box
    //------------------------------------------------------------------------
    homePrependDateAndTimeCheck = gcnew CheckBox;
    homePrependDateAndTimeCheck->Text = _T("Prepend date & time");
    GUI_PositionAndSizeBelow(homePrependDateAndTimeCheck, homeSaveCSVResultsCheck, 7);
    GUI_SetObjectInterfaceProperties(homePrependDateAndTimeCheck);
    homePrependDateAndTimeCheck->UseMnemonic = GUI_NO;      // to display ampersands
    homePrependDateAndTimeCheck->Click +=
        gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_HomePrependDateAndTimeChecked);
    homePrependDateAndTimeCheck->MouseEnter +=
        gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_HomePrependDateAndTimeCheckMouseEntered);
    homePrependDateAndTimeCheck->MouseLeave +=
        gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_AnyObjectMouseExited);
    if (DTSTest_PrependDateAndTime)
        homePrependDateAndTimeCheck->Checked = GUI_YES;
    Controls->Add(homePrependDateAndTimeCheck);
    //------------------------------------------------------------------------
    // Verbose Log Messages check box
    //------------------------------------------------------------------------
    CheckBox ^homeVerboseLogMessagesCheck = gcnew CheckBox;
    homeVerboseLogMessagesCheck->Text = _T("Verbose log messages");
    GUI_PositionAndSizeBelow(homeVerboseLogMessagesCheck, homeNormalizeReadingsCheck, 7);
    GUI_SetObjectInterfaceProperties(homeVerboseLogMessagesCheck);
    homeVerboseLogMessagesCheck->Click +=
        gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_HomeVerboseLogMessagesChecked);
    homeVerboseLogMessagesCheck->MouseEnter +=
        gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_HomeVerboseLogMessagesCheckMouseEntered);
    homeVerboseLogMessagesCheck->MouseLeave +=
        gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_AnyObjectMouseExited);
    if (DTSTest_GeneralInfo->flags & DTSTEST_GENERAL_VERBOSE_LOG_MESSAGES)
        homeVerboseLogMessagesCheck->Checked = GUI_YES;
    Controls->Add(homeVerboseLogMessagesCheck);
    //------------------------------------------------------------------------
    // Baud Rate label
    //------------------------------------------------------------------------
    homeBaudRateLabel = gcnew Label;
    homeBaudRateLabel->Text =
        DTSTest_BaudRateSetTo2400 ? _T("2400 Baud") : _T("1200 Baud");
    homeBaudRateLabel->Location = Point(
        GUI_HOME_WINDOW_MIN_WIDTH - 360,
        32);
    homeBaudRateLabel->Size = Drawing::Size(
        158, 32);
    homeBaudRateLabel->Font = gcnew Drawing::Font(
        FontFamily::GenericSansSerif,
        20.0F,                          // em-size of the font
        FontStyle::Bold);               // choose from Bold, Italic, Underline, Strikeout
    homeBaudRateLabel->ForeColor = Color::OliveDrab;
    homeBaudRateLabel->BackColor = Color::Transparent;
    homeBaudRateLabel->TextAlign = Drawing::ContentAlignment::BottomLeft;
    homeBaudRateLabel->MouseEnter +=
        gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_HomeBaudRateLabelMouseEntered);
    homeBaudRateLabel->MouseLeave +=
        gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_AnyObjectMouseExited);
    Controls->Add(homeBaudRateLabel);
    //------------------------------------------------------------------------
    // Switch Baud Rate button
    //------------------------------------------------------------------------
    homeSwitchBaudRateButton = gcnew Button;
    homeSwitchBaudRateButton->Text = _T("Switch to 2400 Baud");
    homeSwitchBaudRateButton->Text = String::Concat(
        _T("Switch to "),
        (DTSTest_BaudRateSetTo2400 ? _T("1200") : _T("2400")),
        _T(" Baud"));
    homeSwitchBaudRateButton->Location = Point(
        GUI_HOME_WINDOW_MIN_WIDTH - 185,
        homeLoadControlScriptButton->Top);
    homeSwitchBaudRateButton->Size = homeLoadControlScriptButton->Size;
    GUI_SetButtonInterfaceProperties(homeSwitchBaudRateButton);
    homeSwitchBaudRateButton->Click +=
        gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_HomeSwitchBaudRateButtonClicked);
    homeSwitchBaudRateButton->MouseEnter +=
        gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_HomeSwitchBaudRateButtonMouseEntered);
    homeSwitchBaudRateButton->MouseLeave +=
        gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_AnyObjectMouseExited);
    homeSwitchBaudRateButton->Enabled = GUI_NO;
    Controls->Add(homeSwitchBaudRateButton);
    //------------------------------------------------------------------------
    // Command dialogue text box
    //------------------------------------------------------------------------
    homeCommandDialogueBox = gcnew TextBox;
    homeCommandDialogueBox->Location = Point(
        homeLoadControlScriptButton->Left,
        GUI_HOME_COMMAND_DIALOGUE_TOP);
    homeCommandDialogueBox->Size = Drawing::Size(
        GUI_HOME_WINDOW_MIN_WIDTH - 35,
        GUI_HOME_WINDOW_MIN_HEIGHT - GUI_HOME_COMMAND_DIALOGUE_TOP - 135);
    homeCommandDialogueBox->MaxLength = 65000;
    homeCommandDialogueBox->Multiline = GUI_YES;
    homeCommandDialogueBox->ReadOnly = GUI_YES;
    homeCommandDialogueBox->ScrollBars = ScrollBars::Vertical;
    homeCommandDialogueBox->AcceptsReturn = GUI_YES;
    homeCommandDialogueBox->AcceptsTab = GUI_YES;
    homeCommandDialogueBox->WordWrap = GUI_YES;
    homeCommandDialogueBox->MaxLength = (1024 * 1024) - 1;
    homeCommandDialogueBox->TextAlign = HorizontalAlignment::Left;
    homeCommandDialogueBox->ForeColor = Color::White;
    homeCommandDialogueBox->BackColor = Color::Black;
    homeCommandDialogueBox->Font = gcnew Drawing::Font(
        FontFamily::GenericMonospace,
        8.0F,
        FontStyle::Regular);
    homeCommandDialogueBox->MouseEnter +=
        gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_HomeCommandDialogueBoxMouseEntered);
    homeCommandDialogueBox->MouseLeave +=
        gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_AnyObjectMouseExited);
    Controls->Add(homeCommandDialogueBox);
    //------------------------------------------------------------------------
    // Clear Command Dialogue button
    //------------------------------------------------------------------------
    homeClearCommandDialogueButton = gcnew Button;
    homeClearCommandDialogueButton->Text = _T("Clear");
    homeClearCommandDialogueButton->Location = Point(
        homeCommandDialogueBox->Left,
        homeCommandDialogueBox->Bottom + 10);
    homeClearCommandDialogueButton->Size = Drawing::Size(
        GUI_CLOSE_BUTTON_WIDTH,
        GUI_REGULAR_BUTTON_HEIGHT);
    GUI_SetButtonInterfaceProperties(homeClearCommandDialogueButton);
    homeClearCommandDialogueButton->Click +=
        gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_HomeClearCommandDialogueButtonClicked);
    homeClearCommandDialogueButton->MouseEnter +=
        gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_HomeClearCommandDialogueButtonMouseEntered);
    homeClearCommandDialogueButton->MouseLeave +=
        gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_AnyObjectMouseExited);
    Controls->Add(homeClearCommandDialogueButton);
    if (StringSet(generalCSVFileString) || StringSet(homeCommandDialogueBox->Text))
        homeClearCommandDialogueButton->Enabled = GUI_YES;
    else
        homeClearCommandDialogueButton->Enabled = GUI_NO;
    //------------------------------------------------------------------------
    // Save Command Dialogue button
    //------------------------------------------------------------------------
    Button ^homeSaveCommandDialogueButton = gcnew Button;
    homeSaveCommandDialogueButton->Text = _T("Save");
    homeSaveCommandDialogueButton->Location = Point(
        homeClearCommandDialogueButton->Right + 15,
        homeClearCommandDialogueButton->Top);
    homeSaveCommandDialogueButton->Size = Drawing::Size(
        GUI_CLOSE_BUTTON_WIDTH,
        GUI_REGULAR_BUTTON_HEIGHT);
    GUI_SetButtonInterfaceProperties(homeSaveCommandDialogueButton);
    homeSaveCommandDialogueButton->Click +=
        gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_HomeSaveCommandDialogueButtonClicked);
    homeSaveCommandDialogueButton->MouseEnter +=
        gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_HomeSaveCommandDialogueButtonMouseEntered);
    homeSaveCommandDialogueButton->MouseLeave +=
        gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_AnyObjectMouseExited);
    Controls->Add(homeSaveCommandDialogueButton);
    //------------------------------------------------------------------------
    // Results Log Path label
    //------------------------------------------------------------------------
    homeResultsLogPathLabel = gcnew Label;
    homeResultsLogPathLabel->Text = String::Concat(
        _T("Results log: "),
        DTSTest_GeneralInfo->mainScript->resultsLogFilePath);
    homeResultsLogPathLabel->Location = Point(
        homeSaveCommandDialogueButton->Right + 10,
        homeSaveCommandDialogueButton->Top + 6);
    homeResultsLogPathLabel->Size = Drawing::Size(
        610, GUI_REGULAR_LABEL_HEIGHT);
    homeResultsLogPathLabel->BackColor = Color::Transparent;
    homeResultsLogPathLabel->TextAlign = Drawing::ContentAlignment::MiddleLeft;
    homeResultsLogPathLabel->MouseEnter +=
        gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_HomeResultsLogPathLabelMouseEntered);
    homeResultsLogPathLabel->MouseLeave +=
        gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_AnyObjectMouseExited);
    Controls->Add(homeResultsLogPathLabel);
    //--------------------------------------------------------------------
    // Operator Name label
    //--------------------------------------------------------------------
    Label ^homeOperatorNameLabel = gcnew Label;
    homeOperatorNameLabel->Text = _T("Operator: ");
    homeOperatorNameLabel->Location = Point(
        homeClearCommandDialogueButton->Left,
        this->Bottom - 84);
    homeOperatorNameLabel->Size = Drawing::Size(
        54, GUI_REGULAR_LABEL_HEIGHT);
    homeOperatorNameLabel->BackColor = Color::Transparent;
    homeOperatorNameLabel->TextAlign = Drawing::ContentAlignment::MiddleLeft;
    homeOperatorNameLabel->MouseEnter +=
        gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_HomeOperatorNameAreaMouseEntered);
    homeOperatorNameLabel->MouseLeave +=
        gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_AnyObjectMouseExited);
    Controls->Add(homeOperatorNameLabel);
    //--------------------------------------------------------------------
    // Operator Name text box
    //--------------------------------------------------------------------
    homeOperatorNameBox = gcnew TextBox;
    homeOperatorNameBox->Text = DTSTest_GeneralInfo->operatorName;
    homeOperatorNameBox->Location = Point(
        homeOperatorNameLabel->Right + 2,
        homeOperatorNameLabel->Top - 2);
    homeOperatorNameBox->Size = Drawing::Size(
        80,
        GUI_REGULAR_TEXT_BOX_HEIGHT);
    homeOperatorNameBox->Multiline = GUI_NO;
    homeOperatorNameBox->AcceptsReturn = GUI_NO;
    homeOperatorNameBox->AcceptsTab = GUI_NO;
    homeOperatorNameBox->WordWrap = GUI_NO;
    homeOperatorNameBox->TextAlign = HorizontalAlignment::Center;
    homeOperatorNameBox->BackColor = Color::White;
    homeOperatorNameBox->Validating +=
        gcnew CancelEventHandler(this, &DTSTest_GUIClass::DTSTest_ValidateHomeOperatorNameAddress);
    homeOperatorNameBox->MouseEnter +=
        gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_HomeOperatorNameAreaMouseEntered);
    homeOperatorNameBox->MouseLeave +=
        gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_AnyObjectMouseExited);
    Controls->Add(homeOperatorNameBox);
    //--------------------------------------------------------------------
    // Die Serial Number label
    //--------------------------------------------------------------------
    Label ^homeDieSerialNumberLabel = gcnew Label;
    homeDieSerialNumberLabel->Text = _T("Serial Number: ");
    homeDieSerialNumberLabel->Location = Point(
        homeOperatorNameBox->Right + 15,
        homeOperatorNameLabel->Top);
    homeDieSerialNumberLabel->Size = Drawing::Size(
        80, GUI_REGULAR_LABEL_HEIGHT);
    homeDieSerialNumberLabel->BackColor = Color::Transparent;
    homeDieSerialNumberLabel->TextAlign = Drawing::ContentAlignment::MiddleLeft;
    homeDieSerialNumberLabel->MouseEnter +=
        gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_HomeDieSerialNumberAreaMouseEntered);
    homeDieSerialNumberLabel->MouseLeave +=
        gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_AnyObjectMouseExited);
    Controls->Add(homeDieSerialNumberLabel);
    //--------------------------------------------------------------------
    // Die Serial Number text box
    //--------------------------------------------------------------------
    homeDieSerialNumberBox = gcnew TextBox;
    homeDieSerialNumberBox->Text = DTSTest_GeneralInfo->dieSerialNumber;
    homeDieSerialNumberBox->Location = Point(
        homeDieSerialNumberLabel->Right + 2,
        homeDieSerialNumberLabel->Top - 2);
    homeDieSerialNumberBox->Size = Drawing::Size(
        80,
        GUI_REGULAR_TEXT_BOX_HEIGHT);
    homeDieSerialNumberBox->Multiline = GUI_NO;
    homeDieSerialNumberBox->AcceptsReturn = GUI_NO;
    homeDieSerialNumberBox->AcceptsTab = GUI_NO;
    homeDieSerialNumberBox->WordWrap = GUI_NO;
    homeDieSerialNumberBox->TextAlign = HorizontalAlignment::Center;
    homeDieSerialNumberBox->BackColor = Color::White;
    homeDieSerialNumberBox->Validating +=
        gcnew CancelEventHandler(this, &DTSTest_GUIClass::DTSTest_ValidateHomeDieSerialNumberAddress);
    homeDieSerialNumberBox->MouseEnter +=
        gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_HomeDieSerialNumberAreaMouseEntered);
    homeDieSerialNumberBox->MouseLeave +=
        gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_AnyObjectMouseExited);
    Controls->Add(homeDieSerialNumberBox);
    //--------------------------------------------------------------------
    // Main script placeholder $1 label
    //--------------------------------------------------------------------
    Label ^homePlaceholder1Label = gcnew Label;
    homePlaceholder1Label->Text = _T("$1 = ");
    homePlaceholder1Label->Location = Point(
        homeDieSerialNumberBox->Right + 15,
        homeDieSerialNumberLabel->Top);
    homePlaceholder1Label->Size = Drawing::Size(
        26, GUI_REGULAR_LABEL_HEIGHT);
    homePlaceholder1Label->BackColor = Color::Transparent;
    homePlaceholder1Label->TextAlign = Drawing::ContentAlignment::MiddleLeft;
    homePlaceholder1Label->MouseEnter +=
        gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_HomePlaceholderAreaMouseEntered);
    homePlaceholder1Label->MouseLeave +=
        gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_AnyObjectMouseExited);
    Controls->Add(homePlaceholder1Label);
    //--------------------------------------------------------------------
    // Main script placeholder $1 text box
    //--------------------------------------------------------------------
    homePlaceholder1Box = gcnew TextBox;
    homePlaceholder1Box->Tag = 1;
    homePlaceholder1Box->Text = DTSTest_GeneralInfo->mainScript->placeholder1String;
    homePlaceholder1Box->Location = Point(
        homePlaceholder1Label->Right + 2,
        homeDieSerialNumberBox->Top);
    homePlaceholder1Box->Size = Drawing::Size(
        28, GUI_REGULAR_TEXT_BOX_HEIGHT);
    homePlaceholder1Box->Multiline = GUI_NO;
    homePlaceholder1Box->AcceptsReturn = GUI_NO;
    homePlaceholder1Box->AcceptsTab = GUI_NO;
    homePlaceholder1Box->WordWrap = GUI_NO;
    homePlaceholder1Box->TextAlign = HorizontalAlignment::Center;
    homePlaceholder1Box->BackColor = Color::White;
    homePlaceholder1Box->Validating +=
        gcnew CancelEventHandler(this, &DTSTest_GUIClass::DTSTest_ValidateHomePlaceholderValue);
    homePlaceholder1Box->MouseEnter +=
        gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_HomePlaceholderAreaMouseEntered);
    homePlaceholder1Box->MouseLeave +=
        gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_AnyObjectMouseExited);
    Controls->Add(homePlaceholder1Box);
    //--------------------------------------------------------------------
    // Main script placeholder $2 label
    //--------------------------------------------------------------------
    Label ^homePlaceholder2Label = gcnew Label;
    homePlaceholder2Label->Text = _T("$2 = ");
    homePlaceholder2Label->Location = Point(
        homePlaceholder1Box->Right + 15,
        homePlaceholder1Label->Top);
    homePlaceholder2Label->Size = homePlaceholder1Label->Size;
    homePlaceholder2Label->BackColor = Color::Transparent;
    homePlaceholder2Label->TextAlign = Drawing::ContentAlignment::MiddleLeft;
    homePlaceholder2Label->MouseEnter +=
        gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_HomePlaceholderAreaMouseEntered);
    homePlaceholder2Label->MouseLeave +=
        gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_AnyObjectMouseExited);
    Controls->Add(homePlaceholder2Label);
    //--------------------------------------------------------------------
    // Main script placeholder $2 text box
    //--------------------------------------------------------------------
    homePlaceholder2Box = gcnew TextBox;
    homePlaceholder2Box->Tag = 2;
    homePlaceholder2Box->Text = DTSTest_GeneralInfo->mainScript->placeholder2String;
    homePlaceholder2Box->Location = Point(
        homePlaceholder2Label->Right + 2,
        homePlaceholder1Box->Top);
    homePlaceholder2Box->Size = homePlaceholder1Box->Size;
    homePlaceholder2Box->Multiline = GUI_NO;
    homePlaceholder2Box->AcceptsReturn = GUI_NO;
    homePlaceholder2Box->AcceptsTab = GUI_NO;
    homePlaceholder2Box->WordWrap = GUI_NO;
    homePlaceholder2Box->TextAlign = HorizontalAlignment::Center;
    homePlaceholder2Box->BackColor = Color::White;
    homePlaceholder2Box->Validating +=
        gcnew CancelEventHandler(this, &DTSTest_GUIClass::DTSTest_ValidateHomePlaceholderValue);
    homePlaceholder2Box->MouseEnter +=
        gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_HomePlaceholderAreaMouseEntered);
    homePlaceholder2Box->MouseLeave +=
        gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_AnyObjectMouseExited);
    Controls->Add(homePlaceholder2Box);
    //------------------------------------------------------------------------
    // Demo Mode check box
    //------------------------------------------------------------------------
    homeDemoModeCheck = gcnew CheckBox;
    homeDemoModeCheck->Text = _T("Demo mode only");
    homeDemoModeCheck->Location = Point(this->Right - 230, this->Bottom - 86);
    homeDemoModeCheck->Size = Drawing::Size(
        110, GUI_REGULAR_CHECK_BOX_HEIGHT);
    GUI_SetObjectInterfaceProperties(homeDemoModeCheck);
    homeDemoModeCheck->Click +=
        gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_HomeDemoModeChecked);
    homeDemoModeCheck->MouseEnter +=
        gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_HomeDemoModeCheckMouseEntered);
    homeDemoModeCheck->MouseLeave +=
        gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_AnyObjectMouseExited);
    if (DTSTest_DemoModeEnabled)
        homeDemoModeCheck->Checked = GUI_YES;
    Controls->Add(homeDemoModeCheck);
    //------------------------------------------------------------------------
    // Exit button
    //------------------------------------------------------------------------
    homeExitButton = gcnew Button;
    homeExitButton->Text = _T("Exit");
    homeExitButton->Location = Point(this->Right - 100, this->Bottom - 90);
    homeExitButton->Size = Drawing::Size(
        GUI_CLOSE_BUTTON_WIDTH,
        GUI_REGULAR_BUTTON_HEIGHT);
    homeExitButton->BackgroundImage = gcnew Bitmap(GUI_BG_SAND, GUI_YES);
    homeExitButton->DialogResult = System::Windows::Forms::DialogResult::OK;
    GUI_DisplayHandCursorOnHover(homeExitButton);
    homeExitButton->Click +=
        gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_ExitProgram);
    homeExitButton->MouseEnter +=
        gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_HomeExitButtonMouseEntered);
    homeExitButton->MouseLeave +=
        gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_AnyObjectMouseExited);
    homeExitButton->Enabled = GUI_NO;
    Controls->Add(homeExitButton);
    //--------------------------------------------------------------------
    // Set the remaining window properties
    //--------------------------------------------------------------------
    this->AcceptButton = homeExitButton;
    this->CancelButton = homeExitButton;
    //------------------------------------------------------------------------
    // Finally, resume displaying the window
    //------------------------------------------------------------------------
    this->ResumeLayout();
    DTSTest_GeneralInfo->flags |= DTSTEST_GENERAL_GUI_READY_FOR_UPDATING;
    RecordBasicEvent("        {0} concluded", functionName);
}                                       // end of DTSTest_InstallHomeWindowGraphics()
//----------------------------------------------------------------------------
// DTSTest_InstallStatusStrip
//
// Displays the status strip (bottom status bar) in the home window
//
// Note:    A statusstrip is organized by the following hierarchy of classes:
//
//              StatusStrip
//              ToolStripStatusLabel / ToolStripSeparator / ToolStripProgressBar
//
// Called by:   DTSTest_ConstructHomeWindow
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_InstallStatusStrip(void)
{
    String          ^functionName = _T("DTSTest_InstallStatusStrip");
    //------------------------------------------------------------------------
    RecordVerboseEvent("        {0} called", functionName);
    this->SuspendLayout();
    homeStatusStrip = gcnew StatusStrip;
    //------------------------------------------------------------------------
    // Specify the status strip properties
    //------------------------------------------------------------------------
    homeStatusStrip->ShowItemToolTips = GUI_NO;
    homeStatusStrip->GripStyle = ToolStripGripStyle::Hidden;
    homeStatusStrip->SizingGrip = GUI_NO;
    homeStatusStrip->LayoutStyle = ToolStripLayoutStyle::Table;
    //------------------------------------------------------------------------
    // Create the left (main) panel
    //------------------------------------------------------------------------
    homeTSStatusLabel = gcnew ToolStripStatusLabel;
    homeTSStatusLabel->Spring = GUI_YES;
    homeTSStatusLabel->Alignment = ToolStripItemAlignment::Left;
    homeTSStatusLabel->BorderStyle = Border3DStyle::Sunken;
    homeTSStatusLabel->BorderSides = ToolStripStatusLabelBorderSides::All;
    homeTSStatusLabel->TextAlign = Drawing::ContentAlignment::MiddleLeft;
    homeStatusStrip->Items->Add(homeTSStatusLabel);
    //------------------------------------------------------------------------
    // Create the progress bar and label, then initialize it
    //------------------------------------------------------------------------
    ToolStripSeparator ^verticalSeparator1 = gcnew ToolStripSeparator;
    verticalSeparator1->Width = 4;
    homeStatusStrip->Items->Add(verticalSeparator1);
    homeTSProgressBar = gcnew ToolStripProgressBar;
    homeTSProgressBar->Minimum = 0;
    homeTSProgressBar->Maximum = 100;
    homeTSProgressBar->Style = ProgressBarStyle::Continuous;
    homeTSProgressBar->MouseEnter +=
        gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_HomeProgressBarMouseEntered);
    homeTSProgressBar->MouseLeave +=
        gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_AnyObjectMouseExited);
    homeStatusStrip->Items->Add(homeTSProgressBar);
    //------------------------------------------------------------------------
    // Create the right (time-of-day) panel
    //------------------------------------------------------------------------
    ToolStripSeparator ^verticalSeparator2 = gcnew ToolStripSeparator;
    verticalSeparator2->Width = 4;
    homeStatusStrip->Items->Add(verticalSeparator2);
    nowTSStatusLabel = gcnew ToolStripStatusLabel;
    nowTSStatusLabel->Alignment = ToolStripItemAlignment::Right;
    nowTSStatusLabel->BorderStyle = Border3DStyle::Sunken;
    nowTSStatusLabel->BorderSides = ToolStripStatusLabelBorderSides::All;
    homeStatusStrip->Items->Add(nowTSStatusLabel);
    //------------------------------------------------------------------------
    // Display and initialize the resulting status strip
    //------------------------------------------------------------------------
    Controls->Add(homeStatusStrip);
    this->ResumeLayout();
    DTSTest_GeneralInfo->flags |= DTSTEST_GENERAL_STATUS_LINE_AVAILABLE;
    RecordVerboseEvent("        {0} concluded", functionName);
}                                       // end of DTSTest_InstallStatusStrip()
//----------------------------------------------------------------------------
// DTSTest_InstallToolStrip
//
// Displays the tool strip (tool bar) in the home window
//
// Note:    A toolstrip is organized by the following hierarchy of classes:
//
//              ToolStrip
//              ToolStripDropDownButton
//              ToolStripDropDown
//              ToolStripButton
//
// Called by:   DTSTest_ConstructHomeWindow
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_InstallToolStrip(void)
{
    String          ^functionName = _T("DTSTest_InstallToolStrip");
    //------------------------------------------------------------------------
    RecordVerboseEvent("        {0} called", functionName);
    this->SuspendLayout();
    ToolStrip ^toolStrip = gcnew ToolStrip;
    //------------------------------------------------------------------------
    // Tool strip properties
    //------------------------------------------------------------------------
    Bitmap ^toolStripBG = gcnew Bitmap(GUI_BG_TOOLSTRIP, GUI_YES);
    toolStrip->ShowItemToolTips = GUI_NO;
    toolStrip->AutoSize = GUI_YES;
    toolStrip->Size = Drawing::Size(this->Width, 25);
    toolStrip->BackgroundImage = toolStripBG;
    //------------------------------------------------------------------------
    // Open drop-down 'button' for the File drop-down
    //------------------------------------------------------------------------
    ToolStripButton ^openFileTSButton = gcnew ToolStripButton("Open");
//    openFileTSButton->Click +=
//        gcnew EventHandler(this, &DTSTest_GUIClass::GUI_UtilImportCoefficientDataFileButtonClicked);
    openFileTSButton->Enabled = GUI_NO;
    //------------------------------------------------------------------------
    // SaveAs drop-down 'button' for the File drop-down
    //------------------------------------------------------------------------
    ToolStripButton ^saveAsFileTSButton = gcnew ToolStripButton("Save As . . .");
    saveAsFileTSButton->Click +=
        gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_HomeSaveCommandDialogueButtonClicked);
//    saveAsFileTSButton->Enabled = GUI_NO;
    //------------------------------------------------------------------------
    // Print drop-down 'button' for the File drop-down
    //------------------------------------------------------------------------
    ToolStripButton ^printFileTSButton = gcnew ToolStripButton("Print");
//    printFileTSButton->Click +=
//        gcnew EventHandler(this, &DTSTest_GUIClass::GUI_PrintFileButtonClicked);
    printFileTSButton->Enabled = GUI_NO;
    //------------------------------------------------------------------------
    // Config drop-down 'button' for the File drop-down
    //------------------------------------------------------------------------
    configFileSaveDontSaveTSButton = gcnew ToolStripButton;
    configFileSaveDontSaveTSButton->Text =
        (DTSTest_GeneralInfo->flags & DTSTEST_GENERAL_CONFIG_DONT_SAVE) ?
            GUI_ENABLE_CONFIG_SAVE_STRING : GUI_DISABLE_CONFIG_SAVE_STRING;
    configFileSaveDontSaveTSButton->Click +=
        gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_ConfigFileSaveDontSaveAreaClicked);
    configFileSaveDontSaveTSButton->MouseEnter +=
        gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_ConfigFileSaveDontSaveAreaMouseEntered);
    configFileSaveDontSaveTSButton->MouseLeave +=
        gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_AnyObjectMouseExited);
    //------------------------------------------------------------------------
    // Open drop-down 'button' for the File drop-down
    //------------------------------------------------------------------------
    ToolStripButton ^exitProgramTSButton = gcnew ToolStripButton("Exit DTSTest");
    exitProgramTSButton->Click +=
        gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_ExitProgram);
    exitProgramTSButton->MouseEnter +=
        gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_HomeExitButtonMouseEntered);
    exitProgramTSButton->MouseLeave +=
        gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_AnyObjectMouseExited);
    //------------------------------------------------------------------------
    // File toolstrip drop-down and its properties
    //------------------------------------------------------------------------
    ToolStripDropDown ^fileDropDown = gcnew ToolStripDropDown;
    fileDropDown->BackColor = Color::Wheat;
    fileDropDown->ShowItemToolTips = GUI_NO;
    fileDropDown->MouseLeave +=
        gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_ToolStripDropDownsMouseExited);
    //------------------------------------------------------------------------
    // Add the tool strip buttons to the File drop-down
    //------------------------------------------------------------------------
    array <ToolStripItem ^> ^fileDropDownItems =
    {
        openFileTSButton,
        saveAsFileTSButton,
        printFileTSButton,
        configFileSaveDontSaveTSButton,
        exitProgramTSButton
    };
    fileDropDown->Items->AddRange(fileDropDownItems);
    //------------------------------------------------------------------------
    // File toolstrip button as a drop-down
    //------------------------------------------------------------------------
    fileTSDDButton = gcnew ToolStripDropDownButton("File");
    fileTSDDButton->Tag = GUI_DROP_DOWN_CLOSED;
    fileTSDDButton->Font = gcnew Drawing::Font(
        FontFamily::GenericSansSerif,
        10.0F,
        FontStyle::Bold);
    fileTSDDButton->DropDown = fileDropDown;
    fileTSDDButton->ShowDropDownArrow = GUI_NO;
    fileTSDDButton->MouseEnter +=
        gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_ToolStripFileButtonMouseEntered);
    fileTSDDButton->MouseLeave +=
        gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_ToolStripButtonsMouseExited);
    fileTSDDButton->MouseMove +=
        gcnew MouseEventHandler(this, &DTSTest_GUIClass::DTSTest_ToolStripFileButtonMouseMoved);
    //------------------------------------------------------------------------
    // Expert Mode drop-down 'button' for the Control drop-down
    //------------------------------------------------------------------------
    expertFunctionTSButton = gcnew ToolStripButton;
    expertFunctionTSButton->Text =
        (DTSTest_GeneralInfo->flags & DTSTEST_GENERAL_EXPERT_MODE) ?
            GUI_DISABLE_EXPERT_MODE_STRING : GUI_ENABLE_EXPERT_MODE_STRING;
    expertFunctionTSButton->Click +=
        gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_ToolStripExpertModeDropDownClicked);
    expertFunctionTSButton->MouseEnter +=
        gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_ToolStripExpertModeDropDownMouseEntered);
    expertFunctionTSButton->MouseLeave +=
        gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_AnyObjectMouseExited);
//    //------------------------------------------------------------------------
//    // Script Controls drop-down 'button' for the Control drop-down
//    //------------------------------------------------------------------------
//    scriptControlsTSButton = gcnew ToolStripButton("Script Controls");
//    scriptControlsTSButton->Click +=
//        gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_ToolStripScriptControlsDropDownClicked);
//    scriptControlsTSButton->MouseEnter +=
//        gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_ToolStripScriptControlsDropDownMouseEntered);
//    scriptControlsTSButton->MouseLeave +=
//        gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_AnyObjectMouseExited);
//    scriptControlsTSButton->Enabled = GUI_NO;
    //------------------------------------------------------------------------
    // Testing drop-down 'button' for the Control drop-down
    //------------------------------------------------------------------------
    testingControlsTSButton = gcnew ToolStripButton("Testing Controls");
    testingControlsTSButton->Click +=
        gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_ToolStripTestingControlsDropDownClicked);
    testingControlsTSButton->MouseEnter +=
        gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_ToolStripTestingControlsDropDownMouseEntered);
    testingControlsTSButton->MouseLeave +=
        gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_AnyObjectMouseExited);
    testingControlsTSButton->Enabled = GUI_NO;
    //------------------------------------------------------------------------
    // Sampling Controls drop-down 'button' for the Control drop-down
    //------------------------------------------------------------------------
    samplingControlsTSButton = gcnew ToolStripButton("Sampling Controls");
    samplingControlsTSButton->Click +=
        gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_ToolStripSamplingControlsDropDownClicked);
    samplingControlsTSButton->MouseEnter +=
        gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_ToolStripSamplingControlsDropDownMouseEntered);
    samplingControlsTSButton->MouseLeave +=
        gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_AnyObjectMouseExited);
    samplingControlsTSButton->Enabled = GUI_NO;
    //------------------------------------------------------------------------
    // CSV File Controls drop-down 'button' for the Control drop-down
    //------------------------------------------------------------------------
    ToolStripButton ^CSVControlsTSButton = gcnew ToolStripButton("CSV File Controls");
    CSVControlsTSButton->Click +=
        gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_ToolStripCSVControlsDropDownClicked);
    CSVControlsTSButton->MouseEnter +=
        gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_ToolStripCSVControlsDropDownMouseEntered);
    CSVControlsTSButton->MouseLeave +=
        gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_AnyObjectMouseExited);
    //------------------------------------------------------------------------
    // Control drop-down and its properties
    //------------------------------------------------------------------------
    ToolStripDropDown ^controlDropDown = gcnew ToolStripDropDown;
    controlDropDown->BackColor = Color::Wheat;
    controlDropDown->ShowItemToolTips = GUI_NO;
//    controlDropDown->AutoClose = GUI_YES;
    controlDropDown->MouseLeave +=
        gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_ToolStripDropDownsMouseExited);
    //------------------------------------------------------------------------
    // Add the Control buttons to the Control drop-down
    //------------------------------------------------------------------------
    array <ToolStripItem ^> ^controlDropDownItems =
    {
//        scriptControlsTSButton,
        testingControlsTSButton,
        samplingControlsTSButton,
        CSVControlsTSButton,
        expertFunctionTSButton
    };
    controlDropDown->Items->AddRange(controlDropDownItems);
    //------------------------------------------------------------------------
    // Control toolstrip button as a drop-down
    //------------------------------------------------------------------------
    controlTSDDButton = gcnew ToolStripDropDownButton("Control");
    controlTSDDButton->Tag = GUI_DROP_DOWN_CLOSED;
    controlTSDDButton->Font = gcnew Drawing::Font(
        FontFamily::GenericSansSerif,
        10.0F,
        FontStyle::Bold);
    controlTSDDButton->DropDown = controlDropDown;
    controlTSDDButton->ShowDropDownArrow = GUI_NO;
    controlTSDDButton->MouseEnter +=
        gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_ToolStripControlButtonMouseEntered);
    controlTSDDButton->MouseLeave +=
        gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_ToolStripButtonsMouseExited);
    controlTSDDButton->MouseMove +=
        gcnew MouseEventHandler(this, &DTSTest_GUIClass::DTSTest_ToolStripControlButtonMouseMoved);
    //------------------------------------------------------------------------
    // About drop-down 'button' for the Help drop-down
    //------------------------------------------------------------------------
    ToolStripButton ^aboutTSButton = gcnew ToolStripButton("About DTSTest");
    aboutTSButton->Click +=
        gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_ToolStripAboutDropDownClicked);
    aboutTSButton->MouseEnter +=
        gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_ToolStripAboutDropDownMouseEntered);
    aboutTSButton->MouseLeave +=
        gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_AnyObjectMouseExited);
    //------------------------------------------------------------------------
    // OnlineHelp drop-down 'button' for the Help drop-down
    //------------------------------------------------------------------------
    ToolStripButton ^onlineHelpTSButton = gcnew ToolStripButton("Online Help");
    onlineHelpTSButton->Click +=
        gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_ToolStripOnlineHelpDropDownClicked);
    onlineHelpTSButton->MouseEnter +=
        gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_ToolStripOnlineHelpDropDownMouseEntered);
    onlineHelpTSButton->MouseLeave +=
        gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_AnyObjectMouseExited);
    //------------------------------------------------------------------------
    // Support Log drop-down 'button' for the Help drop-down
    //------------------------------------------------------------------------
    ToolStripButton ^supportLogTSButton = gcnew ToolStripButton("Create a Support Log");
    supportLogTSButton->Click +=
        gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_ToolStripSupportLogDropDownClicked);
    supportLogTSButton->MouseEnter +=
        gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_ToolStripSupportLogDropDownMouseEntered);
    supportLogTSButton->MouseLeave +=
        gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_AnyObjectMouseExited);
    //------------------------------------------------------------------------
    // Check For Update drop-down 'button' for the Help drop-down
    //------------------------------------------------------------------------
    ToolStripButton ^checkForUpdateTSButton = gcnew ToolStripButton("Check for Update");
    checkForUpdateTSButton->Click +=
        gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_ToolStripCheckForUpdateDropDownClicked);
    checkForUpdateTSButton->MouseEnter +=
        gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_ToolStripCheckForUpdateDropDownMouseEntered);
    checkForUpdateTSButton->MouseLeave +=
        gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_AnyObjectMouseExited);
    checkForUpdateTSButton->Enabled = GUI_NO;
    //------------------------------------------------------------------------
    // Help toolstrip drop-down and its properties
    //------------------------------------------------------------------------
    helpTSDropDown = gcnew ToolStripDropDown;
    helpTSDropDown->BackColor = Color::Wheat;
    helpTSDropDown->ShowItemToolTips = GUI_NO;
    helpTSDropDown->MouseLeave +=
        gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_ToolStripDropDownsMouseExited);
    //------------------------------------------------------------------------
    // Add these entries to the Help drop-down
    //------------------------------------------------------------------------
    array <ToolStripItem ^> ^helpTSDropDownItems =
    {
        aboutTSButton,
        onlineHelpTSButton,
        supportLogTSButton,
        checkForUpdateTSButton
    };
    helpTSDropDown->Items->AddRange(helpTSDropDownItems);
    //------------------------------------------------------------------------
    // Help toolstrip button as a drop-down
    //------------------------------------------------------------------------
    helpTSDDButton = gcnew ToolStripDropDownButton("Help");
    helpTSDDButton->Tag = GUI_DROP_DOWN_CLOSED;
    helpTSDDButton->Font = gcnew Drawing::Font(
        FontFamily::GenericSansSerif,
        10.0F,
        FontStyle::Bold);
    helpTSDDButton->DropDown = helpTSDropDown;
    helpTSDDButton->ShowDropDownArrow = GUI_NO;
    helpTSDDButton->MouseEnter +=
        gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_ToolStripHelpButtonMouseEntered);
    helpTSDDButton->MouseLeave +=
        gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_ToolStripButtonsMouseExited);
    helpTSDDButton->MouseMove +=
        gcnew MouseEventHandler(this, &DTSTest_GUIClass::DTSTest_ToolStripHelpButtonMouseMoved);
    //------------------------------------------------------------------------
    // Log All Events drop-down 'button' for the Advanced drop-down
    //------------------------------------------------------------------------
    eventLogAllTSButton = gcnew ToolStripButton;
    eventLogAllTSButton->Text =
        (DTSTest_EventLogBasicEnabled || DTSTest_EventLogVerboseEnabled || DTSTest_EventLogDetailedEnabled) ?
            GUI_ELOG_ALL_STOP_STRING : GUI_ELOG_ALL_START_STRING;
    eventLogAllTSButton->Click +=
        gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_ToolStripEventLogAllDropDownClicked);
    eventLogAllTSButton->MouseEnter +=
        gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_ToolStripEventLogAllDropDownMouseEntered);
    eventLogAllTSButton->MouseLeave +=
        gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_AnyObjectMouseExited);
    //------------------------------------------------------------------------
    // Log Basic Events drop-down 'button' for the Advanced drop-down
    //------------------------------------------------------------------------
    eventLogBasicTSButton = gcnew ToolStripButton;
    eventLogBasicTSButton->Text =
        DTSTest_EventLogBasicEnabled ?
            GUI_ELOG_BASIC_STOP_STRING : GUI_ELOG_BASIC_START_STRING;
    eventLogBasicTSButton->Click +=
        gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_ToolStripEventLogBasicDropDownClicked);
    eventLogBasicTSButton->MouseEnter +=
        gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_ToolStripEventLogBasicDropDownMouseEntered);
    eventLogBasicTSButton->MouseLeave +=
        gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_AnyObjectMouseExited);
    //------------------------------------------------------------------------
    // Log Verbose Events drop-down 'button' for the Advanced drop-down
    //------------------------------------------------------------------------
    eventLogVerboseTSButton = gcnew ToolStripButton;
    eventLogVerboseTSButton->Text =
        DTSTest_EventLogVerboseEnabled ?
            GUI_ELOG_VERBOSE_STOP_STRING : GUI_ELOG_VERBOSE_START_STRING;
    eventLogVerboseTSButton->Click +=
        gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_ToolStripEventLogVerboseDropDownClicked);
    eventLogVerboseTSButton->MouseEnter +=
        gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_ToolStripEventLogVerboseDropDownMouseEntered);
    eventLogVerboseTSButton->MouseLeave +=
        gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_AnyObjectMouseExited);
    //------------------------------------------------------------------------
    // Log Detailed Events drop-down 'button' for the Advanced drop-down
    //------------------------------------------------------------------------
    eventLogDetailedTSButton = gcnew ToolStripButton;
    eventLogDetailedTSButton->Text =
        DTSTest_EventLogDetailedEnabled ?
            GUI_ELOG_DETAILED_STOP_STRING : GUI_ELOG_DETAILED_START_STRING;
    eventLogDetailedTSButton->Click +=
        gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_ToolStripEventLogDetailedDropDownClicked);
    eventLogDetailedTSButton->MouseEnter +=
        gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_ToolStripEventLogDetailedDropDownMouseEntered);
    eventLogDetailedTSButton->MouseLeave +=
        gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_AnyObjectMouseExited);
    //------------------------------------------------------------------------
    // Event Log drop-down and its properties
    //------------------------------------------------------------------------
    ToolStripDropDown ^eventLogDropDown = gcnew ToolStripDropDown;
    eventLogDropDown->BackColor = Color::Wheat;
    eventLogDropDown->ShowItemToolTips = GUI_NO;
    eventLogDropDown->MouseLeave +=
        gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_ToolStripEventLogDropDownMouseExited);
    //------------------------------------------------------------------------
    // Add these entries to the Event Log drop-down
    //------------------------------------------------------------------------
    array <ToolStripItem ^> ^eventLogDropDownItems =
    {
        eventLogAllTSButton,
        eventLogBasicTSButton,
        eventLogVerboseTSButton,
        eventLogDetailedTSButton
    };
    eventLogDropDown->Items->AddRange(eventLogDropDownItems);
    //------------------------------------------------------------------------
    // Program Info drop-down 'button' for the Advanced drop-down
    //------------------------------------------------------------------------
    programInfoTSButton = gcnew ToolStripButton("Program Information");
    programInfoTSButton->Click +=
        gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_ToolStripProgInfoDropDownClicked);
    programInfoTSButton->MouseEnter +=
        gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_ToolStripProgInfoDropDownMouseEntered);
    programInfoTSButton->MouseLeave +=
        gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_AnyObjectMouseExited);
    programInfoTSButton->Enabled = GUI_NO;
    //------------------------------------------------------------------------
    // Experimental Controls drop-down 'button' for the Advanced drop-down
    //------------------------------------------------------------------------
    experimentalControlsTSButton = gcnew ToolStripButton("Experimental Controls");
    experimentalControlsTSButton->Click +=
        gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_ToolStripExperimentalControlsDropDownClicked);
    experimentalControlsTSButton->MouseEnter +=
        gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_ToolStripExperimentalControlsDropDownMouseEntered);
    experimentalControlsTSButton->MouseLeave +=
        gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_AnyObjectMouseExited);
    experimentalControlsTSButton->Enabled = GUI_NO;
    //------------------------------------------------------------------------
    // Advanced Controls drop-down 'button' for the Advanced drop-down
    //------------------------------------------------------------------------
    advancedControlsTSButton = gcnew ToolStripButton("Advanced Controls");
    advancedControlsTSButton->Click +=
        gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_ToolStripAdvancedControlsDropDownClicked);
    advancedControlsTSButton->MouseEnter +=
        gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_ToolStripAdvancedControlsDropDownMouseEntered);
    advancedControlsTSButton->MouseLeave +=
        gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_AnyObjectMouseExited);
    advancedControlsTSButton->Enabled = GUI_NO;
    //------------------------------------------------------------------------
    // Event Log Recording toolstrip button as a sub-drop-down
    //------------------------------------------------------------------------
    eventLogRecordingTSDDButton = gcnew ToolStripDropDownButton("Event Log Recording");
    eventLogRecordingTSDDButton->DropDown = eventLogDropDown;
    eventLogRecordingTSDDButton->ShowDropDownArrow = GUI_NO;
    eventLogRecordingTSDDButton->MouseEnter +=
        gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_ToolStripEventLogDropDownMouseEntered);
    eventLogRecordingTSDDButton->MouseLeave +=
        gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_AnyObjectMouseExited);
    //------------------------------------------------------------------------
    // Display Event Log drop-down 'button' for the Advanced drop-down
    //------------------------------------------------------------------------
    displayEventLogTSButton = gcnew ToolStripButton("Display Last Event Log");
    displayEventLogTSButton->Click +=
        gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_ToolStripDisplayEventLogDropDownClicked);
    displayEventLogTSButton->MouseEnter +=
        gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_ToolStripDisplayEventLogDropDownMouseEntered);
    displayEventLogTSButton->MouseLeave +=
        gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_AnyObjectMouseExited);
    //------------------------------------------------------------------------
    // Advanced toolstrip drop-down and its properties
    //------------------------------------------------------------------------
    ToolStripDropDown ^advancedDropDown = gcnew ToolStripDropDown;
    advancedDropDown->BackColor = Color::Wheat;
    advancedDropDown->ShowItemToolTips = GUI_NO;
    advancedDropDown->MouseLeave +=
        gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_ToolStripDropDownsMouseExited);
    //------------------------------------------------------------------------
    // Add these entries to the Advanced drop-down
    //------------------------------------------------------------------------
    array <ToolStripItem ^> ^advancedDropDownItems =
    {
        programInfoTSButton,
        experimentalControlsTSButton,
        advancedControlsTSButton,
        eventLogRecordingTSDDButton,
        displayEventLogTSButton
    };
    advancedDropDown->Items->AddRange(advancedDropDownItems);
    //------------------------------------------------------------------------
    // Advanced toolstrip button as a drop-down
    //------------------------------------------------------------------------
    advancedTSDDButton = gcnew ToolStripDropDownButton("Advanced");
    advancedTSDDButton->Tag = GUI_DROP_DOWN_CLOSED;
    advancedTSDDButton->Font = gcnew Drawing::Font(
        FontFamily::GenericSansSerif,
        10.0F,
        FontStyle::Bold);
    advancedTSDDButton->DropDown = advancedDropDown;
    advancedTSDDButton->ShowDropDownArrow = GUI_NO;
    advancedTSDDButton->MouseEnter +=
        gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_ToolStripAdvancedButtonMouseEntered);
    advancedTSDDButton->MouseLeave +=
        gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_ToolStripButtonsMouseExited);
    advancedTSDDButton->MouseMove +=
        gcnew MouseEventHandler(this, &DTSTest_GUIClass::DTSTest_ToolStripAdvancedButtonMouseMoved);
    advancedTSDDButton->Visible =
        (DTSTest_GeneralInfo->flags & DTSTEST_GENERAL_EXPERT_MODE) ?
            GUI_YES : GUI_NO;
    //------------------------------------------------------------------------
    // Attach the components to the tool strip
    //------------------------------------------------------------------------
    array <ToolStripDropDownButton ^> ^toolStripButtons =
    {
        fileTSDDButton,
        controlTSDDButton,
        helpTSDDButton,
        advancedTSDDButton
     };
    toolStrip->Items->AddRange(toolStripButtons);
    //------------------------------------------------------------------------
    // Display the resulting tool strip
    //------------------------------------------------------------------------
    Controls->Add(toolStrip);
    this->ResumeLayout();
    RecordVerboseEvent("        {0} concluded", functionName);
}                                       // end of DTSTest_InstallToolStrip()
//----------------------------------------------------------------------------
// DTSTest_LoadImagesAndSounds
//
// Initializes the background image pointers
//
// Called by:   DTSTest_Start
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_LoadImagesAndSounds(void)
{
    String          ^functionName = _T("DTSTest_LoadImagesAndSounds");
    //------------------------------------------------------------------------
    RecordVerboseEvent("    {0} called", functionName);
    //------------------------------------------------------------------------
    // Install the program icon
    //------------------------------------------------------------------------
    if (File::Exists(GUI_PROGRAM_ICON))
        DTSTest_SoftwareIcon = gcnew Drawing::Icon(GUI_PROGRAM_ICON);
    else
        DTSTest_RecordAndModalErrorEvent(
            "{0} : File {1} is missing",
            functionName, GUI_PROGRAM_ICON);
    //------------------------------------------------------------------------
    // Install the backgrounds
    //------------------------------------------------------------------------
    if (File::Exists(GUI_BG_SAND))
        sandBackground = gcnew Bitmap(GUI_BG_SAND, GUI_YES);
    else
        DTSTest_RecordAndModalErrorEvent(
            "{0} : File {1} is missing",
            functionName, GUI_BG_SAND);
    if (File::Exists(GUI_BG_WHITE_MARBLE))
        whiteMarbleBackground = gcnew Bitmap(GUI_BG_WHITE_MARBLE, GUI_YES);
    else
        DTSTest_RecordAndModalErrorEvent(
            "{0} : File {1} is missing",
            functionName, GUI_BG_WHITE_MARBLE);
    if (File::Exists(GUI_BG_WHITE_SAND))
        whiteSandBackground = gcnew Bitmap(GUI_BG_WHITE_SAND, GUI_YES);
    else
        DTSTest_RecordAndModalErrorEvent(
            "{0} : File {1} is missing",
            functionName, GUI_BG_WHITE_SAND);
    //------------------------------------------------------------------------
    // Install images
    //------------------------------------------------------------------------
    if (File::Exists(GUI_IMAGE_BLUE_DOT_OFF))
        blueDotOffImage = gcnew Bitmap(Image::FromFile(GUI_IMAGE_BLUE_DOT_OFF), 14, 14);
    else
        RecordErrorEvent("    File {0} is missing", GUI_IMAGE_BLUE_DOT_OFF);
    if (File::Exists(GUI_IMAGE_BLUE_DOT_ON))
        blueDotOnImage = gcnew Bitmap(Image::FromFile(GUI_IMAGE_BLUE_DOT_ON), 14, 14);
    else
        RecordErrorEvent("    File {0} is missing", GUI_IMAGE_BLUE_DOT_ON);
    if (File::Exists(GUI_IMAGE_GREEN_DOT_OFF))
        greenDotOffImage = gcnew Bitmap(Image::FromFile(GUI_IMAGE_GREEN_DOT_OFF), 14, 14);
    else
        RecordErrorEvent("    File {0} is missing", GUI_IMAGE_GREEN_DOT_OFF);
    if (File::Exists(GUI_IMAGE_GREEN_DOT_ON))
        greenDotOnImage = gcnew Bitmap(Image::FromFile(GUI_IMAGE_GREEN_DOT_ON), 14, 14);
    else
        RecordErrorEvent("    File {0} is missing", GUI_IMAGE_GREEN_DOT_ON);
    if (File::Exists(GUI_IMAGE_RED_DOT_OFF))
        redDotOffImage = gcnew Bitmap(Image::FromFile(GUI_IMAGE_RED_DOT_OFF), 14, 14);
    else
        RecordErrorEvent("    File {0} is missing", GUI_IMAGE_RED_DOT_OFF);
    if (File::Exists(GUI_IMAGE_RED_DOT_ON))
        redDotOnImage = gcnew Bitmap(Image::FromFile(GUI_IMAGE_RED_DOT_ON), 14, 14);
    else
        RecordErrorEvent("    File {0} is missing", GUI_IMAGE_RED_DOT_ON);
    if (File::Exists(GUI_IMAGE_YELLOW_LED_OFF))
        yellowLEDOffImage = gcnew Bitmap(GUI_IMAGE_YELLOW_LED_OFF, GUI_YES);
    else
        RecordErrorEvent("    File {0} is missing", GUI_IMAGE_YELLOW_LED_OFF);
    if (File::Exists(GUI_IMAGE_YELLOW_LED_ON))
        yellowLEDOnImage = gcnew Bitmap(GUI_IMAGE_YELLOW_LED_ON, GUI_YES);
    else
        RecordErrorEvent("    File {0} is missing", GUI_IMAGE_YELLOW_LED_ON);
    //------------------------------------------------------------------------
    // Install the sounds
    //------------------------------------------------------------------------
    if (File::Exists(GUI_SOUND_DOWN))
    {
        downSound = gcnew Media::SoundPlayer(GUI_SOUND_DOWN);
        downSound->Load();
    }
    else
        DTSTest_RecordAndModalErrorEvent(
            "{0} : File {1} is missing",
            functionName, GUI_SOUND_DOWN);
    if (File::Exists(GUI_SOUND_ERROR))
    {
        errorSound = gcnew Media::SoundPlayer(GUI_SOUND_ERROR);
        errorSound->Load();
    }
    else
        DTSTest_RecordAndModalErrorEvent(
            "{0} : File {1} is missing",
            functionName, GUI_SOUND_ERROR);
    if (File::Exists(GUI_SOUND_OPEN))
    {
        openSound = gcnew Media::SoundPlayer(GUI_SOUND_OPEN);
        openSound->Load();
    }
    else
        DTSTest_RecordAndModalErrorEvent(
            "{0} : File {1} is missing",
            functionName, GUI_SOUND_OPEN);
    if (File::Exists(GUI_SOUND_TADA))
    {
        tadaSound = gcnew Media::SoundPlayer(GUI_SOUND_TADA);
        tadaSound->Load();
    }
    else
        DTSTest_RecordAndModalErrorEvent(
            "{0} : File {1} is missing",
            functionName, GUI_SOUND_TADA);
    RecordVerboseEvent("    {0} concluded", functionName);
}                                       // end of DTSTest_LoadImagesAndSounds()
//----------------------------------------------------------------------------
// DTSTest_SetCalculateCRCs
//
// Enables or disables automatic CRC calculation
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_SetCalculateCRCs(
    bool            enableCRCCalculation)
{
    String          ^functionName = _T("DTSTest_SetCalculateCRCs");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0} called", functionName);
    if (enableCRCCalculation)
    {
        DTSTest_CalculateCRCs = GUI_YES;
        testingCRCLEDLabel->Image = greenDotOnImage;
        homeCalculateCRCsCheck->Checked = GUI_YES;
        RecordBasicEvent("    Automatic CRC Calculation enabled");
    }
    else
    {
        DTSTest_CalculateCRCs = GUI_NO;
        testingCRCLEDLabel->Image = greenDotOffImage;
        homeCalculateCRCsCheck->Checked = GUI_NO;
        RecordBasicEvent("    Automatic CRC Calculation disabled");
    }
    RecordBasicEvent("{0} concluded", functionName);
}                                       // end of DTSTest_SetCalculateCRCs()
//----------------------------------------------------------------------------
// DTSTest_SetDisplayBaudRate
//
// Updates the various display objects according to the specified baud rate
//
// Called by:   DTSTest_SwitchBaudRate
//              DTSTest_TestingBaudRate1200RadioSelected
//              DTSTest_TestingBaudRate2400RadioSelected
//              DTSTest_TestingBaudRate4800RadioSelected
//              DTSTest_TestingBaudRate600RadioSelected
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_SetDisplayBaudRate(
    int             targetBaudRate)
{
    bool            baudRateIsValid = GUI_YES;
    DWORD           status = DTSTEST_SUCCESS;
    String          ^functionName = _T("DTSTest_SetDisplayBaudRate");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0}({1:D}) called", functionName, targetBaudRate);
    PDGICInfo ^pgInfo = DTSTest_GeneralInfo->pgInfo;
    this->Cursor = Cursors::WaitCursor;
    switch (targetBaudRate)
    {
        case 1200 :
            testingBaudRate1200Radio->Checked = GUI_YES;
            break;
        case 2400 :
            testingBaudRate2400Radio->Checked = GUI_YES;
            break;
        case 4800 :
            testingBaudRate4800Radio->Checked = GUI_YES;
            break;
        case 600 :
            testingBaudRate600Radio->Checked = GUI_YES;
            break;
        default :
            baudRateIsValid = GUI_NO;
            break;
    }
    if (baudRateIsValid)
    {
        status = DTSTest_PDGICSetDTSSystemBaudRate(pgInfo, targetBaudRate);
        if (status == DTSTEST_SUCCESS)
        {
            DTSTest_BaudRateSetTo2400 = (targetBaudRate == 2400) ? GUI_YES : GUI_NO;
            switch (targetBaudRate)
            {
                case 1200 :
                    homeSwitchBaudRateButton->Text = _T("Switch to 2400 Baud");
                    homeBaudRateLabel->Text = _T("1200 Baud");
                    testingBaudRate1200Radio->Checked = GUI_YES;
                    break;
                case 2400 :
                    homeSwitchBaudRateButton->Text = _T("Switch to 1200 Baud");
                    homeBaudRateLabel->Text = _T("2400 Baud");
                    testingBaudRate2400Radio->Checked = GUI_YES;
                    break;
                case 4800 :
                    homeSwitchBaudRateButton->Text = _T("Switch to 1200 Baud");
                    homeBaudRateLabel->Text = _T("4800 Baud");
                    testingBaudRate4800Radio->Checked = GUI_YES;
                    break;
                case 600 :
                    homeSwitchBaudRateButton->Text = _T("Switch to 1200 Baud");
                    homeBaudRateLabel->Text = _T("600 Baud");
                    testingBaudRate600Radio->Checked = GUI_YES;
                    break;
                default :
//                    baudRateIsValid = GUI_NO;
                    break;
            }
            pgInfo->baudRate = targetBaudRate;
            RecordBasicEvent("    Baud Rate successfully set to {0:D}", targetBaudRate);
        }
        else
        {
            Modal("{0} failed with 0x{1:X8}", functionName, status);
            RecordBasicEvent("    Baud Rate set to {0:D} failed", targetBaudRate);
        }
    }
    else
        RecordBasicEvent("    Invalid baud rate {0:D} set attempted", targetBaudRate);
    this->Cursor = Cursors::Default;
    RecordBasicEvent("{0} concluded", functionName);
}                                       // end of DTSTest_SetDisplayBaudRate()
//----------------------------------------------------------------------------
// DTSTest_SetNormalizeMeasurements
//
// Enables or disables measurement (pressure and temperature) normalization
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_SetNormalizeMeasurements(
    bool            enableNormalizeMeasurements)
{
    String          ^functionName = _T("DTSTest_SetNormalizeMeasurements");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0} called", functionName);
    if (enableNormalizeMeasurements)
    {
        DTSTest_NormalizeReadings = GUI_YES;
        testingNormalizeLEDLabel->Image = greenDotOnImage;
        homeNormalizeReadingsCheck->Checked = GUI_YES;
        RecordBasicEvent("    Measurement Normalization enabled");
    }
    else
    {
        DTSTest_NormalizeReadings = GUI_NO;
        testingNormalizeLEDLabel->Image = greenDotOffImage;
        homeNormalizeReadingsCheck->Checked = GUI_NO;
        RecordBasicEvent("    Measurement Normalization disabled");
    }
    RecordBasicEvent("{0} concluded", functionName);
}                                       // end of DTSTest_SetNormalizeMeasurements()
//----------------------------------------------------------------------------
// DTSTest_SetSync
//
// Enables or disables sync
//
// Called by:   DTSTest_SendCommandArray
//              DTSTest_ToggleSync
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_SetSync(
    bool            enableSync,
    bool            testingContext)
{
    String          ^functionName = _T("DTSTest_SetSync");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0} called", functionName);
    if (enableSync)
    {
        if (DTSTest_SyncEnabled)
            RecordBasicEvent("    Sync still set");
        else
        {
            DTSTest_SyncEnabled = GUI_YES;
            testingSyncLEDLabel->Image = greenDotOnImage;
            DTSTest_SendSync(testingContext);
            RecordBasicEvent("    Sync now set");
        }
    }
    else
    {
        if (DTSTest_SyncEnabled)
        {
            DTSTest_SyncEnabled = GUI_NO;
            testingSyncLEDLabel->Image = greenDotOffImage;
            RecordBasicEvent("    Sync no longer set");
        }
        else
            RecordBasicEvent("    Sync was NOT set");
    }
    RecordBasicEvent("{0} concluded", functionName);
}                                       // end of DTSTest_SetSync()
//----------------------------------------------------------------------------
// DTSTest_ToggleCalculateCRCs
//
// Toggle to enable or disable automatic CRC calculation
//
// Called by:   DTSTest_HomeCalculateCRCsChecked
//              DTSTest_TestingCalculateCRCsClicked
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_ToggleCalculateCRCs(void)
{
    String          ^functionName = _T("DTSTest_ToggleCalculateCRCs");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0} called", functionName);
    if (DTSTest_CalculateCRCs)
        DTSTest_SetCalculateCRCs(GUI_NO);
    else
        DTSTest_SetCalculateCRCs(GUI_YES);
    RecordBasicEvent("{0} concluded", functionName);
}                                       // end of DTSTest_ToggleCalculateCRCs()
//----------------------------------------------------------------------------
// DTSTest_ToggleNormalizeMeasurements
//
// Toggle to enable or disable measurement normalization
//
// Called by:   DTSTest_HomeNormalizeReadingsChecked
//              DTSTest_TestingNormalizeClicked
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_ToggleNormalizeMeasurements(void)
{
    String          ^functionName = _T("DTSTest_ToggleNormalizeMeasurements");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0} called", functionName);
    if (DTSTest_NormalizeReadings)
        DTSTest_SetNormalizeMeasurements(GUI_NO);
    else
        DTSTest_SetNormalizeMeasurements(GUI_YES);
    RecordBasicEvent("{0} concluded", functionName);
}                                       // end of DTSTest_ToggleNormalizeMeasurements()
//----------------------------------------------------------------------------
// DTSTest_ToggleSync
//
// Toggle to enable or disable sync
//
// Called by:   DTSTest_TestingSyncClicked
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_ToggleSync(void)
{
    String          ^functionName = _T("DTSTest_ToggleSync");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0} called", functionName);
    bool testingContext = GUI_YES;
    if (DTSTest_SyncEnabled)
        DTSTest_SetSync(GUI_NO, testingContext);
    else
        DTSTest_SetSync(GUI_YES, testingContext);
    RecordBasicEvent("{0} concluded", functionName);
}                                       // end of DTSTest_ToggleSync()
//----------------------------------------------------------------------------
// DTSTest_ToggleExpertMode
//
// Toggle to enable or disable Expert Mode
//
// Called by:   DTSTest_ToolStripExpertModeDropDownClicked
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_ToggleExpertMode(void)
{
    String          ^functionName = _T("DTSTest_ToggleExpertMode");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0} called", functionName);
    if (DTSTest_GeneralInfo->flags & DTSTEST_GENERAL_EXPERT_MODE)
    {
        DTSTest_GeneralInfo->flags &= ~DTSTEST_GENERAL_EXPERT_MODE;
        expertFunctionTSButton->Text = GUI_ENABLE_EXPERT_MODE_STRING;
        advancedTSDDButton->Visible = GUI_NO;
        RecordBasicEvent("    Expert Mode disabled");
    }
    else
    {
        DTSTest_GeneralInfo->flags |= DTSTEST_GENERAL_EXPERT_MODE;
        expertFunctionTSButton->Text = GUI_DISABLE_EXPERT_MODE_STRING;
        advancedTSDDButton->Visible = GUI_YES;
        DTSTest_UpdateMessageChecks();
        RecordBasicEvent("    Expert Mode enabled");
    }
    RecordBasicEvent("{0} concluded", functionName);
}                                       // end of DTSTest_ToggleExpertMode()
//----------------------------------------------------------------------------
// DTSTest_UpdateHomeFields
//
// Updates the variable objects in the Home window
//
// Called by:   DTSTest_InitializeUserInterface
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_UpdateHomeFields(void)
{
    String          ^functionName = _T("DTSTest_UpdateHomeFields");
    //------------------------------------------------------------------------
    RecordDetailedEvent("{0} called", functionName);
    if (DTSTest_GeneralInfo->pgInfo)
    {
        PDGICInfo ^pgInfo = DTSTest_GeneralInfo->pgInfo;
        if (pgInfo->PDGICPresent && pgInfo->firmwareVersion)
        {
        }                               // end of if (pgInfo->PDGICPresent && pgInfo->firmwareVersion)
        else
        {
        }
    }                                   // end of if (DTSTest_GeneralInfo->pgInfo)
    else
    {
    }
    RecordBasicEvent("{0} concluded", functionName);
}                                       // end of DTSTest_UpdateHomeFields()
//----------------------------------------------------------------------------
// DTSTest_UpdateHomeProgressBar
//
// Updates the home progress bar with the specified whole number percentage,
// calculated from the numbers of items completed out of the items to complete
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_UpdateHomeProgressBar(
    DWORD           itemsCompleted,
    DWORD           itemsToComplete)
{
    int             percentComplete = 0;
    String          ^functionName = _T("DTSTest_UpdateHomeProgressBar");
    //------------------------------------------------------------------------
    if (DTSTest_GeneralInfo->flags & DTSTEST_GENERAL_STATUS_LINE_AVAILABLE)
    {
        if (itemsToComplete)
        {
            percentComplete = DTSTest_CalculatePercentage(
                itemsCompleted,
                itemsToComplete);
        }
        if ((percentComplete <= 100) && (itemsCompleted <= itemsToComplete))
        {
            if (homeTSProgressBar && homeStatusStrip)
            {
                //------------------------------------------------------------
                // Set the bar to 100% to erase the previous percentage value,
                // then display the actual percentage bar
                //------------------------------------------------------------
                homeTSProgressBar->Value = 100;
                homeTSProgressBar->Value = percentComplete;
                //------------------------------------------------------------
                // Display the percentage string by creating a graphic, but
                // only for nonzero percentage values
                //------------------------------------------------------------
                if (percentComplete)
                {
                    Graphics ^percentGraphics = homeTSProgressBar->ProgressBar->CreateGraphics();
                    String ^percentString = String::Concat(percentComplete, _T("%"));
                    percentGraphics->DrawString(
                        percentString,
                        SystemFonts::DefaultFont,
                        Brushes::Black,
                        PointF(
                            (homeTSProgressBar->Width / 2) - (percentGraphics->MeasureString(percentString, SystemFonts::DefaultFont).Width / 2.0F),
                            (homeTSProgressBar->Height / 2) - (percentGraphics->MeasureString(percentString, SystemFonts::DefaultFont).Height / 2.0F)));
                }
                homeStatusStrip->Update();
                Thread::Sleep(10);
            }
        }
        else
        {
            GUI_DisplaySimpleError(
                functionName,
                String::Format(
                    "Home progress percentage out of range:\n"
                    "Completed = {0:D} to complete = {1:D}",
                    itemsCompleted,
                    itemsToComplete));
        }
    }
}                                       // end of DTSTest_UpdateHomeProgressBar()
//----------------------------------------------------------------------------
// DTSTest_UpdateHomeStatusLine
//
// Updates the home status strip message box with the specified string
//
// Note:    The status line can hold at most GUI_MAXIMUM_STATUS_LINE_PIXEL_SIZE
//          (400) pixels of text
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_UpdateHomeStatusLine(
    String          ^statusString)
{
    //------------------------------------------------------------------------
    if (DTSTest_GeneralInfo->flags & DTSTEST_GENERAL_STATUS_LINE_AVAILABLE)
    {
        if (StringSet(statusString))
        {
            while (DTSTest_StringWidth(statusString) > GUI_MAXIMUM_STATUS_LINE_PIXEL_SIZE)
            {
                statusString = statusString->Insert(statusString->Length - 1, String::Empty);
            }
            homeTSStatusLabel->Text = statusString;
            homeStatusStrip->Update();
        }
        else
        {
            homeTSStatusLabel->Text = String::Empty;
        }
    }
}                                       // end of DTSTest_UpdateHomeStatusLine()
//----------------------------------------------------------------------------
// DTSTest_UpdateStatusLine
//
// Updates the home status strip message box with the specified managed string
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_UpdateStatusLine(
    String          ^statusMessage)
{
    //------------------------------------------------------------------------
    if (DTSTest_GeneralInfo->flags & DTSTEST_GENERAL_STATUS_LINE_AVAILABLE)
    {
        if (StringSet(statusMessage))
        {
            homeTSStatusLabel->Text = statusMessage;
            homeStatusStrip->Update();
        }
        else
        {
            homeTSStatusLabel->Text = String::Empty;
        }
    }
}                                       // end of DTSTest_UpdateStatusLine()
//----------------------------------------------------------------------------
#endif      // GUI_CPP
//============================================================================
// End of GUI.cpp
//============================================================================
