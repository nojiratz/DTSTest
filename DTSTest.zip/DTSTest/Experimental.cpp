//============================================================================
// Experimental.cpp
//
// The methods provided for experimental tasks
//
// Copyright (C) 2014 - 2016 Quartzdyne, Inc.  All rights reserved.
//
// No part of this source code may be reproduced or transmitted in any form or
// by any means, electronic or mechanical, including photocopying, recording,
// or any information storage and retrieval system, without express written
// permission from Quartzdyne, Inc.  Further, no use of this source code is
// permitted in any form or means without a valid, written license agreement
// with Quartzdyne, Inc.  While every reasonable precaution has been taken in
// the preparation of this source code, Quartzdyne, Inc., assumes no
// responsibility for errors, omissions, or damages from the use of the source
// code contained herein.
//
// NEITHER QUARTZDYNE, INC., ANY MEMBER OF QUARTZDYNE, INC., NOR ANY PERSON OR
// ORGANIZATION ACTING ON BEHALF OF THEM MAKES ANY WARRANTY OR REPRESENTATION
// WHATSOEVER, EXPRESS OR IMPLIED, INCLUDING ANY WARRANTY OF MERCHANTABILITY
// OR FITNESS FOR ANY PURPOSE WITH RESPECT TO THE SOURCE CODE OR ASSUMES ANY
// LIABILITY WHATSOEVER WITH RESPECT TO ANY USE OF THE SOURCE CODE OR ANY
// PORTION THEREOF OR WITH RESPECT TO ANY DAMAGES THAT MAY RESULT FROM SUCH
// USE.
//
// Noji Ratzlaff
//
// See DTSTest.log for a complete history of all updates, changes, and revisions
// of this source and other files and policies regarding DTSTest software
//
// Updated 01-14-2016
//============================================================================
#include    "stdafx.h"
#ifndef     EXPERIMENTAL_CPP
#define     EXPERIMENTAL_CPP
#include    "Experimental.h"
//----------------------------------------------------------------------------
// DTSTest_ExperimentalControlsSetUpWindow
//
// Displays experimental program controls in a new window
//
// Called by:   DTSTest_InstallUtilities
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_ExperimentalControlsSetUpWindow(void)
{
    String          ^functionName = _T("DTSTest_ExperimentalControlsSetUpWindow");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0} called", functionName);
    if (DTSTest_GeneralInfo)
    {
        //--------------------------------------------------------------------
        // Create a new window form each time this is called, due to the
        // dynamic nature of the program values
        //--------------------------------------------------------------------
        experimentalControlsWindow = gcnew Form;
        experimentalControlsWindow->SuspendLayout();
        //--------------------------------------------------------------------
        // Set its properties
        //--------------------------------------------------------------------
        experimentalControlsWindow->MaximizeBox = GUI_NO;
        experimentalControlsWindow->HelpButton = GUI_NO;
        //--------------------------------------------------------------------
        // Set its icon
        //--------------------------------------------------------------------
        experimentalControlsWindow->Icon = DTSTest_SoftwareIcon;
        //--------------------------------------------------------------------
        // Set the background image
        //--------------------------------------------------------------------
    //        experimentalControlsWindow->BackgroundImage = whiteSandBackground;
        //--------------------------------------------------------------------
        // Set the title and border style
        //--------------------------------------------------------------------
        experimentalControlsWindow->Text = _T("DTSTest Experimental Controls");
        experimentalControlsWindow->FormBorderStyle = ::FormBorderStyle::Fixed3D;
        //--------------------------------------------------------------------
        // Set the dimensions of the Experimental Controls window
        //--------------------------------------------------------------------
        experimentalControlsWindow->Size = Drawing::Size(
            GUI_EXPERIMENTAL_CONTROLS_WINDOW_WIDTH,
            GUI_EXPERIMENTAL_CONTROLS_WINDOW_HEIGHT);
        //--------------------------------------------------------------------
        // Send Chip ID Comand button
        //--------------------------------------------------------------------
        Button ^experimentalSendIdentifyCommandButton = gcnew Button;
        experimentalSendIdentifyCommandButton->Text = _T("Send Identify Command");
        experimentalSendIdentifyCommandButton->Location = Point(10, 10);
        experimentalSendIdentifyCommandButton->Size = Drawing::Size(180, GUI_REGULAR_BUTTON_HEIGHT);
        GUI_SetButtonInterfaceProperties(experimentalSendIdentifyCommandButton);
        experimentalSendIdentifyCommandButton->Click +=
            gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_ExperimentalSendIdentifyCommandButtonClicked);
        experimentalControlsWindow->Controls->Add(experimentalSendIdentifyCommandButton);
        //--------------------------------------------------------------------
        // Send Chip ID Comand button
        //--------------------------------------------------------------------
        Button ^experimentalSendChipIDCommandButton = gcnew Button;
        experimentalSendChipIDCommandButton->Text = _T("Send Chip ID Command");
        GUI_PositionAndSizeBelow(experimentalSendChipIDCommandButton, experimentalSendIdentifyCommandButton, 6);
        GUI_SetButtonInterfaceProperties(experimentalSendChipIDCommandButton);
        experimentalSendChipIDCommandButton->Click +=
            gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_ExperimentalSendChipIDCommandButtonClicked);
        experimentalControlsWindow->Controls->Add(experimentalSendChipIDCommandButton);
        //--------------------------------------------------------------------
        // Send Status Command button
        //--------------------------------------------------------------------
        Button ^experimentalSendStatusCommandButton = gcnew Button;
        experimentalSendStatusCommandButton->Text = _T("Test QDCalMux DLL"); //_T("Send Status Command");
        GUI_PositionAndSizeBelow(experimentalSendStatusCommandButton, experimentalSendChipIDCommandButton, 6);
        GUI_SetButtonInterfaceProperties(experimentalSendStatusCommandButton);
        experimentalSendStatusCommandButton->Click +=
            gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_ExperimentalSendStatusCommandButtonClicked);
        experimentalControlsWindow->Controls->Add(experimentalSendStatusCommandButton);
        //--------------------------------------------------------------------
        // Send Status Command button
        //--------------------------------------------------------------------
        Button ^experimentalMemoryToolButton = gcnew Button;
        experimentalMemoryToolButton->Text = _T("Test mtRecord DLL"); //_T("Send Status Command");
        GUI_PositionAndSizeBelow(experimentalMemoryToolButton, experimentalSendStatusCommandButton, 6);
        GUI_SetButtonInterfaceProperties(experimentalMemoryToolButton);
        experimentalMemoryToolButton->Click +=
            gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_ExperimentalMemoryToolButtonClicked);
        experimentalControlsWindow->Controls->Add(experimentalMemoryToolButton);
        //--------------------------------------------------------------------
        // Piezo-quartz swap button
        //--------------------------------------------------------------------
        Button ^experimentalChangeHardwareTypeButton = gcnew Button;
        experimentalChangeHardwareTypeButton->Text = _T("Change Hardware Type");
        GUI_PositionAndSizeBelow(experimentalChangeHardwareTypeButton, experimentalMemoryToolButton, 6);
        GUI_SetButtonInterfaceProperties(experimentalChangeHardwareTypeButton);
        experimentalChangeHardwareTypeButton->Click +=
            gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_ExperimentalChangeHardwareTypeButtonClicked);
        experimentalControlsWindow->Controls->Add(experimentalChangeHardwareTypeButton);
        ////--------------------------------------------------------------------
        //// Disable Barge Power From 3E button
        ////--------------------------------------------------------------------
        //Button ^experimentalBargePowerFrom3EDisableButton = gcnew Button;
        //experimentalBargePowerFrom3EDisableButton->Text = _T("Disable Barge Power From 3E");
        //GUI_PositionAndSizeBelow(experimentalBargePowerFrom3EDisableButton, experimentalBargePowerFrom3EEnableButton, 6);
        //GUI_SetButtonInterfaceProperties(experimentalBargePowerFrom3EDisableButton);
        //experimentalBargePowerFrom3EDisableButton->Click +=
        //    gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_ExperimentalBargePowerFrom3EDisableButtonClicked);
        //experimentalControlsWindow->Controls->Add(experimentalBargePowerFrom3EDisableButton);
        ////--------------------------------------------------------------------
        //// Read E2 at 0000 button
        ////--------------------------------------------------------------------
        //Button ^experimentalReadE2At0000CommandButton = gcnew Button;
        //experimentalReadE2At0000CommandButton->Text = _T("Read Barge E2 at 0000");
        //GUI_PositionAndSizeBelow(experimentalReadE2At0000CommandButton, experimentalBargePowerFrom3EDisableButton, 6);
        //GUI_SetButtonInterfaceProperties(experimentalReadE2At0000CommandButton);
        //experimentalReadE2At0000CommandButton->Click +=
        //    gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_ExperimentalReadE2At0000CommandButtonClicked);
        //experimentalControlsWindow->Controls->Add(experimentalReadE2At0000CommandButton);
        ////--------------------------------------------------------------------
        //// Load 3E Coefficients button
        ////--------------------------------------------------------------------
        //Button ^experimentalLoad3ECoefficientsButton = gcnew Button;
        //experimentalLoad3ECoefficientsButton->Text = _T("Load 3E Coefficients");
        //GUI_PositionAndSizeBelow(experimentalLoad3ECoefficientsButton, experimentalReadE2At0000CommandButton, 6);
        //GUI_SetButtonInterfaceProperties(experimentalLoad3ECoefficientsButton);
        //experimentalLoad3ECoefficientsButton->Click +=
        //    gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_ExperimentalLoad3ECoefficientsButtonClicked);
        //experimentalControlsWindow->Controls->Add(experimentalLoad3ECoefficientsButton);
        ////--------------------------------------------------------------------
        //// Read E2 Pressure button
        ////--------------------------------------------------------------------
        //experimentalReadE2PressureButton = gcnew Button;
        //experimentalReadE2PressureButton->Text = _T("Read Barge E2 Pressure");
        //GUI_PositionAndSizeBelow(experimentalReadE2PressureButton, experimentalLoad3ECoefficientsButton, 6);
        //GUI_SetButtonInterfaceProperties(experimentalReadE2PressureButton);
        //experimentalReadE2PressureButton->Click +=
        //    gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_ExperimentalReadE2PressureButtonClicked);
        //experimentalReadE2PressureButton->Enabled = GUI_NO;
        //experimentalControlsWindow->Controls->Add(experimentalReadE2PressureButton);
        ////--------------------------------------------------------------------
        //// Read E2 Temperature button
        ////--------------------------------------------------------------------
        //experimentalReadE2TemperatureButton = gcnew Button;
        //experimentalReadE2TemperatureButton->Text = _T("Read Barge E2 Temperature");
        //GUI_PositionAndSizeBelow(experimentalReadE2TemperatureButton, experimentalReadE2PressureButton, 6);
        //GUI_SetButtonInterfaceProperties(experimentalReadE2TemperatureButton);
        //experimentalReadE2TemperatureButton->Click +=
        //    gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_ExperimentalReadE2TemperatureButtonClicked);
        //experimentalReadE2TemperatureButton->Enabled = GUI_NO;
        //experimentalControlsWindow->Controls->Add(experimentalReadE2TemperatureButton);
        ////--------------------------------------------------------------------
        //// Sync E2 button
        ////--------------------------------------------------------------------
        //Button ^experimentalSyncE2Button = gcnew Button;
        //experimentalSyncE2Button->Text = _T("Sync E2");
        //GUI_PositionAndSizeBelow(experimentalSyncE2Button, experimentalReadE2TemperatureButton, 6);
        //GUI_SetButtonInterfaceProperties(experimentalSyncE2Button);
        //experimentalSyncE2Button->Click +=
        //    gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_ExperimentalSyncE2ButtonClicked);
        //experimentalControlsWindow->Controls->Add(experimentalSyncE2Button);
        ////--------------------------------------------------------------------
        //// Enable Barge Power From 2D button
        ////--------------------------------------------------------------------
        //Button ^experimentalBargePowerFrom2DEnableButton = gcnew Button;
        //experimentalBargePowerFrom2DEnableButton->Text = _T("Enable Barge Power From 2D");
        //GUI_PositionAndSizeBelow(experimentalBargePowerFrom2DEnableButton, experimentalSyncE2Button, 6);
        //GUI_SetButtonInterfaceProperties(experimentalBargePowerFrom2DEnableButton);
        //experimentalBargePowerFrom2DEnableButton->Click +=
        //    gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_ExperimentalBargePowerFrom2DEnableButtonClicked);
        //experimentalControlsWindow->Controls->Add(experimentalBargePowerFrom2DEnableButton);
        ////--------------------------------------------------------------------
        //// Disable Barge Power From 2D button
        ////--------------------------------------------------------------------
        //Button ^experimentalBargePowerFrom2DDisableButton = gcnew Button;
        //experimentalBargePowerFrom2DDisableButton->Text = _T("Disable Barge Power From 2D");
        //GUI_PositionAndSizeBelow(experimentalBargePowerFrom2DDisableButton, experimentalBargePowerFrom2DEnableButton, 6);
        //GUI_SetButtonInterfaceProperties(experimentalBargePowerFrom2DDisableButton);
        //experimentalBargePowerFrom2DDisableButton->Click +=
        //    gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_ExperimentalBargePowerFrom2DDisableButtonClicked);
        //experimentalControlsWindow->Controls->Add(experimentalBargePowerFrom2DDisableButton);
        ////--------------------------------------------------------------------
        //// Read B4 at 0000 button
        ////--------------------------------------------------------------------
        //Button ^experimentalReadB4At0000CommandButton = gcnew Button;
        //experimentalReadB4At0000CommandButton->Text = _T("Read Barge B4 at 0000");
        //GUI_PositionAndSizeBelow(experimentalReadB4At0000CommandButton, experimentalBargePowerFrom2DDisableButton, 6);
        //GUI_SetButtonInterfaceProperties(experimentalReadB4At0000CommandButton);
        //experimentalReadB4At0000CommandButton->Click +=
        //    gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_ExperimentalReadB4At0000CommandButtonClicked);
        //experimentalControlsWindow->Controls->Add(experimentalReadB4At0000CommandButton);
        ////--------------------------------------------------------------------
        //// Load 2D Coefficients button
        ////--------------------------------------------------------------------
        //Button ^experimentalLoad2DCoefficientsButton = gcnew Button;
        //experimentalLoad2DCoefficientsButton->Text = _T("Load 2D Coefficients");
        //GUI_PositionAndSizeBelow(experimentalLoad2DCoefficientsButton, experimentalReadB4At0000CommandButton, 6);
        //GUI_SetButtonInterfaceProperties(experimentalLoad2DCoefficientsButton);
        //experimentalLoad2DCoefficientsButton->Click +=
        //    gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_ExperimentalLoad2DCoefficientsButtonClicked);
        //experimentalControlsWindow->Controls->Add(experimentalLoad2DCoefficientsButton);
        ////--------------------------------------------------------------------
        //// Read B4 Pressure button
        ////--------------------------------------------------------------------
        //experimentalReadB4PressureButton = gcnew Button;
        //experimentalReadB4PressureButton->Text = _T("Read Barge B4 Pressure");
        //GUI_PositionAndSizeBelow(experimentalReadB4PressureButton, experimentalLoad2DCoefficientsButton, 6);
        //GUI_SetButtonInterfaceProperties(experimentalReadB4PressureButton);
        //experimentalReadB4PressureButton->Click +=
        //    gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_ExperimentalReadB4PressureButtonClicked);
        //experimentalReadB4PressureButton->Enabled = GUI_NO;
        //experimentalControlsWindow->Controls->Add(experimentalReadB4PressureButton);
        ////--------------------------------------------------------------------
        //// Read B4 Temperature button
        ////--------------------------------------------------------------------
        //experimentalReadB4TemperatureButton = gcnew Button;
        //experimentalReadB4TemperatureButton->Text = _T("Read Barge B4 Temperature");
        //GUI_PositionAndSizeBelow(experimentalReadB4TemperatureButton, experimentalReadB4PressureButton, 6);
        //GUI_SetButtonInterfaceProperties(experimentalReadB4TemperatureButton);
        //experimentalReadB4TemperatureButton->Click +=
        //    gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_ExperimentalReadB4TemperatureButtonClicked);
        //experimentalReadB4TemperatureButton->Enabled = GUI_NO;
        //experimentalControlsWindow->Controls->Add(experimentalReadB4TemperatureButton);
        ////--------------------------------------------------------------------
        //// Sync B4 button
        ////--------------------------------------------------------------------
        //Button ^experimentalSyncB4Button = gcnew Button;
        //experimentalSyncB4Button->Text = _T("Sync B4");
        //GUI_PositionAndSizeBelow(experimentalSyncB4Button, experimentalReadB4TemperatureButton, 6);
        //GUI_SetButtonInterfaceProperties(experimentalSyncB4Button);
        //experimentalSyncB4Button->Click +=
        //    gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_ExperimentalSyncB4ButtonClicked);
        //experimentalControlsWindow->Controls->Add(experimentalSyncB4Button);
        ////--------------------------------------------------------------------
        //// Sync All button
        ////--------------------------------------------------------------------
        //Button ^experimentalSyncAllButton = gcnew Button;
        //experimentalSyncAllButton->Text = _T("Sync All");
        //GUI_PositionAndSizeBelow(experimentalSyncAllButton, experimentalSyncB4Button, 6);
        //GUI_SetButtonInterfaceProperties(experimentalSyncAllButton);
        //experimentalSyncAllButton->Click +=
        //    gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_ExperimentalSyncAllButtonClicked);
        //experimentalControlsWindow->Controls->Add(experimentalSyncAllButton);
        ////--------------------------------------------------------------------
        //// Start / Stop Sampling Gauge 3E button
        ////--------------------------------------------------------------------
        //experimentalStartStopSamplingGauge3EButton = gcnew Button;
        //experimentalStartStopSamplingGauge3EButton->Text = _T("Start Sampling Gauge 3E");
        //experimentalStartStopSamplingGauge3EButton->Location = Point(
        //    experimentalSyncE2Button->Right + 20,
        //    experimentalSyncE2Button->Top);
        //experimentalStartStopSamplingGauge3EButton->Size = experimentalSyncE2Button->Size;
        //GUI_SetButtonInterfaceProperties(experimentalStartStopSamplingGauge3EButton);
        //experimentalStartStopSamplingGauge3EButton->Click +=
        //    gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_ExperimentalStartStopSamplingGauge3EButtonClicked);
        //experimentalStartStopSamplingGauge3EButton->Enabled = GUI_NO;
        //experimentalControlsWindow->Controls->Add(experimentalStartStopSamplingGauge3EButton);
        //--------------------------------------------------------------------
        // Add a Close button
        //--------------------------------------------------------------------
        Button ^closeButton = gcnew Button;
        closeButton->Text = _T("Close");
        closeButton->Location = Point(
            experimentalControlsWindow->Right - 100,
            experimentalControlsWindow->Bottom - 70);
        closeButton->Size = Drawing::Size(
            GUI_CLOSE_BUTTON_WIDTH,
            GUI_REGULAR_BUTTON_HEIGHT);
        GUI_SetButtonInterfaceProperties(closeButton);
        closeButton->DialogResult = System::Windows::Forms::DialogResult::OK;
        closeButton->Click +=
            gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_ExperimentalControlsCloseWindow);
        experimentalControlsWindow->Controls->Add(closeButton);
        //------------------------------------------------------------------------
        // Handle the closing of the window by any other way
        //------------------------------------------------------------------------
        experimentalControlsWindow->FormClosing +=
            gcnew FormClosingEventHandler(this, &DTSTest_GUIClass::DTSTest_ExperimentalControlsClosingWindow);
        //--------------------------------------------------------------------
        // Set the remaining window properties
        //--------------------------------------------------------------------
        experimentalControlsWindow->AcceptButton = closeButton;
        experimentalControlsWindow->CancelButton = closeButton;
        //--------------------------------------------------------------------
        // Finally, hide the new window
        //--------------------------------------------------------------------
        experimentalControlsWindow->ResumeLayout();
        experimentalControlsWindow->Hide();
    }                                   // end of if (DTSTest_GeneralInfo)
    RecordBasicEvent("{0} concluded", functionName);
}                                       // end of DTSTest_ExperimentalControlsSetUpWindow()
//----------------------------------------------------------------------------
// DTSTest_ExperimentalEnableUserInterface
//
// Enables key GUI controls
//
// Called by:   DTSTest_InitializeUserInterface
//
// Note: must only be called after the scan is complete
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_ExperimentalEnableUserInterface(void)
{
    String          ^functionName = _T("DTSTest_ExperimentalEnableUserInterface");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0} called", functionName);
//    samplingControlsTSButton->Enabled = GUI_YES;
    testingControlsTSButton->Enabled = GUI_YES;
    programInfoTSButton->Enabled = GUI_YES;
    experimentalControlsTSButton->Enabled = GUI_YES;
    advancedControlsTSButton->Enabled = GUI_YES;
//    samplingStartStopAllButton->Enabled =
//        pgInfo->atLeastOneSensorPresent ? GUI_YES : GUI_NO;
//    samplingStartStopAllGaugesButton->Enabled =
//        pgInfo->atLeastOneGaugePresent ? GUI_YES : GUI_NO;
//    samplingStartStopAllBargesButton->Enabled =
//        pgInfo->atLeastOneBargePresent ? GUI_YES : GUI_NO;
//    samplingStartStopGauge2DButton->Enabled =
//        pgInfo->sensorInfoArray[DTSTEST_EXPERIMENTAL_GAUGE_2D_VALUE]->sensorPresent ? GUI_YES : GUI_NO;
//    samplingStartStopGauge3EButton->Enabled =
//        pgInfo->sensorInfoArray[DTSTEST_EXPERIMENTAL_GAUGE_3E_VALUE]->sensorPresent ? GUI_YES : GUI_NO;
//    samplingStartStopBargeB4Button->Enabled =
//        pgInfo->sensorInfoArray[DTSTEST_EXPERIMENTAL_BARGE_B4_VALUE]->sensorPresent ? GUI_YES : GUI_NO;
//    samplingStartStopBargeC9Button->Enabled =
//        pgInfo->sensorInfoArray[DTSTEST_EXPERIMENTAL_BARGE_C9_VALUE]->sensorPresent ? GUI_YES : GUI_NO;
//    samplingStartStopBargeE2Button->Enabled =
//        pgInfo->sensorInfoArray[DTSTEST_EXPERIMENTAL_BARGE_E2_VALUE]->sensorPresent ? GUI_YES : GUI_NO;
//    samplingStartStopBarge02Button->Enabled =
//        pgInfo->sensorInfoArray[DTSTEST_EXPERIMENTAL_BARGE_02_VALUE]->sensorPresent ? GUI_YES : GUI_NO;
//    samplingStartStopUserGauge1Button->Enabled =
//        pgInfo->sensorInfoArray[pgInfo->userGaugeNodeAddress1]->sensorPresent ? GUI_YES : GUI_NO;
//    samplingStartStopUserGauge2Button->Enabled =
//        pgInfo->sensorInfoArray[pgInfo->userGaugeNodeAddress2]->sensorPresent ? GUI_YES : GUI_NO;
//    samplingStartStopUserGauge3Button->Enabled =
//        pgInfo->sensorInfoArray[pgInfo->userGaugeNodeAddress3]->sensorPresent ? GUI_YES : GUI_NO;
//    samplingStartStopUserBarge1Button->Enabled =
//        pgInfo->sensorInfoArray[pgInfo->userBargeNodeAddress1]->sensorPresent ? GUI_YES : GUI_NO;
//    samplingStartStopUserBarge2Button->Enabled =
//        pgInfo->sensorInfoArray[pgInfo->userBargeNodeAddress2]->sensorPresent ? GUI_YES : GUI_NO;
//    samplingStartStopUserBarge3Button->Enabled =
//        pgInfo->sensorInfoArray[pgInfo->userBargeNodeAddress3]->sensorPresent ? GUI_YES : GUI_NO;
//    samplingStartStopUserBarge4Button->Enabled =
//        pgInfo->sensorInfoArray[pgInfo->userBargeNodeAddress4]->sensorPresent ? GUI_YES : GUI_NO;
//    samplingStartStopUserBarge5Button->Enabled =
//        pgInfo->sensorInfoArray[pgInfo->userBargeNodeAddress5]->sensorPresent ? GUI_YES : GUI_NO;
//    samplingStartStopUserBarge6Button->Enabled =
//        pgInfo->sensorInfoArray[pgInfo->userBargeNodeAddress6]->sensorPresent ? GUI_YES : GUI_NO;
//    advancedUserGauge1LoadButton->Enabled =
//        pgInfo->sensorInfoArray[pgInfo->userGaugeNodeAddress1]->sensorPresent ? GUI_YES : GUI_NO;
//    advancedUserGauge2LoadButton->Enabled =
//        pgInfo->sensorInfoArray[pgInfo->userGaugeNodeAddress2]->sensorPresent ? GUI_YES : GUI_NO;
//    advancedUserGauge3LoadButton->Enabled =
//        pgInfo->sensorInfoArray[pgInfo->userGaugeNodeAddress3]->sensorPresent ? GUI_YES : GUI_NO;
//    advancedUserBarge1LoadButton->Enabled =
//        pgInfo->sensorInfoArray[pgInfo->userBargeNodeAddress1]->sensorPresent ? GUI_YES : GUI_NO;
//    advancedUserBarge2LoadButton->Enabled =
//        pgInfo->sensorInfoArray[pgInfo->userBargeNodeAddress2]->sensorPresent ? GUI_YES : GUI_NO;
//    advancedUserBarge3LoadButton->Enabled =
//        pgInfo->sensorInfoArray[pgInfo->userBargeNodeAddress3]->sensorPresent ? GUI_YES : GUI_NO;
//    advancedUserBarge4LoadButton->Enabled =
//        pgInfo->sensorInfoArray[pgInfo->userBargeNodeAddress4]->sensorPresent ? GUI_YES : GUI_NO;
//    advancedUserBarge5LoadButton->Enabled =
//        pgInfo->sensorInfoArray[pgInfo->userBargeNodeAddress5]->sensorPresent ? GUI_YES : GUI_NO;
//    advancedUserBarge6LoadButton->Enabled =
//        pgInfo->sensorInfoArray[pgInfo->userBargeNodeAddress6]->sensorPresent ? GUI_YES : GUI_NO;
    homeLoadControlScriptButton->Enabled = GUI_YES;
    homeSwitchBaudRateButton->Enabled = GUI_YES;
    homeExitButton->Enabled = GUI_YES;
    homeAddCommentBox->BackColor = Color::Lavender;
    homeSingleCommandBox->BackColor = Color::Lavender;
    RecordBasicEvent("{0} concluded", functionName);
}                                       // end of DTSTest_ExperimentalEnableUserInterface()
//----------------------------------------------------------------------------
// DTSTest_ExperimentalScanForDevicesThread
//
// Thread for experimentally scanning for DTS / DPS devices
//
// Called by:   DTSTest_PDGICAcquireReadings
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_ExperimentalScanForDevicesThread(
    Object          ^pgInfoContext)
{
    PDGICInfo       ^pgInfo = (PDGICInfo ^) (dynamic_cast <Object ^> (pgInfoContext));
    String          ^functionName = _T("DTSTest_ExperimentalScanForDevicesThread");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0} called", functionName);
    if (pgInfo)
    {
        DTSTest_ExperimentalScanForDevices(pgInfo);
    }                                   // end of if (pgInfo)
    RecordBasicEvent("{0} concluded", functionName);
}                                       // end of DTSTest_ExperimentalScanForDevicesThread()
//----------------------------------------------------------------------------
// DTSTest_ExperimentalScanForDevices
//
// Scans the entire system for all possible DTS-related devices
//
// Called by:   DTSTest_ExperimentalScanForDevicesThread
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_ExperimentalScanForDevices(
    PDGICInfo       ^pgInfo)
{
    DWORD           status = DTSTEST_SUCCESS;
    String          ^functionName = _T("DTSTest_ExperimentalScanForDevices");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0} called", functionName);
    if (pgInfo)
    {
//        DTSTest_PDGICOpenPersistentPort(pgInfo);
        BYTE originalNodeAddress = pgInfo->nodeAddress;
        //--------------------------------------------------------------------
        // Enable power to all barges connected to all gauges
        //--------------------------------------------------------------------
        DTSTest_PDGICEnablePowerToAllGaugeBarges(pgInfo);
        Thread::Sleep(1000);
        //--------------------------------------------------------------------
        // Set main fields and objects
        //--------------------------------------------------------------------
        Script ^mainScript = DTSTest_GeneralInfo->mainScript;
        if (mainScript->placeholder1Value)
        {
            SensorInfo ^sensor = pgInfo->sensorInfoArray[mainScript->placeholder1Value];
            if (!sensor->sensorIdentified)
            {
                if (sensor->sensorType == DTSTEST_SENSOR_TYPE_UNKNOWN)
                {
                    status = DTSTest_SensorRetrieveType(sensor);
                }
                if (status == DTSTEST_SUCCESS)
                {
                    if (sensor->sensorType == DTSTEST_SENSOR_TYPE_GAUGE)
                        status = DTSTest_SensorRetrieveGaugeInformation(sensor);
                    else
                        status = DTSTest_SensorRetrieveBargeInformation(sensor);
                }
                sensor->sensorIdentified = GUI_YES;
            }                           // end of if (!sensor->sensorIdentified)
            status = DTSTest_SensorCalibrateReadings(sensor);
        }
        if (mainScript->placeholder2Value)
        {
            SensorInfo ^sensor = pgInfo->sensorInfoArray[mainScript->placeholder2Value];
            if (!sensor->sensorIdentified)
            {
                if (sensor->sensorType == DTSTEST_SENSOR_TYPE_UNKNOWN)
                {
                    status = DTSTest_SensorRetrieveType(sensor);
                }
                if (status == DTSTEST_SUCCESS)
                {
                    if (sensor->sensorType == DTSTEST_SENSOR_TYPE_GAUGE)
                        status = DTSTest_SensorRetrieveGaugeInformation(sensor);
                    else
                        status = DTSTest_SensorRetrieveBargeInformation(sensor);
                }
                sensor->sensorIdentified = GUI_YES;
            }                           // end of if (!sensor->sensorIdentified)
            status = DTSTest_SensorCalibrateReadings(sensor);
        }
        if (mainScript->placeholder3Value)
        {
            SensorInfo ^sensor = pgInfo->sensorInfoArray[mainScript->placeholder3Value];
            if (!sensor->sensorIdentified)
            {
                if (sensor->sensorType == DTSTEST_SENSOR_TYPE_UNKNOWN)
                {
                    status = DTSTest_SensorRetrieveType(sensor);
                }
                if (status == DTSTEST_SUCCESS)
                {
                    if (sensor->sensorType == DTSTEST_SENSOR_TYPE_GAUGE)
                        status = DTSTest_SensorRetrieveGaugeInformation(sensor);
                    else
                        status = DTSTest_SensorRetrieveBargeInformation(sensor);
                }
                sensor->sensorIdentified = GUI_YES;
            }                           // end of if (!sensor->sensorIdentified)
            status = DTSTest_SensorCalibrateReadings(sensor);
        }
        //--------------------------------------------------------------------
        // Set test entry fields and objects
        //--------------------------------------------------------------------
        for (int offset = 0; offset < DTSTEST_MAXIMUM_NUMBER_OF_TEST_ENTRIES; offset++)
        {
            status = DTSTEST_SUCCESS;
            TestEntry ^testEntry = DTSTest_TestEntryArray[offset];
            if (testEntry->placeholder1Value)
            {
                SensorInfo ^sensor = pgInfo->sensorInfoArray[testEntry->placeholder1Value];
                if (!sensor->sensorIdentified)
                {
                    if (sensor->sensorType == DTSTEST_SENSOR_TYPE_UNKNOWN)
                    {
                        status = DTSTest_SensorRetrieveType(sensor);
                    }
                    if (status == DTSTEST_SUCCESS)
                    {
                        if (sensor->sensorType == DTSTEST_SENSOR_TYPE_GAUGE)
                            status = DTSTest_SensorRetrieveGaugeInformation(sensor);
                        else
                            status = DTSTest_SensorRetrieveBargeInformation(sensor);
                    }
                    sensor->sensorIdentified = GUI_YES;
                }                       // end of if (!sensor->sensorIdentified)
                testEntry->primaryDeviceTypeLabel->Text = sensor->hardwareIDString;
                status = DTSTest_SensorCalibrateReadings(sensor);
                testEntry->coefficientDataLoaded = GUI_YES;
                if (StringICompare(sensor->coefficientInfo->hexFilePath, GUI_DEFAULT_COEFFICIENT_HEX_FILE) == 0)
                    testEntry->entryLoadEraseButton->Text = _T("Default");
                else
                    testEntry->entryLoadEraseButton->Text = Path::GetFileNameWithoutExtension(
                        sensor->coefficientInfo->hexFilePath);
            }                           // end of if (testEntry->placeholder1Value)
        }                               // end of for (int offset = 0; ...)
        pgInfo->nodeAddress = originalNodeAddress;
//        DTSTest_PDGICClosePersistentPort(pgInfo);
        DTSTest_ExperimentalEnableUserInterface();
    }                                   // end of if (pgInfo)
    else
    {
        status = DTSTEST_ERROR_PDGIC_INFO_POINTER_INVALID;                      // 0x000000C1
    }
    DTSTest_GeneralInfo->flags |= DTSTEST_GENERAL_SCAN_COMPLETED;
    RecordBasicEvent("{0} concluded with status = 0x{1:X8}", functionName, status);
}                                       // end of DTSTest_ExperimentalScanForDevices()
//----------------------------------------------------------------------------
// DTSTest_ExperimentalSetDTSBaudRate
//
// Sets all known gauges to the specified baud rate
//
// Returns: 0       = Success
//          nonzero = Failure
//
// Called by:   DTSTest_PDGICSetDTSSystemBaudRate
//----------------------------------------------------------------------------
    DWORD DTSTest_GUIClass::
DTSTest_ExperimentalSetDTSBaudRate(
    PDGICInfo       ^pgInfo,
    int             targetBaudRate)
{
    SensorInfo      ^sensor = nullptr;
    DWORD           status = DTSTEST_SUCCESS;
    String          ^functionName = _T("DTSTest_ExperimentalSetDTSBaudRate");
    //------------------------------------------------------------------------
    if (pgInfo)
    {
        RecordBasicEvent("{0}({1:D}) called", functionName, targetBaudRate);
        DTSTest_PleaseWait(
            GUI_PLEASE_WAIT_DISPLAY_NEW_TITLE,
            String::Concat("Changing to ", targetBaudRate, " baud"));
        //--------------------------------------------------------------------
        // Enable power to all barges
        //--------------------------------------------------------------------
        status = DTSTest_PDGICEnablePowerToAllGaugeBarges(pgInfo);
        if (status == DTSTEST_SUCCESS)
            RecordVerboseEvent("Gauge barge power enable succeeded");
        else
            DTSTest_RecordAndModalErrorEvent("Gauge barge power enable failed");
        Thread::Sleep(1000);
        //--------------------------------------------------------------------
        // Set the baud rate for all the barges simultaneously
        //--------------------------------------------------------------------
        status = DTSTest_PDGICSetBaudRateForAllBarges(pgInfo, targetBaudRate);
        if (status == DTSTEST_SUCCESS)
            RecordVerboseEvent("Barges set to {0:D}", targetBaudRate);
        else
            DTSTest_RecordAndModalErrorEvent(
                "Barges failed to set to {0:D} baud",
                targetBaudRate);
        DTSTest_PleaseWait(GUI_PLEASE_WAIT_REMOVE, nullptr);
    }                                   // end of if (pgInfo)
    else
    {
        status = DTSTEST_ERROR_PDGIC_INFO_POINTER_INVALID;                      // 0x000000C1
    }
    RecordBasicEvent("{0} concluded, returning 0x{1:X8}", functionName, status);
    return status;
}                                       // end of DTSTest_ExperimentalSetDTSBaudRate()
//----------------------------------------------------------------------------
#endif      // EXPERIMENTAL_CPP
//============================================================================
// End of Experimental.cpp
//============================================================================
