//============================================================================
// ExpEvents.cpp
//
// The event methods registered by the experimental source methods
//
// Copyright (C) 2014 - 2016 Quartzdyne, Inc.  All rights reserved.
//
// No part of this source code may be reproduced or transmitted in any form or
// by any means, electronic or mechanical, including photocopying, recording,
// or any information storage and retrieval system, without express written
// permission from Quartzdyne, Inc.  Further, no use of this source code is
// permitted in any form or means without a valid, written license agreement
// with Quartzdyne, Inc.  While every reasonable precaution has been taken in
// the preparation of this source code, Quartzdyne, Inc., assumes no
// responsibility for errors, omissions, or damages from the use of the source
// code contained herein.
//
// NEITHER QUARTZDYNE, INC., ANY MEMBER OF QUARTZDYNE, INC., NOR ANY PERSON OR
// ORGANIZATION ACTING ON BEHALF OF THEM MAKES ANY WARRANTY OR REPRESENTATION
// WHATSOEVER, EXPRESS OR IMPLIED, INCLUDING ANY WARRANTY OF MERCHANTABILITY
// OR FITNESS FOR ANY PURPOSE WITH RESPECT TO THE SOURCE CODE OR ASSUMES ANY
// LIABILITY WHATSOEVER WITH RESPECT TO ANY USE OF THE SOURCE CODE OR ANY
// PORTION THEREOF OR WITH RESPECT TO ANY DAMAGES THAT MAY RESULT FROM SUCH
// USE.
//
// Noji Ratzlaff
//
// See DTSTest.log for a complete history of all updates, changes, and revisions
// of this source and other files and policies regarding DTSTest software
//
// Updated 01-14-2016
//============================================================================
#include    "stdafx.h"
#ifndef     EXPEVENTS_CPP
#define     EXPEVENTS_CPP
#include    "ExpEvents.h"
////----------------------------------------------------------------------------
//// DTSTest_ExperimentalBargePowerFrom2DDisableButtonClicked
////
//// Handles the check of the experimental Disable Barge Power From 2D button
////
//// Called by:   DTSTest_ExperimentalControlsSetUpWindow
////----------------------------------------------------------------------------
//    void DTSTest_GUIClass::
//DTSTest_ExperimentalBargePowerFrom2DDisableButtonClicked(
//    Object          ^sender,
//    EventArgs       ^evt)
//{
//    PDGICInfo       ^pgInfo = DTSTest_GeneralInfo->pgInfo;
//    //------------------------------------------------------------------------
//    RecordBasicEvent("Experimental Disable Barge Power From 2D button clicked");
//    if (pgInfo->powerToBargesEnabled)
//    {
//        BYTE originaNodeAddress = pgInfo->nodeAddress;
//        pgInfo->nodeAddress = DTSTEST_EXPERIMENTAL_GAUGE_2D_VALUE;
//        pgInfo->startingRegisterOffset = 0x0004;
//        pgInfo->numberOfRegistersToTransfer = 2;
//        DTSTest_PDGICDisablePowerToAllGaugeBarges(pgInfo);
//        pgInfo->nodeAddress = originaNodeAddress;
//    }
//    else
//    {
//        Modal("!!! Barge power from 2D is not enabled");
//    }
//}                                       // end of DTSTest_ExperimentalBargePowerFrom2DDisableButtonClicked()
////----------------------------------------------------------------------------
//// DTSTest_ExperimentalBargePowerFrom2DEnableButtonClicked
////
//// Handles the check of the experimental Enable Barge Power From 2D button
////
//// Called by:   DTSTest_ExperimentalControlsSetUpWindow
////----------------------------------------------------------------------------
//    void DTSTest_GUIClass::
//DTSTest_ExperimentalBargePowerFrom2DEnableButtonClicked(
//    Object          ^sender,
//    EventArgs       ^evt)
//{
//    PDGICInfo       ^pgInfo = DTSTest_GeneralInfo->pgInfo;
//    //------------------------------------------------------------------------
//    RecordBasicEvent("Experimental Enable Barge Power From 2D button clicked");
//    if (!pgInfo->powerToBargesEnabled)
//    {
//        BYTE originaNodeAddress = pgInfo->nodeAddress;
//        pgInfo->nodeAddress = DTSTEST_EXPERIMENTAL_GAUGE_2D_VALUE;
//        pgInfo->startingRegisterOffset = 0x0004;
//        pgInfo->numberOfRegistersToTransfer = 2;
//        DTSTest_PDGICEnablePowerToAllGaugeBarges(pgInfo);
//        pgInfo->nodeAddress = originaNodeAddress;
//    }
//    else
//    {
//        Modal("!!! The barge from 2D is already enabled");
//    }
//}                                       // end of DTSTest_ExperimentalBargePowerFrom2DEnableButtonClicked()
////----------------------------------------------------------------------------
//// DTSTest_ExperimentalBargePowerFrom3EDisableButtonClicked
////
//// Handles the check of the experimental Disable Barge Power From 3E button
////
//// Called by:   DTSTest_ExperimentalControlsSetUpWindow
////----------------------------------------------------------------------------
//    void DTSTest_GUIClass::
//DTSTest_ExperimentalBargePowerFrom3EDisableButtonClicked(
//    Object          ^sender,
//    EventArgs       ^evt)
//{
//    PDGICInfo       ^pgInfo = DTSTest_GeneralInfo->pgInfo;
//    //------------------------------------------------------------------------
//    RecordBasicEvent("Experimental Disable Barge Power From 3E button clicked");
//    if (pgInfo->powerToBargesEnabled)
//    {
//        BYTE originaNodeAddress = pgInfo->nodeAddress;
//        pgInfo->nodeAddress = DTSTEST_EXPERIMENTAL_GAUGE_3E_VALUE;
//        pgInfo->startingRegisterOffset = 0x0004;
//        pgInfo->numberOfRegistersToTransfer = 2;
//        DTSTest_PDGICDisablePowerToAllGaugeBarges(pgInfo);
//        pgInfo->nodeAddress = originaNodeAddress;
//    }
//    else
//    {
//        Modal("!!! Barge power from 3E is not enabled");
//    }
//}                                       // end of DTSTest_ExperimentalBargePowerFrom3EDisableButtonClicked()
////----------------------------------------------------------------------------
//// DTSTest_ExperimentalBargePowerFrom3EEnableButtonClicked
////
//// Handles the check of the experimental Enable Barge Power From 3E button
////
//// Called by:   DTSTest_ExperimentalControlsSetUpWindow
////----------------------------------------------------------------------------
//    void DTSTest_GUIClass::
//DTSTest_ExperimentalBargePowerFrom3EEnableButtonClicked(
//    Object          ^sender,
//    EventArgs       ^evt)
//{
//    PDGICInfo       ^pgInfo = DTSTest_GeneralInfo->pgInfo;
//    //------------------------------------------------------------------------
//    RecordBasicEvent("Experimental Enable Barge Power From 3E button clicked");
//    if (!pgInfo->powerToBargesEnabled)
//    {
//        BYTE originaNodeAddress = pgInfo->nodeAddress;
//        pgInfo->nodeAddress = DTSTEST_EXPERIMENTAL_GAUGE_3E_VALUE;
//        pgInfo->startingRegisterOffset = 0x0004;
//        pgInfo->numberOfRegistersToTransfer = 2;
//        DTSTest_PDGICEnablePowerToAllGaugeBarges(pgInfo);
//        pgInfo->nodeAddress = originaNodeAddress;
//    }
//    else
//    {
//        Modal("!!! The barge from 3E is already enabled");
//    }
//}                                       // end of DTSTest_ExperimentalBargePowerFrom3EEnableButtonClicked()
//----------------------------------------------------------------------------
// DTSTest_ExperimentalControlsCloseWindow
//
// Event that closes the Experimental Controls display window
//
// Called by:   DTSTest_ExperimentalControlsSetUpWindow
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_ExperimentalControlsCloseWindow(
    Object          ^sender,
    EventArgs       ^evt)
{
    //------------------------------------------------------------------------
    RecordBasicEvent("Experimental Controls window closed");
    if (experimentalControlsWindow)
    {
        experimentalControlsWindow->Hide();
    }
}                                       // end of DTSTest_ExperimentalControlsCloseWindow()
//----------------------------------------------------------------------------
// DTSTest_ExperimentalControlsClosingWindow
//
// Handles the closing of the Experimental Controls window by the red X
//
// Called by:   DTSTest_ExperimentalControlsSetUpWindow
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_ExperimentalControlsClosingWindow(
    Object          ^sender,
    FormClosingEventArgs
                    ^evt)
{
    //------------------------------------------------------------------------
    evt->Cancel = GUI_YES;              // cancel the closing of the window
    RecordBasicEvent("Experimental Controls window closed");
    if (experimentalControlsWindow)
    {
        experimentalControlsWindow->Hide();
    }
}                                       // end of DTSTest_ExperimentalControlsClosingWindow()
//----------------------------------------------------------------------------
// DTSTest_ExperimentalMemoryToolButtonClicked
//
// Handles the click of the Memory Tool button
//
// Called by:   DTSTest_ExperimentalControlsSetUpWindow
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_ExperimentalMemoryToolButtonClicked(
    Object          ^sender,
    EventArgs       ^evt)
{
    DWORD           status = MT_SUCCESS;
    PDGICInfo       ^pgInfo = DTSTest_GeneralInfo->pgInfo;
    //------------------------------------------------------------------------
    RecordBasicEvent("Experimental test mtRecord DLL button clicked");
    BYTE majorDLLVersion = 0;
    BYTE minorDLLVersion = 0;
    BYTE buildDLLVersion = 0;
    MT_GetQDDLLVersion(
        (LPBYTE) &majorDLLVersion,
        (LPBYTE) &minorDLLVersion,
        (LPBYTE) &buildDLLVersion);
    Modal("The mtRecord DLL version is {0:D}.{1:D}.{2:D}",
        majorDLLVersion, minorDLLVersion, buildDLLVersion);
    DWORD numberOfTools = MT_GetNumberOfTools();
    Modal("Reported number of units = {0:D}", numberOfTools);
    if (numberOfTools)
    {
        HANDLE toolHandle = INVALID_HANDLE_VALUE;
        status = MT_Open(0, &toolHandle);
        if (toolHandle != INVALID_HANDLE_VALUE)
        {
            BYTE majorFWVersion = 0;
            BYTE minorFWVersion = 0;
            BYTE firmwareID = 0;
            status = MT_GetFirmwareInformation(
                toolHandle,
                (LPBYTE) &majorFWVersion,
                (LPBYTE) &minorFWVersion,
                (LPBYTE) &firmwareID);
            if (status == MT_SUCCESS)
                Modal("FW version = {0:X2}.{1:X2} and ID = {2:X2}", majorFWVersion, minorFWVersion, firmwareID);
            else
                Modal("FW version status = {0:X8}", status);
            BYTE hardwareType = 0;
            status = MT_GetHardwareInformation(
                toolHandle,
                (LPBYTE) &hardwareType);
            if (status == MT_SUCCESS)
                Modal("HW type = {0:X2}", hardwareType);
            else
                Modal("HW type status = {0:X8}", status);
            DWORD pressureCount;
            DWORD temperatureCount;
            status = MT_GetTransducerCounts(
                toolHandle,
                (LPDWORD) &pressureCount,
                (LPDWORD) &temperatureCount);
            if (status == MT_SUCCESS)
                Modal("Pressure count = 0x{0:X8}\nTemperature count = 0x{1:X8}", pressureCount, temperatureCount);
            else
                Modal("XD count status = {0:X8}", status);
            LPBYTE coefficientData = (LPBYTE) &DTSTest_GeneralInfo->defaultCoefficientInfo->coefficientData[0];
            DOUBLE pressure;
            DOUBLE temperature;
            status = MT_CalculatePressureAndTemperature(
                (LPBYTE) coefficientData,
                pressureCount,
                temperatureCount,
                &pressure,
                &temperature);
            if (status == MT_SUCCESS)
                Modal("Pressure = {0:F3} psi\nTemperature = {1:F3} �C", pressure, temperature);
            else
                Modal("Calculate PandT status = {0:X8}", status);
//            DWORD currentStartingAddress;
//            status = MT_GetFlashMemoryStartingAddress(
//                toolHandle,
//                (LPDWORD) &currentStartingAddress);
//            if (status == MT_SUCCESS)
//                Modal("Set starting address succeeded = {0:X8}", currentStartingAddress);
//            else
//                Modal("GSA status = {0:X8}", status);
//            currentStartingAddress = 0x0008F6CE;
//            status = MT_SetFlashMemoryStartingAddress(
//                toolHandle,
//                currentStartingAddress);
//            if (status == MT_SUCCESS)
//                Modal("Starting address just set = {0:X8}", currentStartingAddress);
//            else
//                Modal("SSA status = {0:X8}", status);
//            status = MT_GetFlashMemoryStartingAddress(
//                toolHandle,
//                (LPDWORD) &currentStartingAddress);
//            if (status == MT_SUCCESS)
//                Modal("Get starting address succeeded = {0:X8}", currentStartingAddress);
//            else
//                Modal("GSA status = {0:X8}", status);
            char writeBuffer[MT_FLASH_MEMORY_WRITE_LINE_LENGTH];
            ClearBuffer(writeBuffer, MT_FLASH_MEMORY_WRITE_LINE_LENGTH);
            strcpy(writeBuffer, "My name is Noji");
//            strcpy_s(writeBuffer, MT_FLASH_MEMORY_WRITE_LINE_LENGTH, "My name is Noji");
//            sprintf_s(writeBuffer, MT_FLASH_MEMORY_WRITE_LINE_LENGTH, "My name is Noji");
            DWORD newStartingAddress = 0x00027A4E;
            status = MT_WriteToFlashMemory(
                toolHandle,
                newStartingAddress,
                MT_FLASH_MEMORY_WRITE_LINE_LENGTH,
                (LPBYTE) writeBuffer);
            if (status == MT_SUCCESS)
                Modal("Write buffer succeeded = '{0}'", gcnew String(writeBuffer));
            else
                Modal("WriteToFlash status = {0:X8}", status);
            if (status == MT_SUCCESS)
            {
                char readBuffer[MT_FLASH_MEMORY_READ_BLOCK_LENGTH];
                ClearBuffer(readBuffer, MT_FLASH_MEMORY_READ_BLOCK_LENGTH);
                status = MT_ReadFromFlashMemory(
                    toolHandle,
                    newStartingAddress,
                    MT_FLASH_MEMORY_READ_BLOCK_LENGTH,
                    (LPBYTE) readBuffer);
                if (status == MT_SUCCESS)
//                    Modal("Read buffer =\n{0:X2} {1:X2} {2:X2} {3:X2} {4:X2} {5:X2} {6:X2} {7:X2}",
//                    readBuffer[0], readBuffer[1], readBuffer[2], readBuffer[3], readBuffer[4], readBuffer[5], readBuffer[6], readBuffer[7]);
                    Modal("Read buffer = {0}", gcnew String(readBuffer));
                else
                    Modal("ReadFromFlash status = {0:X8}", status);
            }
            MT_Close(toolHandle);
            toolHandle = INVALID_HANDLE_VALUE;
        }
        else
            Modal("MT_Open returned 0x{0:X8}", status);
    }
}                                       // end of DTSTest_ExperimentalMemoryToolButtonClicked()
//----------------------------------------------------------------------------
// DTSTest_ExperimentalChangeHardwareTypeButtonClicked
//
// Handles the click of the Change Hardware Type button
//
// Called by:   DTSTest_ExperimentalControlsSetUpWindow
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_ExperimentalChangeHardwareTypeButtonClicked(
    Object          ^sender,
    EventArgs       ^evt)
{
    DWORD           status = DTSTEST_SUCCESS;
    //------------------------------------------------------------------------
    RecordBasicEvent("Experimental Change Hardware Type button clicked");
    HANDLE toolHandle = INVALID_HANDLE_VALUE;
    status = MT_Open(0, &toolHandle);
    if (toolHandle != INVALID_HANDLE_VALUE)
    {
        BYTE hardwareType = 0;
        status = MT_GetHardwareInformation(
            toolHandle,
            (LPBYTE) &hardwareType);
        if (status == MT_SUCCESS)
            Modal("HW Get type = {0:X2}", hardwareType);
        else
            Modal("HW Get type status = {0:X8}", status);
        hardwareType = (hardwareType == 1) ? 0 : 1;
        status = MT_SetHardwareInformation(
            toolHandle,
            hardwareType);
        if (status == MT_SUCCESS)
            Modal("HW Set type = {0:X2}", hardwareType);
        else
            Modal("HW Set type status = {0:X8}", status);
        status = MT_GetHardwareInformation(
            toolHandle,
            (LPBYTE) &hardwareType);
        if (status == MT_SUCCESS)
            Modal("HW Get type = {0:X2}", hardwareType);
        else
            Modal("HW Get type status = {0:X8}", status);
        MT_Close(toolHandle);
        toolHandle = INVALID_HANDLE_VALUE;
    }
}                                       // end of DTSTest_ExperimentalChangeHardwareTypeButtonClicked()
////----------------------------------------------------------------------------
//// DTSTest_ExperimentalLoad3ECoefficientsButtonClicked
////
//// Handles the click of the Load 3E Coefficients button
////
//// Called by:   DTSTest_ExperimentalControlsSetUpWindow
////----------------------------------------------------------------------------
//    void DTSTest_GUIClass::
//DTSTest_ExperimentalLoad3ECoefficientsButtonClicked(
//    Object          ^sender,
//    EventArgs       ^evt)
//{
//    char            *filePath;
//    DWORD           status = DTSTEST_SUCCESS;
//    //------------------------------------------------------------------------
//    RecordBasicEvent("Experimental Load 3E Coefficients button clicked");
//    String ^filePathString = GUI_DEFAULT_COEFFICIENT_HEX_FILE;
//    if (File::Exists(filePathString))
//    {
//        filePath = (char *) malloc(DTSTEST_MAXIMUM_FILE_PATH_LENGTH);
//        if (filePath)
//        {
//            DTSTest_ConvertString(
//                filePathString,
//                filePath,
//                DTSTEST_MAXIMUM_FILE_PATH_LENGTH);
//            PDGICInfo ^pgInfo = DTSTest_GeneralInfo->pgInfo;
//            BYTE *coefficientBytes = (LPBYTE) pgInfo->sensorInfoArray[1]->coefficientInfo->coefficientData;
//            status = QD_ReadCoefficientDataFromHexFile(
//                (LPBYTE) filePath,
//                (LPBYTE) coefficientBytes);
//            if (status == QD_SUCCESS)
//            {
//                RecordBasicEvent("    Coefficient data for 3E loaded from {0}", filePathString);
//                experimentalReadE2PressureButton->Enabled = GUI_YES;
//                experimentalReadE2TemperatureButton->Enabled = GUI_YES;
//                experimentalStartStopSamplingGauge3EButton->Enabled = GUI_YES;
//            }
//            else
//            {
//                DTSTest_RecordAndModalErrorEvent(
//                    "QD_ReadCoefficientDataFromHexFile returned status 0x{0:X8} while analyzing file\n{1}",
//                    status,
//                    filePathString);
//                Modal("CF data failed to read in");
//            }
//            free((void *) filePath);
//        }                               // end of if (filePath)
//    }                                   // end of if (File::Exists(filePathString))
//    else
//    {
//        Modal("!!! File is not found:\n\n{0}", filePathString);
//    }
//}                                       // end of DTSTest_ExperimentalLoad3ECoefficientsButtonClicked()
////----------------------------------------------------------------------------
//// DTSTest_ExperimentalReadB4At0000CommandButtonClicked
////
//// Handles the click of the Read B4 at 0000 button
////
//// Called by:   DTSTest_ExperimentalControlsSetUpWindow
////----------------------------------------------------------------------------
//    void DTSTest_GUIClass::
//DTSTest_ExperimentalReadB4At0000CommandButtonClicked(
//    Object          ^sender,
//    EventArgs       ^evt)
//{
//    PDGICInfo       ^pgInfo = DTSTest_GeneralInfo->pgInfo;
//    //------------------------------------------------------------------------
//    RecordBasicEvent("Experimental Read B4 at 0000 button clicked");
//    if (pgInfo->powerToBargesEnabled)
//    {
//        BYTE originaNodeAddress = pgInfo->nodeAddress;
//        pgInfo->nodeAddress = DTSTEST_EXPERIMENTAL_BARGE_B4_VALUE;
//        pgInfo->startingRegisterOffset = 0x0000;
//        pgInfo->numberOfRegistersToTransfer = 1;
//        DWORD status = DTSTest_PDGICReadWords(pgInfo);
//        if (status == DTSTEST_SUCCESS)
//        {
//            WORD replyWord = (WORD) (pgInfo->responseArray[3] << 8) | pgInfo->responseArray[4];
//            Modal("Response = 0x{0:X4}", replyWord);
//        }
//        else
//        {
//            Modal("DTSTest_PDGICReadWords failed with 0x{0:X2}", status);
//        }
//        pgInfo->nodeAddress = originaNodeAddress;
//    }
//    else
//    {
//        Modal("!!! Barge power from 2D is not enabled");
//    }
//}                                       // end of DTSTest_ExperimentalReadB4At0000CommandButtonClicked()
////----------------------------------------------------------------------------
//// DTSTest_ExperimentalReadB4PressureButtonClicked
////
//// Handles the click of the Read B4 Pressure button
////
//// Called by:   DTSTest_ExperimentalControlsSetUpWindow
////----------------------------------------------------------------------------
//    void DTSTest_GUIClass::
//DTSTest_ExperimentalReadB4PressureButtonClicked(
//    Object          ^sender,
//    EventArgs       ^evt)
//{
//    PDGICInfo       ^pgInfo = DTSTest_GeneralInfo->pgInfo;
//    //------------------------------------------------------------------------
//    RecordBasicEvent("Experimental Read B4 Pressure button clicked");
//    if (pgInfo->powerToBargesEnabled)
//    {
//        BYTE originaNodeAddress = pgInfo->nodeAddress;
//        pgInfo->nodeAddress = DTSTEST_EXPERIMENTAL_BARGE_B4_VALUE;
//        pgInfo->startingRegisterOffset = 0x0002;
//        pgInfo->numberOfRegistersToTransfer = 2;
//        DWORD status = DTSTest_PDGICReadWords(pgInfo);
//        if (status == DTSTEST_SUCCESS)
//        {
//            int pressureCount = (int) (pgInfo->responseArray[3] << 24) | (pgInfo->responseArray[4] << 16) | (pgInfo->responseArray[5] << 8) | pgInfo->responseArray[6];
//            Modal("B4 Pressure counts = {0:D} ({1:F3} Hz)", pressureCount, (pressureCount * DTSTEST_FREQUENCY_MULTIPLIER));
//        }
//        else
//        {
//            Modal("DTSTest_PDGICReadWords failed with 0x{0:X2}", status);
//        }
//        pgInfo->nodeAddress = originaNodeAddress;
//    }
//    else
//    {
//        Modal("!!! Barge power from 2D is not enabled");
//    }
//}                                       // end of DTSTest_ExperimentalReadB4PressureButtonClicked()
////----------------------------------------------------------------------------
//// DTSTest_ExperimentalReadB4TemperatureButtonClicked
////
//// Handles the click of the Read B4 Temperature button
////
//// Called by:   DTSTest_ExperimentalControlsSetUpWindow
////----------------------------------------------------------------------------
//    void DTSTest_GUIClass::
//DTSTest_ExperimentalReadB4TemperatureButtonClicked(
//    Object          ^sender,
//    EventArgs       ^evt)
//{
//    PDGICInfo       ^pgInfo = DTSTest_GeneralInfo->pgInfo;
//    //------------------------------------------------------------------------
//    RecordBasicEvent("Experimental Read B4 Temperature button clicked");
//    if (pgInfo->powerToBargesEnabled)
//    {
//        BYTE originaNodeAddress = pgInfo->nodeAddress;
//        pgInfo->nodeAddress = DTSTEST_EXPERIMENTAL_BARGE_B4_VALUE;
//        pgInfo->startingRegisterOffset = 0x0004;
//        pgInfo->numberOfRegistersToTransfer = 2;
//        DWORD status = DTSTest_PDGICReadWords(pgInfo);
//        if (status == DTSTEST_SUCCESS)
//        {
//            int temperatureCount = (int) (pgInfo->responseArray[3] << 24) | (pgInfo->responseArray[4] << 16) | (pgInfo->responseArray[5] << 8) | pgInfo->responseArray[6];
//            pgInfo->startingRegisterOffset = 0x0002;
//            pgInfo->numberOfRegistersToTransfer = 2;
//            status = DTSTest_PDGICReadWords(pgInfo);
//            if (status == DTSTEST_SUCCESS)
//            {
//                int pressureCount = (int) (pgInfo->responseArray[3] << 24) | (pgInfo->responseArray[4] << 16) | (pgInfo->responseArray[5] << 8) | pgInfo->responseArray[6];
//                double pressureValuePSI = 0.0;
//                double temperatureValueCelsius = 0.0;
//                LPBYTE coefficientData = (LPBYTE) pgInfo->sensorInfoArray[0]->coefficientInfo->coefficientData;
//                status = QD_CalculatePressureAndTemperature(
//                    coefficientData,
//                    pressureCount,
//                    temperatureCount,
//                    &pressureValuePSI,
//                    &temperatureValueCelsius);
//                if (status == QD_SUCCESS)
//                {
//                    Modal("B4 Temperature counts = {0:D} ({1:F3} Hz) => {2:F5} �C",
//                        temperatureCount, (temperatureCount * DTSTEST_FREQUENCY_MULTIPLIER),
//                        temperatureValueCelsius);
//                }
//                else
//                {
//                    Modal("QD_CalculatePressureAndTemperature returned status 0x{0:X2}", status);
//                }
//            }
//        }
//        else
//        {
//            Modal("DTSTest_PDGICReadWords failed with 0x{0:X2}", status);
//        }
//        pgInfo->nodeAddress = originaNodeAddress;
//    }
//    else
//    {
//        Modal("!!! Barge power from 2D is not enabled");
//    }
//}                                       // end of DTSTest_ExperimentalReadB4TemperatureButtonClicked()
////----------------------------------------------------------------------------
//// DTSTest_ExperimentalReadE2At0000CommandButtonClicked
////
//// Handles the click of the Read E2 at 0000 button
////
//// Called by:   DTSTest_ExperimentalControlsSetUpWindow
////----------------------------------------------------------------------------
//    void DTSTest_GUIClass::
//DTSTest_ExperimentalReadE2At0000CommandButtonClicked(
//    Object          ^sender,
//    EventArgs       ^evt)
//{
//    PDGICInfo       ^pgInfo = DTSTest_GeneralInfo->pgInfo;
//    //------------------------------------------------------------------------
//    RecordBasicEvent("Experimental Read E2 at 0000 button clicked");
//    if (pgInfo->powerToBargesEnabled)
//    {
//        BYTE originaNodeAddress = pgInfo->nodeAddress;
//        pgInfo->nodeAddress = DTSTEST_EXPERIMENTAL_BARGE_E2_VALUE;
//        pgInfo->startingRegisterOffset = 0x0000;
//        pgInfo->numberOfRegistersToTransfer = 1;
//        DWORD status = DTSTest_PDGICReadWords(pgInfo);
//        if (status == DTSTEST_SUCCESS)
//        {
//            WORD replyWord = (WORD) (pgInfo->responseArray[3] << 8) | pgInfo->responseArray[4];
//            Modal("Response = 0x{0:X4}", replyWord);
//        }
//        else
//        {
//            Modal("DTSTest_PDGICReadWords failed with 0x{0:X2}", status);
//        }
//        pgInfo->nodeAddress = originaNodeAddress;
//    }
//    else
//    {
//        Modal("!!! Barge power from 3E is not enabled");
//    }
//}                                       // end of DTSTest_ExperimentalReadE2At0000CommandButtonClicked()
////----------------------------------------------------------------------------
//// DTSTest_ExperimentalReadE2PressureButtonClicked
////
//// Handles the click of the Read E2 Pressure button
////
//// Called by:   DTSTest_ExperimentalControlsSetUpWindow
////----------------------------------------------------------------------------
//    void DTSTest_GUIClass::
//DTSTest_ExperimentalReadE2PressureButtonClicked(
//    Object          ^sender,
//    EventArgs       ^evt)
//{
//    PDGICInfo       ^pgInfo = DTSTest_GeneralInfo->pgInfo;
//    //------------------------------------------------------------------------
//    RecordBasicEvent("Experimental Read E2 Pressure button clicked");
//    if (pgInfo->powerToBargesEnabled)
//    {
//        BYTE originaNodeAddress = pgInfo->nodeAddress;
//        pgInfo->nodeAddress = DTSTEST_EXPERIMENTAL_BARGE_E2_VALUE;
//        pgInfo->startingRegisterOffset = 0x0002;
//        pgInfo->numberOfRegistersToTransfer = 2;
//        DWORD status = DTSTest_PDGICReadWords(pgInfo);
//        if (status == DTSTEST_SUCCESS)
//        {
//            int pressureCount = (int) (pgInfo->responseArray[3] << 24) | (pgInfo->responseArray[4] << 16) | (pgInfo->responseArray[5] << 8) | pgInfo->responseArray[6];
//            Modal("E2 Pressure counts = {0:D} ({1:F3} Hz)", pressureCount, (pressureCount * DTSTEST_FREQUENCY_MULTIPLIER));
//        }
//        else
//        {
//            Modal("DTSTest_PDGICReadWords failed with 0x{0:X2}", status);
//        }
//        pgInfo->nodeAddress = originaNodeAddress;
//    }
//    else
//    {
//        Modal("!!! Barge power from 3E is not enabled");
//    }
//}                                       // end of DTSTest_ExperimentalReadE2PressureButtonClicked()
////----------------------------------------------------------------------------
//// DTSTest_ExperimentalReadE2TemperatureButtonClicked
////
//// Handles the click of the Read E2 Temperature button
////
//// Called by:   DTSTest_ExperimentalControlsSetUpWindow
////----------------------------------------------------------------------------
//    void DTSTest_GUIClass::
//DTSTest_ExperimentalReadE2TemperatureButtonClicked(
//    Object          ^sender,
//    EventArgs       ^evt)
//{
//    PDGICInfo       ^pgInfo = DTSTest_GeneralInfo->pgInfo;
//    //------------------------------------------------------------------------
//    RecordBasicEvent("Experimental Read E2 Temperature button clicked");
//    if (pgInfo->powerToBargesEnabled)
//    {
//        BYTE originaNodeAddress = pgInfo->nodeAddress;
//        pgInfo->nodeAddress = DTSTEST_EXPERIMENTAL_BARGE_E2_VALUE;
//        pgInfo->startingRegisterOffset = 0x0004;
//        pgInfo->numberOfRegistersToTransfer = 2;
//        DWORD status = DTSTest_PDGICReadWords(pgInfo);
//        if (status == DTSTEST_SUCCESS)
//        {
//            int temperatureCount = (int) (pgInfo->responseArray[3] << 24) | (pgInfo->responseArray[4] << 16) | (pgInfo->responseArray[5] << 8) | pgInfo->responseArray[6];
//            pgInfo->startingRegisterOffset = 0x0002;
//            pgInfo->numberOfRegistersToTransfer = 2;
//            status = DTSTest_PDGICReadWords(pgInfo);
//            if (status == DTSTEST_SUCCESS)
//            {
//                int pressureCount = (int) (pgInfo->responseArray[3] << 24) | (pgInfo->responseArray[4] << 16) | (pgInfo->responseArray[5] << 8) | pgInfo->responseArray[6];
//                double pressureValuePSI = 0.0;
//                double temperatureValueCelsius = 0.0;
//                LPBYTE coefficientData = (LPBYTE) pgInfo->sensorInfoArray[1]->coefficientInfo->coefficientData;
//                status = QD_CalculatePressureAndTemperature(
//                    coefficientData,
//                    pressureCount,
//                    temperatureCount,
//                    &pressureValuePSI,
//                    &temperatureValueCelsius);
//                if (status == QD_SUCCESS)
//                {
//                    Modal("E2 Temperature counts = {0:D} ({1:F3} Hz) => {2:F5} �C",
//                        temperatureCount, (temperatureCount * DTSTEST_FREQUENCY_MULTIPLIER),
//                        temperatureValueCelsius);
//                }
//                else
//                {
//                    Modal("QD_CalculatePressureAndTemperature returned status 0x{0:X2}", status);
//                }
//            }
//        }
//        else
//        {
//            Modal("DTSTest_PDGICReadWords failed with 0x{0:X2}", status);
//        }
//        pgInfo->nodeAddress = originaNodeAddress;
//    }
//    else
//    {
//        Modal("!!! Barge power from 3E is not enabled");
//    }
//}                                       // end of DTSTest_ExperimentalReadE2TemperatureButtonClicked()
//----------------------------------------------------------------------------
// DTSTest_ExperimentalSendChipIDCommandButtonClicked
//
// Handles the click of the experimental Send Chip ID Command button
//
// Called by:   DTSTest_ExperimentalControlsSetUpWindow
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_ExperimentalSendChipIDCommandButtonClicked(
    Object          ^sender,
    EventArgs       ^evt)
{
    //------------------------------------------------------------------------
    RecordBasicEvent("Experimental Send Chip ID Command button clicked");
    DTSTest_PDGICRetrieveDTSChipID(DTSTest_GeneralInfo->pgInfo);
}                                       // end of DTSTest_ExperimentalSendChipIDCommandButtonClicked()
//----------------------------------------------------------------------------
// DTSTest_ExperimentalSendIdentifyCommandButtonClicked
//
// Handles the click of the experimental Send Identify Command button
//
// Called by:   DTSTest_ExperimentalControlsSetUpWindow
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_ExperimentalSendIdentifyCommandButtonClicked(
    Object          ^sender,
    EventArgs       ^evt)
{
    //------------------------------------------------------------------------
    RecordBasicEvent("Experimental Send Identify Command button clicked");
    DTSTest_PDGICRetrieveDTSIdentification(DTSTest_GeneralInfo->pgInfo);
}                                       // end of DTSTest_ExperimentalSendIdentifyCommandButtonClicked()
//----------------------------------------------------------------------------
// DTSTest_ExperimentalSendStatusCommandButtonClicked
//
// Handles the click of the experimental Send Status Command button
//
// Called by:   DTSTest_ExperimentalControlsSetUpWindow
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_ExperimentalSendStatusCommandButtonClicked(
    Object          ^sender,
    EventArgs       ^evt)
{
    //------------------------------------------------------------------------
    RecordBasicEvent("Experimental Send Status Command button clicked");
    int initRetCode = InitUSBMux();
    Modal("InitUSBMux returned 0x{0:X8}", initRetCode);
    if (initRetCode == 0)
    {
        DWORD numberOfMasters = QD_GetNumberOfModules();
        if (numberOfMasters)
        {
            bool ducerPresent = GUI_NO;
            for (DWORD masterNumber = 0; masterNumber < numberOfMasters; masterNumber++)
            {
                for (int slaveNumber = 1; slaveNumber <= QD_NUMBER_OF_SLAVES_PER_MASTER; slaveNumber++)
                {
                    for (int portNumber = 1; portNumber <= QD_NUMBER_OF_PORTS_PER_SLAVE; portNumber++)
                    {
                        int transducerPhysicalAddress = (slaveNumber * 100) + portNumber;
                        int ducerType = GetUSBMuxTransducerType(transducerPhysicalAddress);
                        if (ducerType)
                        {
                            ducerPresent = GUI_YES;
                            Modal("Type {0:D} ducer found at {1:D} (slave {2:D} port {3:D}) on master {4:D}",
                                ducerType, transducerPhysicalAddress, slaveNumber, portNumber, masterNumber);
                            BYTE serialNumber[QD_MAXIMUM_SERIAL_NUMBER_SIZE];
                            DWORD status = QD_GetModuleSerialNumber(masterNumber, (LPBYTE) serialNumber);
                            if (status == QD_STATUS_SUCCESS)
                            {
                                int masterOffset = serialNumber[0] - '0' - 1;
                                int transducerLogicalAddress = ((slaveNumber + masterOffset) * 100) + portNumber;
                                SetUSBMuxChannel(transducerLogicalAddress);
                                transducerLogicalAddress += ((ducerType == 1) ? 24 : 0);
                                DWORD pCounts = GetUSBMuxOutput(transducerLogicalAddress, 0);   // 0 = pressure
                                DWORD tCounts = GetUSBMuxOutput(transducerLogicalAddress, 1);   // 1 = temperature
                                DWORD rCounts = GetUSBMuxOutput(transducerLogicalAddress, 2);   // 1 = reference
                                Modal("The counts for the {0} transducer at {1:D} are\n\n    Pres = {2:D}\n    Temp = {3:D}\n    Ref = {4:D}",
                                    ((ducerType == 1) ? "frequency" : "digital"),
                                    transducerLogicalAddress, pCounts, tCounts, rCounts);
                            }           // end of if (status == QD_STATUS_SUCCESS)
                        }               // end of if (ducerType)
                    }                   // end of for (int portNumber = 1; ...)
                }                       // end of for (int slaveNumber = 1; ...)
            }                           // end of for (DWORD masterNumber = 0; ...)
            if (ducerPresent)
            {
            }
            else
            {
                Modal("No ducers found on any slaves");
            }
        }                               // end of if (numberOfMasters)
        else
        {
            Modal("No mux boxes found");
        }
        FreeUSBMux();
    }                                   // end of if (initRetCode == 0)
//    DTSTest_PDGICRetrieveDTSStatus(DTSTest_GeneralInfo->pgInfo);
}                                       // end of DTSTest_ExperimentalSendStatusCommandButtonClicked()
//----------------------------------------------------------------------------
// DTSTest_ExperimentalStartStopSamplingGauge3EButtonClicked
//
// Handles the click of the Start / Stop Sampling Gauge 3E button
//
// Called by:   DTSTest_ExperimentalControlsSetUpWindow
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_ExperimentalStartStopSamplingGauge3EButtonClicked(
    Object          ^sender,
    EventArgs       ^evt)
{
    PDGICInfo       ^pgInfo = DTSTest_GeneralInfo->pgInfo;
    //------------------------------------------------------------------------
    RecordBasicEvent("Experimental Start / Stop Sampling Gauge 3E button clicked");
    if (pgInfo->powerToBargesEnabled)
    {
    }
    else
    {
        Modal("!!! Barge power from 3E is not enabled");
    }
}                                       // end of DTSTest_ExperimentalStartStopSamplingGauge3EButtonClicked()
//----------------------------------------------------------------------------
// DTSTest_ExperimentalSyncAllButtonClicked
//
// Handles the click of the experimental Sync All button
//
// Called by:   DTSTest_ExperimentalControlsSetUpWindow
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_ExperimentalSyncAllButtonClicked(
    Object          ^sender,
    EventArgs       ^evt)
{
    //------------------------------------------------------------------------
    RecordBasicEvent("Experimental Sync All button clicked");
    DTSTest_GeneralInfo->pgInfo->commandArray[0] = DTSTEST_EXPERIMENTAL_ALL_BARGES_VALUE;
    DTSTest_Sync();
}                                       // end of DTSTest_ExperimentalSyncAllButtonClicked()
//----------------------------------------------------------------------------
// DTSTest_ExperimentalSyncB4ButtonClicked
//
// Handles the click of the experimental Sync B4 button
//
// Called by:   DTSTest_ExperimentalControlsSetUpWindow
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_ExperimentalSyncB4ButtonClicked(
    Object          ^sender,
    EventArgs       ^evt)
{
    //------------------------------------------------------------------------
    RecordBasicEvent("Experimental Sync B4 button clicked");
    DTSTest_GeneralInfo->pgInfo->commandArray[0] = DTSTEST_EXPERIMENTAL_BARGE_B4_VALUE;
    DTSTest_Sync();
}                                       // end of DTSTest_ExperimentalSyncB4ButtonClicked()
//----------------------------------------------------------------------------
// DTSTest_ExperimentalSyncE2ButtonClicked
//
// Handles the click of the experimental Sync E2 button
//
// Called by:   DTSTest_ExperimentalControlsSetUpWindow
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_ExperimentalSyncE2ButtonClicked(
    Object          ^sender,
    EventArgs       ^evt)
{
    //------------------------------------------------------------------------
    RecordBasicEvent("Experimental Sync E2 button clicked");
    DTSTest_GeneralInfo->pgInfo->commandArray[0] = DTSTEST_EXPERIMENTAL_BARGE_E2_VALUE;
    DTSTest_Sync();
}                                       // end of DTSTest_ExperimentalSyncE2ButtonClicked()
//----------------------------------------------------------------------------
// DTSTest_ToolStripExperimentalControlsDropDownClicked
//
// Handles the click of the Experimental Controls drop down button
//
// Called by:   DTSTest_InstallToolStrip
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_ToolStripExperimentalControlsDropDownClicked(
    Object          ^sender,
    EventArgs       ^evt)
{
    //------------------------------------------------------------------------
    RecordBasicEvent("Experimental Controls drop-down button clicked");
    if (experimentalControlsWindow->WindowState == FormWindowState::Minimized)
        experimentalControlsWindow->WindowState = FormWindowState::Normal;
    else
        experimentalControlsWindow->Show();
    experimentalControlsWindow->BringToFront();
    if (experimentalControlsWindow->CanFocus)
        experimentalControlsWindow->Focus();
    if (experimentalControlsWindow->CanSelect)
        experimentalControlsWindow->Select();
}                                       // end of DTSTest_ToolStripExperimentalControlsDropDownClicked()
//----------------------------------------------------------------------------
#endif      // EXPEVENTS_CPP
//============================================================================
// End of ExpEvents.cpp
//============================================================================
