//============================================================================
// DTSTestDefs.h
//
// Header for type definitions not defined elsewhere
//
// Copyright (C) 2014 - 2016 Quartzdyne, Inc.  All rights reserved.
//
// No part of this source code may be reproduced or transmitted in any form or
// by any means, electronic or mechanical, including photocopying, recording,
// or any information storage and retrieval system, without express written
// permission from Quartzdyne, Inc.  Further, no use of this source code is
// permitted in any form or means without a valid, written license agreement
// with Quartzdyne, Inc.  While every reasonable precaution has been taken in
// the preparation of this source code, Quartzdyne, Inc., assumes no
// responsibility for errors, omissions, or damages from the use of the source
// code contained herein.
//
// NEITHER QUARTZDYNE, INC., ANY MEMBER OF QUARTZDYNE, INC., NOR ANY PERSON OR
// ORGANIZATION ACTING ON BEHALF OF THEM MAKES ANY WARRANTY OR REPRESENTATION
// WHATSOEVER, EXPRESS OR IMPLIED, INCLUDING ANY WARRANTY OF MERCHANTABILITY
// OR FITNESS FOR ANY PURPOSE WITH RESPECT TO THE SOURCE CODE OR ASSUMES ANY
// LIABILITY WHATSOEVER WITH RESPECT TO ANY USE OF THE SOURCE CODE OR ANY
// PORTION THEREOF OR WITH RESPECT TO ANY DAMAGES THAT MAY RESULT FROM SUCH
// USE.
//
// Noji Ratzlaff
//
// See DTSTest.log for a complete history of all updates, changes, and revisions
// of this source and other files and policies regarding DTSTest software
//
// Updated 01-14-2016
//============================================================================
#pragma once
#ifndef     DTSTESTDEFS_H  // provided for legacy compilers, but unnecessary for
#define     DTSTESTDEFS_H  // recent compilers, due to the preceding pragma
//----------------------------------------------------------------------------
// Functions to be generated as inline code
//----------------------------------------------------------------------------
//#pragma intrinsic(strlen, strcpy, memset, memcpy)
//----------------------------------------------------------------------------
// Headers to include
//----------------------------------------------------------------------------
#include    "qdUSB.h"
//----------------------------------------------------------------------------
// Type definitions automatically created by Visual C++
//----------------------------------------------------------------------------
typedef
    unsigned char
        UI8;
//typedef
//    unsigned int
//        UI16;
typedef
    signed int
        SI8;
typedef
    unsigned long
        UL32;             // unsigned long typedef
//----------------------------------------------------------------------------
// Missing but required type definitions
//----------------------------------------------------------------------------
typedef
    double
        DOUBLE;                         // originally defined in wtypes.h
typedef
    unsigned int
        UINT;
//----------------------------------------------------------------------------
// DTSTest type definitions
//----------------------------------------------------------------------------
typedef
    struct _GeneralInfo
        GeneralDef;
typedef
    struct _CoefficientDataFormat
        CoefficientDataFormat;
//----------------------------------------------------------------------------
// Version strings
//
// Note:    Be sure to edit Resource.h and AssemblyInfo.cs to reflect DTSTest
//          version changes to the file system
//----------------------------------------------------------------------------
#define     DTSTEST_PROGRAM_VERSION_MAJOR                       "0"
#define     DTSTEST_PROGRAM_VERSION_MINOR                       "5"
#define     DTSTEST_PROGRAM_VERSION_REV                         "1"
#define     DTSTEST_PROGRAM_VERSION_STRING                      DTSTEST_PROGRAM_VERSION_MAJOR "." DTSTEST_PROGRAM_VERSION_MINOR "." DTSTEST_PROGRAM_VERSION_REV
//----------------------------------------------------------------------------
// Windows version
//
//                23 20     19 16     15 12     11  8     7       0
// |....|....|     ....|     ....|     ....|     ....    |.... ....|
//                  SP        Rel       Maj       Min      OS Base
//
// Bits 7 through 0 define the base operating system version, the lower 4 bits
//      for client versions and the upper 4 bits for server versions
// Bits 11 through 8 define the OS minor version
// Bits 15 through 12 define the OS major version
// Bits 19 through 16 define the OS release number
// Bits 23 through 20 define the OS Service Pack number
// The remainder is a bitmap of features, as follows:
// Bit 30 defines 128-bit OS version
// Bit 31 defines 64-bit OS version
//----------------------------------------------------------------------------
#define     DTSTEST_WIN_VER_UNKNOWN                             0x00000000
#define     DTSTEST_WIN_VER_PRE_XP                              0x00000001
#define     DTSTEST_WIN_VER_XP                                  0x00000002
#define     DTSTEST_WIN_VER_VISTA                               0x00000003
#define     DTSTEST_WIN_VER_7                                   0x00000004
#define     DTSTEST_WIN_VER_8                                   0x00000005
#define     DTSTEST_WIN_VER_10                                  0x00000006
#define     DTSTEST_WIN_VER_SERVER_2003                         0x00000010
#define     DTSTEST_WIN_VER_SERVER_2008                         0x00000020
#define     DTSTEST_WIN_VER_SERVER_8                            0x00000030
#define     DTSTEST_WIN_VER_SERVER_2012                         0x00000040
#define     DTSTEST_WIN_VER_SERVER_2016                         0x00000050
#define     DTSTEST_WIN_VER_R1                                  0x00010000
#define     DTSTEST_WIN_VER_R2                                  0x00020000
#define     DTSTEST_WIN_VER_R3                                  0x00030000
#define     DTSTEST_WIN_VER_SP1                                 0x00100000
#define     DTSTEST_WIN_VER_SP2                                 0x00200000
#define     DTSTEST_WIN_VER_SP3                                 0x00300000
#define     DTSTEST_WIN_VER_SP4                                 0x00400000
#define     DTSTEST_WIN_VER_128_BIT                             0x40000000
#define     DTSTEST_WIN_VER_64_BIT                              0x80000000
//----------------------------------------------------------------------------
// Integer definitions
//----------------------------------------------------------------------------
#define     QUARTZDYNE_MAIL_SERVER_PORT_NUMBER                  25
#define     GMAIL_MAIL_SERVER_PORT_NUMBER                       587
#define     DTSTEST_GAUGE_TOOLHEAD_PASSWORD                     0x411
//----------------------------------------------------------------------------
// Interface limits
//----------------------------------------------------------------------------
#define     DTSTEST_MAXIMUM_TEXT_FILE_LINE_SIZE                 1024
#define     DTSTEST_MINIMAL_TEXT_FILE_LINE_SIZE                 128
#define     DTSTEST_MAXIMUM_CONFIG_LINE_SIZE                    DTSTEST_MAXIMUM_TEXT_FILE_LINE_SIZE
#define     DTSTEST_MAXIMUM_ERROR_LOG_LINE_SIZE                 DTSTEST_MAXIMUM_TEXT_FILE_LINE_SIZE
#define     DTSTEST_MAXIMUM_ERROR_LOG_ENTRY_SIZE                1280
#define     DTSTEST_MAXIMUM_EVENT_LOG_ENTRY_SIZE                DTSTEST_MAXIMUM_ERROR_LOG_ENTRY_SIZE
#define     DTSTEST_MAXIMUM_EVENT_LOG_LINE_SIZE                 DTSTEST_MAXIMUM_TEXT_FILE_LINE_SIZE
#define     DTSTEST_MAXIMUM_FILE_PATH_LENGTH                    512
#define     DTSTEST_MAXIMUM_EMAIL_ADDRESS_SIZE                  256
#define     DTSTEST_MAXIMUM_SEARCH_STRING_SIZE                  128
#define     DTSTEST_MAXIMUM_VERSION_STRING_SIZE                 64
#define     DTSTEST_SMALL_DATE_STRING_SIZE                      16
#define     DTSTEST_MINIMUM_LOOP_TIMER_MS_INTERVAL              100
#define     DTSTEST_MAXIMUM_NUMBER_OF_SENSORS                   256
//#define     DTSTEST_MAXIMUM_NUMBER_OF_BARGES_PER_GAUGE          16
//#define     DTSTEST_MAXIMUM_NUMBER_OF_GAUGES                    8
#define     DTSTEST_MAXIMUM_NUMBER_OF_BARGES_PER_GAUGE          256
#define     DTSTEST_MAXIMUM_NUMBER_OF_GAUGES                    256
#define     DTSTEST_BARGE_UNDEFINED_ADDRESS                     255
#define     DTSTEST_GAUGE_UNDEFINED_ADDRESS                     255
#define     DTSTEST_MAXIMUM_NUMBER_OF_PLACEHOLDERS              4
#define     DTSTEST_MAXIMUM_NUMBER_OF_TEST_ENTRIES              16
//----------------------------------------------------------------------------
// Sensor types
//----------------------------------------------------------------------------
#define     DTSTEST_SENSOR_TYPE_UNKNOWN                         0x00
#define     DTSTEST_SENSOR_TYPE_GAUGE                           0x01
#define     DTSTEST_SENSOR_TYPE_DTS                             0x02
#define     DTSTEST_SENSOR_TYPE_DPS                             0x04
#define     DTSTEST_SENSOR_TYPE_BARGE                           (DTSTEST_SENSOR_TYPE_DTS | DTSTEST_SENSOR_TYPE_DPS)
#define     DTSTEST_SENSOR_TYPE_SENSOR                          (DTSTEST_SENSOR_TYPE_GAUGE | DTSTEST_SENSOR_TYPE_BARGE)
#define     DTSTEST_SENSOR_TYPE_BROADCAST_GAUGE                 0x10
#define     DTSTEST_SENSOR_TYPE_BROADCAST_BARGE                 0x20
#define     DTSTEST_SENSOR_CHIPSET_DTS                          0xD960
#define     DTSTEST_SENSOR_CHIPSET_DPS                          0xD970
//----------------------------------------------------------------------------
// Serial protocol definitions
//----------------------------------------------------------------------------
#define     DTSTEST_MAXIMUM_NUMBER_OF_PORTS                     2
#define     DTSTEST_LOWEST_BAUDRATE                             1200
#define     DTSTEST_HIGHEST_BAUDRATE                            19200
#define     DTSTEST_DEFAULT_BAUDRATE                            DTSTEST_LOWEST_BAUDRATE
#define     DTSTEST_DEFAULT_PDGIC_BAUDRATE                      DTSTEST_LOWEST_BAUDRATE
#define     DTSTEST_LOWEST_DATA_BITS                            5
#define     DTSTEST_HIGHEST_DATA_BITS                           8
#define     DTSTEST_DEFAULT_DATA_BITS                           DTSTEST_HIGHEST_DATA_BITS
#define     DTSTEST_LOWEST_MS_TIMEOUT                           200
#define     DTSTEST_HIGHEST_MS_TIMEOUT                          3000
#define     DTSTEST_DEFAULT_PDGIC_MS_TIMEOUT                    400
//----------------------------------------------------------------------------
// The frequency multiplier is 7.2 MHz / 4 GB
//----------------------------------------------------------------------------
#define     DTSTEST_FREQUENCY_MULTIPLIER                        0.001676380634307861328125
#define     DTSTEST_DEFAULT_PRESSURE_BIAS                       12.73
#define     DTSTEST_DEFAULT_TEMPERATURE_BIAS                    22.77778
//----------------------------------------------------------------------------
// Special characters
//----------------------------------------------------------------------------
#define     DTSTEST_CHAR_NULL                                   '\0'
#define     DTSTEST_CHAR_CR                                     '\r'
#define     DTSTEST_CHAR_LF                                     '\n'
#define     DTSTEST_CHAR_SPACE                                  ' '
#define     DTSTEST_CHAR_POUND                                  '#'
#define     DTSTEST_CHAR_COMMA                                  ','
#define     DTSTEST_CHAR_COLON                                  ':'
#define     DTSTEST_CHAR_SEMICOLON                              ';'
//----------------------------------------------------------------------------
// Special strings
//----------------------------------------------------------------------------
#define     DTSTEST_STRING_LF                                   _T("\n")
#define     DTSTEST_STRING_CRLF                                 _T("\r\n")
#define     DTSTEST_STRING_SPACE                                _T(" ")
#define     DTSTEST_STRING_HYPHEN                               _T("-")
#define     DTSTEST_STRING_PERIOD                               _T(".")
#define     DTSTEST_STRING_COMMA                                _T(",")
#define     DTSTEST_STRING_POUND                                _T("#")
#define     DTSTEST_STRING_QUESTION                             _T("?")
#define     DTSTEST_STRING_COLON                                _T(":")
#define     DTSTEST_STRING_SEMICOLON                            _T(";")
#define     DTSTEST_STRING_APOSTROPHE                           _T("'")
#define     DTSTEST_STRING_SLASH                                _T("/")
#define     DTSTEST_STRING_BACKSLASH                            _T("\\")
#define     DTSTEST_STRING_DOLLAR                               _T("$")
#define     DTSTEST_STRING_TILDE                                _T("~")
#define     DTSTEST_STRING_0                                    _T("0")
#define     DTSTEST_STRING_1                                    _T("1")
//----------------------------------------------------------------------------
// Shortcut strings
//----------------------------------------------------------------------------
#define     DTSTEST_STRING_DSPACE                               _T("  ")
#define     DTSTEST_STRING_NA                                   _T("N/A")
#define     DTSTEST_STRING_NONE                                 _T("None")
#define     DTSTEST_STRING_INVALID                              _T("Invalid")
#define     DTSTEST_STRING_UNKNOWN                              _T("Unknown")
#define     DTSTEST_STRING_1200_BAUD                            _T("1200")
#define     DTSTEST_STRING_2400_BAUD                            _T("2400")
#define     DTSTEST_STRING_CRC_OFF                              _T("CRC=Off")
#define     DTSTEST_STRING_CRC_ON                               _T("CRC=On")
//----------------------------------------------------------------------------
// Test results
//----------------------------------------------------------------------------
#define     DTSTEST_TEST_RESULT_UNKNOWN                         0x00
#define     DTSTEST_TEST_RESULT_PASSED                          0x01
#define     DTSTEST_TEST_RESULT_FAILED                          0x02
//----------------------------------------------------------------------------
// Status and results (the comprehensive list maintained by NewProg)
//
// Each value is defined for a 32-bit unsigned integer, but only the LSW
// (least significant 16-bit word) contains a valid error value
//----------------------------------------------------------------------------
#define     DTSTEST_SUCCESS                                     0x00000000
#define     DTSTEST_FAILURE                                     -1
#define     DTSTEST_ERROR_NO_ERROR                              DTSTEST_SUCCESS
#define     DTSTEST_ERROR_INVALID_HANDLE                        0x00000001
#define     DTSTEST_ERROR_READ_ERROR                            0x00000002
#define     DTSTEST_ERROR_RECEIVE_QUEUE_NOT_READY               0x00000003
#define     DTSTEST_ERROR_WRITE_ERROR                           0x00000004
#define     DTSTEST_ERROR_RESET_ERROR                           0x00000005
#define     DTSTEST_ERROR_INVALID_PARAMETER                     0x00000006
#define     DTSTEST_ERROR_INVALID_REQUEST_LENGTH                0x00000007
#define     DTSTEST_ERROR_DEVICE_IO_FAILED                      0x00000008
#define     DTSTEST_ERROR_INVALID_DATA_RATE                     0x00000009
#define     DTSTEST_ERROR_FUNCTION_NOT_SUPPORTED                0x0000000A
#define     DTSTEST_ERROR_GLOBAL_DATA_ERROR                     0x0000000B
#define     DTSTEST_ERROR_SYSTEM_ERROR                          0x0000000C
#define     DTSTEST_ERROR_READ_TIMED_OUT                        0x0000000D
#define     DTSTEST_ERROR_WRITE_TIMED_OUT                       0x0000000E
#define     DTSTEST_ERROR_IO_PENDING                            0x0000000F
#define     DTSTEST_ERROR_CHECKSUM_ERROR                        0x00000010
#define     DTSTEST_ERROR_XD_PRESSURE_COUNT_ZERO                0x00000011
#define     DTSTEST_ERROR_XD_TEMPERATURE_COUNT_ZERO             0x00000012
#define     DTSTEST_ERROR_XD_BOTH_COUNTS_ZERO                   0x00000013
#define     DTSTEST_ERROR_MEMORY_ALLOCATION_FAILED              0x00000014
#define     DTSTEST_ERROR_FILE_OPEN_FAILURE                     0x00000015
#define     DTSTEST_ERROR_ADC_COUNT_ZERO                        0x00000016
#define     DTSTEST_ERROR_FILE_SIZE_MISMATCH                    0x00000017
#define     DTSTEST_ERROR_INVALID_HEX_FILE_DATA                 0x00000018
#define     DTSTEST_ERROR_INCORRECT_DATA_SIZE                   0x00000019
#define     DTSTEST_ERROR_INVALID_FIRMWARE_PAGE                 0x0000001A
#define     DTSTEST_ERROR_UNIT_NOT_READY                        0x0000001B
#define     DTSTEST_ERROR_CADENCE_TIMER_ZERO                    0x0000001C
#define     DTSTEST_ERROR_DATA_RATE_ZERO                        0x0000001D
#define     DTSTEST_ERROR_INVALID_I2C_REPLY                     0x0000001E
#define     DTSTEST_ERROR_FIRMWARE_ID_ZERO                      0x0000001F
#define     DTSTEST_ERROR_DATA_TRANSFER_FAILURE                 0x00000020
#define     DTSTEST_ERROR_DEVICE_TIMED_OUT                      0x00000021
#define     DTSTEST_ERROR_RECEIVE_QUEUE_OVERRUN                 0x00000022
#define     DTSTEST_ERROR_FIRMWARE_SIGNATURE_NOT_ERASED         0x00000023
#define     DTSTEST_ERROR_XD_VOLTAGE_TOO_HIGH                   0x00000024
#define     DTSTEST_ERROR_XD_VOLTAGE_TOO_LOW                    0x00000025
#define     DTSTEST_ERROR_XD_CURRENT_TOO_HIGH                   0x00000026
#define     DTSTEST_ERROR_XD_CURRENT_TOO_LOW                    0x00000027
#define     DTSTEST_ERROR_WRITE_ACKNOWLEDGE_FAILED              0x00000028
#define     DTSTEST_ERROR_UNREACHABLE_CONDITION                 0x00000029
#define     DTSTEST_ERROR_NULL_POINTER_PARAMETER                0x0000002A
#define     DTSTEST_ERROR_ZERO_LENGTH_STRING_PARAMETER          0x0000002B
#define     DTSTEST_ERROR_INVALID_STRING_PARAMETER              0x0000002C
//--------- Data Integrity ---------------------------------------------------
#define     DTSTEST_ERROR_INVALID_COEFFICIENT_DATA              0x00000040
//--------- Command ----------------------------------------------------------
#define     DTSTEST_ERROR_COMMAND_FAILED                        0x00000050
#define     DTSTEST_ERROR_ILLEGAL_COMMAND                       0x00000051
#define     DTSTEST_ERROR_UNSUPPORTED_COMMAND                   0x00000052
#define     DTSTEST_ERROR_INVALID_REPLY_DATA                    0x00000053
#define     DTSTEST_ERROR_UNSUPPORTED_TARGET                    0x00000054
#define     DTSTEST_ERROR_COMMAND_CRC_INVALID                   0x00000055
#define     DTSTEST_ERROR_DATA_CRC_INVALID                      0x00000056
#define     DTSTEST_ERROR_INVALID_BROADCAST_INSTANCE            0x00000058
#define     DTSTEST_ERROR_INVALID_BROADCAST_COMMAND             0x00000059
//--------- Code -------------------------------------------------------------
#define     DTSTEST_ERROR_GENERAL_STRUCTURE_INVALID             0x00000060
//--------- Files ------------------------------------------------------------
#define     DTSTEST_ERROR_FILE_NOT_FOUND                        0x00000070
#define     DTSTEST_ERROR_INVALID_FILE_NAME                     0x00000071
#define     DTSTEST_ERROR_INVALID_FILE_FOUND                    0x00000072
#define     DTSTEST_ERROR_UNABLE_TO_CREATE_FILE                 0x00000073
#define     DTSTEST_ERROR_UNABLE_TO_READ_FILE                   0x00000074
#define     DTSTEST_ERROR_UNRECOGNIZED_FILE_TYPE                0x00000077
//--------- Directories and Folders ------------------------------------------
#define     DTSTEST_ERROR_BASE_DIRECTORY_NOT_FOUND              0x00000080
#define     DTSTEST_ERROR_UNABLE_TO_CREATE_DIRECTORY            0x00000081
//--------- Emails and Texts -------------------------------------------------
#define     DTSTEST_ERROR_EMAIL_FAILED_TO_SEND                  0x00000090
#define     DTSTEST_ERROR_INVALID_EMAIL_ADDRESS                 0x00000091
#define     DTSTEST_ERROR_EMAIL_MISSING_COMPONENT               0x00000092
#define     DTSTEST_ERROR_EMAIL_MISSING_SUBJECT                 0x00000093
#define     DTSTEST_ERROR_EMAIL_MISSING_MESSAGE                 0x00000094
#define     DTSTEST_ERROR_EMAIL_MISSING_ATTACHMENT              0x00000095
#define     DTSTEST_ERROR_INVALID_TEXT_NUMBER                   0x00000098
#define     DTSTEST_ERROR_TEXT_MISSING_COMPONENT                0x00000099
#define     DTSTEST_ERROR_TEXT_MISSING_SUBJECT                  0x0000009A
#define     DTSTEST_ERROR_TEXT_MISSING_MESSAGE                  0x0000009B
//--------- Queries ----------------------------------------------------------
#define     DTSTEST_ERROR_DATABASE_NOT_OPEN                     0x000000A0
#define     DTSTEST_ERROR_NO_RESULTS                            0x000000A1
#define     DTSTEST_ERROR_QUERY_FAILED                          0x000000A2
#define     DTSTEST_ERROR_TOO_MANY_RESULTS                      0x000000A3
#define     DTSTEST_ERROR_HEX_FILE_NOT_ON_SERVER                0x000000A6
#define     DTSTEST_ERROR_CF_NAME_NOT_IN_DATABASE               0x000000A7
//--------- Custom -----------------------------------------------------------
#define     DTSTEST_ERROR_MODBUS_COMMAND_FAILED                 0x000000B0
#define     DTSTEST_ERROR_PDGIC_NOT_FOUND                       0x000000C0
#define     DTSTEST_ERROR_PDGIC_INFO_POINTER_INVALID            0x000000C1
#define     DTSTEST_ERROR_PDGIC_PORT_POINTER_INVALID            0x000000C3
#define     DTSTEST_ERROR_PDGIC_PORT_NAME_MISSING               0x000000C4
#define     DTSTEST_ERROR_PDGIC_PORT_IN_USE                     0x000000C5
#define     DTSTEST_ERROR_PDGIC_PORT_NOT_OPEN                   0x000000CD
#define     DTSTEST_ERROR_PDGIC_PORT_OPEN_FAILURE               0x000000CE
#define     DTSTEST_ERROR_PDGIC_PORT_UNKNOWN_FAILURE            0x000000CF
#define     DTSTEST_ERROR_COF2_FILE_PATH_MISSING                0x000000D0
#define     DTSTEST_ERROR_COF2_WD_SN_MISSING                    0x000000D1
#define     DTSTEST_ERROR_COF2_QD_SN_MISSING                    0x000000D2
#define     DTSTEST_ERROR_COF2_GAUGE_ADDRESS_MISSING            0x000000D3
#define     DTSTEST_ERROR_SENSOR_POINTER_INVALID                0x000000E0
#define     DTSTEST_ERROR_SENSOR_TYPE_INCORRECT                 0x000000E1
//--------- Others -----------------------------------------------------------
#define     DTSTEST_ERROR_NETWORK_UNAVAILABLE                   0x000000F0
#define     DTSTEST_ERROR_RETRIEVE_RESPONSE_TIMEOUT             0x000000F1
#define     DTSTEST_ERROR_TEST_CANCELED                         0x000000F8
#define     DTSTEST_ERROR_NO_DEVICE_FOUND                       0x000000FF
//----------------------------------------------------------------------------
// General Information flags
//----------------------------------------------------------------------------
#define     DTSTEST_GENERAL_ZERO_FLAG                           0x00000000
#define     DTSTEST_GENERAL_ALLOCATED                           0x00000001
#define     DTSTEST_GENERAL_USE_PATH_SPECIFIED                  0x00000002
#define     DTSTEST_GENERAL_NAVISION_OPEN                       0x00000004
#define     DTSTEST_GENERAL_NAVISION_CONNECTION_ESTABLISHED     0x00000008
#define     DTSTEST_GENERAL_STATUS_LINE_AVAILABLE               0x00000010
#define     DTSTEST_GENERAL_EVENT_LOG_SPECIFIED                 0x00000020
#define     DTSTEST_GENERAL_GUI_READY_FOR_UPDATING              0x00000100
#define     DTSTEST_GENERAL_GUI_UP_AND_RUNNING                  0x00000200
#define     DTSTEST_GENERAL_SOUNDS_ENABLED                      0x00001000
#define     DTSTEST_GENERAL_ERROR_LOG_SPECIFIED                 0x00004000
#define     DTSTEST_GENERAL_SCAN_COMPLETED                      0x00008000
//#define     DTSTEST_GENERAL_RESULTS_LOG_SPECIFIED               0x00010000
#define     DTSTEST_GENERAL_VERBOSE_LOG_MESSAGES                0x00020000
#define     DTSTEST_GENERAL_CREATE_CSV_LOG_FILE                 0x00040000
//#define     DTSTEST_GENERAL_COMMAND_LINE_ONLY                   0x00100000
#define     DTSTEST_GENERAL_CONFIG_DONT_LOAD                    0x00800000
#define     DTSTEST_GENERAL_CONFIG_FILE_SPECIFIED               0x01000000
#define     DTSTEST_GENERAL_CONFIG_INFO_LOADED                  0x02000000
#define     DTSTEST_GENERAL_CONFIG_DONT_SAVE                    0x04000000
#define     DTSTEST_GENERAL_CONFIG_DELETE_ON_EXIT               0x08000000
#define     DTSTEST_GENERAL_INTERNET_AVAILABLE                  0x10000000
#define     DTSTEST_GENERAL_PROGRAM_REDRAWING                   0x20000000
#define     DTSTEST_GENERAL_PROGRAM_EXITING                     0x40000000
#define     DTSTEST_GENERAL_EXPERT_MODE                         0x80000000
#define     DTSTEST_GENERAL_DEFAULT_SETTINGS                   (DTSTEST_GENERAL_ZERO_FLAG |                 \
                                                                DTSTEST_GENERAL_SOUNDS_ENABLED |            \
                                                                DTSTEST_GENERAL_VERBOSE_LOG_MESSAGES |      \
                                                                DTSTEST_GENERAL_ZERO_FLAG)
#define     DTSTEST_GENERAL_INITIAL_SETTINGS                   (DTSTEST_GENERAL_ZERO_FLAG |                 \
                                                                DTSTEST_GENERAL_DEFAULT_SETTINGS |          \
                                                                DTSTEST_GENERAL_ZERO_FLAG)
#define     DTSTEST_GENERAL_DEFAULT_PERSISTENT_FLAGS           (DTSTEST_GENERAL_ZERO_FLAG |                 \
                                                                DTSTEST_GENERAL_SOUNDS_ENABLED |            \
                                                                DTSTEST_GENERAL_VERBOSE_LOG_MESSAGES |      \
                                                                DTSTEST_GENERAL_CREATE_CSV_LOG_FILE |       \
                                                                DTSTEST_GENERAL_EXPERT_MODE |               \
                                                                DTSTEST_GENERAL_ZERO_FLAG)
#define     DTSTEST_GENERAL_HOT_PLUG_FLAGS                     (DTSTEST_GENERAL_ZERO_FLAG |                 \
                                                                DTSTEST_GENERAL_ALLOCATED |                 \
                                                                DTSTEST_GENERAL_USE_PATH_SPECIFIED |        \
                                                                DTSTEST_GENERAL_STATUS_LINE_AVAILABLE |     \
                                                                DTSTEST_GENERAL_EVENT_LOG_SPECIFIED |       \
                                                                DTSTEST_GENERAL_SOUNDS_ENABLED |            \
                                                                DTSTEST_GENERAL_VERBOSE_LOG_MESSAGES |      \
                                                                DTSTEST_GENERAL_CREATE_CSV_LOG_FILE |       \
                                                                DTSTEST_GENERAL_ERROR_LOG_SPECIFIED |       \
                                                                DTSTEST_GENERAL_CONFIG_FILE_SPECIFIED |     \
                                                                DTSTEST_GENERAL_CONFIG_INFO_LOADED |        \
                                                                DTSTEST_GENERAL_CONFIG_DONT_SAVE |          \
                                                                DTSTEST_GENERAL_CONFIG_DELETE_ON_EXIT |     \
                                                                DTSTEST_GENERAL_PROGRAM_REDRAWING |         \
                                                                DTSTEST_GENERAL_EXPERT_MODE |               \
                                                                DTSTEST_GENERAL_ZERO_FLAG)
//----------------------------------------------------------------------------
// String definitions
//----------------------------------------------------------------------------
#define     DTSTEST_PROGRAM_FILENAME                            _T("NewProg.exe")
#define     DTSTEST_PROGRAM_AUTHOR                              _T("Noji Ratzlaff (noji@quartzdyne.com)")
#define     DTSTEST_SW_UPDATE_FILENAME                          _T("DTSTest.update")
#define     DTSTEST_LOG_DIRECTORY                               _T("DLog")
#define     QUARTZDYNE_URL                                      _T("http://www.quartzdyne.com/")
#define     QUARTZDYNE_QD_URL_DIR                               _T("http://qd.quartzdyne.com/")
#define     QUARTZDYNE_HOST                                     _T("quartzdyne.com")
#define     QUARTZDYNE_EXCHANGE_SERVER                          _T("QDExchange1.quartzdyne.local")
#define     QUARTZDYNE_MAIL_SERVER                              _T("mail.quartzdyne.com")
#define     QUARTZDYNE_SUPPORT_EMAIL_ADDRESS                    _T("Quartzdyne Support <support@quartzdyne.com>")
#define     QUARTZDYNE_CONFIDENTIAL_ROOT                        _T("\\\\QDCluster\\Confidential\\")
#define     QUARTZDYNE_PUBLIC_ROOT                              _T("\\\\QDCluster\\Public\\")
#define     QUARTZDYNE_PROG_SUBFOLDER                           _T("Software-Eng\\Prog\\")
#define     QUARTZDYNE_PROG_FOLDER                              QUARTZDYNE_CONFIDENTIAL_ROOT QUARTZDYNE_PROG_SUBFOLDER
#define     QUARTZDYNE_CAL_DATA_SUBFOLDER                       _T("Ops\\Cal_Data\\")
#define     QUARTZDYNE_CAL_DATA_FOLDER                          QUARTZDYNE_PUBLIC_ROOT QUARTZDYNE_CAL_DATA_SUBFOLDER
#define     QUARTZDYNE_CALSUM_DB_FILE_PATH                      QUARTZDYNE_PROG_SUBFOLDER _T("CALSUM\\CALSUM.MDB")
#define     QUARTZDYNE_DTSTEST_FOLDER                           QUARTZDYNE_PROG_FOLDER _T("WWW\\DTSTest\\")
#define     DTSTEST_URL_DIR                                     QUARTZDYNE_QD_URL_DIR _T("DTSTest/")
#define     DTSTEST_HELP_URL                                    DTSTEST_URL_DIR _T("DTSTest-Help.php")
#define     DTSTEST_VERSION_URL                                 DTSTEST_URL_DIR _T("CurrentVersion.DTSTest")
#define     DTSTEST_PKG_URL_DIR                                 DTSTEST_URL_DIR _T("pkg/")
#define     DTSTEST_TEXT_MESSAGE_SOURCE                         _T("DTSTest Notify <dtstest.notify@gmail.com>")
#define     DTSTEST_EMAIL_MESSAGE_SOURCE                        DTSTEST_TEXT_MESSAGE_SOURCE
#define     DTSTEST_CREDENTIAL_PRIMARY                          _T("EVVXJY[\x16WY_USg")
#define     DTSTEST_CREDENTIAL_SECONDARY                        _T("ewx{n~\x81HBDN")
#define     DTSTEST_DEFAULT_CONNECTION_STRING                   _T("DSN=Navision;DRIVER=Microsoft Dynamics NAV Driver;")    \
                                                                _T("SERVER=QDSQL2\\QDSQL2;UID=flooruser;Trusted_Connection=Yes;")   \
                                                                _T("APP=Microsoft® Windows® Operating System;DATABASE=QD6NAVSQL")
#define     DTSTEST_DEV_CONNECTION_STRING                       _T("DSN=NavisionD;DRIVER=Microsoft Dynamics NAV Driver;")    \
                                                                _T("SERVER=QDSQL2\\QDSQL2;UID=flooruser;Trusted_Connection=Yes;")   \
                                                                _T("APP=Microsoft® Windows® Operating System;DATABASE=QD6NAVDEVD")
#define     GMAIL_MAIL_SERVER                                   _T("smtp.gmail.com")
//----------------------------------------------------------------------------
// Experimental
//----------------------------------------------------------------------------
//#define     DTSTEST_EXPERIMENTAL_GAUGE_2D_OFFSET                0
#define     DTSTEST_EXPERIMENTAL_GAUGE_2D_VALUE                 0x2D
#define     DTSTEST_EXPERIMENTAL_GAUGE_2D_STRING                _T("2D")
//#define     DTSTEST_EXPERIMENTAL_GAUGE_3E_OFFSET                1
#define     DTSTEST_EXPERIMENTAL_GAUGE_3E_VALUE                 0x3E
#define     DTSTEST_EXPERIMENTAL_GAUGE_3E_STRING                _T("3E")
//#define     DTSTEST_EXPERIMENTAL_MAXIMUM_GAUGES                 2
//#define     DTSTEST_EXPERIMENTAL_BARGE_B4_OFFSET                0
#define     DTSTEST_EXPERIMENTAL_BARGE_B4_VALUE                 0xB4
#define     DTSTEST_EXPERIMENTAL_BARGE_B4_STRING                _T("B4")
//#define     DTSTEST_EXPERIMENTAL_BARGE_C9_OFFSET                1
#define     DTSTEST_EXPERIMENTAL_BARGE_C9_VALUE                 0xC9
#define     DTSTEST_EXPERIMENTAL_BARGE_C9_STRING                _T("C9")
//#define     DTSTEST_EXPERIMENTAL_BARGE_E2_OFFSET                2
#define     DTSTEST_EXPERIMENTAL_BARGE_E2_VALUE                 0xE2
#define     DTSTEST_EXPERIMENTAL_BARGE_E2_STRING                _T("E2")
//#define     DTSTEST_EXPERIMENTAL_BARGE_02_OFFSET                3
#define     DTSTEST_EXPERIMENTAL_BARGE_02_VALUE                 0x02
#define     DTSTEST_EXPERIMENTAL_BARGE_02_STRING                _T("02")
//#define     DTSTEST_EXPERIMENTAL_MAXIMUM_BARGES                 4
#define     DTSTEST_EXPERIMENTAL_ALL_BARGES_VALUE               0xFE
#define     DTSTEST_EXPERIMENTAL_GAUGE_DEFAULT_VALUE            DTSTEST_EXPERIMENTAL_GAUGE_2D_VALUE
#define     DTSTEST_EXPERIMENTAL_BARGE_DEFAULT_VALUE            DTSTEST_EXPERIMENTAL_BARGE_B4_VALUE
#define     DTSTEST_SENSOR_ADDRESS_NONE                         0x00
#define     DTSTEST_SENSOR_ADDRESS_BROADCAST                    0xFE
//----------------------------------------------------------------------------
// User
//----------------------------------------------------------------------------
//#define     DTSTEST_USER_GAUGE_1_OFFSET                         DTSTEST_EXPERIMENTAL_MAXIMUM_GAUGES
//#define     DTSTEST_USER_GAUGE_2_OFFSET                         DTSTEST_USER_GAUGE_1_OFFSET + 1
//#define     DTSTEST_USER_GAUGE_3_OFFSET                         DTSTEST_USER_GAUGE_2_OFFSET + 1
//#define     DTSTEST_USER_MAXIMUM_GAUGES                         3
#define     DTSTEST_USER_GAUGE_DEFAULT_VALUE                    0
//#define     DTSTEST_USER_BARGE_1_OFFSET                         DTSTEST_EXPERIMENTAL_MAXIMUM_BARGES
//#define     DTSTEST_USER_BARGE_2_OFFSET                         DTSTEST_USER_BARGE_1_OFFSET + 1
//#define     DTSTEST_USER_BARGE_3_OFFSET                         DTSTEST_USER_BARGE_2_OFFSET + 1
//#define     DTSTEST_USER_BARGE_4_OFFSET                         DTSTEST_USER_BARGE_3_OFFSET + 1
//#define     DTSTEST_USER_BARGE_5_OFFSET                         DTSTEST_USER_BARGE_4_OFFSET + 1
//#define     DTSTEST_USER_BARGE_6_OFFSET                         DTSTEST_USER_BARGE_5_OFFSET + 1
//#define     DTSTEST_USER_MAXIMUM_BARGES                         6
#define     DTSTEST_USER_BARGE_DEFAULT_VALUE                    0
//----------------------------------------------------------------------------
// Compound macros
//----------------------------------------------------------------------------
#define     DTSTest_SetErrorLogPath(P)                                                      \
                {                                                                           \
                    if (DTSTest_GeneralInfo && StringSet(P))                                \
                    {                                                                       \
                        DTSTest_GeneralInfo->errorLogPath = (P);                            \
                        DTSTest_GeneralInfo->flags |= DTSTEST_GENERAL_ERROR_LOG_SPECIFIED;  \
                    }                                                                       \
                }
#define     DTSTest_SetEventLogPath(P)                                                      \
                {                                                                           \
                    if (DTSTest_GeneralInfo && StringSet(P))                                \
                    {                                                                       \
                        DTSTest_GeneralInfo->eventLogPath = (P);                            \
                        DTSTest_GeneralInfo->mostRecentEventLogPath = (P);                  \
                        DTSTest_GeneralInfo->flags |= DTSTEST_GENERAL_EVENT_LOG_SPECIFIED;  \
                    }                                                                       \
                }
#define     DTSTest_SetGeneralUsePath(P)                                                    \
                {                                                                           \
                    if (DTSTest_GeneralInfo && StringSet(P))                                \
                    {                                                                       \
                        DTSTest_GeneralInfo->generalUsePath = (P);                          \
                        DTSTest_GeneralInfo->flags |= DTSTEST_GENERAL_USE_PATH_SPECIFIED;   \
                    }                                                                       \
                }
//----------------------------------------------------------------------------
// Utility macros
//----------------------------------------------------------------------------
#define     AtoX(C)                             (isdigit(((BYTE) (C))) ? ((C) - '0') : (toupper(((BYTE) (C))) - 'A' + 10))
#define     ClearArray(A)                       Array::Clear((A), 0, (A)->Length)
#define     ClearBuffer(P,A)                    memset((void *) (P), 0, (size_t) (A))
#define     FileExists(P)                       (!(_access((P), 0)))
#define     FunctionName()                      (String::Concat(__FUNCTION__)->Contains("::") ? \
                                                    String::Concat(__FUNCTION__)->Substring(String::Concat(__FUNCTION__)->IndexOf("::") + 2) : \
                                                    __FUNCTION__)
#define     HandleIsValid(H)                    ((H) && ((H) != INVALID_HANDLE_VALUE))
#define     Max(A,B)                            (((A) > (B)) ? (A) : (B))
#define     Min(A,B)                            (((A) < (B)) ? (A) : (B))
#define     Mult10(X)                           ((((X) << 2) + (X)) << 1)
#define     ReadBinary(P)                       gcnew BinaryReader(File::Open((P), FileMode::Open, FileAccess::Read))
#define     StringAfter(A,B)                    (A)->Substring((A)->IndexOf(B) + (B)->Length)
#define     StringICompare(A,B)                 String::Compare((A), (B), StringComparison::OrdinalIgnoreCase)
#define     StringSet(S)                        ((S) && (S)->Length)
#define     WriteBinary(S)                      gcnew BinaryWriter(File::Open((S), FileMode::Create))
#define     XtoA(H)                             ((char) ((((H) & 0x0F) > 9) ? (((H) & 0x0F) + 'A' - 10) : (((H) & 0x0F) + '0')))
//----------------------------------------------------------------------------
// Modal macros
//----------------------------------------------------------------------------
#define     AnyMessageEnabled                   (DTSTest_BasicMessagesEnabled || DTSTest_ErrorMessagesEnabled || DTSTest_VerboseMessagesEnabled || DTSTest_DetailedMessagesEnabled)
#define     AnyNonErrorMessageEnabled           (DTSTest_BasicMessagesEnabled || DTSTest_VerboseMessagesEnabled || DTSTest_DetailedMessagesEnabled)
#define     DModal(M,...)                       DTSTest_ModalMessage(true, GUI_MODAL_ICON_INFORMATION, FunctionName(), (M), __VA_ARGS__)
#define     DModalB(M,...)                      DTSTest_ModalMessage(DTSTest_BasicMessagesEnabled, GUI_MODAL_ICON_WARNING, FunctionName(), (M), __VA_ARGS__)
#define     DModalD(M,...)                      DTSTest_ModalMessage(DTSTest_DetailedMessagesEnabled, GUI_MODAL_ICON_INFORMATION, FunctionName(), (M), __VA_ARGS__)
#define     DModalE(M,...)                      DTSTest_ModalMessage(DTSTest_ErrorMessagesEnabled, GUI_MODAL_ICON_ERROR, FunctionName(), (M), __VA_ARGS__)
#define     DModalT(T,M,...)                    DTSTest_ModalMessage(true, GUI_MODAL_ICON_INFORMATION, (T), (M), __VA_ARGS__)
#define     DModalV(M,...)                      DTSTest_ModalMessage(DTSTest_VerboseMessagesEnabled, GUI_MODAL_ICON_INFORMATION, FunctionName(), (M), __VA_ARGS__)
#define     DModalX(M,...)                      DTSTest_ModalMessage(DTSTest_ExpMessagesEnabled, GUI_MODAL_ICON_INFORMATION, FunctionName(), (M), __VA_ARGS__)
//----------------------------------------------------------------------------
// Event recording macros
//----------------------------------------------------------------------------
#define     AnyEventLogEnabled                  (DTSTest_EventLogBasicEnabled || DTSTest_EventLogVerboseEnabled || DTSTest_EventLogDetailedEnabled)
#define     RecordBasicEvent(S,...)             DTSTest_RecordEvent(AnyEventLogEnabled, (S), __VA_ARGS__)
#define     RecordDetailedEvent(S,...)          DTSTest_RecordEvent(DTSTest_EventLogDetailedEnabled, (S), __VA_ARGS__)
#define     RecordErrorEvent(S,...)             DTSTest_RecordEvent(AnyEventLogEnabled, String::Concat("!!! ", (S)), __VA_ARGS__)
#define     RecordVerboseEvent(S,...)           DTSTest_RecordEvent((DTSTest_EventLogVerboseEnabled || DTSTest_EventLogDetailedEnabled), (S), __VA_ARGS__)
#define     RecordEventUnconditional(S,...)     DTSTest_RecordEvent(GUI_YES, (S), __VA_ARGS__)
//----------------------------------------------------------------------------
#endif      // DTSTESTDEFS_H
//============================================================================
// End of DTSTestDefs.h
//============================================================================
