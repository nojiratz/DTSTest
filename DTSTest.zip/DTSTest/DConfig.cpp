//============================================================================
// DConfig.cpp
//
// Functions for handling program configuration, error log, and event log tasks
//
// Copyright (C) 2014 - 2016 Quartzdyne, Inc.  All rights reserved.
//
// No part of this source code may be reproduced or transmitted in any form or
// by any means, electronic or mechanical, including photocopying, recording,
// or any information storage and retrieval system, without express written
// permission from Quartzdyne, Inc.  Further, no use of this source code is
// permitted in any form or means without a valid, written license agreement
// with Quartzdyne, Inc.  While every reasonable precaution has been taken in
// the preparation of this source code, Quartzdyne, Inc., assumes no
// responsibility for errors, omissions, or damages from the use of the source
// code contained herein.
//
// NEITHER QUARTZDYNE, INC., ANY MEMBER OF QUARTZDYNE, INC., NOR ANY PERSON OR
// ORGANIZATION ACTING ON BEHALF OF THEM MAKES ANY WARRANTY OR REPRESENTATION
// WHATSOEVER, EXPRESS OR IMPLIED, INCLUDING ANY WARRANTY OF MERCHANTABILITY
// OR FITNESS FOR ANY PURPOSE WITH RESPECT TO THE SOURCE CODE OR ASSUMES ANY
// LIABILITY WHATSOEVER WITH RESPECT TO ANY USE OF THE SOURCE CODE OR ANY
// PORTION THEREOF OR WITH RESPECT TO ANY DAMAGES THAT MAY RESULT FROM SUCH
// USE.
//
// Noji Ratzlaff
//
// See DTSTest.log for a complete history of all updates, changes, and revisions
// of this source and other files and policies regarding DTSTest software
//
// Updated 01-14-2016
//============================================================================
#include    "stdafx.h"
#ifndef     DCONFIG_CPP
#define     DCONFIG_CPP
#include    "DConfig.h"
//----------------------------------------------------------------------------
// DTSTest_ConcludeErrorLog
//
// Finishes the error log by adding a footer to the file
//
// Called by:   DTSTest_ConcludeGeneralLogs
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_ConcludeErrorLog(
    String          ^finalErrorEntry)
{
    String          ^border = GUI_TEXT_FILE_BORDER;
    String          ^lineString;
    DateTime        dateTime = DateTime::Now;
    StreamWriter    ^textWriter;
    //------------------------------------------------------------------------
    if (DTSTest_GeneralInfo->flags & DTSTEST_GENERAL_ERROR_LOG_SPECIFIED)
    {
        RecordEventUnconditional(finalErrorEntry);
        textWriter = File::AppendText(DTSTest_GeneralInfo->errorLogPath);
        if (textWriter)
        {
            textWriter->WriteLine(border);
            lineString = String::Format(
                "# {0} concluded on {1:D2} {2} {3:D4} at {4:D2}:{5:D2}:{6:D2}",
                Path::GetFileName(DTSTest_GeneralInfo->errorLogPath),
                dateTime.Day,
                DTSTest_MonthStringArray[dateTime.Month],
                dateTime.Year,
                dateTime.Hour,
                dateTime.Minute,
                dateTime.Second);
            textWriter->WriteLine(lineString);
            textWriter->WriteLine(border);
            textWriter->Close();
        }
        DTSTest_GeneralInfo->flags &= ~DTSTEST_GENERAL_ERROR_LOG_SPECIFIED;
    }
}                                       // end of DTSTest_ConcludeErrorLog()
//----------------------------------------------------------------------------
// DTSTest_ConcludeEventLog
//
// Finishes the event log by adding a footer to the file
//
// Called by:   DTSTest_ConcludeGeneralLogs
//              DTSTest_ToolStripEventLogBasicDropDownClicked
//              DTSTest_ToolStripEventLogDetailedDropDownClicked
//              DTSTest_ToolStripEventLogVerboseDropDownClicked
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_ConcludeEventLog(
    String          ^finalEventEntry)
{
    String          ^border = GUI_TEXT_FILE_BORDER;
    String          ^lineString;
    DateTime        dateTime = DateTime::Now;
    StreamWriter    ^textWriter;
    //------------------------------------------------------------------------
    if (DTSTest_CurrentlyEventLogging && (DTSTest_GeneralInfo->flags & DTSTEST_GENERAL_EVENT_LOG_SPECIFIED))
    {
        RecordEventUnconditional("    All event logging stopped");
        RecordEventUnconditional(finalEventEntry);
        textWriter = File::AppendText(DTSTest_GeneralInfo->eventLogPath);
        if (textWriter)
        {
            textWriter->WriteLine(border);
            lineString = String::Format(
                "# {0} concluded on {1:D2} {2} {3:D4} at {4:D2}:{5:D2}:{6:D2}",
                Path::GetFileName(DTSTest_GeneralInfo->eventLogPath),
                dateTime.Day,
                DTSTest_MonthStringArray[dateTime.Month],
                dateTime.Year,
                dateTime.Hour,
                dateTime.Minute,
                dateTime.Second);
            textWriter->WriteLine(lineString);
            textWriter->WriteLine(border);
            textWriter->Close();
        }
        DTSTest_GeneralInfo->flags &= ~DTSTEST_GENERAL_EVENT_LOG_SPECIFIED;
        DTSTest_CurrentlyEventLogging = GUI_NO;
    }
}                                       // end of DTSTest_ConcludeEventLog()
//----------------------------------------------------------------------------
// DTSTest_ConcludeGeneralLogs
//
// Finishes the error and event log files
//
// Called by:   DTSTest_Finalize
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_ConcludeGeneralLogs(
    String          ^finalEventEntry)
{
    //------------------------------------------------------------------------
    DTSTest_ConcludeErrorLog(String::Empty);
    DTSTest_ConcludeEventLog(finalEventEntry);
}                                       // end of DTSTest_ConcludeGeneralLogs()
//----------------------------------------------------------------------------
// DTSTest_EstablishErrorLog
//
// Creates a new error log file
//
// Called by:   DTSTest_InitializeDTSTest
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_EstablishErrorLog(void)
{
    bool            logHasEntries;
    int             logInstance = 1;
    String          ^border = GUI_TEXT_FILE_BORDER;
    String          ^fileString;
    String          ^lineString;
    String          ^pathString;
    StreamReader    ^textReader;
    StreamWriter    ^textWriter;
    DateTime        dateTime = DateTime::Now;
    //------------------------------------------------------------------------
    ModalD("Loc 4.1 : DTSTest_GeneralInfo is {0}",
        (DTSTest_GeneralInfo ? "valid" : "invalid"));
    if (DTSTest_GeneralInfo)
    {
        ModalD("Loc 4.2 : Just before calling DTSTest_EstablishLogDirectory");
        DTSTest_EstablishLogDirectory();
        ModalD("Loc 4.3 : Just after calling DTSTest_EstablishLogDirectory");
        if (!(DTSTest_GeneralInfo->flags & DTSTEST_GENERAL_ERROR_LOG_SPECIFIED))
        {
            do
            {
                fileString = String::Format(
                    "DTSTest-ErrorLog-{0:D2}{1:D2}{2:D2}-{3:D3}.log",
                    (dateTime.Year % 100),
                    dateTime.Month,
                    dateTime.Day,
                    logInstance);
                pathString = String::Concat(
                    DTSTest_GeneralInfo->logDirectory,
                    "\\",
                    fileString);
                logHasEntries = GUI_NO;
                if (File::Exists(pathString))
                {
                    textReader = File::OpenText(pathString);
                    if (textReader)
                    {
                        while (lineString = textReader->ReadLine())
                        {
                            lineString = lineString->Trim();
                            if (!lineString->StartsWith("#"))
                            {
                                logHasEntries = GUI_YES;
                                logInstance++;
                                break;
                            }
                        }
                        textReader->Close();
                    }
                }
                if (logInstance >= 1000)
                {
                    Modal("The error log could not be created");
                }
            }
            while (File::Exists(pathString) && logHasEntries);
            if (File::Exists(pathString))
            {
                ModalD("Loc 4.4 : The file will be deleted:\n{0}", pathString);
                File::Delete(pathString);
                Thread::Sleep(100);
                ModalD("Loc 4.5 : The file {0} deleted:\n{1}",
                    (File::Exists(pathString) ? "failed to be" : "was"),
                    pathString);
            }
            textWriter = File::CreateText(pathString);
            ModalD("Loc 4.6 : The file {0} created:\n{1}",
                (textWriter ? "was" : "failed to be"),
                pathString);
            if (textWriter)
            {
                //------------------------------------------------------------
                // Write out the header, including the program name and the
                // current date and time
                //------------------------------------------------------------
                textWriter->WriteLine(border);
                lineString = String::Format(
                    "# {0}\n#\n"
                    "# DTSTest Error Log File (DTSTest v{1} build {2:D})\n#\n"
                    "# Created on {3:D2} {4} {5:D4} at {6:D2}:{7:D2}:{8:D2}",
                    fileString,
                    DTSTEST_PROGRAM_VERSION_STRING,
                    DTSTest_BuildNumber,
                    dateTime.Day,
                    DTSTest_MonthStringArray[dateTime.Month],
                    dateTime.Year,
                    dateTime.Hour,
                    dateTime.Minute,
                    dateTime.Second);
                textWriter->WriteLine(lineString->Replace(DTSTEST_STRING_LF, Environment::NewLine));
                textWriter->WriteLine(border);
                textWriter->Close();
                DTSTest_GeneralInfo->errorLogPath = pathString;
                DTSTest_GeneralInfo->flags |= DTSTEST_GENERAL_ERROR_LOG_SPECIFIED;
                RecordVerboseEvent("Error Log created as\n{0}", pathString);
            }
        }                               // end of if (!(DTSTest_GeneralInfo->flags & DTSTEST_GENERAL_ERROR_LOG_SPECIFIED))
    }
    ModalD("Loc 4.7 : End of DTSTest_EstablishErrorLog");
}                                       // end of DTSTest_EstablishErrorLog()
//----------------------------------------------------------------------------
// DTSTest_EstablishEventLog
//
// Creates a new event log file if an event is enabled
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_EstablishEventLog(
    String          ^initialEventEntry)
{
    bool            eventLogLocated = GUI_NO;
    int             logInstance = 1;
    String          ^border = GUI_TEXT_FILE_BORDER;
    String          ^fileString;
    String          ^lineString;
    String          ^pathString;
    StreamWriter    ^textWriter;
    DateTime        dateTime = DateTime::Now;
    //------------------------------------------------------------------------
    ModalD("Loc 5.1 : DTSTest_GeneralInfo is {0}",
        (DTSTest_GeneralInfo ? "valid" : "invalid"));
    if (DTSTest_GeneralInfo)
    {
        ModalD("Loc 5.2 : Just before calling DTSTest_EstablishLogDirectory");
        DTSTest_EstablishLogDirectory();
        ModalD("Loc 5.3 : Just after calling DTSTest_EstablishLogDirectory");
        if (AnyEventLogEnabled && !(DTSTest_GeneralInfo->flags & DTSTEST_GENERAL_EVENT_LOG_SPECIFIED))
        {
            do
            {
                fileString = String::Format(
                    "DTSTest-EventLog-{0:D2}{1:D2}{2:D2}-{3:D3}.log",
                    (dateTime.Year % 100),
                    dateTime.Month,
                    dateTime.Day,
                    logInstance);
                pathString = String::Concat(
                    DTSTest_GeneralInfo->logDirectory,
                    "\\",
                    fileString);
                if (File::Exists(pathString))
                    logInstance++;
                if (logInstance >= 1000)
                {
                    Modal("The event log could not be created");
                }
            }
            while (File::Exists(pathString));
            DTSTest_CurrentlyEventLogging = GUI_YES;
            textWriter = File::CreateText(pathString);
            ModalD("Loc 5.4 : The file {0} created:\n{1}",
                (textWriter ? "was" : "failed to be"),
                pathString);
            if (textWriter)
            {
                //------------------------------------------------------------
                // Write out the header, including the program name and the
                // current date and time
                //------------------------------------------------------------
                textWriter->WriteLine(border);
                lineString = String::Format(
                    "# {0}\n#\n"
                    "# DTSTest Event Log File (DTSTest v{1} build {2:D})\n#\n"
                    "# Created on {3:D2} {4} {5:D4} at {6:D2}:{7:D2}:{8:D2}",
                    fileString,
                    DTSTEST_PROGRAM_VERSION_STRING,
                    DTSTest_BuildNumber,
                    dateTime.Day,
                    DTSTest_MonthStringArray[dateTime.Month],
                    dateTime.Year,
                    dateTime.Hour,
                    dateTime.Minute,
                    dateTime.Second);
                textWriter->WriteLine(lineString->Replace(DTSTEST_STRING_LF, Environment::NewLine));
                textWriter->WriteLine(border);
                if (StringSet(initialEventEntry))
                {
                    if (initialEventEntry->Contains(DTSTEST_STRING_LF))
                    {
                        lineString = initialEventEntry->Replace(
                            DTSTEST_STRING_LF, _T("\n                     :     "));
                    }
                    else
                    {
                        lineString = initialEventEntry;
                    }
                    lineString = String::Format(
                        "{0:D2} {1} {2:D4} {3:D2}:{4:D2}:{5:D2} : {6}",
                        dateTime.Day,
                        DTSTest_MonthStringArray[dateTime.Month],
                        dateTime.Year,
                        dateTime.Hour,
                        dateTime.Minute,
                        dateTime.Second,
                        lineString);
                    textWriter->WriteLine(lineString);
                }
                textWriter->Close();
                //------------------------------------------------------------
                // Store the newly created path and set the
                // DTSTEST_GENERAL_EVENT_LOG_SPECIFIED flag
                //------------------------------------------------------------
                DTSTest_SetEventLogPath(pathString);
                RecordVerboseEvent("Event Log created as\n{0}", pathString);
            }                           // end of if (textWriter)
        }                               // end of if (AnyEventLogEnabled && ...)
        //--------------------------------------------------------------------
        // Search for the most recent event log, if any exists
        //--------------------------------------------------------------------
        if (!eventLogLocated)
        {
            String ^latestPath = String::Empty;
            String ^logDir = String::Concat(DTSTest_GeneralInfo->logDirectory, DTSTEST_STRING_BACKSLASH);
            array <String ^> ^eventLogFiles = Directory::GetFiles(logDir, "DTSTest-EventLog-*.log");
            if (StringSet(eventLogFiles))
            {
                for each (String ^pathString in eventLogFiles)
                {
                    if (StringSet(latestPath))
                    {
                        if (StringICompare(pathString, latestPath) > 0)
                            latestPath = pathString;
                    }
                    else
                        latestPath = pathString;
                }
                if (StringSet(latestPath) && File::Exists(latestPath))
                {
                    DTSTest_GeneralInfo->mostRecentEventLogPath = latestPath;
                    eventLogLocated = GUI_YES;
                }
            }
            delete [] eventLogFiles;
        }                               // end of if (!eventLogLocated)
    }                                   // end of if (DTSTest_GeneralInfo)
    ModalD("Loc 5.5 : End of DTSTest_EstablishEventLog");
}                                       // end of DTSTest_EstablishEventLog()
//----------------------------------------------------------------------------
// DTSTest_EstablishLogDirectory
//
// Ensures the Log directory exists in the current working directory, and
// stores the directory path string
//
// Called by:   DTSTest_EstablishErrorLog
//              DTSTest_EstablishEventLog
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_EstablishLogDirectory(void)
{
    //------------------------------------------------------------------------
    ModalD("Loc 4.2.1 : DTSTest_GeneralInfo is {0}",
        (DTSTest_GeneralInfo ? "valid" : "invalid"));
    if (DTSTest_GeneralInfo)
    {
        if (String::IsNullOrEmpty(DTSTest_GeneralInfo->logDirectory))
        {
            String ^pathString = String::Concat(
                Application::StartupPath,
                DTSTEST_STRING_BACKSLASH,
                DTSTEST_LOG_DIRECTORY);
            DTSTest_GeneralInfo->logDirectory = pathString;
            try
            {
                if (!Directory::Exists(pathString))
                {
                    ModalD("Loc 4.2.2 : The directory will be created:\n{0}", pathString);
                    Directory::CreateDirectory(pathString);
                    Thread::Sleep(100);
                    ModalD("Loc 4.2.3 : The directory {0} created:\n{1}",
                        (Directory::Exists(pathString) ? "was" : "failed to be"),
                        pathString);
                }
                if (!Directory::Exists(pathString))
                {
                    DTSTest_GeneralInfo->logDirectory = String::Empty;
                }
            }
            catch (Exception ^ex)
            {
                RecordErrorEvent("Problem creating the {0} directory\n{1} :\n{2}",
                    DTSTEST_LOG_DIRECTORY, pathString, ex->Message);
                Modal("The {0} folder could not be created:\n{1}\n\n"
                    "Create the folder manually, then allow all users\n"
                    "on this computer rights to modify this folder\n\n"
                    "The program will now exit",
                    DTSTEST_LOG_DIRECTORY, pathString);
                exit(0);
            }
            delete pathString;
        }
    }
    ModalD("Loc 4.2.4 : End of DTSTest_EstablishLogDirectory");
}                                       // end of DTSTest_EstablishLogDirectory()
//----------------------------------------------------------------------------
// DTSTest_LogTesterInfo
//
// Records the user name and machine name of the current tester
//
// Called by:   DTSTest_ConstructAndPresentUserInterface
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_LogTesterInfo(void)
{
    String          ^functionName = _T("DTSTest_LogTesterInfo");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0} called", functionName);
    DateTime dateTime = DateTime::Now;
    String ^testerInfoString = String::Concat(
        String::Format(
            "[ {0:D2}-{1:D2}-{2:D4} {3:D2}:{4:D2}:{5:D2} ] ",
            dateTime.Month,
            dateTime.Day,
            dateTime.Year,
            dateTime.Hour,
            dateTime.Minute,
            dateTime.Second),
        Environment::UserName,
        _T(" started DTSTest "),
        DTSTest_BuildNumber,
        _T(" on "),
        Environment::MachineName,
        _T(" ("),
        DTSTest_GeneralInfo->windowsVersion,
        _T(")"));
    String ^testerInfoFilename = String::Concat(
        DTSTest_GeneralInfo->logDirectory,
        DTSTEST_STRING_BACKSLASH,
        _T("DTSTest-TesterInfo.log"));
    StreamWriter ^textWriter = File::AppendText(testerInfoFilename);
    if (textWriter)
    {
        textWriter->WriteLine(testerInfoString);
        textWriter->Close();
    }
    RecordBasicEvent("{0} concluded", functionName);
}                                       // end of DTSTest_LogTesterInfo()
//----------------------------------------------------------------------------
// DTSTest_ReadFilePathFromLine
//
// Returns the unmanaged file path string stored in the specified managed line
// identified by parameter
//
// Note:    This function assumes that the characters that represent the
//          value are located beginning with the first character following the
//          parameter string
//----------------------------------------------------------------------------
    String ^ DTSTest_GUIClass::
DTSTest_ReadFilePathFromLine(
    String          ^lineString,
    String          ^parameter)
{
    String          ^data;
    //------------------------------------------------------------------------
    if (StringSet(lineString) && StringSet(parameter))
    {
        if (lineString->Contains(parameter))
        {
            data = StringAfter(lineString, parameter);
            if (StringSet(data) && StringICompare(data, DTSTEST_STRING_NONE))
            {
                if (File::Exists(data))
                {
                    return data;
                }
            }
        }
    }
    return String::Empty;
}                                       // end of DTSTest_ReadFilePathFromLine()
//----------------------------------------------------------------------------
// DTSTest_ReadHexByteFromLine
//
// Returns the value stored in the specified line as hex text and identified
// by parameter
//
// Note:    This function assumes that the hex characters that represent the
//          value are located beginning with the first character following the
//          parameter string
//----------------------------------------------------------------------------
    BYTE DTSTest_GUIClass::
DTSTest_ReadHexByteFromLine(
    String          ^lineString,
    String          ^parameter)
{
    BYTE            inputValue = 0;
    //------------------------------------------------------------------------
    if (StringSet(lineString) && StringSet(parameter))
    {
        if (lineString->Contains(parameter))
        {
            String ^data = StringAfter(lineString, parameter);
            if ((data->Length == 2) && StringICompare(data, "00"))
            {
                inputValue = Convert::ToByte(data, 16);
            }
        }
    }
    return inputValue;
}                                       // end of DTSTest_ReadHexByteFromLine()
//----------------------------------------------------------------------------
// DTSTest_ReadHexValueFromLine
//
// Returns the value stored in the specified line as hex text and identified
// by parameter
//
// Note:    This function assumes that the hex characters that represent the
//          value are located beginning with the first character following the
//          parameter string
//----------------------------------------------------------------------------
    DWORD DTSTest_GUIClass::
DTSTest_ReadHexValueFromLine(
    String          ^lineString,
    String          ^parameter)
{
    DWORD           inputValue = 0;
    //------------------------------------------------------------------------
    if (StringSet(lineString) && StringSet(parameter))
    {
        if (lineString->Contains(parameter))
        {
            String ^data = StringAfter(lineString, parameter);
            if ((data->Length == 8) && StringICompare(data, "00000000"))
            {
                inputValue = Convert::ToInt32(data, 16);
            }
        }
    }
    return inputValue;
}                                       // end of DTSTest_ReadHexValueFromLine()
//----------------------------------------------------------------------------
// DTSTest_ReadStringFromLine
//
// Returns the unmanaged string stored in the specified managed line
// identified by parameter
//
// Note:    This function assumes that the characters that represent the
//          value are located beginning with the first character following the
//          parameter string
//----------------------------------------------------------------------------
    String ^ DTSTest_GUIClass::
DTSTest_ReadStringFromLine(
    String          ^lineString,
    String          ^parameter)
{
    String          ^data;
    //------------------------------------------------------------------------
    if (StringSet(lineString) && StringSet(parameter))
    {
        if (lineString->Contains(parameter))
        {
            data = StringAfter(lineString, parameter);
            if (StringSet(data) && StringICompare(data, DTSTEST_STRING_NONE))
            {
                return data;
            }
        }
    }
    return String::Empty;
}                                       // end of DTSTest_ReadStringFromLine()
//----------------------------------------------------------------------------
// DTSTest_ReadYesNoFromLine
//
// Returns true or false, corresponding to the Yes or No value stored in the
// specified line identified by parameter
//
// Note:    This function assumes that the characters that represent the
//          value are located beginning with the first character following the
//          parameter string
//----------------------------------------------------------------------------
    bool DTSTest_GUIClass::
DTSTest_ReadYesNoFromLine(
    String          ^lineString,
    String          ^parameter)
{
    bool            inputValue = GUI_NO;
    //------------------------------------------------------------------------
    if (StringSet(lineString) && StringSet(parameter))
    {
        if (lineString->Contains(parameter))
        {
            String ^data = StringAfter(lineString, parameter);
            if (StringICompare(data, "Yes") == 0)
                inputValue = GUI_YES;
        }
    }
    return inputValue;
}                                       // end of DTSTest_ReadYesNoFromLine()
//----------------------------------------------------------------------------
// DTSTest_RecordEvent
//
// Records the formatted string in the Event Log, using variable arguments
//
// Note:    Because this function uses the String::Format method to format the
//          arguments into a single managed string, the calling convention
//          should look similar to
//
//          char    *unmanagedString = "Testing";
//          DWORD   status = DTSTEST_SUCCESS;
//          . . .
//          DTSTest_RecordEvent(
//              true,
//              "The {0} function was clicked and returned 0x{1:X2}",
//              gcnew String(unmanagedString),
//              status);
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_RecordEvent(
    bool            allow,
    String          ^formatString,
    ...array <Object ^>
                    ^parameters)
{
    //------------------------------------------------------------------------
    if (allow && StringSet(formatString))
    {
        String ^formattedString = String::Format(formatString, parameters);
        DTSTest_UpdateEventLog(formattedString);
        delete formattedString;
    }
}                                       // end of DTSTest_RecordEvent()
//----------------------------------------------------------------------------
// DTSTest_RetrieveConfigData
//
// Retrieves the information stored in the configuration file, if present
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_RetrieveConfigData(void)
{
    bool            proceedToReadConfigFile = GUI_NO;
    bool            processingGeneralSection = GUI_YES;
    bool            usingOutdatedConfigFile = GUI_NO;
    DWORD           generalFlags = DTSTEST_GENERAL_ZERO_FLAG;
    DWORD           inputValue;
    String          ^data;
    String          ^lineString;
    String          ^parameter;
    String          ^pathString;
    StreamReader    ^textReader;
    String          ^functionName = _T("DTSTest_RetrieveConfigData");
    //------------------------------------------------------------------------
    RecordVerboseEvent("{0} called", functionName);
    if (!(DTSTest_GeneralInfo->flags & DTSTEST_GENERAL_CONFIG_DONT_LOAD))
    {
        pathString = String::Concat(
            DTSTest_GeneralInfo->logDirectory,
            DTSTEST_STRING_BACKSLASH,
            _T("DTSTest-"),
            DTSTEST_PROGRAM_VERSION_STRING,
            _T(".config"));
        if (File::Exists(pathString))
        {
            proceedToReadConfigFile = GUI_YES;
            DTSTest_GeneralInfo->configFilePath = pathString;
            DTSTest_GeneralInfo->flags |= DTSTEST_GENERAL_CONFIG_FILE_SPECIFIED;
        }
        else
        {
            //----------------------------------------------------------------
            // The version-appropriate config file is not found, so search for
            // one from an older version
            //----------------------------------------------------------------
            String ^latestConfigPath = String::Empty;
            String ^logDir = String::Concat(DTSTest_GeneralInfo->logDirectory, DTSTEST_STRING_BACKSLASH);
            array <String ^> ^configFiles = Directory::GetFiles(logDir, "DTSTest-*.config");
            if (StringSet(configFiles))
            {
                for each (String ^oldConfigPath in configFiles)
                {
                    if (StringSet(latestConfigPath))
                    {
                        if (StringICompare(oldConfigPath, latestConfigPath) > 0)
                            latestConfigPath = oldConfigPath;
                    }
                    else
                        latestConfigPath = oldConfigPath;
                }
                if (StringSet(latestConfigPath) && File::Exists(latestConfigPath))
                {
                    //--------------------------------------------------------
                    // A config file from an older software version is found,
                    // so load as many parameters from the old one as possible
                    //--------------------------------------------------------
                    proceedToReadConfigFile = GUI_YES;
                    usingOutdatedConfigFile = GUI_YES;
                    pathString = latestConfigPath;
                }                       // end of if (StringSet(latestConfigPath) && File::Exists(latestConfigPath))
            }
            delete [] configFiles;
        }                               // end of else of if (File::Exists(pathString))
        if (proceedToReadConfigFile)
        {
            textReader = File::OpenText(pathString);
            if (textReader)
            {
                //------------------------------------------------------------
                // Read a line
                //------------------------------------------------------------
                while (lineString = textReader->ReadLine())
                {
                    lineString = lineString->Trim();
                    //--------------------------------------------------------
                    // Locate any comments and zero out the line from that
                    // point to the end of the line
                    //--------------------------------------------------------
                    if (lineString->Contains("#"))
                    {
                        lineString = lineString->Substring(0, lineString->IndexOf("#"));
                    }
                    if (StringSet(lineString))
                    {
                        if (processingGeneralSection)
                        {
                            //------------------------------------------------
                            // Import the operator name, if present
                            //------------------------------------------------
                            parameter = _T("OperatorName=");
                            if (lineString->Contains(parameter))
                            {
                                data = StringAfter(lineString, parameter);
                                if (StringSet(data))
                                {
                                    if (StringICompare(data, DTSTEST_STRING_NONE))
                                    {
                                        DTSTest_GeneralInfo->operatorName = data;
                                    }
                                }
                                continue;
                            }
                            //------------------------------------------------
                            // Import the die serial Number, if present
                            //------------------------------------------------
                            parameter = _T("DieSerialNumber=");
                            if (lineString->Contains(parameter))
                            {
                                data = StringAfter(lineString, parameter);
                                if (StringSet(data))
                                {
                                    if (StringICompare(data, DTSTEST_STRING_NONE))
                                    {
                                        DTSTest_GeneralInfo->dieSerialNumber = data;
                                    }
                                }
                                continue;
                            }
                            //------------------------------------------------
                            // Import the Main Placeholders, if present
                            //------------------------------------------------
                            parameter = _T("MainPlaceholder1=");
                            if (lineString->Contains(parameter))
                            {
                                data = StringAfter(lineString, parameter);
                                if (StringSet(data))
                                {
                                    if (StringICompare(data, DTSTEST_STRING_NONE))
                                    {
                                        DTSTest_GeneralInfo->mainScript->placeholder1String = data;
                                        BYTE mainPlaceholder1Value = 0;
                                        bool isCorrectFormat = DTSTest_ParseAndConvertHexStringToByte(
                                            DTSTest_GeneralInfo->mainScript->placeholder1String,
                                            &mainPlaceholder1Value);
                                        if (isCorrectFormat)
                                            DTSTest_GeneralInfo->mainScript->placeholder1Value = mainPlaceholder1Value;
                                    }
                                }
                                continue;
                            }
                            parameter = _T("MainPlaceholder2=");
                            if (lineString->Contains(parameter))
                            {
                                data = StringAfter(lineString, parameter);
                                if (StringSet(data))
                                {
                                    if (StringICompare(data, DTSTEST_STRING_NONE))
                                    {
                                        DTSTest_GeneralInfo->mainScript->placeholder2String = data;
                                        BYTE mainPlaceholder2Value = 0;
                                        bool isCorrectFormat = DTSTest_ParseAndConvertHexStringToByte(
                                            DTSTest_GeneralInfo->mainScript->placeholder2String,
                                            &mainPlaceholder2Value);
                                        if (isCorrectFormat)
                                            DTSTest_GeneralInfo->mainScript->placeholder2Value = mainPlaceholder2Value;
                                    }
                                }
                                continue;
                            }
                            //------------------------------------------------
                            // Import the general search string, if present
                            //------------------------------------------------
                            parameter = _T("SearchString=");
                            if (lineString->Contains(parameter))
                            {
                                data = StringAfter(lineString, parameter);
                                if (StringSet(data))
                                {
                                    if (StringICompare(data, DTSTEST_STRING_NONE))
                                    {
                                        DTSTest_GeneralInfo->searchString = data;
                                    }
                                }
                                continue;
                            }
                            //------------------------------------------------
                            // Import the general control script path string,
                            // if present
                            //------------------------------------------------
                            parameter = _T("ControlScriptPath=");
                            if (lineString->Contains(parameter))
                            {
                                data = StringAfter(lineString, parameter);
                                if (StringSet(data))
                                {
                                    if (StringICompare(data, DTSTEST_STRING_NONE))
                                    {
                                        DTSTest_GeneralInfo->mainScript->controlScriptFilePath = data;
                                    }
                                }
                                continue;
                            }
                            //------------------------------------------------
                            // Import the general results log path string, if
                            // present
                            //------------------------------------------------
                            parameter = _T("ResultsLogPath=");
                            if (lineString->Contains(parameter))
                            {
                                data = StringAfter(lineString, parameter);
                                if (StringSet(data))
                                {
                                    if (StringICompare(data, DTSTEST_STRING_NONE))
                                    {
                                        DTSTest_GeneralInfo->mainScript->resultsLogFilePath = data;
                                    }
                                }
                                continue;
                            }
                            //------------------------------------------------
                            // Import the email address, if present
                            //------------------------------------------------
                            parameter = _T("EmailAddress=");
                            if (lineString->Contains(parameter))
                            {
                                data = StringAfter(lineString, parameter);
                                if (StringSet(data))
                                {
                                    if (StringICompare(data, DTSTEST_STRING_NONE))
                                    {
                                        DTSTest_GeneralInfo->emailAddress = data;
                                    }
                                }
                                continue;
                            }
                            //------------------------------------------------
                            // Import the email CC address, if present
                            //------------------------------------------------
                            parameter = _T("EmailCCAddress=");
                            if (lineString->Contains(parameter))
                            {
                                data = StringAfter(lineString, parameter);
                                if (StringSet(data))
                                {
                                    if (StringICompare(data, DTSTEST_STRING_NONE))
                                    {
                                        DTSTest_GeneralInfo->emailCCAddress = data;
                                    }
                                }
                                continue;
                            }
                            //------------------------------------------------
                            // Import the text message To number, if present
                            //------------------------------------------------
                            parameter = _T("TextMessageToNumber=");
                            if (lineString->Contains(parameter))
                            {
                                data = StringAfter(lineString, parameter);
                                if (StringSet(data))
                                {
                                    if (StringICompare(data, DTSTEST_STRING_NONE))
                                    {
                                        DTSTest_GeneralInfo->textMessageToNumber = data;
                                    }
                                }
                                continue;
                            }
                            //------------------------------------------------
                            // Import the text message CC number, if present
                            //------------------------------------------------
                            parameter = _T("TextMessageCCNumber=");
                            if (lineString->Contains(parameter))
                            {
                                data = StringAfter(lineString, parameter);
                                if (StringSet(data))
                                {
                                    if (StringICompare(data, DTSTEST_STRING_NONE))
                                    {
                                        DTSTest_GeneralInfo->textMessageCCNumber = data;
                                    }
                                }
                                continue;
                            }
                            //------------------------------------------------
                            // Import the email message To address, if present
                            //------------------------------------------------
                            parameter = _T("EmailMessageToAddress=");
                            if (lineString->Contains(parameter))
                            {
                                data = StringAfter(lineString, parameter);
                                if (StringSet(data))
                                {
                                    if (StringICompare(data, DTSTEST_STRING_NONE))
                                    {
                                        DTSTest_GeneralInfo->emailMessageToAddress = data;
                                    }
                                }
                                continue;
                            }
                            //------------------------------------------------
                            // Import the email message CC address, if present
                            //------------------------------------------------
                            parameter = _T("EmailMessageCCAddress=");
                            if (lineString->Contains(parameter))
                            {
                                data = StringAfter(lineString, parameter);
                                if (StringSet(data))
                                {
                                    if (StringICompare(data, DTSTEST_STRING_NONE))
                                    {
                                        DTSTest_GeneralInfo->emailMessageCCAddress = data;
                                    }
                                }
                                continue;
                            }
                            //------------------------------------------------
                            // Import the general use path, if present
                            //------------------------------------------------
                            parameter = _T("GeneralUsePath=");
                            if (lineString->Contains(parameter))
                            {
                                data = DTSTest_ReadFilePathFromLine(
                                    lineString,
                                    parameter);
                                DTSTest_SetGeneralUsePath(data);
                                continue;
                            }
                            if (!usingOutdatedConfigFile)
                            {
                                //--------------------------------------------
                                // Import the general, persistent, and message
                                // flags, if present, but only if using the
                                // current config file, since flags can change
                                // between versions of the config file
                                //--------------------------------------------
                                parameter = _T("GeneralFlags=");
                                if (lineString->Contains(parameter))
                                {
                                    generalFlags = DTSTest_ReadHexValueFromLine(lineString, parameter);
                                    continue;
                                }
                                parameter = _T("GeneralPersistentFlags=");
                                if (lineString->Contains(parameter))
                                {
                                    DTSTest_GeneralInfo->persistentFlags = DTSTest_ReadHexValueFromLine(lineString, parameter);
                                    continue;
                                }
                                //--------------------------------------------
                                // The idea here is to read in the message flags
                                // flags from the config file only if the
                                // software is in Expert Mode, and if the
                                // program was not invoked from the command
                                // line
                                //--------------------------------------------
                                generalFlags |= (DTSTest_GeneralInfo->flags & DTSTEST_GENERAL_EXPERT_MODE);
                                if ((generalFlags & DTSTEST_GENERAL_EXPERT_MODE) && !StringSet(DTSTest_GeneralInfo->commandLine))
                                {
                                    parameter = _T("MessageFlags=");
                                    if (lineString->Contains(parameter))
                                    {
                                        inputValue = DTSTest_ReadHexValueFromLine(lineString, parameter);
                                        //------------------------------------
                                        // Note: the following test for the
                                        // MessageFlags value being nonzero
                                        // can be problematic. If it is, just
                                        // comment the test, but the consequence
                                        // is that the default values for all
                                        // these globals will be overridden.
                                        //------------------------------------
                                        if (inputValue)
                                        {
                                            DTSTest_BasicMessagesEnabled = (inputValue & GUI_MODAL_BASIC) ? GUI_YES : DTSTest_BasicMessagesEnabled;
                                            DTSTest_ErrorMessagesEnabled = (inputValue & GUI_MODAL_ERROR) ? GUI_YES : DTSTest_ErrorMessagesEnabled;
                                            DTSTest_VerboseMessagesEnabled = (inputValue & GUI_MODAL_VERBOSE) ? GUI_YES : DTSTest_VerboseMessagesEnabled;
                                            DTSTest_DetailedMessagesEnabled = (inputValue & GUI_MODAL_DETAILED) ? GUI_YES : DTSTest_DetailedMessagesEnabled;
                                            DTSTest_ExpMessagesEnabled = (inputValue & GUI_MODAL_EXP) ? GUI_YES : DTSTest_ExpMessagesEnabled;
                                            DTSTest_StackTracesEnabled = (inputValue & GUI_MODAL_STACK) ? GUI_YES : DTSTest_StackTracesEnabled;
                                            DTSTest_SendTextErrorMessagesEnabled = (inputValue & GUI_MODAL_TEXT) ? GUI_YES : GUI_NO;
                                            DTSTest_SendEmailErrorMessagesEnabled = (inputValue & GUI_MODAL_EMAIL) ? GUI_YES : GUI_NO;
                                            DTSTest_ExperimentsEnabled = (inputValue & GUI_EXPERIMENTS_BASIC) ? GUI_YES : GUI_NO;
                                            DTSTest_SoftwareUpdateInProgress = (inputValue & GUI_SOFTWARE_UPDATE) ? GUI_YES : GUI_NO;
                                        }
                                    }
                                }
                                parameter = _T("TestingFlags=");
                                if (lineString->Contains(parameter))
                                {
                                    inputValue = DTSTest_ReadHexValueFromLine(lineString, parameter);
                                    DTSTest_TestingDisplayInCommandDialogue = (inputValue & GUI_TESTING_FLAG_DISPLAY_IN_MAIN_DIALOGUE) ? GUI_YES : GUI_NO;
                                    DTSTest_TestingAutoLoadCoefficientData = (inputValue & GUI_TESTING_FLAG_AUTO_LOAD_COEFFICIENT_DATA) ? GUI_YES : GUI_NO;
                                }
                                //--------------------------------------------
                                // Import the user gauge and barge node
                                // addresses
                                //--------------------------------------------
//                                PDGICInfo ^pgInfo = DTSTest_GeneralInfo->pgInfo;
//                                parameter = _T("UserBargeNodeAddress1=");
//                                if (lineString->Contains(parameter))
//                                {
//                                    pgInfo->userBargeNodeAddress1 = DTSTest_ReadHexByteFromLine(lineString, parameter);
//                                }
//                                parameter = _T("UserBargeNodeAddress2=");
//                                if (lineString->Contains(parameter))
//                                {
//                                    pgInfo->userBargeNodeAddress2 = DTSTest_ReadHexByteFromLine(lineString, parameter);
//                                }
//                                parameter = _T("UserBargeNodeAddress3=");
//                                if (lineString->Contains(parameter))
//                                {
//                                    pgInfo->userBargeNodeAddress3 = DTSTest_ReadHexByteFromLine(lineString, parameter);
//                                }
//                                parameter = _T("UserBargeNodeAddress4=");
//                                if (lineString->Contains(parameter))
//                                {
//                                    pgInfo->userBargeNodeAddress4 = DTSTest_ReadHexByteFromLine(lineString, parameter);
//                                }
//                                parameter = _T("UserBargeNodeAddress5=");
//                                if (lineString->Contains(parameter))
//                                {
//                                    pgInfo->userBargeNodeAddress5 = DTSTest_ReadHexByteFromLine(lineString, parameter);
//                                }
//                                parameter = _T("UserBargeNodeAddress6=");
//                                if (lineString->Contains(parameter))
//                                {
//                                    pgInfo->userBargeNodeAddress6 = DTSTest_ReadHexByteFromLine(lineString, parameter);
//                                }
//                                parameter = _T("UserGaugeNodeAddress1=");
//                                if (lineString->Contains(parameter))
//                                {
//                                    pgInfo->userGaugeNodeAddress1 = DTSTest_ReadHexByteFromLine(lineString, parameter);
//                                }
//                                parameter = _T("UserGaugeNodeAddress2=");
//                                if (lineString->Contains(parameter))
//                                {
//                                    pgInfo->userGaugeNodeAddress2 = DTSTest_ReadHexByteFromLine(lineString, parameter);
//                                }
//                                parameter = _T("UserGaugeNodeAddress3=");
//                                if (lineString->Contains(parameter))
//                                {
//                                    pgInfo->userGaugeNodeAddress3 = DTSTest_ReadHexByteFromLine(lineString, parameter);
//                                }
                            }           // end of if (!usingOutdatedConfigFile)
                            parameter = _T("ExperimentNumber=");
                            if (lineString->Contains(parameter))
                            {
                                data = StringAfter(lineString, parameter);
                                if (StringSet(data))
                                {
                                    inputValue = Convert::ToInt32(data);
                                    if ((inputValue >= GUI_MINIMUM_EXPERIMENT_NUMBER) &&
                                        (inputValue <= GUI_MAXIMUM_EXPERIMENT_NUMBER))
                                    {
                                        DTSTest_CurrentExperimentNumber = inputValue;
                                    }
                                }
                                continue;
                            }
//                            for (int offset = 0; offset < DTSTEST_MAXIMUM_NUMBER_OF_PLACEHOLDERS; offset++)
//                            {
//                                parameter = String::Format("ScriptPlaceholder{0:D2}=", offset + 1);
//                                if (lineString->Contains(parameter))
//                                {
//                                    DTSTest_ScriptPlaceholderArray[offset]->placeholderValue =
//                                        DTSTest_ReadHexByteFromLine(lineString, parameter);
//                                }
//                            }
                            parameter = _T("TestingDelay=");
                            if (lineString->Contains(parameter))
                            {
                                data = StringAfter(lineString, parameter);
                                if (StringSet(data))
                                {
                                    inputValue = Convert::ToInt32(data);
                                    if (inputValue > 0)
                                    {
                                        DTSTest_TestingDelay = inputValue;
                                    }
                                }
                                continue;
                            }
                            for (int offset = 0; offset < DTSTEST_MAXIMUM_NUMBER_OF_TEST_ENTRIES; offset++)
                            {
                                TestEntry ^testEntry = DTSTest_TestEntryArray[offset];
                                parameter = String::Format("TestEntry{0:D2}Selected=", offset);
                                if (lineString->Contains(parameter))
                                {
                                    testEntry->entrySelectedForTesting =
                                        DTSTest_ReadYesNoFromLine(lineString, parameter);
                                }
                                parameter = String::Format("TestEntry{0:D2}Placeholder1=", offset);
                                if (lineString->Contains(parameter))
                                {
                                    testEntry->placeholder1Value =
                                        DTSTest_ReadHexByteFromLine(lineString, parameter);
                                }
                                parameter = String::Format("TestEntry{0:D2}Placeholder2=", offset);
                                if (lineString->Contains(parameter))
                                {
                                    testEntry->placeholder2Value =
                                        DTSTest_ReadHexByteFromLine(lineString, parameter);
                                }
                                parameter = String::Format("TestEntry{0:D2}Placeholder3=", offset);
                                if (lineString->Contains(parameter))
                                {
                                    testEntry->placeholder3Value =
                                        DTSTest_ReadHexByteFromLine(lineString, parameter);
                                }
                                parameter = String::Format("TestEntry{0:D2}ScriptPath=", offset);
                                if (lineString->Contains(parameter))
                                {
                                    data = DTSTest_ReadFilePathFromLine(
                                        lineString,
                                        parameter);
                                    if (StringSet(data))
                                    {
                                        testEntry->entryControlScriptPath = data;
                                        testEntry->entryControlScriptFile = Path::GetFileName(data);
                                    }
                                }
                                parameter = String::Format("TestEntry{0:D2}CommandString=", offset);
                                if (lineString->Contains(parameter))
                                {
                                    data = DTSTest_ReadStringFromLine(
                                        lineString,
                                        parameter);
                                    testEntry->entryCommandString = data;
                                    if (data->Contains(DTSTEST_STRING_DOLLAR) || data->Contains(DTSTEST_STRING_SPACE))
                                    {
                                        if (data->Contains(DTSTEST_STRING_DOLLAR))
                                        {
                                            String ^replacedString = String::Empty;
                                            replacedString = data->Replace(
                                                "$1", String::Format("{0:X2}", testEntry->placeholder1Value));
                                            replacedString = replacedString->Replace(
                                                "$2", String::Format("{0:X2}", testEntry->placeholder2Value));
                                            replacedString = replacedString->Replace(
                                                "$3", String::Format("{0:X2}", testEntry->placeholder3Value));
                                            testEntry->entryCommandReplacedString = replacedString;
                                        }
                                        else
                                            testEntry->entryCommandReplacedString = data;
                                    }
                                    else
                                        testEntry->entryCommandReplacedString = data;
                                }
                            }
                            parameter = _T("[Unit_Information]");
                            if (lineString->Contains(parameter))
                            {
                                processingGeneralSection = GUI_NO;
                                continue;
                            }
                        }               // end of if (processingGeneralSection)
                        else
                        {
                            //------------------------------------------------
                            // Import the per-unit information
                            //------------------------------------------------
                        }               // end of else of if (processGeneralSection)
                    }                   // end of if (StringSet(lineString))
                }                       // end of while (lineString = textReader->ReadLine())
                textReader->Close();
                DTSTest_GeneralInfo->flags |= DTSTEST_GENERAL_CONFIG_INFO_LOADED;
            }                           // end of if (textReader)
            RecordVerboseEvent("Config information read from file\n{0}",
                pathString);
        }                               // end of if (proceedToReadConfigFile)
        else
        {
            DTSTest_GeneralInfo->configFilePath = String::Empty;
            DTSTest_GeneralInfo->flags &= ~DTSTEST_GENERAL_CONFIG_FILE_SPECIFIED;
            DTSTest_GeneralInfo->flags &= ~DTSTEST_GENERAL_CONFIG_INFO_LOADED;
        }
        //--------------------------------------------------------------------
        // Set the persistent flags if they are not set
        //--------------------------------------------------------------------
        if (!DTSTest_GeneralInfo->persistentFlags)
            DTSTest_GeneralInfo->persistentFlags = DTSTEST_GENERAL_DEFAULT_PERSISTENT_FLAGS;
        //--------------------------------------------------------------------
        // Apply the effects of the persistent flags
        //--------------------------------------------------------------------
        DTSTest_GeneralInfo->flags |= (generalFlags & DTSTest_GeneralInfo->persistentFlags);
    }
    RecordVerboseEvent("{0} concluded", functionName);
}                                       // end of DTSTest_RetrieveConfigData()
//----------------------------------------------------------------------------
// DTSTest_SaveConfigData
//
// Saves program information in the configuration file
//
// Note:    If the config file exists, it is overwritten
//
// Note:    The config file is created in the executable directory, by default
//
// Note:    This function reports no errors, by design
//
// Called by:   DTSTest_Finalize
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_SaveConfigData(void)
{
    String          ^border = GUI_TEXT_FILE_BORDER;
    String          ^configFileName;
    String          ^lineString;
    String          ^pathString;
    StreamWriter    ^textWriter;
    DateTime        dateTime = DateTime::Now;
    String          ^functionName = _T("DTSTest_SaveConfigData");
    //------------------------------------------------------------------------
    RecordVerboseEvent("{0} called", functionName);
    if (DTSTest_GeneralInfo->flags & DTSTEST_GENERAL_CONFIG_FILE_SPECIFIED)
    {
        pathString = DTSTest_GeneralInfo->configFilePath;
        configFileName = Path::GetFileName(pathString);
    }
    else
    {
        configFileName = String::Concat(
            "DTSTest-",
            DTSTEST_PROGRAM_VERSION_STRING,
            ".config");
        pathString = String::Concat(
            DTSTest_GeneralInfo->logDirectory,
            DTSTEST_STRING_BACKSLASH,
            configFileName);
    }
    if (DTSTest_GeneralInfo->flags & DTSTEST_GENERAL_CONFIG_DELETE_ON_EXIT)
    {
        if (File::Exists(pathString))
        {
            File::Delete(pathString);
        }
    }
    if (!(DTSTest_GeneralInfo->flags & DTSTEST_GENERAL_CONFIG_DONT_SAVE))
    {
        textWriter = File::CreateText(pathString);
        if (textWriter)
        {
            textWriter->WriteLine(border);
            //----------------------------------------------------------------
            // Write out the header, including the program name and the
            // current date and time
            //----------------------------------------------------------------
            lineString = String::Format(
                "# {0}\n#\n"
                "# DTSTest Configuration Data File\n#\n"
                "# Created on {1:D2} {2} {3:D4} at {4:D2}:{5:D2}:{6:D2}",
                configFileName,
                dateTime.Day,
                DTSTest_MonthStringArray[dateTime.Month],
                dateTime.Year,
                dateTime.Hour,
                dateTime.Minute,
                dateTime.Second);
            textWriter->WriteLine(lineString);
            textWriter->WriteLine(border);
            //----------------------------------------------------------------
            // Save general program information
            //----------------------------------------------------------------
            lineString = String::Format(
                "[DTSTest_Start]\n"
                "    ProgramVersion={0}\n"
                "    ProgramBuild={1:D}\n"
                "    OperatorName={2}\n"
                "    DieSerialNumber={3}\n"
                "    MainPlaceholder1={4}\n"
                "    MainPlaceholder2={5}\n"
                "    MainPlaceholder3={6}",
                DTSTEST_PROGRAM_VERSION_STRING,
                DTSTest_BuildNumber,
                DTSTest_GeneralInfo->operatorName,
                (StringSet(DTSTest_GeneralInfo->dieSerialNumber) ?
                    DTSTest_GeneralInfo->dieSerialNumber : DTSTEST_STRING_NONE),
                (StringSet(DTSTest_GeneralInfo->mainScript->placeholder1String) ?
                    DTSTest_GeneralInfo->mainScript->placeholder1String : DTSTEST_STRING_NONE),
                (StringSet(DTSTest_GeneralInfo->mainScript->placeholder2String) ?
                    DTSTest_GeneralInfo->mainScript->placeholder2String : DTSTEST_STRING_NONE),
                (StringSet(DTSTest_GeneralInfo->mainScript->placeholder3String) ?
                    DTSTest_GeneralInfo->mainScript->placeholder3String : DTSTEST_STRING_NONE));
            textWriter->WriteLine(lineString->Replace(DTSTEST_STRING_LF, Environment::NewLine));
            //----------------------------------------------------------------
            // Save program parameters and discrete flags
            //----------------------------------------------------------------
            lineString = String::Format(
                "[DTSTest_Parameters]\n"
                "    CommandLine={0}\n"
                "    ConfigFilePath={1}\n"
                "    GeneralUsePath={2}\n"
                "    SearchString={3}\n"
                "    ErrorLogPath={4}\n"
                "    EventLogPath={5}\n"
                "    ControlScriptPath={6}\n"
                "    ResultsLogPath={7}\n"
                "    EmailAddress={8}\n"
                "    EmailCCAddress={9}\n"
                "    TextMessageToNumber={10}\n"
                "    TextMessageCCNumber={11}\n"
                "    EmailMessageToAddress={12}\n"
                "    EmailMessageCCAddress={13}",
                (StringSet(DTSTest_GeneralInfo->commandLine) ?
                    DTSTest_GeneralInfo->commandLine : DTSTEST_STRING_NONE),
                (((DTSTest_GeneralInfo->flags & DTSTEST_GENERAL_CONFIG_FILE_SPECIFIED) && StringSet(DTSTest_GeneralInfo->configFilePath)) ?
                    DTSTest_GeneralInfo->configFilePath : DTSTEST_STRING_NONE),
                (((DTSTest_GeneralInfo->flags & DTSTEST_GENERAL_USE_PATH_SPECIFIED) && StringSet(DTSTest_GeneralInfo->generalUsePath)) ?
                    DTSTest_GeneralInfo->generalUsePath : DTSTEST_STRING_NONE),
                (StringSet(DTSTest_GeneralInfo->searchString) ?
                    DTSTest_GeneralInfo->searchString : DTSTEST_STRING_NONE),
                ((DTSTest_GeneralInfo->flags & DTSTEST_GENERAL_ERROR_LOG_SPECIFIED) ?
                    DTSTest_GeneralInfo->errorLogPath : DTSTEST_STRING_NONE),
                ((DTSTest_GeneralInfo->flags & DTSTEST_GENERAL_EVENT_LOG_SPECIFIED) ?
                    DTSTest_GeneralInfo->eventLogPath : DTSTEST_STRING_NONE),
                (StringSet(DTSTest_GeneralInfo->mainScript->controlScriptFilePath) ?
                    DTSTest_GeneralInfo->mainScript->controlScriptFilePath : DTSTEST_STRING_NONE),
                (StringSet(DTSTest_GeneralInfo->mainScript->resultsLogFilePath) ?
                    DTSTest_GeneralInfo->mainScript->resultsLogFilePath : DTSTEST_STRING_NONE),
                (StringSet(DTSTest_GeneralInfo->emailAddress) ?
                    DTSTest_GeneralInfo->emailAddress : DTSTEST_STRING_NONE),
                (StringSet(DTSTest_GeneralInfo->emailCCAddress) ?
                    DTSTest_GeneralInfo->emailCCAddress : DTSTEST_STRING_NONE),
                (StringSet(DTSTest_GeneralInfo->textMessageToNumber) ?
                    DTSTest_GeneralInfo->textMessageToNumber : DTSTEST_STRING_NONE),
                (StringSet(DTSTest_GeneralInfo->textMessageCCNumber) ?
                    DTSTest_GeneralInfo->textMessageCCNumber : DTSTEST_STRING_NONE),
                (StringSet(DTSTest_GeneralInfo->emailMessageToAddress) ?
                    DTSTest_GeneralInfo->emailMessageToAddress : DTSTEST_STRING_NONE),
                (StringSet(DTSTest_GeneralInfo->emailMessageCCAddress) ?
                    DTSTest_GeneralInfo->emailMessageCCAddress : DTSTEST_STRING_NONE));
            textWriter->WriteLine(lineString->Replace(DTSTEST_STRING_LF, Environment::NewLine));
            //----------------------------------------------------------------
            // Save global flags
            //----------------------------------------------------------------
            DWORD messageFlags = 0;
            if (DTSTest_BasicMessagesEnabled)
                messageFlags |= GUI_MODAL_BASIC;
            if (DTSTest_ErrorMessagesEnabled)
                messageFlags |= GUI_MODAL_ERROR;
            if (DTSTest_VerboseMessagesEnabled)
                messageFlags |= GUI_MODAL_VERBOSE;
            if (DTSTest_DetailedMessagesEnabled)
                messageFlags |= GUI_MODAL_DETAILED;
            if (DTSTest_ExpMessagesEnabled)
                messageFlags |= GUI_MODAL_EXP;
            if (DTSTest_StackTracesEnabled)
                messageFlags |= GUI_MODAL_STACK;
            if (DTSTest_SendTextErrorMessagesEnabled)
                messageFlags |= GUI_MODAL_TEXT;
            if (DTSTest_SendEmailErrorMessagesEnabled)
                messageFlags |= GUI_MODAL_EMAIL;
            if (DTSTest_EventLogBasicEnabled)
                messageFlags |= GUI_ELOG_BASIC;
            if (DTSTest_EventLogVerboseEnabled)
                messageFlags |= GUI_ELOG_VERBOSE;
            if (DTSTest_EventLogDetailedEnabled)
                messageFlags |= GUI_ELOG_DETAILED;
            if (DTSTest_ExperimentsEnabled)
                messageFlags |= GUI_EXPERIMENTS_BASIC;
            if (DTSTest_SoftwareUpdateInProgress)
                messageFlags |= GUI_SOFTWARE_UPDATE;
            lineString = String::Format(
                "    GeneralFlags={0:X8}\n"
                "    GeneralPersistentFlags={1:X8}\n"
                "    MessageFlags={2:X8}",
                DTSTest_GeneralInfo->flags,
                DTSTest_GeneralInfo->persistentFlags,
                messageFlags);
            textWriter->WriteLine(lineString->Replace(DTSTEST_STRING_LF, Environment::NewLine));
//            //----------------------------------------------------------------
//            // Save user gauge and barge values
//            //----------------------------------------------------------------
//            PDGICInfo ^pgInfo = DTSTest_GeneralInfo->pgInfo;
//            lineString = String::Format(
//                "    UserGaugeNodeAddress1={0:X2}\n"
//                "    UserGaugeNodeAddress2={1:X2}\n"
//                "    UserGaugeNodeAddress3={2:X2}\n"
//                "    UserBargeNodeAddress1={3:X2}\n"
//                "    UserBargeNodeAddress2={4:X2}\n"
//                "    UserBargeNodeAddress3={5:X2}\n"
//                "    UserBargeNodeAddress4={6:X2}\n"
//                "    UserBargeNodeAddress5={7:X2}\n"
//                "    UserBargeNodeAddress6={8:X2}",
//                pgInfo->userGaugeNodeAddress1,
//                pgInfo->userGaugeNodeAddress2,
//                pgInfo->userGaugeNodeAddress3,
//                pgInfo->userBargeNodeAddress1,
//                pgInfo->userBargeNodeAddress2,
//                pgInfo->userBargeNodeAddress3,
//                pgInfo->userBargeNodeAddress4,
//                pgInfo->userBargeNodeAddress5,
//                pgInfo->userBargeNodeAddress6);
//            textWriter->WriteLine(lineString->Replace(DTSTEST_STRING_LF, Environment::NewLine));
            //----------------------------------------------------------------
            // Save global integer values
            //----------------------------------------------------------------
            lineString = String::Format(
                "    ExperimentNumber={0:D}",
                DTSTest_CurrentExperimentNumber);
            textWriter->WriteLine(lineString->Replace(DTSTEST_STRING_LF, Environment::NewLine));
//            //----------------------------------------------------------------
//            // Save script placeholder values
//            //----------------------------------------------------------------
//            for (int offset = 0; offset < DTSTEST_MAXIMUM_NUMBER_OF_PLACEHOLDERS; offset++)
//            {
//                if (offset)
//                    lineString += "\n";
//                else
//                    lineString = String::Empty;
//                lineString += String::Format(
//                    "    ScriptPlaceholder{0:D2}={1:X2}",
//                    (offset + 1), DTSTest_ScriptPlaceholderArray[offset]->placeholderValue);
//            }
//            textWriter->WriteLine(lineString->Replace(DTSTEST_STRING_LF, Environment::NewLine));
            //----------------------------------------------------------------
            // Save testing flags and delay
            //----------------------------------------------------------------
            DWORD testingFlags = 0;
            if (DTSTest_TestingDisplayInCommandDialogue)
                testingFlags |= GUI_TESTING_FLAG_DISPLAY_IN_MAIN_DIALOGUE;
            if (DTSTest_TestingAutoLoadCoefficientData)
                testingFlags |= GUI_TESTING_FLAG_AUTO_LOAD_COEFFICIENT_DATA;
            lineString = String::Format(
                "    TestingDelay={0:D}\n"
                "    TestingFlags={1:X8}",
                DTSTest_TestingDelay,
                testingFlags);
            textWriter->WriteLine(lineString->Replace(DTSTEST_STRING_LF, Environment::NewLine));
            //----------------------------------------------------------------
            // Save test entry values
            //----------------------------------------------------------------
            for (int offset = 0; offset < DTSTEST_MAXIMUM_NUMBER_OF_TEST_ENTRIES; offset++)
            {
                TestEntry ^testEntry = DTSTest_TestEntryArray[offset];
                if (offset)
                    lineString += "\n";
                else
                    lineString = String::Empty;
                lineString += String::Format(
                    "    TestEntry{0:D2}Selected={1}\n"
                    "    TestEntry{0:D2}Placeholder1={2:X2}\n"
                    "    TestEntry{0:D2}Placeholder2={3:X2}\n"
                    "    TestEntry{0:D2}Placeholder3={4:X2}\n"
                    "    TestEntry{0:D2}ScriptPath={5:X2}\n"
                    "    TestEntry{0:D2}CommandString={6:X2}",
                    offset,
                    (testEntry->entrySelectedForTesting ? "Yes" : "No"),
                    testEntry->placeholder1Value,
                    testEntry->placeholder2Value,
                    testEntry->placeholder3Value,
                    (StringSet(testEntry->entryControlScriptFile) ?
                        testEntry->entryControlScriptPath : DTSTEST_STRING_NONE),
                    (StringSet(testEntry->entryCommandString) ?
                        testEntry->entryCommandString : DTSTEST_STRING_NONE));
            }
            textWriter->WriteLine(lineString->Replace(DTSTEST_STRING_LF, Environment::NewLine));
            //----------------------------------------------------------------
            // Write out the footer
            //----------------------------------------------------------------
            textWriter->WriteLine("[DTSTest_End]");
            textWriter->WriteLine(border);
            lineString = String::Concat("# End of ", configFileName);
            textWriter->WriteLine(lineString);
            textWriter->WriteLine(border);
            textWriter->Close();
        }                               // end of if (textWriter)
        RecordVerboseEvent(
            "Config information saved in file\n{0}",
            pathString);
    }                                   // end of if (!(DTSTest_GeneralInfo->flags & DTSTEST_GENERAL_CONFIG_DONT_SAVE))
    RecordVerboseEvent("{0} concluded", functionName);
}                                       // end of DTSTest_SaveConfigData()
//----------------------------------------------------------------------------
// DTSTest_UpdateErrorLog
//
// Updates the error log file with the specified line, preceded by a date-and-
// time stamp
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_UpdateErrorLog(
    String          ^descriptionString)
{
    String          ^lineString;
    StreamWriter    ^textWriter;
    DateTime        dateTime = DateTime::Now;
    //------------------------------------------------------------------------
    if ((DTSTest_GeneralInfo->flags & DTSTEST_GENERAL_ERROR_LOG_SPECIFIED) &&
        StringSet(descriptionString))
    {
        descriptionString = descriptionString->Replace(DTSTEST_STRING_LF, Environment::NewLine);
        if (descriptionString->Contains(Environment::NewLine))
        {
            lineString = descriptionString->Replace(
                Environment::NewLine,
                String::Concat(Environment::NewLine, _T("                     :     ")));
        }
        else
        {
            lineString = descriptionString;
        }
        lineString = String::Format(
            "{0:D2} {1} {2:D4} {3:D2}:{4:D2}:{5:D2} : {6}",
            dateTime.Day,
            DTSTest_MonthStringArray[dateTime.Month],
            dateTime.Year,
            dateTime.Hour,
            dateTime.Minute,
            dateTime.Second,
            lineString);
        textWriter = File::AppendText(DTSTest_GeneralInfo->errorLogPath);
        if (textWriter)
        {
            textWriter->WriteLine(lineString);
            textWriter->Close();
        }
    }
}                                       // end of DTSTest_UpdateErrorLog()
//----------------------------------------------------------------------------
// DTSTest_UpdateEventLog
//
// Updates the event log file with the specified line, preceded by a date-and-
// time stamp
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_UpdateEventLog(
    String          ^descriptionString)
{
    String          ^lineString;
    StreamWriter    ^textWriter;
    DateTime        dateTime = DateTime::Now;
    //------------------------------------------------------------------------
    if ((DTSTest_GeneralInfo->flags & DTSTEST_GENERAL_EVENT_LOG_SPECIFIED) &&
        StringSet(descriptionString))
    {
        descriptionString = descriptionString->Replace(DTSTEST_STRING_LF, Environment::NewLine);
        if (descriptionString->Contains(Environment::NewLine))
        {
            lineString = descriptionString->Replace(
                Environment::NewLine,
                String::Concat(Environment::NewLine, _T("                     :     ")));
        }
        else
        {
            lineString = descriptionString;
        }
        lineString = String::Format(
            "{0:D2} {1} {2:D4} {3:D2}:{4:D2}:{5:D2} : {6}",
            dateTime.Day,
            DTSTest_MonthStringArray[dateTime.Month],
            dateTime.Year,
            dateTime.Hour,
            dateTime.Minute,
            dateTime.Second,
            lineString);
        try
        {
            textWriter = File::AppendText(DTSTest_GeneralInfo->eventLogPath);
            if (textWriter)
            {
                textWriter->WriteLine(lineString);
                textWriter->Close();
            }
        }
        catch (Exception ^ex)
        {
            UNREFERENCED_PARAMETER(ex);
            //----------------------------------------------------------------
            // If the write failed, just ignore the failure and move on
            //----------------------------------------------------------------
        }
    }
}                                       // end of DTSTest_UpdateEventLog()
//----------------------------------------------------------------------------
#endif      // DCONFIG_CPP
//============================================================================
// End of DConfig.cpp
//============================================================================
