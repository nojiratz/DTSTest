//============================================================================
// QDPDGIC.cpp
//
// The methods used to communicate with the WellDynamics PDGIC device
//
// Copyright (C) 2014 - 2016 Quartzdyne, Inc.  All rights reserved.
//
// No part of this source code may be reproduced or transmitted in any form or
// by any means, electronic or mechanical, including photocopying, recording,
// or any information storage and retrieval system, without express written
// permission from Quartzdyne, Inc.  Further, no use of this source code is
// permitted in any form or means without a valid, written license agreement
// with Quartzdyne, Inc.  While every reasonable precaution has been taken in
// the preparation of this source code, Quartzdyne, Inc., assumes no
// responsibility for errors, omissions, or damages from the use of the source
// code contained herein.
//
// NEITHER QUARTZDYNE, INC., ANY MEMBER OF QUARTZDYNE, INC., NOR ANY PERSON OR
// ORGANIZATION ACTING ON BEHALF OF THEM MAKES ANY WARRANTY OR REPRESENTATION
// WHATSOEVER, EXPRESS OR IMPLIED, INCLUDING ANY WARRANTY OF MERCHANTABILITY
// OR FITNESS FOR ANY PURPOSE WITH RESPECT TO THE SOURCE CODE OR ASSUMES ANY
// LIABILITY WHATSOEVER WITH RESPECT TO ANY USE OF THE SOURCE CODE OR ANY
// PORTION THEREOF OR WITH RESPECT TO ANY DAMAGES THAT MAY RESULT FROM SUCH
// USE.
//
// Noji Ratzlaff
//
// See DTSTest.log for a complete history of all updates, changes, and revisions
// of this source and other files and policies regarding DTSTest software
//
// Updated 01-14-2016
//============================================================================
#include    "stdafx.h"
#ifndef     QDPDGIC_CPP
#define     QDPDGIC_CPP
#include    "QDPDGIC.h"
//----------------------------------------------------------------------------
// DTSTest_PDGICAcquireReadings
//
// Retrieves one set of readings from the attached PDGIC device
//
// Returns: 0       = Success
//          nonzero = Failure
//
// Called by:   DTSTest_PDGICRetrieveCurrentReadings
//----------------------------------------------------------------------------
    DWORD DTSTest_GUIClass::
DTSTest_PDGICAcquireReadings(void)
{
    DWORD           status = DTSTEST_SUCCESS;
    String          ^functionName = _T("DTSTest_PDGICAcquireReadings");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0} called", functionName);
    if (DTSTest_GeneralInfo->pgInfo)
    {
        PDGICInfo ^pgInfo = DTSTest_GeneralInfo->pgInfo;
        //--------------------------------------------------------------------
        // Build a command and send it to the PDGIC device
        //--------------------------------------------------------------------
        if (pgInfo->PDGICPresent)
        {
            this->Cursor = Cursors::WaitCursor;
            //----------------------------------------------------------------
            // Load the default coefficient data
            //----------------------------------------------------------------
            DTSTest_LoadDefaultCoefficientData();
            //----------------------------------------------------------------
            // Discover the current PDGIC settings
            //----------------------------------------------------------------
//            DTSTest_ExperimentalScanForDevices(pgInfo);
            Thread ^runScanThread =
                gcnew Thread(gcnew ParameterizedThreadStart(this, &DTSTest_GUIClass::DTSTest_ExperimentalScanForDevicesThread));
            runScanThread->Start(pgInfo);
            this->Cursor = Cursors::Default;
        }                               // end of if (pgInfo->PDGICPresent)
        else
        {
//            Modal("A PDGIC device is not found on this computer");
            status = DTSTEST_ERROR_PDGIC_NOT_FOUND;                             // 0x000000C0
        }
    }                                   // end of if (DTSTest_GeneralInfo->pgInfo)
    else
    {
        status = DTSTEST_ERROR_PDGIC_INFO_POINTER_INVALID;                      // 0x000000C1
    }
    RecordBasicEvent("{0} concluded, returning 0x{1:X8}", functionName, status);
    return status;
}                                       // end of DTSTest_PDGICAcquireReadings()
//----------------------------------------------------------------------------
// DTSTest_PDGICDeterminePDGICPresence
//
// Determines whether a PDGIC exists at the serial port specified by
// pgInfo->portName
//
// Called by:   DTSTest_PDGICLocatePort
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_PDGICDeterminePDGICPresence(
    PDGICInfo       ^pgInfo)
{
    DWORD           status = DTSTEST_SUCCESS;
    String          ^functionName = _T("DTSTest_PDGICDeterminePDGICPresence");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0} called", functionName);
    if (pgInfo)
    {
        //--------------------------------------------------------------------
        // Set up a MODBUS command to read the PDGIC node address
        //--------------------------------------------------------------------
        pgInfo->nodeAddress = 0;
        pgInfo->commandArray[1] = MODBUS_COMMAND_REPORT_SLAVE_ID;               // 0x11
        DTSTest_PDGICSendCommand(pgInfo);
        if (pgInfo->numberOfBytesRead >= 7)
        {
            //----------------------------------------------------------------
            // If a PDGIC is present, not only will it respond successfully to
            // the MODBUS Identify command, but will actually return 7 or more
            // bytes; doesn't matter what those bytes are
            //
            // Unfortunately, it appears the Fluke Scopemeter will too
            //----------------------------------------------------------------
            pgInfo->PDGICPresent = GUI_YES;
            pgInfo->modelName = _T("PDGIC");
            RecordBasicEvent("    {0} found", pgInfo->modelName);
        }
        else
        {
            status = DTSTEST_ERROR_MODBUS_COMMAND_FAILED;                       // 0x000000B0
            Thread::Sleep(100);
        }
    }                                   // end of if (pgInfo)
    else
    {
        status = DTSTEST_ERROR_PDGIC_INFO_POINTER_INVALID;                      // 0x000000C1
    }
    RecordBasicEvent("{0} concluded with status = 0x{1:X8}", functionName, status);
}                                       // end of DTSTest_PDGICDeterminePDGICPresence()
//----------------------------------------------------------------------------
// DTSTest_PDGICDummyRead
//
// Performs a dummy read
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_PDGICDummyRead(
    PDGICInfo       ^pgInfo)
{
    DWORD           status = DTSTEST_SUCCESS;
    String          ^functionName = _T("DTSTest_PDGICDummyRead");
    //------------------------------------------------------------------------
    RecordBasicEvent("            {0} called", functionName);
    if (pgInfo)
    {
        //--------------------------------------------------------------------
        // Set up a MODBUS command to read the first word
        //--------------------------------------------------------------------
        pgInfo->commandArray[1] = MODBUS_COMMAND_READ_INPUT_REGISTERS;          // 0x04
        pgInfo->startingRegisterOffset = 0x0000;
        pgInfo->numberOfRegistersToTransfer = 1;
        DTSTest_PDGICSendCommand(pgInfo);
        //--------------------------------------------------------------------
        // The DTSTest_PDGICSuccessfulReply flag is reset in
        // DTSTest_PDGICSendCommand and then set in DTSTest_PDGICDataReceived
        // if no errors were encountered
        //--------------------------------------------------------------------
        if (DTSTest_PDGICSuccessfulReply)
        {
            pgInfo->systemStatus = (WORD)
                (pgInfo->responseArray[PDGIC_MODBUS_RESPONSE_DATA_OFFSET] << 8) |
                pgInfo->responseArray[PDGIC_MODBUS_RESPONSE_DATA_OFFSET + 1];
        }
        else
        {
            status = DTSTEST_ERROR_MODBUS_COMMAND_FAILED;                       // 0x000000B0
        }
    }                                   // end of if (pgInfo)
    else
    {
        status = DTSTEST_ERROR_PDGIC_INFO_POINTER_INVALID;                      // 0x000000C1
    }
    RecordBasicEvent("            {0} concluded with status = 0x{1:X8}", functionName, status);
}                                       // end of DTSTest_PDGICDummyRead()
//----------------------------------------------------------------------------
// DTSTest_PDGICRetrieveCurrentReadings
//
// Retrieves the current readings of the attached PDGIC device
//
// Called by:   DTSTest_InitializeDTSTest
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_PDGICRetrieveCurrentReadings(void)
{
    DWORD           status = DTSTEST_SUCCESS;
    String          ^functionName = _T("DTSTest_PDGICRetrieveCurrentReadings");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0} called", functionName);
        //--------------------------------------------------------------------
        // Create an instance of the PDGICData structure and pouplate it
        //--------------------------------------------------------------------
        status = DTSTest_PDGICAcquireReadings();
        if (status == DTSTEST_SUCCESS)
        {
        }
        else
        {
//            Modal("Error : DTSTest_PDGICAcquireReadings returned 0x{0:X8}", status);
        }
    RecordBasicEvent("{0} concluded", functionName);
}                                       // end of DTSTest_PDGICRetrieveCurrentReadings()
//----------------------------------------------------------------------------
// DTSTest_PDGICInitializeEnvironment
//
// Initializes the software environment and prepares the PDGIC hardware for I/O
//
// Returns: 0       = Success
//          nonzero = Failure
//
// Called by:   DTSTest_ScanForDevices
//----------------------------------------------------------------------------
    DWORD DTSTest_GUIClass::
DTSTest_PDGICInitializeEnvironment(void)
{
//    bool            serialPortOpened = GUI_NO;
    DWORD           status = DTSTEST_SUCCESS;
    String          ^functionName = _T("DTSTest_PDGICInitializeEnvironment");
    //------------------------------------------------------------------------
    RecordBasicEvent("    {0} called", functionName);
    if (DTSTest_GeneralInfo->pgInfo)
    {
        PDGICInfo ^pgInfo = DTSTest_GeneralInfo->pgInfo;
        //--------------------------------------------------------------------
        // Initialize default hardware and protocol parameters
        //--------------------------------------------------------------------
        pgInfo->baudRate = DTSTEST_DEFAULT_PDGIC_BAUDRATE;                      // 1200
        pgInfo->dataBits = DTSTEST_DEFAULT_DATA_BITS;                           // 8
        pgInfo->stopBits = StopBits::One;
        pgInfo->parity = Parity::None;
        pgInfo->handShaking = Handshake::None;
        pgInfo->timeout = DTSTEST_DEFAULT_PDGIC_MS_TIMEOUT;                     // 400
        //--------------------------------------------------------------------
        // Search for a serial port attached to a PDGIC device
        //
        // Note: DTSTest_PDGICLocatePort initializes the PDGICPresent
        // field
        //--------------------------------------------------------------------
        DTSTest_PDGICLocatePort(pgInfo);
        if (pgInfo->PDGICPresent)
        {
        }                               // end of if (pgInfo->PDGICPresent)
        else
        {
            status = DTSTEST_ERROR_PDGIC_NOT_FOUND;                             // 0x000000C0
//            DTSTest_GeneralInfo->flags |= DTSTEST_GENERAL_SCAN_COMPLETED;
        }
    }                                   // end of if (DTSTest_GeneralInfo->pgInfo)
    else
    {
        status = DTSTEST_ERROR_PDGIC_INFO_POINTER_INVALID;                      // 0x000000C1
    }
    RecordBasicEvent("    {0} concluded, returning 0x{1:X8}", functionName, status);
    return status;
}                                       // end of DTSTest_PDGICInitializeEnvironment()
//----------------------------------------------------------------------------
// DTSTest_PDGICLocatePort
//
// Locates a valid serial port attached to a PDGIC device on this computer
// by searching through all the registered serial ports and stopping at the
// first one that returns the proper information for a PDGIC ID command
//
// Called by:   DTSTest_PDGICInitializeEnvironment
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_PDGICLocatePort(
    PDGICInfo       ^pgInfo)
{
    DWORD           status = DTSTEST_SUCCESS;
    String          ^functionName = _T("DTSTest_PDGICLocatePort");
    //------------------------------------------------------------------------
    RecordBasicEvent("        {0} called", functionName);
    if (pgInfo)
    {
        this->Cursor = Cursors::WaitCursor;
        pgInfo->PDGICPresent = GUI_NO;
        pgInfo->modelName = String::Empty;
        bool pgSerialPortFound = GUI_NO;
        array <String ^> ^serialPortsArray = SerialPort::GetPortNames();
        int portOffset = 0;
        for (int portNumber = 0; portNumber < serialPortsArray->Length; portNumber++)
        {
            bool addThisPort = GUI_YES;
            String ^thisPortString = gcnew String(serialPortsArray[portNumber]);
            //----------------------------------------------------------------
            // Omit redundant names
            //----------------------------------------------------------------
            for (int index = 0; index < portOffset; index++)
            {
                if (StringICompare(thisPortString, DTSTest_SerialPortNameStringArray[index]) == 0)
                    addThisPort = GUI_NO;
            }
            if (addThisPort)
            {
                if (portNumber)
                {
                    Array::Resize(
                        DTSTest_SerialPortNameStringArray,
                        DTSTest_SerialPortNameStringArray->Length + 1);
                }
                //------------------------------------------------------------
                // Proceed to append this port name string
                //------------------------------------------------------------
                DTSTest_SerialPortNameStringArray[portOffset++] = thisPortString;
            }                           // end of if (addThisPort)
        }                               // end of for (int portNumber = 0; ...)
        for each (String ^serialPortName in serialPortsArray)
        {
            bool portNameUsed = GUI_NO;
            for each (String ^savedPortName in DTSTest_GeneralInfo->serialPortsSearchedArray)
            {
                if (StringICompare(serialPortName, savedPortName) == 0)
                    portNameUsed = GUI_YES;
            }
            if (!portNameUsed)
            {
                pgInfo->portName = serialPortName;
//                DTSTest_PDGICRetrieveNodeAddress(pgInfo);
                DTSTest_PDGICDeterminePDGICPresence(pgInfo);
                if (pgInfo->PDGICPresent)
                {
                    DTSTest_PDGICRetrieveDTSInformation(pgInfo);
                    pgSerialPortFound = GUI_YES;
                    //--------------------------------------------------------
                    // No need to search further
                    //--------------------------------------------------------
                    pgInfo->portOffset = DTSTest_GeneralInfo->serialPortsSearchedCount++;
                    DTSTest_GeneralInfo->serialPortsSearchedArray[pgInfo->portOffset] = pgInfo->portName;
                    break;
                }
            }                           // end of if (!portNameUsed)
        }                               // end of for each (String ^serialPortName in ...)
        if (pgSerialPortFound)
        {
            RecordBasicEvent("            {0} device detected on {1}",
                pgInfo->modelName, pgInfo->portName);
        }
        else
        {
            RecordBasicEvent("            No PDGIC device detected on {0}", pgInfo->portName);
            status = DTSTEST_ERROR_PDGIC_NOT_FOUND;                             // 0x000000C0
            pgInfo->portName = String::Empty;
            pgInfo->modelName = String::Empty;
        }
        this->Cursor = Cursors::Default;
    }                                   // end of if (pgInfo)
    else
    {
        status = DTSTEST_ERROR_PDGIC_INFO_POINTER_INVALID;                      // 0x000000C1
    }
    RecordBasicEvent("        {0} concluded with status = 0x{1:X8}", functionName, status);
}                                       // end of DTSTest_PDGICLocatePort()
//----------------------------------------------------------------------------
// DTSTest_PDGICOpenPort
//
// Sets the specified port to the protocol parameters stored in the PDGICInfo
// structure, then opens the port
//
// Returns: 0       = Success
//          nonzero = Failure
//
// Called by:   DTSTest_PDGICOpenPersistentPort
//              DTSTest_PDGICSendCommand
//              DTSTest_PDGICSendRawCommand
//----------------------------------------------------------------------------
    DWORD DTSTest_GUIClass::
DTSTest_PDGICOpenPort(
    PDGICInfo       ^pgInfo,
    SerialPort      ^port)
{
    DWORD           status = DTSTEST_SUCCESS;
    String          ^functionName = _T("DTSTest_PDGICOpenPort");
    //------------------------------------------------------------------------
    RecordBasicEvent("        {0}({1}) called", functionName, pgInfo->portName);
    if (port && pgInfo && StringSet(pgInfo->portName))
    {
        port->PortName = pgInfo->portName;
        //--------------------------------------------------------------------
        // Alert to an illegal baud rate change
        //--------------------------------------------------------------------
        if ((pgInfo->baudRate != 1200) && (pgInfo->baudRate != 2400))
            DTSTest_RecordAndModalErrorEvent(
                "About to change baud rate to {0:D}",
                pgInfo->baudRate);
        port->BaudRate = pgInfo->baudRate;
        port->DataBits = pgInfo->dataBits;
        port->ReadTimeout = pgInfo->timeout;
        port->Parity = pgInfo->parity;
        port->StopBits = pgInfo->stopBits;
        port->Handshake = pgInfo->handShaking;
        try
        {
            port->Open();
            if (port->IsOpen)
            {
                //------------------------------------------------------------
                // Clear out the buffers
                //------------------------------------------------------------
//                port->DiscardOutBuffer();
//                port->DiscardInBuffer();
            }                           // end of if (port->IsOpen)
        }                               // end of try
        catch (UnauthorizedAccessException ^ex)
        {
            UNREFERENCED_PARAMETER(ex);
            DTSTest_PromptOKModal(functionName,
                "Port {0} is already being used by another program\n\n"
                "Please close the other program and try again",
                port->PortName);
            status = DTSTEST_ERROR_PDGIC_PORT_IN_USE;                           // 0x000000C5
        }
        catch (Exception ^ex)
        {
            DTSTest_RecordAndModalErrorEvent(
                "Attempt to open port {0} failed:\n{1}",
                port->PortName, ex->Message);
            status = DTSTEST_ERROR_PDGIC_PORT_UNKNOWN_FAILURE;                  // 0x000000CF
        }
    }                                   // end of if (port && pgInfo && StringSet(pgInfo->portName))
    else
    {
        if (port)
        {
            if (pgInfo)
            {
                status = DTSTEST_ERROR_PDGIC_PORT_NAME_MISSING;                 // 0x000000C4
            }
            else
            {
                status = DTSTEST_ERROR_PDGIC_INFO_POINTER_INVALID;              // 0x000000C1
            }
        }
        else
        {
            status = DTSTEST_ERROR_PDGIC_PORT_POINTER_INVALID;                  // 0x000000C3
        }
    }
    RecordBasicEvent("        {0} concluded, returning 0x{1:X8}", functionName, status);
    return status;
}                                       // end of DTSTest_PDGICOpenPort()
//----------------------------------------------------------------------------
// DTSTest_PDGICDisablePowerToAllGaugeBarges
//
// Disables power to all barges attached to gauges
//
// Note:    All gauges must have been set to supply power to their barges
//          prior to calling this method
//----------------------------------------------------------------------------
    DWORD DTSTest_GUIClass::
DTSTest_PDGICDisablePowerToAllGaugeBarges(
    PDGICInfo       ^pgInfo)
{
    DWORD           status = DTSTEST_SUCCESS;
    String          ^functionName = _T("DTSTest_PDGICDisablePowerToAllGaugeBarges");
    //------------------------------------------------------------------------
    RecordBasicEvent("    {0} called", functionName);
    if (pgInfo)
    {
        //--------------------------------------------------------------------
        // Set up a MODBUS command to enable barge power
        //--------------------------------------------------------------------
        pgInfo->commandArray[1] = MODBUS_COMMAND_WRITE_MULTIPLE_COILS;          // 0x0F
        pgInfo->startingRegisterOffset = 0x0000;
        pgInfo->numberOfRegistersToTransfer = 0x10;
        pgInfo->commandArray[6] = 0x02;
        pgInfo->commandArray[7] = 0x03;
        pgInfo->commandArray[8] = 0x00;
        DTSTest_PDGICSendCommand(pgInfo);
        if (!DTSTest_PDGICSuccessfulReply)
        {
            //----------------------------------------------------------------
            // Wait 100 ms, then retry
            //----------------------------------------------------------------
            Thread::Sleep(100);
            DTSTest_PDGICSendCommand(pgInfo);
            if (!DTSTest_PDGICSuccessfulReply)
            {
                status = DTSTEST_ERROR_MODBUS_COMMAND_FAILED;                   // 0x000000B0
            }
        }
        if (DTSTest_PDGICSuccessfulReply && (status == DTSTEST_SUCCESS))
        {
            pgInfo->powerToBargesEnabled = GUI_NO;
        }
        else
        {
            if (status == DTSTEST_SUCCESS)
                status = DTSTEST_ERROR_MODBUS_COMMAND_FAILED;                   // 0x000000B0
        }
    }                                   // end of if (pgInfo)
    else
    {
        status = DTSTEST_ERROR_PDGIC_INFO_POINTER_INVALID;                      // 0x000000C1
    }
    RecordBasicEvent("    {0} concluded, returning 0x{1:X8}", functionName, status);
    return status;
}                                       // end of DTSTest_PDGICDisablePowerToAllGaugeBarges()
//----------------------------------------------------------------------------
// DTSTest_PDGICEnablePowerToAllGaugeBarges
//
// Enables power to all barges attached to gauges
//
// Note:    All gauges must have been set to supply power to their barges
//          prior to calling this method
//----------------------------------------------------------------------------
    DWORD DTSTest_GUIClass::
DTSTest_PDGICEnablePowerToAllGaugeBarges(
    PDGICInfo       ^pgInfo)
{
    DWORD           status = DTSTEST_SUCCESS;
    String          ^functionName = _T("DTSTest_PDGICEnablePowerToAllGaugeBarges");
    //------------------------------------------------------------------------
    RecordBasicEvent("    {0} called", functionName);
    if (pgInfo)
    {
        BYTE originalNodeAddress = pgInfo->nodeAddress;
        pgInfo->nodeAddress = 0x00;
        //--------------------------------------------------------------------
        // Set up a MODBUS command to enable barge power
        //--------------------------------------------------------------------
        pgInfo->commandArray[1] = MODBUS_COMMAND_WRITE_MULTIPLE_COILS;          // 0x0F
        pgInfo->startingRegisterOffset = 0x0000;
        pgInfo->numberOfRegistersToTransfer = 0x10;
        pgInfo->commandArray[6] = 0x02;
        pgInfo->commandArray[7] = 0x0F;
        pgInfo->commandArray[8] = 0x00;
        DTSTest_PDGICSendCommand(pgInfo);
        if (!DTSTest_PDGICSuccessfulReply)
        {
            //----------------------------------------------------------------
            // Wait 100 ms, then retry
            //----------------------------------------------------------------
            Thread::Sleep(100);
            DTSTest_PDGICSendCommand(pgInfo);
            if (!DTSTest_PDGICSuccessfulReply)
            {
                status = DTSTEST_ERROR_MODBUS_COMMAND_FAILED;                   // 0x000000B0
            }
        }
        if (DTSTest_PDGICSuccessfulReply && (status == DTSTEST_SUCCESS))
        {
            pgInfo->powerToBargesEnabled = GUI_YES;
        }
        else
        {
            if (status == DTSTEST_SUCCESS)
                status = DTSTEST_ERROR_MODBUS_COMMAND_FAILED;                   // 0x000000B0
        }
        //--------------------------------------------------------------------
        // Restore the original node address
        //--------------------------------------------------------------------
        pgInfo->nodeAddress = originalNodeAddress;
    }                                   // end of if (pgInfo)
    else
    {
        status = DTSTEST_ERROR_PDGIC_INFO_POINTER_INVALID;                      // 0x000000C1
    }
    RecordBasicEvent("    {0} concluded, returning 0x{1:X8}", functionName, status);
    return status;
}                                       // end of DTSTest_PDGICEnablePowerToAllGaugeBarges()
//----------------------------------------------------------------------------
// DTSTest_PDGICReadWords
//
// Reads one or more WORD values from the specified node and register address
//----------------------------------------------------------------------------
    DWORD DTSTest_GUIClass::
DTSTest_PDGICReadWords(
    PDGICInfo       ^pgInfo)
{
    DWORD           status = DTSTEST_SUCCESS;
    String          ^functionName = _T("DTSTest_PDGICReadWords");
    //------------------------------------------------------------------------
    RecordBasicEvent("            {0} called", functionName);
    if (pgInfo)
    {
        if (pgInfo->powerToBargesEnabled)
        {
            //----------------------------------------------------------------
            // Set up a MODBUS command to read the unit information structure
            //----------------------------------------------------------------
            pgInfo->commandArray[1] = MODBUS_COMMAND_READ_INPUT_REGISTERS;      // 0x04
            DTSTest_PDGICSendCommand(pgInfo);
            if (!DTSTest_PDGICSuccessfulReply)
            {
                //------------------------------------------------------------
                // Wait 100 ms, then retry
                //------------------------------------------------------------
                Thread::Sleep(100);
                DTSTest_PDGICSendCommand(pgInfo);
                if (!DTSTest_PDGICSuccessfulReply)
                {
                    status = DTSTEST_ERROR_MODBUS_COMMAND_FAILED;               // 0x000000B0
                }
            }
            if (DTSTest_PDGICSuccessfulReply && (status == DTSTEST_SUCCESS))
            {
            }
            else
            {
                if (status == DTSTEST_SUCCESS)
                    status = DTSTEST_ERROR_MODBUS_COMMAND_FAILED;               // 0x000000B0
                DTSTest_RecordAndModalErrorEvent(
                    "ReadWords for ID 0x{0:X2} failed",
                    pgInfo->nodeAddress);
            }
        }
        else
        {
            DTSTest_RecordAndModalErrorEvent("!!! Barge power is not enabled");
        }
    }                                   // end of if (pgInfo)
    else
    {
        status = DTSTEST_ERROR_PDGIC_INFO_POINTER_INVALID;                      // 0x000000C1
    }
    RecordBasicEvent("            {0} concluded, returning 0x{1:X8}", functionName, status);
    return status;
}                                       // end of DTSTest_PDGICReadWords()
////----------------------------------------------------------------------------
//// DTSTest_PDGICGaugeToolheadEnable
////
//// Enables the toolhead interface for the gauge located at the pre-defined
//// node address
////----------------------------------------------------------------------------
//    DWORD DTSTest_GUIClass::
//DTSTest_PDGICGaugeToolheadEnable(
//    PDGICInfo       ^pgInfo)
//{
//    DWORD           status = DTSTEST_SUCCESS;
//    String          ^functionName = _T("DTSTest_PDGICGaugeToolheadEnable");
//    //------------------------------------------------------------------------
//    RecordBasicEvent("    {0} called", functionName);
//    if (pgInfo)
//    {
//        //--------------------------------------------------------------------
//        // Set up a MODBUS command to write to the holding register
//        //--------------------------------------------------------------------
//        pgInfo->commandArray[1] = MODBUS_COMMAND_WRITE_SINGLE_REGISTER;         // 0x06
//        pgInfo->startingRegisterOffset = 0x0000;
//        pgInfo->writeData = DTSTEST_GAUGE_TOOLHEAD_PASSWORD;                    // 0x411
//        DTSTest_PDGICSendCommand(pgInfo);
//        if (!DTSTest_PDGICSuccessfulReply)
//        {
//            //----------------------------------------------------------------
//            // Wait 100 ms, then retry
//            //----------------------------------------------------------------
//            Thread::Sleep(100);
//            DTSTest_PDGICSendCommand(pgInfo);
//            if (!DTSTest_PDGICSuccessfulReply)
//            {
//                status = DTSTEST_ERROR_MODBUS_COMMAND_FAILED;                   // 0x000000B0
//            }
//        }
//    }                                   // end of if (pgInfo)
//    else
//    {
//        status = DTSTEST_ERROR_PDGIC_INFO_POINTER_INVALID;                      // 0x000000C1
//    }
//    RecordBasicEvent("    {0} concluded, returning 0x{1:X8}", functionName, status);
//    return status;
//}                                       // end of DTSTest_PDGICGaugeToolheadEnable()
//----------------------------------------------------------------------------
// DTSTest_PDGICResetErrorCondition
//
// Resets the error condition if one is detected
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_PDGICResetErrorCondition(
    PDGICInfo       ^pgInfo)
{
    String          ^functionName = _T("DTSTest_PDGICResetErrorCondition");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0} called", functionName);
    RecordBasicEvent("{0} concluded", functionName);
}                                       // end of DTSTest_PDGICResetErrorCondition()
//----------------------------------------------------------------------------
// DTSTest_PDGICRetrieveDTSInformation
//
// Retrieves the general DTS system information
//
// Called by:   DTSTest_PDGICLocatePort
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_PDGICRetrieveDTSInformation(
    PDGICInfo       ^pgInfo)
{
    DWORD           status = DTSTEST_SUCCESS;
    String          ^functionName = _T("DTSTest_PDGICRetrieveDTSInformation");
    //------------------------------------------------------------------------
    RecordBasicEvent("            {0} called", functionName);
    if (pgInfo)
    {
//        DTSTest_PDGICRetrieveDTSIdentification(pgInfo);
//        DTSTest_PDGICRetrieveDTSChipID(pgInfo);
//        DTSTest_PDGICRetrieveDTSStatus(pgInfo);
    }                                   // end of if (pgInfo)
    else
    {
        status = DTSTEST_ERROR_PDGIC_INFO_POINTER_INVALID;                      // 0x000000C1
    }
    RecordBasicEvent("            {0} concluded with status = 0x{1:X8}", functionName, status);
}                                       // end of DTSTest_PDGICRetrieveDTSInformation()
//----------------------------------------------------------------------------
// DTSTest_PDGICRetrieveDTSChipID
//
// Retrieves the DTS Chip ID
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_PDGICRetrieveDTSChipID(
    PDGICInfo       ^pgInfo)
{
    DWORD           status = DTSTEST_SUCCESS;
    String          ^functionName = _T("DTSTest_PDGICRetrieveDTSChipID");
    //------------------------------------------------------------------------
    RecordBasicEvent("            {0} called", functionName);
    if (pgInfo)
    {
        //--------------------------------------------------------------------
        // Set up a MODBUS command to read the chip ID WORD
        //--------------------------------------------------------------------
        pgInfo->commandArray[1] = MODBUS_COMMAND_READ_INPUT_REGISTERS;          // 0x04
        pgInfo->startingRegisterOffset = 0x0001;
        pgInfo->numberOfRegistersToTransfer = 1;
        DTSTest_PDGICSendCommand(pgInfo);
        //--------------------------------------------------------------------
        // The DTSTest_PDGICSuccessfulReply flag is reset in
        // DTSTest_PDGICSendCommand and then set in DTSTest_PDGICDataReceived
        // if no errors were encountered
        //--------------------------------------------------------------------
        if (DTSTest_PDGICSuccessfulReply)
        {
//Modal("Chip ID Response: {0:X2}  {1:X2}  {2:X2}  {3:X2}  {4:X2}  {5:X2}  {6:X2}",
//    pgInfo->responseArray[0], pgInfo->responseArray[1], pgInfo->responseArray[2],
//    pgInfo->responseArray[3], pgInfo->responseArray[4], pgInfo->responseArray[5], pgInfo->responseArray[6]);
            pgInfo->chipID = (WORD)
                (pgInfo->responseArray[PDGIC_MODBUS_RESPONSE_DATA_OFFSET] << 8) |
                pgInfo->responseArray[PDGIC_MODBUS_RESPONSE_DATA_OFFSET + 1];
        }
        else
        {
            status = DTSTEST_ERROR_MODBUS_COMMAND_FAILED;                       // 0x000000B0
Modal("Chip ID command for ID 0x{0:X2} failed", pgInfo->nodeAddress);
        }
    }                                   // end of if (pgInfo)
    else
    {
        status = DTSTEST_ERROR_PDGIC_INFO_POINTER_INVALID;                      // 0x000000C1
    }
    RecordBasicEvent("            {0} concluded with status = 0x{1:X8}", functionName, status);
}                                       // end of DTSTest_PDGICRetrieveDTSChipID()
//----------------------------------------------------------------------------
// DTSTest_PDGICRetrieveDTSIdentification
//
// Retrieves the DTS server identification (node address)
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_PDGICRetrieveDTSIdentification(
    PDGICInfo       ^pgInfo)
{
    DWORD           status = DTSTEST_SUCCESS;
    String          ^functionName = _T("DTSTest_PDGICRetrieveDTSIdentification");
    //------------------------------------------------------------------------
    RecordBasicEvent("            {0} called", functionName);
    if (pgInfo)
    {
        //--------------------------------------------------------------------
        // Set up a MODBUS command to read the ID byte
        //--------------------------------------------------------------------
        pgInfo->nodeAddress = 0x00;
        pgInfo->commandArray[1] = MODBUS_COMMAND_REPORT_SLAVE_ID;               // 0x11
        pgInfo->startingRegisterOffset = 0x0E01;                                // ROC-X address
        pgInfo->numberOfRegistersToTransfer = 0;
        DTSTest_PDGICSendCommand(pgInfo);
        //--------------------------------------------------------------------
        // The DTSTest_PDGICSuccessfulReply flag is reset in
        // DTSTest_PDGICSendCommand
        //--------------------------------------------------------------------
        if (DTSTest_PDGICSuccessfulReply)
        {
            unsigned char nodeAddress = pgInfo->responseArray[3];
            pgInfo->nodeAddress = nodeAddress;
        }
        else
        {
            status = DTSTEST_ERROR_MODBUS_COMMAND_FAILED;                       // 0x000000B0
        }
    }                                   // end of if (pgInfo)
    else
    {
        status = DTSTEST_ERROR_PDGIC_INFO_POINTER_INVALID;                      // 0x000000C1
    }
    RecordBasicEvent("            {0} concluded with status = 0x{1:X8}", functionName, status);
}                                       // end of DTSTest_PDGICRetrieveDTSIdentification()
//----------------------------------------------------------------------------
// DTSTest_PDGICRetrieveDTSStatus
//
// Retrieves the DTS system status
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_PDGICRetrieveDTSStatus(
    PDGICInfo       ^pgInfo)
{
    DWORD           status = DTSTEST_SUCCESS;
    String          ^functionName = _T("DTSTest_PDGICRetrieveDTSStatus");
    //------------------------------------------------------------------------
    RecordBasicEvent("            {0} called", functionName);
    if (pgInfo)
    {
        //--------------------------------------------------------------------
        // Set up a MODBUS command to read the status word
        //--------------------------------------------------------------------
        pgInfo->commandArray[1] = MODBUS_COMMAND_READ_INPUT_REGISTERS;          // 0x04
        pgInfo->startingRegisterOffset = 0x0000;
        pgInfo->numberOfRegistersToTransfer = 1;
//        pgInfo->expectedNumberOfResponseBytes = 7;
        DTSTest_PDGICSendCommand(pgInfo);
        //--------------------------------------------------------------------
        // The DTSTest_PDGICSuccessfulReply flag is reset in
        // DTSTest_PDGICSendCommand and then set in DTSTest_PDGICDataReceived
        // if no errors were encountered
        //--------------------------------------------------------------------
        if (DTSTest_PDGICSuccessfulReply)
        {
//Modal("Status Response: {0:X2}  {1:X2}  {2:X2}  {3:X2}  {4:X2}  {5:X2}  {6:X2}",
//    pgInfo->responseArray[0], pgInfo->responseArray[1], pgInfo->responseArray[2], pgInfo->responseArray[3],
//    pgInfo->responseArray[4], pgInfo->responseArray[5], pgInfo->responseArray[6]);
            pgInfo->systemStatus = (WORD)
                (pgInfo->responseArray[PDGIC_MODBUS_RESPONSE_DATA_OFFSET] << 8) |
                pgInfo->responseArray[PDGIC_MODBUS_RESPONSE_DATA_OFFSET + 1];
        }
        else
        {
            status = DTSTEST_ERROR_MODBUS_COMMAND_FAILED;                       // 0x000000B0
Modal("Status command for ID 0x{0:X2} failed", pgInfo->nodeAddress);
        }
    }                                   // end of if (pgInfo)
    else
    {
        status = DTSTEST_ERROR_PDGIC_INFO_POINTER_INVALID;                      // 0x000000C1
    }
    RecordBasicEvent("            {0} concluded with status = 0x{1:X8}", functionName, status);
}                                       // end of DTSTest_PDGICRetrieveDTSStatus()
//----------------------------------------------------------------------------
// DTSTest_PDGICRetrieveNodeAddress
//
// Retrieves the PDGIC node address and stores it for use by other commands
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_PDGICRetrieveNodeAddress(
    PDGICInfo       ^pgInfo)
{
    DWORD           status = DTSTEST_SUCCESS;
    String          ^functionName = _T("DTSTest_PDGICRetrieveNodeAddress");
    //------------------------------------------------------------------------
    RecordBasicEvent("            {0} called", functionName);
    if (pgInfo)
    {
        //--------------------------------------------------------------------
        // Set up a MODBUS command to read the PDGIC node address
        //--------------------------------------------------------------------
        pgInfo->nodeAddress = 0;
        pgInfo->commandArray[1] = MODBUS_COMMAND_REPORT_SLAVE_ID;               // 0x11
        DTSTest_PDGICSendCommand(pgInfo);
        if (DTSTest_PDGICSuccessfulReply)
        {
            //----------------------------------------------------------------
            // TODO: The following if statement doesn't work if more than one
            // device (gauge, barge. etc.) is present, because the Identify
            // command will fail, and the returned "node address" becomes
            // meaningless
            //----------------------------------------------------------------
            if (pgInfo->responseArray[4] == 0xFF)
            {
                unsigned char nodeAddress = pgInfo->responseArray[3];
                pgInfo->nodeAddress = nodeAddress;
                RecordVerboseEvent("                Node address 0x{0:X2} identified",
                    pgInfo->nodeAddress);
            }
            else
            {
                RecordVerboseEvent("                No node address identified");
            }
            status = DTSTEST_SUCCESS;
        }
        else
        {
            status = DTSTEST_ERROR_MODBUS_COMMAND_FAILED;                       // 0x000000B0
            Thread::Sleep(600);
        }
    }                                   // end of if (pgInfo)
    else
    {
        status = DTSTEST_ERROR_PDGIC_INFO_POINTER_INVALID;                      // 0x000000C1
    }
    RecordBasicEvent("            {0} concluded with status = 0x{1:X8}", functionName, status);
}                                       // end of DTSTest_PDGICRetrieveNodeAddress()
//----------------------------------------------------------------------------
// DTSTest_PDGICRetrieveResponse
//
// Retrieves the serial data response from the PDGIC at the specified port
//
// Returns: 0       = Success
//          nonzero = Failure
//
// Called by:   DTSTest_PDGICSendCommand
//              DTSTest_PDGICSendRawCommand
//----------------------------------------------------------------------------
    DWORD DTSTest_GUIClass::
DTSTest_PDGICRetrieveResponse(
    PDGICInfo       ^pgInfo,
    SerialPort      ^port)
{
    bool            proceedToCalculateCRC = DTSTest_ReportCRCErrors;
    bool            responseExpected = GUI_YES;
    bool            responseIsValid = GUI_YES;
    int             totalNumberOfBytesToRead = 0;
    DWORD           status = DTSTEST_SUCCESS;
    String          ^functionName = _T("DTSTest_PDGICRetrieveResponse");
    //------------------------------------------------------------------------
    DTSTest_RetrieveResponseContext = GUI_YES;
    RecordBasicEvent("        {0} called", functionName);
    if (pgInfo && port)
    {
        BYTE nodeAddress = pgInfo->commandArray[0];
        SensorInfo ^sensor = pgInfo->sensorInfoArray[nodeAddress];
        Array::Clear(pgInfo->responseArray, 0, PDGIC_MODBUS_MAXIMUM_RESPONSE_LENGTH);
        //--------------------------------------------------------------------
        // Set the number of bytes expected in the response
        //
        // Note: Each register is 16-bits (two bytes)
        //--------------------------------------------------------------------
        BYTE functionCode = pgInfo->commandArray[1];
        switch (functionCode)
        {
            case MODBUS_COMMAND_READ_HOLDING_REGISTERS :                        // 0x03
            case MODBUS_COMMAND_READ_INPUT_REGISTERS :                          // 0x04
                totalNumberOfBytesToRead = Min(
                    ((pgInfo->numberOfRegistersToTransfer * 2) + PDGIC_MODBUS_RESPONSE_HEADER_LENGTH),
                    PDGIC_MODBUS_MAXIMUM_RESPONSE_LENGTH);
                break;
            case MODBUS_COMMAND_WRITE_SINGLE_REGISTER :                         // 0x06
                if (nodeAddress == 0xFE)
                {
                    //--------------------------------------------------------
                    // No response expected for broadcast commands
                    //--------------------------------------------------------
                    responseExpected = GUI_NO;
                }
                else
                {
                    totalNumberOfBytesToRead = 8;
                }
                break;
            case MODBUS_COMMAND_WRITE_MULTIPLE_COILS :                          // 0x0F
                if (nodeAddress == 0x00)
                    responseExpected = GUI_NO;
                else
                    totalNumberOfBytesToRead = 8;
                break;
            case MODBUS_COMMAND_REPORT_SLAVE_ID :                               // 0x11
                totalNumberOfBytesToRead = 9;
                break;
            default :
                //------------------------------------------------------------
                // The remaining commands are not supported by DTS, but their
                // failure responses must be handled if they are valid MODBUS
                // commands
                //------------------------------------------------------------
                totalNumberOfBytesToRead = PDGIC_MODBUS_ERROR_RESPONSE_LENGTH;  // 5
                break;
        }                               // end of switch (functionCode)
        if (!responseExpected)
            proceedToCalculateCRC = GUI_NO;
        RecordDetailedEvent("            {0:D} bytes to read", totalNumberOfBytesToRead);
        pgInfo->numberOfBytesRead = 0;
        if (responseExpected)
        {
            do
            {
                try
                {
                    pgInfo->responseArray[pgInfo->numberOfBytesRead] = port->ReadByte();
                }
                catch (Exception ^ex)
                {
                    if (responseExpected && !pgInfo->numberOfBytesRead)
                        responseIsValid = GUI_NO;
                    RecordDetailedEvent("            Exception: {0}", ex->Message);
                    proceedToCalculateCRC = GUI_NO;
                    break;
                }
                pgInfo->numberOfBytesRead++;
            }
            while (pgInfo->numberOfBytesRead < totalNumberOfBytesToRead);
        }                               // end of if (responseExpected)
        if (responseIsValid)
        {
            if (proceedToCalculateCRC)
            {
                //------------------------------------------------------------
                // Must have at least the address, command, and CRC to verify
                //------------------------------------------------------------
                if (pgInfo->numberOfBytesRead >= 4)
                {
                    WORD calculatedCRC = PDGIC_CalculateWordCRC(
                        pgInfo->responseArray,
                        pgInfo->numberOfBytesRead - 2);
                    WORD readCRC = (pgInfo->responseArray[pgInfo->numberOfBytesRead - 1] << 8) | pgInfo->responseArray[pgInfo->numberOfBytesRead - 2];
                    if (calculatedCRC == readCRC)
                    {
                        DTSTest_PDGICSuccessfulReply = GUI_YES;
                    }
                    else
                    {
                        RecordErrorEvent(
                            "            Invalid response CRC for 0x{0:X2} : 0x{1:X4} (s/b 0x{2:X4})",
                            pgInfo->commandArray[1], readCRC, calculatedCRC);
                        status = DTSTEST_ERROR_DATA_CRC_INVALID;                // 0x00000056
                    }
                }
                else
                {
                    status = DTSTEST_ERROR_INVALID_REPLY_DATA;                  // 0x00000053
                }
            }                           // end of if (proceedToCalculateCRC)
            else
            {
                DTSTest_PDGICSuccessfulReply = GUI_YES;
            }
        }                               // end of if (responseIsValid)
        else
        {
            switch (nodeAddress)
            {
                case 0x00 :
                case 0xFE :
                    if (functionCode == MODBUS_COMMAND_REPORT_SLAVE_ID)
                    {
                        if (nodeAddress == 0xFE)
                            status = DTSTEST_ERROR_INVALID_BROADCAST_INSTANCE;  // 0x00000058
                        else
                            status = DTSTEST_ERROR_COMMAND_FAILED;              // 0x00000050
                    }
                    else
                        status = DTSTEST_ERROR_INVALID_BROADCAST_COMMAND;       // 0x00000059
                    break;
                default :
                    if (sensor->sensorPresent)
                    {
                        if (DTSTest_PDGICTransmitCRCIsValid(pgInfo))
                            status = DTSTEST_ERROR_COMMAND_FAILED;              // 0x00000050
                        else
                            status = DTSTEST_ERROR_COMMAND_CRC_INVALID;         // 0x00000055
                    }
                    else
                        status = DTSTEST_ERROR_UNSUPPORTED_TARGET;              // 0x00000054
                    break;
            }
        }
        if (AnyEventLogEnabled)
        {
            if (pgInfo->numberOfBytesRead)
            {
                String ^bytesReadString = String::Empty;
                for (int count = 0; count < pgInfo->numberOfBytesRead; count++)
                    bytesReadString += String::Format(" {0:X2}", pgInfo->responseArray[count]);
                RecordDetailedEvent("            {0:D} bytes actually read:\n           {1}",
                    pgInfo->numberOfBytesRead,
                    bytesReadString);
            }
            else
            {
                RecordDetailedEvent("            No bytes read");
            }
        }
    }                                   // end of if (pgInfo && port)
    else
    {
        if (port)
            status = DTSTEST_ERROR_PDGIC_INFO_POINTER_INVALID;                  // 0x000000C1
        else
            status = DTSTEST_ERROR_PDGIC_PORT_POINTER_INVALID;                  // 0x000000C3
    }
    RecordBasicEvent("        {0} concluded, returning 0x{1:X8}", functionName, status);
    DTSTest_RetrieveResponseContext = GUI_NO;
    return status;
}                                       // end of DTSTest_PDGICRetrieveResponse()
//----------------------------------------------------------------------------
// DTSTest_PDGICReturnDeviceInformationString
//
// Returns the DTS system information, including PDGIC port and all the
// sensors attached to it
//
// Called by:   DTSTest_InitializeDTSTest
//----------------------------------------------------------------------------
    String ^DTSTest_GUIClass::
DTSTest_PDGICReturnDeviceInformationString(
    PDGICInfo       ^pgInfo)
{
    DWORD           status = DTSTEST_SUCCESS;
    String          ^systemInformationString = String::Empty;
    String          ^functionName = _T("DTSTest_PDGICReturnDeviceInformationString");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0} called", functionName);
    if (pgInfo)
    {
        String ^interpretationString = String::Concat(
            _T("    DTS / DPS / ROC-X system information:"), Environment::NewLine,
            _T("        Host port = "), pgInfo->portName);
        //--------------------------------------------------------------------
        // Collect the current gauge measurements
        //--------------------------------------------------------------------
        String ^measurementsString = String::Empty;
        for (int sensorNumber = 0; sensorNumber < DTSTEST_MAXIMUM_NUMBER_OF_SENSORS; sensorNumber++)
        {
            SensorInfo ^sensor = pgInfo->sensorInfoArray[sensorNumber];
            if (sensor->sensorPresent)
            {
                bool originalAddBiasState = sensor->addBias;
                sensor->addBias = GUI_YES;
                measurementsString = DTSTest_SensorReturnMeasurementsString(sensor);
                sensor->addBias = originalAddBiasState;
                interpretationString += String::Concat(
                    Environment::NewLine,
                    _T("        "),
                    ((sensor->sensorType == DTSTEST_SENSOR_TYPE_GAUGE) ? "Gauge" : ((sensor->sensorType == DTSTEST_SENSOR_TYPE_DTS) ? "DTS" : "DPS")),
                    String::Format(" {0:X2}", sensorNumber),
                    _T(" at "),
                    (sensor->measurementsValid ? measurementsString : _T("present (measurements unknown)")));
            }
        }
        systemInformationString = interpretationString;
    }                                   // end of if (pgInfo)
    else
    {
        status = DTSTEST_ERROR_PDGIC_INFO_POINTER_INVALID;                      // 0x000000C1
    }
    RecordBasicEvent("{0} concluded with status = 0x{1:X8}", functionName, status);
    return systemInformationString;
}                                       // end of DTSTest_PDGICReturnDeviceInformationString()
//----------------------------------------------------------------------------
// DTSTest_PDGICSendCommand
//
// Opens the serial (MODBUS) port associated with the PDGIC device and sends
// it the specified command string
//
// Returns: 0       = Success
//          nonzero = Failure
//----------------------------------------------------------------------------
    DWORD DTSTest_GUIClass::
DTSTest_PDGICSendCommand(
    PDGICInfo       ^pgInfo)
{
    bool            commandIsValid = GUI_YES;
    DWORD           status = DTSTEST_SUCCESS;
    String          ^functionName = _T("DTSTest_PDGICSendCommand");
    //------------------------------------------------------------------------
    RecordBasicEvent("    {0} called", functionName);
    if (pgInfo && StringSet(pgInfo->commandArray))
    {
        //--------------------------------------------------------------------
        // Only attempt to open the appropriately located PDGIC port
        //--------------------------------------------------------------------
        if (StringSet(pgInfo->portName))
        {
            pgInfo->commandArray[0] = pgInfo->nodeAddress;
            switch (pgInfo->commandArray[1])
            {
                case MODBUS_COMMAND_READ_DISCRETE_INPUTS :                      // 0x02
                case MODBUS_COMMAND_READ_HOLDING_REGISTERS :                    // 0x03
                case MODBUS_COMMAND_READ_INPUT_REGISTERS :                      // 0x04
                case MODBUS_COMMAND_WRITE_SINGLE_REGISTER :                     // 0x06
                    {
                        pgInfo->commandArray[2] = ((pgInfo->startingRegisterOffset >> 8) & 0xFF);
                        pgInfo->commandArray[3] = (pgInfo->startingRegisterOffset & 0xFF);
                        if (pgInfo->commandArray[1] == MODBUS_COMMAND_WRITE_SINGLE_REGISTER)
                        {
                            pgInfo->commandArray[4] = ((pgInfo->writeData >> 8) & 0xFF);
                            pgInfo->commandArray[5] = (pgInfo->writeData & 0xFF);
                        }
                        else
                        {
                            pgInfo->commandArray[4] = ((pgInfo->numberOfRegistersToTransfer >> 8) & 0xFF);
                            pgInfo->commandArray[5] = (pgInfo->numberOfRegistersToTransfer & 0xFF);
                        }
                        pgInfo->numberOfCommandBytes = PDGIC_MODBUS_SINGLE_COMMAND_LENGTH;
                    }
                    break;
                case MODBUS_COMMAND_WRITE_MULTIPLE_COILS :                      // 0x0F
                    {
                        pgInfo->commandArray[2] = ((pgInfo->startingRegisterOffset >> 8) & 0xFF);
                        pgInfo->commandArray[3] = (pgInfo->startingRegisterOffset & 0xFF);
                        pgInfo->commandArray[4] = ((pgInfo->numberOfRegistersToTransfer >> 8) & 0xFF);
                        pgInfo->commandArray[5] = (pgInfo->numberOfRegistersToTransfer & 0xFF);
                        pgInfo->numberOfCommandBytes = PDGIC_MODBUS_SET_COIL_COMMAND_LENGTH;
                    }
                    break;
                case MODBUS_COMMAND_REPORT_SLAVE_ID :                           // 0x11
                    {
                        pgInfo->numberOfCommandBytes = PDGIC_MODBUS_SHORT_IDENTIFY_COMMAND_LENGTH;
                    }
                    break;
                default :
                    commandIsValid = GUI_NO;
                    break;
            }                           // end of switch (pgInfo->commandArray[1])
            //----------------------------------------------------------------
            // Set the CRC at the end of the command
            //----------------------------------------------------------------
            DTSTest_PDGICSuccessfulReply = GUI_NO;
            pgErrorReply = 0;
            if (commandIsValid)
            {
                int CRCOffset = pgInfo->numberOfCommandBytes - 2;
                WORD CRC = PDGIC_CalculateWordCRC(
                    pgInfo->commandArray,
                    CRCOffset);
                pgInfo->commandArray[CRCOffset] = (*((unsigned char *) &CRC) & 0xFF);
                pgInfo->commandArray[CRCOffset + 1] = (*(((unsigned char *) &CRC) + 1) & 0xFF);
                if (DTSTest_EventLogBasicEnabled)
                {
                    String ^byteString = _T("        Will send");
                    for (int count = 0; count < pgInfo->numberOfCommandBytes; count++)
                        byteString += String::Format(" {0:X2}", pgInfo->commandArray[count]);
                    RecordBasicEvent(byteString);
                    delete byteString;
                }
                if (DTSTest_KeepPortOpen)
                {
                    SerialPort ^port = pgInfo->port;
                    if (!port || !port->IsOpen)
                    {
                        SerialPort ^port = gcnew SerialPort();
                        status = DTSTest_PDGICOpenPort(pgInfo, port);
                        if (status == DTSTEST_SUCCESS)
                        {
                            DTSTest_PortIsOpen = GUI_YES;
                            Thread::Sleep(200);
                            if (port && port->IsOpen)
                            {
                                pgInfo->port = port;
                            }
                        }
                    }
                    if (port && port->IsOpen)
                    {
                        //----------------------------------------------------
                        // Write the MODBUS command, then poll for the response
                        //----------------------------------------------------
                        port->Write(pgInfo->commandArray, 0, pgInfo->numberOfCommandBytes);
                        Thread::Sleep(1);
                        status = DTSTest_PDGICRetrieveResponse(pgInfo, port);
                    }
                    else
                    {
                        status = DTSTEST_ERROR_PDGIC_PORT_NOT_OPEN;             // 0x000000CD
                    }
                }
                else
                {
                    while (DTSTest_PortIsOpen)
                    {
                        Thread::Sleep(10);
                    }
                    SerialPort ^port = gcnew SerialPort();
                    status = DTSTest_PDGICOpenPort(pgInfo, port);
                    if (status == DTSTEST_SUCCESS)
                    {
                        DTSTest_PortIsOpen = GUI_YES;
                        Thread::Sleep(200);
                        if (port && port->IsOpen)
                        {
                            pgInfo->port = port;
                            //------------------------------------------------
                            // Write the MODBUS command, then poll for the
                            // response
                            //------------------------------------------------
                            port->Write(pgInfo->commandArray, 0, pgInfo->numberOfCommandBytes);
                            Thread::Sleep(1);
                            status = DTSTest_PDGICRetrieveResponse(pgInfo, port);
                            port->Close();
                            pgInfo->port = nullptr;
                        }               // end of if (port->IsOpen)
                        else
                        {
                            status = DTSTEST_ERROR_PDGIC_PORT_OPEN_FAILURE;     // 0x000000CE
                        }
                        port->~SerialPort();
                    }                   // end of if (status == DTSTEST_SUCCESS)
                    delete port;
                    DTSTest_PortIsOpen = GUI_NO;
                }                       // end of else of if (DTSTest_KeepPortOpen)
                //------------------------------------------------------------
                // Workaround for a known DTS issue (bad CRC hangs until it
                // gets a dummy read)
                //------------------------------------------------------------
                if ((status != DTSTEST_SUCCESS) && DTSTest_WorkAroundDTSBadCRCError)
                    DTSTest_PDGICDummyRead(pgInfo);
            }                           // end of if (commandIsValid)
        }                               // end of if (StringSet(pgInfo->portName))
        else
        {
            status = DTSTEST_ERROR_PDGIC_PORT_NAME_MISSING;                     // 0x000000C4
        }
    }                                   // end of if (pgInfo && StringSet(pgInfo->commandArray))
    else
    {
        status = DTSTEST_ERROR_PDGIC_INFO_POINTER_INVALID;                      // 0x000000C1
    }
    RecordBasicEvent("    {0} concluded, returning 0x{1:X8}", functionName, status);
    return status;
}                                       // end of DTSTest_PDGICSendCommand()
//----------------------------------------------------------------------------
// DTSTest_PDGICSendRawCommand
//
// Opens the serial (MODBUS) port associated with the PDGIC device and sends
// it the specified (raw) command string
//
// Returns: 0       = Success
//          nonzero = Failure
//----------------------------------------------------------------------------
    DWORD DTSTest_GUIClass::
DTSTest_PDGICSendRawCommand(
    PDGICInfo       ^pgInfo)
{
    bool            legalCommand = GUI_NO;
    DWORD           status = DTSTEST_SUCCESS;
    String          ^functionName = _T("DTSTest_PDGICSendRawCommand");
    //------------------------------------------------------------------------
    RecordBasicEvent("    {0} called", functionName);
    if (pgInfo && StringSet(pgInfo->commandArray))
    {
        //--------------------------------------------------------------------
        // First check whether the command is even a legal one
        //--------------------------------------------------------------------
        BYTE functionCode = pgInfo->commandArray[1];
        switch (functionCode)
        {
            case 0x01 :     case 0x02 :     case 0x03 :     case 0x04 :
            case 0x05 :     case 0x06 :     case 0x07 :     case 0x08 :
            case 0x0B :     case 0x0C :     case 0x0F :     case 0x10 :
            case 0x11 :     case 0x14 :     case 0x15 :     case 0x16 :
            case 0x17 :     case 0x18 :     case 0x2B :     
                legalCommand = GUI_YES;
                break;
            default :
                break;
        }                               // end of switch (functionCode)
        //--------------------------------------------------------------------
        // Only attempt to send legal MODBUS commands
        //--------------------------------------------------------------------
        if (legalCommand)
        {
            //----------------------------------------------------------------
            // Only attempt to open the appropriately located PDGIC port
            //----------------------------------------------------------------
            if (StringSet(pgInfo->portName))
            {
                //------------------------------------------------------------
                // Set the CRC at the end of the command if requested
                //------------------------------------------------------------
                DTSTest_PDGICSuccessfulReply = GUI_NO;
                pgErrorReply = 0;
                if (DTSTest_CalculateCRCs)
                {
                    int CRCOffset = pgInfo->numberOfCommandBytes - 2;
                    WORD calculatedCRC = PDGIC_CalculateWordCRC(
                        pgInfo->commandArray,
                        CRCOffset);             // the number of bytes to CRC
                    pgInfo->commandArray[CRCOffset] = (*((unsigned char *) &calculatedCRC) & 0xFF);
                    pgInfo->commandArray[CRCOffset + 1] = (*(((unsigned char *) &calculatedCRC) + 1) & 0xFF);
                }
                if (DTSTest_EventLogBasicEnabled)
                {
                    String ^byteString = _T("        Will send");
                    for (int count = 0; count < pgInfo->numberOfCommandBytes; count++)
                        byteString += String::Format(" {0:X2}", pgInfo->commandArray[count]);
                    RecordBasicEvent(byteString);
                    delete byteString;
                }
                if (DTSTest_KeepPortOpen)
                {
                    SerialPort ^port = pgInfo->port;
                    if (!port || !port->IsOpen)
                    {
                        SerialPort ^port = gcnew SerialPort();
                        status = DTSTest_PDGICOpenPort(pgInfo, port);
                        if (status == DTSTEST_SUCCESS)
                        {
                            DTSTest_PortIsOpen = GUI_YES;
                            Thread::Sleep(200);
                            if (port && port->IsOpen)
                            {
                                pgInfo->port = port;
                            }
                        }
                    }
                    if (port && port->IsOpen)
                    {
                        //----------------------------------------------------
                        // Write the MODBUS command, then poll for the response
                        //----------------------------------------------------
                        port->Write(pgInfo->commandArray, 0, pgInfo->numberOfCommandBytes);
                        Thread::Sleep(1);
                        status = DTSTest_PDGICRetrieveResponse(pgInfo, port);
                    }
                    else
                    {
                        status = DTSTEST_ERROR_PDGIC_PORT_NOT_OPEN;             // 0x000000CD
                    }
                }
                else
                {
                    while (DTSTest_PortIsOpen)
                    {
                        Thread::Sleep(10);
                    }
                    SerialPort ^port = gcnew SerialPort();
                    status = DTSTest_PDGICOpenPort(pgInfo, port);
                    if (status == DTSTEST_SUCCESS)
                    {
                        DTSTest_PortIsOpen = GUI_YES;
                        Thread::Sleep(200);
                        if (port && port->IsOpen)
                        {
                            pgInfo->port = port;
                            //------------------------------------------------
                            // Write the MODBUS command, then poll for the
                            // response
                            //------------------------------------------------
                            port->Write(pgInfo->commandArray, 0, pgInfo->numberOfCommandBytes);
                            Thread::Sleep(1);
                            status = DTSTest_PDGICRetrieveResponse(pgInfo, port);
                            port->Close();
                            pgInfo->port = nullptr;
                        }               // end of if (port->IsOpen)
                        else
                        {
                            status = DTSTEST_ERROR_PDGIC_PORT_OPEN_FAILURE;     // 0x000000CE
                        }
                        port->~SerialPort();
                    }                   // end of if (status == DTSTEST_SUCCESS)
                    delete port;
                    DTSTest_PortIsOpen = GUI_NO;
                }                       // end of else of if (DTSTest_KeepPortOpen)
                //------------------------------------------------------------
                // Workaround for a known DTS issue (bad CRC hangs until it
                // gets a dummy read)
                //------------------------------------------------------------
                if ((status != DTSTEST_SUCCESS) && DTSTest_WorkAroundDTSBadCRCError)
                    DTSTest_PDGICDummyRead(pgInfo);
            }                           // end of if (StringSet(pgInfo->portName))
            else
            {
                status = DTSTEST_ERROR_PDGIC_PORT_NAME_MISSING;                 // 0x000000C4
            }
        }                               // end of if (legalCommand)
        else
        {
            status = DTSTEST_ERROR_ILLEGAL_COMMAND;                             // 0x00000051
        }
    }                                   // end of if (pgInfo && StringSet(pgInfo->commandArray))
    else
    {
        status = DTSTEST_ERROR_PDGIC_INFO_POINTER_INVALID;                      // 0x000000C1
    }
    RecordBasicEvent("    {0} concluded, returning 0x{1:X8}", functionName, status);
    return status;
}                                       // end of DTSTest_PDGICSendRawCommand()
//----------------------------------------------------------------------------
// DTSTest_PDGICOpenPersistentPort
//
// Opens the serial (MODBUS) port associated with the PDGIC device and marks
// the port so that it should not be closed until
// DTSTest_PDGICClosePersistentPort is called
//
// Returns: 0       = Success
//          nonzero = Failure
//----------------------------------------------------------------------------
    DWORD DTSTest_GUIClass::
DTSTest_PDGICOpenPersistentPort(
    PDGICInfo       ^pgInfo)
{
    DWORD           status = DTSTEST_SUCCESS;
    String          ^functionName = _T("DTSTest_PDGICOpenPersistentPort");
    //------------------------------------------------------------------------
    RecordBasicEvent("    {0} called", functionName);
    if (pgInfo)
    {
        //--------------------------------------------------------------------
        // Only attempt to open the appropriately located PDGIC port
        //--------------------------------------------------------------------
        if (StringSet(pgInfo->portName))
        {
            while (DTSTest_PortIsOpen)
            {
                Thread::Sleep(10);
            }
            SerialPort ^port = pgInfo->port;
            if (!port)
                port = gcnew SerialPort();
            if (port && !port->IsOpen)
            {
                status = DTSTest_PDGICOpenPort(pgInfo, port);
                if (status == DTSTEST_SUCCESS)
                {
                    Thread::Sleep(200);
                    if (port->IsOpen)
                    {
                        DTSTest_PortIsOpen = GUI_YES;
                        pgInfo->port = port;
                        DTSTest_KeepPortOpen = GUI_YES;
                    }                   // end of if (port->IsOpen)
                    else
                    {
                        status = DTSTEST_ERROR_PDGIC_PORT_OPEN_FAILURE;         // 0x000000CE
                    }
                }                       // end of if (status == DTSTEST_SUCCESS)
            }
        }                               // end of if (StringSet(pgInfo->portName))
        else
        {
            status = DTSTEST_ERROR_PDGIC_PORT_NAME_MISSING;                     // 0x000000C4
        }
    }                                   // end of if (pgInfo)
    else
    {
        status = DTSTEST_ERROR_PDGIC_INFO_POINTER_INVALID;                      // 0x000000C1
    }
    RecordBasicEvent("    {0} concluded, returning 0x{1:X8}", functionName, status);
    return status;
}                                       // end of DTSTest_PDGICOpenPersistentPort()
//----------------------------------------------------------------------------
// DTSTest_PDGICClosePersistentPort
//
// Closes the serial (MODBUS) port associated with the PDGIC device
//
// Returns: 0       = Success
//          nonzero = Failure
//----------------------------------------------------------------------------
    DWORD DTSTest_GUIClass::
DTSTest_PDGICClosePersistentPort(
    PDGICInfo       ^pgInfo)
{
    DWORD           status = DTSTEST_SUCCESS;
    String          ^functionName = _T("DTSTest_PDGICClosePersistentPort");
    //------------------------------------------------------------------------
    RecordBasicEvent("    {0} called", functionName);
    if (pgInfo)
    {
        int timeout = 1000;
        while (DTSTest_RetrieveResponseContext)
        {
            Thread::Sleep(10);
            timeout--;
            if (!timeout)
            {
                RecordErrorEvent("       {0} timed out waiting for the RetrieveResponse thread to complete",
                    functionName);
                status = DTSTEST_ERROR_RETRIEVE_RESPONSE_TIMEOUT;               // 0x000000F1
            }
        }
        if (status == DTSTEST_SUCCESS)
        {
            //----------------------------------------------------------------
            // Only attempt to close the opened PDGIC port
            //----------------------------------------------------------------
            SerialPort ^port = pgInfo->port;
            if (port && port->IsOpen)
            {
                port->Close();
                pgInfo->port = nullptr;
                port->~SerialPort();
                DTSTest_KeepPortOpen = GUI_NO;
                DTSTest_PortIsOpen = GUI_NO;
            }
        }
    }                                   // end of if (pgInfo)
    else
    {
        status = DTSTEST_ERROR_PDGIC_INFO_POINTER_INVALID;                      // 0x000000C1
    }
    RecordBasicEvent("    {0} concluded, returning 0x{1:X8}", functionName, status);
    return status;
}                                       // end of DTSTest_PDGICClosePersistentPort()
//----------------------------------------------------------------------------
// DTSTest_PDGICSetBaudRateForAllBarges
//
// Sets all barges to the specified baud rate
//
// Returns: 0       = Success
//          nonzero = Failure
//----------------------------------------------------------------------------
    DWORD DTSTest_GUIClass::
DTSTest_PDGICSetBaudRateForAllBarges(
    PDGICInfo       ^pgInfo,
    int             targetBaudRate)
{
    DWORD           status = DTSTEST_SUCCESS;
    String          ^functionName = _T("DTSTest_PDGICSetBaudRateForAllBarges");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0}({1:D}) called", functionName, targetBaudRate);
    if (pgInfo)
    {
        if ((targetBaudRate != 1200) && (targetBaudRate != 2400) &&
            (targetBaudRate != 600) && (targetBaudRate != 4800))
            status = DTSTEST_ERROR_INVALID_DATA_RATE;                           // 0x00000009
        if (status == DTSTEST_SUCCESS)
        {
            //----------------------------------------------------------------
            // Store the original node address
            //----------------------------------------------------------------
            BYTE originalNodeAddress = pgInfo->nodeAddress;
            pgInfo->nodeAddress = DTSTEST_EXPERIMENTAL_ALL_BARGES_VALUE;
            pgInfo->commandArray[1] = MODBUS_COMMAND_WRITE_SINGLE_REGISTER;     // 0x06
            pgInfo->startingRegisterOffset = 0x000B;
            switch (targetBaudRate)
            {
                case 600 : pgInfo->writeData = 0x0000;
                    break;
                case 1200 : pgInfo->writeData = 0x0001;
                    break;
                case 2400 : pgInfo->writeData = 0x0002;
                    break;
                case 4800 : pgInfo->writeData = 0x0003;
                    break;
                default :
                    status = DTSTEST_ERROR_INVALID_DATA_RATE;                   // 0x00000009
                    break;
            }
            DTSTest_PDGICSendCommand(pgInfo);
            if (!DTSTest_PDGICSuccessfulReply)
            {
                //------------------------------------------------------------
                // Retry the command
                //------------------------------------------------------------
                Thread::Sleep(100);
                DTSTest_PDGICSendCommand(pgInfo);
                if (!DTSTest_PDGICSuccessfulReply)
                {
                    status = DTSTEST_ERROR_MODBUS_COMMAND_FAILED;               // 0x000000B0
                }
            }
            if (DTSTest_PDGICSuccessfulReply && (status == DTSTEST_SUCCESS))
            {
                //------------------------------------------------------------
                // Must set the port baud rate here
                //------------------------------------------------------------
                if (pgInfo->baudRate != targetBaudRate)
                    pgInfo->baudRate = targetBaudRate;
            }
            else
            {
                if (status == DTSTEST_SUCCESS)
                    status = DTSTEST_ERROR_MODBUS_COMMAND_FAILED;               // 0x000000B0
            }
            //----------------------------------------------------------------
            // Restore the original node address
            //----------------------------------------------------------------
            pgInfo->nodeAddress = originalNodeAddress;
        }                               // end of if (status == DTSTEST_SUCCESS)
    }                                   // end of if (pgInfo)
    else
    {
        status = DTSTEST_ERROR_PDGIC_INFO_POINTER_INVALID;                      // 0x000000C1
    }
    RecordBasicEvent("{0} concluded, returning 0x{1:X8}", functionName, status);
    return status;
}                                       // end of DTSTest_PDGICSetBaudRateForAllBarges()
//----------------------------------------------------------------------------
// DTSTest_PDGICSetDTSSystemBaudRate
//
// Sets the entire DTS system (PDGIC, gauges, and barges) to the specified
// baud rate
//
// Returns: 0       = Success
//          nonzero = Failure
//----------------------------------------------------------------------------
    DWORD DTSTest_GUIClass::
DTSTest_PDGICSetDTSSystemBaudRate(
    PDGICInfo       ^pgInfo,
    int             targetBaudRate)
{
    DWORD           status = DTSTEST_SUCCESS;
    String          ^functionName = _T("DTSTest_PDGICSetDTSSystemBaudRate");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0}({1:D}) called", functionName, targetBaudRate);
    if (pgInfo)
    {
        status = DTSTest_ExperimentalSetDTSBaudRate(pgInfo, targetBaudRate);
        //--------------------------------------------------------------------
        // TODO: Auto-detect by communicating directly with the PDGIC
        //--------------------------------------------------------------------
    }                                   // end of if (pgInfo)
    else
    {
        status = DTSTEST_ERROR_PDGIC_INFO_POINTER_INVALID;                      // 0x000000C1
    }
    RecordBasicEvent("{0} concluded, returning 0x{1:X8}", functionName, status);
    return status;
}                                       // end of DTSTest_PDGICSetDTSSystemBaudRate()
////----------------------------------------------------------------------------
//// DTSTest_PDGICSetGaugeRxBaudRate
////
//// Sets the gauge located at the pre-defined node address to the specified
//// Rx baud rate
////
//// Returns: 0       = Success
////          nonzero = Failure
////
//// Note: this is replaced by DTSTest_SensorSetGaugeRxBaudRate
////----------------------------------------------------------------------------
//    DWORD DTSTest_GUIClass::
//DTSTest_PDGICSetGaugeRxBaudRate(
//    PDGICInfo       ^pgInfo,
//    int             targetBaudRate)
//{
//    DWORD           status = DTSTEST_SUCCESS;
//    String          ^functionName = _T("DTSTest_PDGICSetGaugeRxBaudRate");
//    //------------------------------------------------------------------------
//    RecordBasicEvent("{0}({1:D}) called", functionName, targetBaudRate);
//    if (pgInfo)
//    {
//        pgInfo->commandArray[1] = MODBUS_COMMAND_WRITE_SINGLE_REGISTER;         // 0x06
//        pgInfo->startingRegisterOffset = 0x0002;
//        pgInfo->writeData = (targetBaudRate == 1200) ? 0x002E : 0x0016;
//        DTSTest_PDGICSendCommand(pgInfo);
//        if (DTSTest_PDGICSuccessfulReply && (status == DTSTEST_SUCCESS))
//        {
//            //----------------------------------------------------------------
//            // Must NOT set the port baud rate here
//            //----------------------------------------------------------------
//        }
//        else
//        {
//            if (status == DTSTEST_SUCCESS)
//                status = DTSTEST_ERROR_MODBUS_COMMAND_FAILED;                   // 0x000000B0
//        }
//    }                                   // end of if (pgInfo)
//    else
//    {
//        status = DTSTEST_ERROR_PDGIC_INFO_POINTER_INVALID;                      // 0x000000C1
//    }
//    RecordBasicEvent("{0} concluded, returning 0x{1:X8}", functionName, status);
//    return status;
//}                                       // end of DTSTest_PDGICSetGaugeRxBaudRate()
////----------------------------------------------------------------------------
//// DTSTest_PDGICSetGaugeTxBaudRate
////
//// Sets the gauge located at the pre-defined node address to the specified
//// Tx baud rate
////
//// Returns: 0       = Success
////          nonzero = Failure
////
//// Note: this is replaced by DTSTest_SensorSetGaugeTxBaudRate
////----------------------------------------------------------------------------
//    DWORD DTSTest_GUIClass::
//DTSTest_PDGICSetGaugeTxBaudRate(
//    PDGICInfo       ^pgInfo,
//    int             targetBaudRate)
//{
//    DWORD           status = DTSTEST_SUCCESS;
//    String          ^functionName = _T("DTSTest_PDGICSetGaugeTxBaudRate");
//    //------------------------------------------------------------------------
//    RecordBasicEvent("{0}({1:D}) called", functionName, targetBaudRate);
//    if (pgInfo)
//    {
//        pgInfo->commandArray[1] = MODBUS_COMMAND_WRITE_SINGLE_REGISTER;         // 0x06
//        pgInfo->startingRegisterOffset = 0x0003;
//        pgInfo->writeData = (targetBaudRate == 1200) ? 0x02ED : 0x0176;
//        DTSTest_PDGICSendCommand(pgInfo);
//        if (DTSTest_PDGICSuccessfulReply && (status == DTSTEST_SUCCESS))
//        {
//            if (pgInfo->baudRate != targetBaudRate)
//                pgInfo->baudRate = targetBaudRate;
//        }
//        else
//        {
//            if (status == DTSTEST_SUCCESS)
//                status = DTSTEST_ERROR_MODBUS_COMMAND_FAILED;                   // 0x000000B0
//        }
//    }                                   // end of if (pgInfo)
//    else
//    {
//        status = DTSTEST_ERROR_PDGIC_INFO_POINTER_INVALID;                      // 0x000000C1
//    }
//    RecordBasicEvent("{0} concluded, returning 0x{1:X8}", functionName, status);
//    return status;
//}                                       // end of DTSTest_PDGICSetGaugeTxBaudRate()
//----------------------------------------------------------------------------
// DTSTest_PDGICShutDownEnvironment
//
// Closes the PDGIC I/O channel and releases environment objects
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_PDGICShutDownEnvironment(void)
{
    String          ^functionName = _T("DTSTest_PDGICShutDownEnvironment");
    //------------------------------------------------------------------------
    RecordBasicEvent("    {0} called", functionName);
    if (DTSTest_GeneralInfo->pgInfo)
    {
        PDGICInfo ^pgInfo = DTSTest_GeneralInfo->pgInfo;
//        if (pgInfo->sensorInfoArray[slotNumber]->coefficientData)
//            free((void *) pgInfo->sensorInfoArray[slotNumber]->coefficientData);
//        delete pgInfo->sensorInfoArray[slotNumber];
        for (int slotNumber = 0; slotNumber < PDGIC_MAXIMUM_NUMBER_OF_GAUGES; slotNumber++)
        {
//            if (pgInfo->sensorInfoArray[slotNumber]->coefficientData)
//                free((void *) pgInfo->sensorInfoArray[slotNumber]->coefficientData);
        }
        delete [] pgInfo->sensorInfoArray;
        delete [] pgInfo->responseArray;
        delete [] pgInfo->commandArray;
    }
    RecordBasicEvent("    {0} concluded", functionName);
}                                       // end of DTSTest_PDGICShutDownEnvironment()
//----------------------------------------------------------------------------
// DTSTest_PDGICTransmitCRCIsValid
//
// Determines whether the CRC bytes in the transmitted command bytes are valid
//----------------------------------------------------------------------------
    bool DTSTest_GUIClass::
DTSTest_PDGICTransmitCRCIsValid(
    PDGICInfo       ^pgInfo)
{
    bool            transmitCRCIsValid = GUI_NO;
    String          ^functionName = _T("DTSTest_PDGICTransmitCRCIsValid");
    //------------------------------------------------------------------------
    if (pgInfo)
    {
        RecordBasicEvent("    {0}(node {1:X2}, command {2:X2}) called",
            functionName, pgInfo->commandArray[0], pgInfo->commandArray[1]);
        int CRCOffset = pgInfo->numberOfCommandBytes - 2;
        WORD calculatedCRC = PDGIC_CalculateWordCRC(
            pgInfo->commandArray,
            CRCOffset);                 // the number of bytes to CRC
        if ((pgInfo->commandArray[CRCOffset] == (*((unsigned char *) &calculatedCRC) & 0xFF)) &&
            (pgInfo->commandArray[CRCOffset + 1] == (*(((unsigned char *) &calculatedCRC) + 1) & 0xFF)))
            transmitCRCIsValid = GUI_YES;
    }                                   // end of if (pgInfo)
    RecordBasicEvent("    {0} concluded with valid = {1}",
        functionName, (transmitCRCIsValid ? "Yes" : "No"));
    return transmitCRCIsValid;
}                                       // end of DTSTest_PDGICTransmitCRCIsValid()
//----------------------------------------------------------------------------
// PDGIC_CalculateWordCRC
//
// Returns the WORD-sized CRC calculated from the specified buffer
//----------------------------------------------------------------------------
    WORD
PDGIC_CalculateWordCRC(
    array <unsigned char>
                    ^dataBuffer,
    int             dataLength)
{
    WORD            wordCRC = 0xFFFF;
    //------------------------------------------------------------------------
    if (dataBuffer && dataLength)
    {
        for (int offset = 0; offset < dataLength; offset++)
        {
            wordCRC ^= (WORD) dataBuffer[offset];
            for (BYTE bitCount = 0; bitCount < 8; bitCount++)
            {
                if (wordCRC & 0x0001)
                {
                    wordCRC >>= 1;
                    wordCRC ^= PDGIC_CRC_POLYNOMIAL;                            // 0xA001
                }
                else
                {
                    wordCRC >>= 1;
                }
            }
        }
    }                                   // end of if (dataBuffer && dataLength)
    return wordCRC;
}                                       // end of PDGIC_CalculateWordCRC()
//----------------------------------------------------------------------------
#endif      // QDPDGIC_CPP
//============================================================================
// End of QDPDGIC.cpp
//============================================================================
