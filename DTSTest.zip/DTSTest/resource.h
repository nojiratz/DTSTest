//{{NO_DEPENDENCIES}}=========================================================
//
// Resource.h
//
// Definitions created by Microsoft Visual C++ and used by DTSTest.rc
//
// Copyright (C) 2014 - 2016 Quartzdyne, Inc.  All rights reserved.
//
// No part of this source code may be reproduced or transmitted in any form or
// by any means, electronic or mechanical, including photocopying, recording,
// or any information storage and retrieval system, without express written
// permission from Quartzdyne, Inc.  Further, no use of this source code is
// permitted in any form or means without a valid, written license agreement
// with Quartzdyne, Inc.  While every reasonable precaution has been taken in
// the preparation of this source code, Quartzdyne, Inc., assumes no
// responsibility for errors, omissions, or damages from the use of the source
// code contained herein.
//
// NEITHER QUARTZDYNE, INC., ANY MEMBER OF QUARTZDYNE, INC., NOR ANY PERSON OR
// ORGANIZATION ACTING ON BEHALF OF THEM MAKES ANY WARRANTY OR REPRESENTATION
// WHATSOEVER, EXPRESS OR IMPLIED, INCLUDING ANY WARRANTY OF MERCHANTABILITY
// OR FITNESS FOR ANY PURPOSE WITH RESPECT TO THE SOURCE CODE OR ASSUMES ANY
// LIABILITY WHATSOEVER WITH RESPECT TO ANY USE OF THE SOURCE CODE OR ANY
// PORTION THEREOF OR WITH RESPECT TO ANY DAMAGES THAT MAY RESULT FROM SUCH
// USE.
//
// Noji Ratzlaff
//
// See DTSTest.log for a complete history of all updates, changes, and revisions
// of this source and other files and policies regarding DTSTest software
//
// Updated 01-14-2016
//============================================================================
#pragma once
//----------------------------------------------------------------------------
// Program version
//----------------------------------------------------------------------------
#define     DTSTEST_VERSION_MAJOR               0
#define     DTSTEST_VERSION_MAJOR_STR           "0"
#define     DTSTEST_VERSION_MINOR               5
#define     DTSTEST_VERSION_MINOR_STR           "5"
#define     DTSTEST_VERSION_BUILD               1
#define     DTSTEST_VERSION_BUILD_STR           "1"
#define     DTSTEST_VERSION_REV                 0
#define     DTSTEST_VERSION_REV_STR             "0"
#define     DTSTEST_VERSION_FILE                DTSTEST_VERSION_MAJOR, DTSTEST_VERSION_MINOR, DTSTEST_VERSION_BUILD, DTSTEST_VERSION_REV
#define     DTSTEST_VERSION_PRODUCT             DTSTEST_VERSION_FILE
//----------------------------------------------------------------------------
// Visible file properties
//----------------------------------------------------------------------------
#define     DTSTEST_VERSION_COMPANY_NAME        value "CompanyName", "Quartzdyne, Inc.\0"
#define     DTSTEST_VERSION_FILE_DESCRIPTION    value "FileDescription", "Quartzdyne DTSTest Software\0"
#define     DTSTEST_VERSION_LEGAL_COPYRIGHT     value "LegalCopyright", "� 2016 Quartzdyne, Inc.\0"
#define     DTSTEST_VERSION_LEGAL_TRADEMARKS    value "LegalTrademarks", "A Dover Company. All rights reserved.\0"
#define     DTSTEST_VERSION_ORIGINAL_FILENAME   value "OriginalFilename", "DTSTest.exe\0"
#define     DTSTEST_VERSION_PRODUCT_NAME        value "ProductName", "DTSTest\0"
#define     DTSTEST_VERSION_PRODUCT_VERSION     value "ProductVersion", DTSTEST_VERSION_MAJOR_STR "." DTSTEST_VERSION_MINOR_STR "." DTSTEST_VERSION_BUILD_STR "." DTSTEST_VERSION_REV_STR "\0"
//----------------------------------------------------------------------------
// Hidden file properties
//----------------------------------------------------------------------------
#define     DTSTEST_VERSION_BUILD_STRING        value "Build", DTSTEST_VERSION_MAJOR_STR "." DTSTEST_VERSION_MINOR_STR "." DTSTEST_VERSION_BUILD_STR "." DTSTEST_VERSION_REV_STR "\0"
#define     DTSTEST_VERSION_COMMENTS            value "Comments", "Quartzdyne DTSTest Software\0"
#define     DTSTEST_VERSION_DEVELOPER           value "Developer", "Noji Ratzlaff\0"
#define     DTSTEST_VERSION_FILE_VERSION        value "FileVersion", DTSTEST_VERSION_MAJOR_STR "." DTSTEST_VERSION_MINOR_STR "." DTSTEST_VERSION_BUILD_STR "." DTSTEST_VERSION_REV_STR "\0"
#define     DTSTEST_VERSION_INTERNAL_NAME       value "InternalName", "DTSTest\0"
#define     DTSTEST_VERSION_PRIVATE_BUILD       value "PrivateBuild", "Noji Ratzlaff\0"
#define     DTSTEST_VERSION_SPECIAL_BUILD       value "SpecialBuild", "Noji Ratzlaff\0"
#define     DTSTEST_VERSION_SUPPORT             value "Support", "http://qd.quartzdyne.com/public/DTSTest/DTSTest-Help.php\0"
#define     DTSTEST_VERSION_USERS               value "Users", "Unlimited\0"
//----------------------------------------------------------------------------
// Program building block identifiers
//----------------------------------------------------------------------------
#define     IDS_APP_TITLE                       103
#define     IDR_MAINFRAME                       128
#define     IDI_DTSTEST                         102
#define     IDI_SMALL                           103
//----------------------------------------------------------------------------
// APS definitions
//----------------------------------------------------------------------------
#ifdef      APSTUDIO_INVOKED
#ifndef     APSTUDIO_READONLY_SYMBOLS
#define     _APS_NO_MFC                         130
#define     _APS_NEXT_RESOURCE_VALUE            129
#define     _APS_NEXT_COMMAND_VALUE             32771
#define     _APS_NEXT_CONTROL_VALUE             1000
#define     _APS_NEXT_SYMED_VALUE               110
#endif      // APSTUDIO_READONLY_SYMBOLS
#endif      // APSTUDIO_INVOKED
//----------------------------------------------------------------------------
// Support for Windows versions later than 7
//----------------------------------------------------------------------------
#define     SXS_MANIFEST_RESOURCE_ID            1
#define     SXS_MANIFEST                        DTSTest.manifest
#define     SXS_ASSEMBLY_NAME                   Microsoft.Windows.DTSTest
#define     SXS_ASSEMBLY_VERSION                1.0
#define     SXS_ASSEMBLY_LANGUAGE_INDEPENDENT   1
#define     SXS_MANIFEST_IN_RESOURCES           1
//============================================================================
// End of resource.h
//============================================================================
