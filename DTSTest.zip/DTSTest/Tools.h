//============================================================================
// Tools.h
//
// Header for Tools.cpp
//
// Copyright (C) 2014 - 2016 Quartzdyne, Inc.  All rights reserved.
//
// No part of this source code may be reproduced or transmitted in any form or
// by any means, electronic or mechanical, including photocopying, recording,
// or any information storage and retrieval system, without express written
// permission from Quartzdyne, Inc.  Further, no use of this source code is
// permitted in any form or means without a valid, written license agreement
// with Quartzdyne, Inc.  While every reasonable precaution has been taken in
// the preparation of this source code, Quartzdyne, Inc., assumes no
// responsibility for errors, omissions, or damages from the use of the source
// code contained herein.
//
// NEITHER QUARTZDYNE, INC., ANY MEMBER OF QUARTZDYNE, INC., NOR ANY PERSON OR
// ORGANIZATION ACTING ON BEHALF OF THEM MAKES ANY WARRANTY OR REPRESENTATION
// WHATSOEVER, EXPRESS OR IMPLIED, INCLUDING ANY WARRANTY OF MERCHANTABILITY
// OR FITNESS FOR ANY PURPOSE WITH RESPECT TO THE SOURCE CODE OR ASSUMES ANY
// LIABILITY WHATSOEVER WITH RESPECT TO ANY USE OF THE SOURCE CODE OR ANY
// PORTION THEREOF OR WITH RESPECT TO ANY DAMAGES THAT MAY RESULT FROM SUCH
// USE.
//
// Noji Ratzlaff
//
// See DTSTest.log for a complete history of all updates, changes, and revisions
// of this source and other files and policies regarding DTSTest software
//
// Updated 01-14-2016
//============================================================================
#pragma once
#ifndef     TOOLS_H
#define     TOOLS_H
//----------------------------------------------------------------------------
// Include appropriate headers
//----------------------------------------------------------------------------
#include    "GUI.h"
#include    "QDPDGIC.h"
//----------------------------------------------------------------------------
// The following lines are only seen by Tools.cpp
//----------------------------------------------------------------------------
#ifdef      TOOLS_CPP
//----------------------------------------------------------------------------
// Internal function prototypes
//----------------------------------------------------------------------------
//----------------------------------------------------------------------------
// External global variables
//----------------------------------------------------------------------------
//----------------------------------------------------------------------------
// End of the lines that are only seen by Tools.cpp
//----------------------------------------------------------------------------
#endif      // TOOLS_CPP
//----------------------------------------------------------------------------
// Shared definitions
//----------------------------------------------------------------------------
#define     DTSTEST_REPLY_HEADER_BYTES                          3
#define     DTSTEST_BARGE_STATUS_ADDRESS                        0
#define     DTSTEST_BARGE_STATUS_WORDS                          1
#define     DTSTEST_BARGE_STATUS_BYTES                          (DTSTEST_BARGE_STATUS_WORDS + DTSTEST_BARGE_STATUS_WORDS)
#define     DTSTEST_BARGE_CHIP_ID_ADDRESS                       1
#define     DTSTEST_BARGE_CHIP_ID_WORDS                         1
#define     DTSTEST_BARGE_CHIP_ID_BYTES                         (DTSTEST_BARGE_CHIP_ID_WORDS + DTSTEST_BARGE_CHIP_ID_WORDS)
#define     DTSTEST_BARGE_PRESSURE_ADDRESS                      2
#define     DTSTEST_BARGE_PRESSURE_WORDS                        2
#define     DTSTEST_BARGE_PRESSURE_BYTES                        (DTSTEST_BARGE_PRESSURE_WORDS + DTSTEST_BARGE_PRESSURE_WORDS)
#define     DTSTEST_BARGE_TEMPERATURE_ADDRESS                   4
#define     DTSTEST_BARGE_TEMPERATURE_WORDS                     2
#define     DTSTEST_BARGE_TEMPERATURE_BYTES                     (DTSTEST_BARGE_TEMPERATURE_WORDS + DTSTEST_BARGE_TEMPERATURE_WORDS)
#define     DTSTEST_BARGE_ADC1_ADDRESS                          6
#define     DTSTEST_BARGE_ADC1_WORDS                            1
#define     DTSTEST_BARGE_ADC1_BYTES                            (DTSTEST_BARGE_ADC1_WORDS + DTSTEST_BARGE_ADC1_WORDS)
#define     DTSTEST_BARGE_ADC2_ADDRESS                          7
#define     DTSTEST_BARGE_ADC2_WORDS                            1
#define     DTSTEST_BARGE_ADC2_BYTES                            (DTSTEST_BARGE_ADC2_WORDS + DTSTEST_BARGE_ADC2_WORDS)
#define     DTSTEST_BARGE_OTP1_ADDRESS                          8
#define     DTSTEST_BARGE_OTP1_WORDS                            1
#define     DTSTEST_BARGE_OTP1_BYTES                            (DTSTEST_BARGE_OTP1_WORDS + DTSTEST_BARGE_OTP1_WORDS)
#define     DTSTEST_BARGE_OTP2_ADDRESS                          9
#define     DTSTEST_BARGE_OTP2_WORDS                            1
#define     DTSTEST_BARGE_OTP2_BYTES                            (DTSTEST_BARGE_OTP2_WORDS + DTSTEST_BARGE_OTP2_WORDS)
#define     DTSTEST_GAUGE_PRESSURE_ADDRESS                      0
#define     DTSTEST_GAUGE_PRESSURE_WORDS                        DTSTEST_BARGE_PRESSURE_WORDS
#define     DTSTEST_GAUGE_PRESSURE_BYTES                        DTSTEST_BARGE_PRESSURE_BYTES
#define     DTSTEST_GAUGE_TEMPERATURE_ADDRESS                   2
#define     DTSTEST_GAUGE_TEMPERATURE_WORDS                     DTSTEST_BARGE_TEMPERATURE_WORDS
#define     DTSTEST_GAUGE_TEMPERATURE_BYTES                     DTSTEST_BARGE_TEMPERATURE_BYTES
#define     DTSTEST_GAUGE_ADC_0_ADDRESS                         8
#define     DTSTEST_GAUGE_ADC_0_WORDS                           1
#define     DTSTEST_GAUGE_ADC_0_BYTES                           (DTSTEST_GAUGE_ADC_0_WORDS + DTSTEST_GAUGE_ADC_0_WORDS)
#define     DTSTEST_GAUGE_ADC_1_ADDRESS                         9
#define     DTSTEST_GAUGE_ADC_1_WORDS                           1
#define     DTSTEST_GAUGE_ADC_1_BYTES                           (DTSTEST_GAUGE_ADC_1_WORDS + DTSTEST_GAUGE_ADC_1_WORDS)
#define     DTSTEST_GAUGE_ADC_2_ADDRESS                         10
#define     DTSTEST_GAUGE_ADC_2_WORDS                           1
#define     DTSTEST_GAUGE_ADC_2_BYTES                           (DTSTEST_GAUGE_ADC_2_WORDS + DTSTEST_GAUGE_ADC_2_WORDS)
#define     DTSTEST_GAUGE_ADC_3_ADDRESS                         11
#define     DTSTEST_GAUGE_ADC_3_WORDS                           1
#define     DTSTEST_GAUGE_ADC_3_BYTES                           (DTSTEST_GAUGE_ADC_3_WORDS + DTSTEST_GAUGE_ADC_3_WORDS)
#define     DTSTEST_GAUGE_STATUS_0_ADDRESS                      12
#define     DTSTEST_GAUGE_STATUS_0_WORDS                        2
#define     DTSTEST_GAUGE_STATUS_0_BYTES                        (DTSTEST_GAUGE_STATUS_0_WORDS + DTSTEST_GAUGE_STATUS_0_WORDS)
#define     DTSTEST_GAUGE_STATUS_1_ADDRESS                      14
#define     DTSTEST_GAUGE_STATUS_1_WORDS                        2
#define     DTSTEST_GAUGE_STATUS_1_BYTES                        (DTSTEST_GAUGE_STATUS_1_WORDS + DTSTEST_GAUGE_STATUS_1_WORDS)
#define     DTSTEST_GAUGE_TYPE_0_ADDRESS                        32
#define     DTSTEST_GAUGE_TYPE_0_WORDS                          1
#define     DTSTEST_GAUGE_TYPE_0_BYTES                          (DTSTEST_GAUGE_TYPE_0_WORDS + DTSTEST_GAUGE_TYPE_0_WORDS)
#define     DTSTEST_GAUGE_TYPE_1_ADDRESS                        33
#define     DTSTEST_GAUGE_TYPE_1_WORDS                          1
#define     DTSTEST_GAUGE_TYPE_1_BYTES                          (DTSTEST_GAUGE_TYPE_1_WORDS + DTSTEST_GAUGE_TYPE_1_WORDS)
#define     DTSTEST_GAUGE_VERSION_0_ADDRESS                     34
#define     DTSTEST_GAUGE_VERSION_0_WORDS                       1
#define     DTSTEST_GAUGE_VERSION_0_BYTES                       (DTSTEST_GAUGE_VERSION_0_WORDS + DTSTEST_GAUGE_VERSION_0_WORDS)
#define     DTSTEST_GAUGE_VERSION_1_ADDRESS                     35
#define     DTSTEST_GAUGE_VERSION_1_WORDS                       1
#define     DTSTEST_GAUGE_VERSION_1_BYTES                       (DTSTEST_GAUGE_VERSION_1_WORDS + DTSTEST_GAUGE_VERSION_1_WORDS)
#define     DTSTEST_GAUGE_HOLDING_0_ADDRESS                     36
#define     DTSTEST_GAUGE_HOLDING_0_WORDS                       1
#define     DTSTEST_GAUGE_HOLDING_0_BYTES                       (DTSTEST_GAUGE_HOLDING_0_WORDS + DTSTEST_GAUGE_HOLDING_0_WORDS)
#define     DTSTEST_GAUGE_HOLDING_1_ADDRESS                     37
#define     DTSTEST_GAUGE_HOLDING_1_WORDS                       1
#define     DTSTEST_GAUGE_HOLDING_1_BYTES                       (DTSTEST_GAUGE_HOLDING_1_WORDS + DTSTEST_GAUGE_HOLDING_1_WORDS)
#define     DTSTEST_GAUGE_HOLDING_2_ADDRESS                     38
#define     DTSTEST_GAUGE_HOLDING_2_WORDS                       1
#define     DTSTEST_GAUGE_HOLDING_2_BYTES                       (DTSTEST_GAUGE_HOLDING_2_WORDS + DTSTEST_GAUGE_HOLDING_2_WORDS)
#define     DTSTEST_GAUGE_HOLDING_3_ADDRESS                     39
#define     DTSTEST_GAUGE_HOLDING_3_WORDS                       1
#define     DTSTEST_GAUGE_HOLDING_3_BYTES                       (DTSTEST_GAUGE_HOLDING_3_WORDS + DTSTEST_GAUGE_HOLDING_3_WORDS)
#define     DTSTEST_GAUGE_FLAGS_ADDRESS                         42
#define     DTSTEST_GAUGE_FLAGS_WORDS                           1
#define     DTSTEST_GAUGE_FLAGS_BYTES                           (DTSTEST_GAUGE_FLAGS_WORDS + DTSTEST_GAUGE_FLAGS_WORDS)
#define     DTSTEST_GAUGE_VENDOR_PREFIX_ADDRESS                 43
#define     DTSTEST_GAUGE_VENDOR_PREFIX_WORDS                   1
#define     DTSTEST_GAUGE_VENDOR_PREFIX_BYTES                   (DTSTEST_GAUGE_VENDOR_PREFIX_WORDS + DTSTEST_GAUGE_VENDOR_PREFIX_WORDS)
#define     DTSTEST_GAUGE_VENDOR_ADDRESS                        44
#define     DTSTEST_GAUGE_VENDOR_WORDS                          13
#define     DTSTEST_GAUGE_VENDOR_BYTES                          (DTSTEST_GAUGE_VENDOR_WORDS + DTSTEST_GAUGE_VENDOR_WORDS)
#define     DTSTEST_GAUGE_DOCUMENT_PREFIX_ADDRESS               57
#define     DTSTEST_GAUGE_DOCUMENT_PREFIX_WORDS                 1
#define     DTSTEST_GAUGE_DOCUMENT_PREFIX_BYTES                 (DTSTEST_GAUGE_DOCUMENT_PREFIX_WORDS + DTSTEST_GAUGE_DOCUMENT_PREFIX_WORDS)
#define     DTSTEST_GAUGE_DOCUMENT_ADDRESS                      58
#define     DTSTEST_GAUGE_DOCUMENT_WORDS                        5
#define     DTSTEST_GAUGE_DOCUMENT_BYTES                        (DTSTEST_GAUGE_DOCUMENT_WORDS + DTSTEST_GAUGE_DOCUMENT_WORDS - 1)
#define     DTSTEST_GAUGE_REVISION_PREFIX_ADDRESS               62
#define     DTSTEST_GAUGE_REVISION_PREFIX_WORDS                 1
#define     DTSTEST_GAUGE_REVISION_PREFIX_BYTES                 (DTSTEST_GAUGE_REVISION_PREFIX_WORDS + DTSTEST_GAUGE_REVISION_PREFIX_WORDS)
#define     DTSTEST_GAUGE_REVISION_ADDRESS                      63
#define     DTSTEST_GAUGE_REVISION_WORDS                        1
#define     DTSTEST_GAUGE_REVISION_BYTES                        (DTSTEST_GAUGE_REVISION_WORDS + DTSTEST_GAUGE_REVISION_WORDS - 1)
//----------------------------------------------------------------------------
// End of shared definitions
//----------------------------------------------------------------------------
#endif      // TOOLS_H
//============================================================================
// End of Tools.h
//============================================================================
