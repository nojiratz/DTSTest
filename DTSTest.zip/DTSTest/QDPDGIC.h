//============================================================================
// QDPDGIC.h
//
// Header for QDPDGIC.cpp
//
// Copyright (C) 2014 - 2016 Quartzdyne, Inc.  All rights reserved.
//
// No part of this source code may be reproduced or transmitted in any form or
// by any means, electronic or mechanical, including photocopying, recording,
// or any information storage and retrieval system, without express written
// permission from Quartzdyne, Inc.  Further, no use of this source code is
// permitted in any form or means without a valid, written license agreement
// with Quartzdyne, Inc.  While every reasonable precaution has been taken in
// the preparation of this source code, Quartzdyne, Inc., assumes no
// responsibility for errors, omissions, or damages from the use of the source
// code contained herein.
//
// NEITHER QUARTZDYNE, INC., ANY MEMBER OF QUARTZDYNE, INC., NOR ANY PERSON OR
// ORGANIZATION ACTING ON BEHALF OF THEM MAKES ANY WARRANTY OR REPRESENTATION
// WHATSOEVER, EXPRESS OR IMPLIED, INCLUDING ANY WARRANTY OF MERCHANTABILITY
// OR FITNESS FOR ANY PURPOSE WITH RESPECT TO THE SOURCE CODE OR ASSUMES ANY
// LIABILITY WHATSOEVER WITH RESPECT TO ANY USE OF THE SOURCE CODE OR ANY
// PORTION THEREOF OR WITH RESPECT TO ANY DAMAGES THAT MAY RESULT FROM SUCH
// USE.
//
// Noji Ratzlaff
//
// See DTSTest.log for a complete history of all updates, changes, and revisions
// of this source and other files and policies regarding DTSTest software
//
// Updated 01-14-2016
//============================================================================
#pragma once
#ifndef     QDPDGIC_H
#define     QDPDGIC_H
//----------------------------------------------------------------------------
// Include appropriate headers
//----------------------------------------------------------------------------
#include    "GUI.h"
#include    "Tools.h"
//----------------------------------------------------------------------------
// The following lines are only seen by QDPDGIC.cpp
//----------------------------------------------------------------------------
#ifdef      QDPDGIC_CPP
//----------------------------------------------------------------------------
// Integer definitions
//----------------------------------------------------------------------------
#define     PDGIC_WD_NODE_ADDRESS                               0xFF
#define     PDGIC_UNIT_INFO_REGISTER_OFFSET                     0x00
#define     PDGIC_UNIT_INFO_NUMBER_OF_REGISTERS                 4
#define     PDGIC_UNIT_PWR_REGISTER_OFFSET                      0x00
#define     PDGIC_UNIT_PWR_BIT                                  0x02
#define     PDGIC_CARD_CONFIGURATION_REGISTER_OFFSET            0x00
#define     PDGIC_CARD_CONFIGURATION_NUMBER_OF_REGISTERS        14
#define     PDGIC_CARD_TEMPERATURE_REGISTER_OFFSET              0x0A
#define     PDGIC_CARD_TEMPERATURE_NUMBER_OF_REGISTERS          2
#define     PDGIC_CARD_SUPPLY_VOLTAGE_REGISTER_OFFSET           0x0E
#define     PDGIC_CARD_SUPPLY_VOLTAGE_NUMBER_OF_REGISTERS       2
#define     PDGIC_CARD_OUTPUT_VOLTAGE_REGISTER_OFFSET           0x10
#define     PDGIC_CARD_OUTPUT_VOLTAGE_NUMBER_OF_REGISTERS       2
#define     PDGIC_CARD_INPUT_VOLTAGE_REGISTER_OFFSET            0x12
#define     PDGIC_CARD_INPUT_VOLTAGE_NUMBER_OF_REGISTERS        2
#define     PDGIC_SLOT_PWR_BIT                                  0x0100
#define     PDGIC_SLOT_LAT_BIT                                  0x0200
#define     PDGIC_SLOT_INFO_REGISTERS_OFFSET                    0x20
#define     PDGIC_SLOT_INFO_NUMBER_OF_REGISTERS                 1
#define     PDGIC_SLOT_READINGS_REGISTERS_OFFSET                0x14
#define     PDGIC_SLOT_READINGS_NUMBER_OF_REGISTERS             5
#define     PDGIC_MAXIMUM_NUMBER_OF_GAUGES                      DTSTEST_MAXIMUM_NUMBER_OF_GAUGES
#define     PDGIC_NUMBER_OF_SIM_SLOTS                           DTSTEST_NUMBER_OF_SIM_SLOTS
#define     PDGIC_NUMBER_OF_REGISTERS_PER_GAUGE                 8
#define     PDGIC_CRC_POLYNOMIAL                                0xA001
//----------------------------------------------------------------------------
// Floating-point definitions
//----------------------------------------------------------------------------
#define     PDGIC_FREQUENCY_COUNT_CONVERSION_FACTOR             256.0
//----------------------------------------------------------------------------
// MODBUS definitions
//----------------------------------------------------------------------------
#define     PDGIC_MODBUS_RESPONSE_HEADER_LENGTH                 5
#define     PDGIC_MODBUS_RESPONSE_DATA_OFFSET                   3
#define     PDGIC_MODBUS_ERROR_RESPONSE_LENGTH                  PDGIC_MODBUS_RESPONSE_HEADER_LENGTH
//----------------------------------------------------------------------------
// Internal function prototypes
//----------------------------------------------------------------------------
WORD            PDGIC_CalculateWordCRC(
                    array <unsigned char>
                                    ^dataBuffer,
                    int             dataLength);
//----------------------------------------------------------------------------
// External function prototypes
//----------------------------------------------------------------------------
extern DWORD    Coeff_CalculatePressureAndTemperature(
                    PDGICInfo       ^pgInfo,
                    int             slotNumber,
                    float           *pressurePSI,
                    float           *temperatureCelsius);
//----------------------------------------------------------------------------
// End of the lines that are only seen by QDPDGIC.cpp
//----------------------------------------------------------------------------
#endif      // QDPDGIC_CPP
//----------------------------------------------------------------------------
// The following lines are seen by all files
//----------------------------------------------------------------------------
//----------------------------------------------------------------------------
// MODBUS commands
//----------------------------------------------------------------------------
#define     MODBUS_COMMAND_READ_COILS                           0x01
#define     MODBUS_COMMAND_READ_DISCRETE_INPUTS                 0x02
#define     MODBUS_COMMAND_READ_HOLDING_REGISTERS               0x03
#define     MODBUS_COMMAND_READ_INPUT_REGISTERS                 0x04
#define     MODBUS_COMMAND_WRITE_SINGLE_COIL                    0x05
#define     MODBUS_COMMAND_WRITE_SINGLE_REGISTER                0x06
#define     MODBUS_COMMAND_READ_EXCEPTION_STATUS                0x07
#define     MODBUS_COMMAND_DIAGNOSTICS                          0x08
#define     MODBUS_COMMAND_GET_COMM_EVENT_CTR                   0x0B
#define     MODBUS_COMMAND_GET_COMM_EVENT_LOG                   0x0C
#define     MODBUS_COMMAND_WRITE_MULTIPLE_COILS                 0x0F
#define     MODBUS_COMMAND_WRITE_MULTIPLE_REGISTERS             0x10
#define     MODBUS_COMMAND_REPORT_SLAVE_ID                      0x11
#define     MODBUS_COMMAND_READ_FILE_RECORD                     0x14
#define     MODBUS_COMMAND_WRITE_FILE_RECORD                    0x15
#define     MODBUS_COMMAND_MASK_WRITE_REGISTER                  0x16
#define     MODBUS_COMMAND_READ_WRITE_MULTIPLE_REGISTERS        0x17
#define     MODBUS_COMMAND_READ_FIFO_QUEUE                      0x18
#define     MODBUS_COMMAND_READ_DEVICE_IDENTIFICATION           0x2B
//----------------------------------------------------------------------------
// MODBUS command definitions
//----------------------------------------------------------------------------
#define     PDGIC_DISPLAY_MODE_INVALID                          0x02
#define     PDGIC_MODBUS_SHORT_IDENTIFY_COMMAND_LENGTH          4
#define     PDGIC_MODBUS_MULTIPLE_COMMAND_LENGTH                7
#define     PDGIC_MODBUS_SINGLE_COMMAND_LENGTH                  8
#define     PDGIC_MODBUS_SET_COIL_COMMAND_LENGTH                11
#define     PDGIC_MODBUS_MAXIMUM_COMMAND_LENGTH                 208
#define     PDGIC_MODBUS_MAXIMUM_RESPONSE_LENGTH                256
#define     PDGIC_COEFFICIENT_REGISTERS_OFFSET                  0x70
#define     PDGIC_COEFFICIENT_NUMBER_OF_REGISTERS               84
//----------------------------------------------------------------------------
// Other definitions
//----------------------------------------------------------------------------
//----------------------------------------------------------------------------
// End of definitions
//----------------------------------------------------------------------------
#endif      // QDPDGIC_H
//============================================================================
// End of QDPDGIC.h
//============================================================================
