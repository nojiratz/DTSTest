﻿//============================================================================
// Testing.cpp
//
// The methods provided for script control
//
// Copyright (C) 2014 - 2016 Quartzdyne, Inc.  All rights reserved.
//
// No part of this source code may be reproduced or transmitted in any form or
// by any means, electronic or mechanical, including photocopying, recording,
// or any information storage and retrieval system, without express written
// permission from Quartzdyne, Inc.  Further, no use of this source code is
// permitted in any form or means without a valid, written license agreement
// with Quartzdyne, Inc.  While every reasonable precaution has been taken in
// the preparation of this source code, Quartzdyne, Inc., assumes no
// responsibility for errors, omissions, or damages from the use of the source
// code contained herein.
//
// NEITHER QUARTZDYNE, INC., ANY MEMBER OF QUARTZDYNE, INC., NOR ANY PERSON OR
// ORGANIZATION ACTING ON BEHALF OF THEM MAKES ANY WARRANTY OR REPRESENTATION
// WHATSOEVER, EXPRESS OR IMPLIED, INCLUDING ANY WARRANTY OF MERCHANTABILITY
// OR FITNESS FOR ANY PURPOSE WITH RESPECT TO THE SOURCE CODE OR ASSUMES ANY
// LIABILITY WHATSOEVER WITH RESPECT TO ANY USE OF THE SOURCE CODE OR ANY
// PORTION THEREOF OR WITH RESPECT TO ANY DAMAGES THAT MAY RESULT FROM SUCH
// USE.
//
// Noji Ratzlaff
//
// See DTSTest.log for a complete history of all updates, changes, and revisions
// of this source and other files and policies regarding DTSTest software
//
// Updated 01-14-2016
//============================================================================
#include    "stdafx.h"
#ifndef     TESTING_CPP
#define     TESTING_CPP
#include    "Testing.h"
//----------------------------------------------------------------------------
// DTSTest_TestingAutoLoadCFDataChecked
//
// Handles the check of the Auto Load Coefficient Data box
//
// Called by:   DTSTest_TestingControlsSetUpWindow
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_TestingAutoLoadCFDataChecked(
    Object          ^sender,
    EventArgs       ^evt)
{
    String          ^functionName = _T("DTSTest_TestingAutoLoadCFDataChecked");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0} called", functionName);
    DTSTest_TestingAutoLoadCoefficientData = DTSTest_TestingAutoLoadCoefficientData ? GUI_NO : GUI_YES;
    RecordBasicEvent("{0} concluded", functionName);
}                                       // end of DTSTest_TestingAutoLoadCFDataChecked()
//----------------------------------------------------------------------------
// DTSTest_TestingBackgroundRunTestEntry
//
// Handles the testing background worker main tasks
//
// Called by:   DTSTest_TestingBackgroundWorker
//----------------------------------------------------------------------------
    DWORD DTSTest_GUIClass::
DTSTest_TestingBackgroundRunTestEntry(
    BackgroundWorker
                    ^workerThread,
    DoWorkEventArgs ^evt)
{
    DWORD           status = DTSTEST_SUCCESS;
    String          ^functionName = _T("DTSTest_TestingBackgroundRunTestEntry");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0} called", functionName);
    if (workerThread->CancellationPending)
    {
        evt->Cancel = GUI_YES;
    }
    else
    {
        status = DTSTest_TestingRunTestEntries(workerThread);
        if (status == DTSTEST_ERROR_TEST_CANCELED)                              // 0x000000F8
            evt->Cancel = GUI_YES;
        else
            evt->Cancel = GUI_NO;
    }
    RecordBasicEvent("{0} concluded, returning 0x{1:X8}", functionName, status);
    return status;
}                                       // end of DTSTest_TestingBackgroundRunTestEntry()
//----------------------------------------------------------------------------
// DTSTest_TestingBackgroundWorker
//
// Handles the testing background worker process
//
// Called by:   DTSTest_InitializeGUIComponents
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_TestingBackgroundWorker(
    Object          ^sender,
    DoWorkEventArgs ^evt)
{
    String          ^functionName = _T("DTSTest_TestingBackgroundWorker");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0} called", functionName);
    BackgroundWorker ^workerThread = dynamic_cast <BackgroundWorker ^> (sender);
    evt->Result = DTSTest_TestingBackgroundRunTestEntry(
        workerThread,
        evt);
    RecordBasicEvent("{0} concluded", functionName);
}                                       // end of DTSTest_TestingBackgroundWorker()
//----------------------------------------------------------------------------
// DTSTest_TestingBackgroundWorkerCompleted
//
// Handles the testing background worker completion process
//
// Called by:   DTSTest_InitializeGUIComponents
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_TestingBackgroundWorkerCompleted(
    Object          ^sender,
    RunWorkerCompletedEventArgs
                    ^evt)
{
    String          ^functionName = _T("DTSTest_TestingBackgroundWorkerCompleted");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0} called", functionName);
    DTSTest_TestingStopActivities(evt->Cancelled);
    RecordBasicEvent("{0} concluded", functionName);
}                                       // end of DTSTest_TestingBackgroundWorkerCompleted()
//----------------------------------------------------------------------------
// DTSTest_TestingBackgroundWorkerUpdateProgress
//
// Handles the testing background worker update progress process
//
// Called by:   DTSTest_InitializeGUIComponents
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_TestingBackgroundWorkerUpdateProgress(
    Object          ^sender,
    ProgressChangedEventArgs
                    ^evt)
{
    String          ^functionName = _T("DTSTest_TestingBackgroundWorkerUpdateProgress");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0} called", functionName);
    int testEntryNumber = (evt->ProgressPercentage >> 8) & 0x0F;
    int percentComplete = evt->ProgressPercentage & 0xFF;
    TestEntry ^testEntry = DTSTest_TestEntryArray[testEntryNumber];
    testEntry->entryProgressBar->Value = percentComplete;
    String ^percentString = String::Concat(percentComplete, _T("%"));
    testEntry->percentGraphics->DrawString(
        percentString,
        SystemFonts::DefaultFont,
        Brushes::Black,
        PointF(
            (testEntry->entryProgressBar->Width / 2) - (testEntry->percentGraphics->MeasureString(percentString, SystemFonts::DefaultFont).Width / 2.0F),
            (testEntry->entryProgressBar->Height / 2) - (testEntry->percentGraphics->MeasureString(percentString, SystemFonts::DefaultFont).Height / 2.0F)));
    RecordBasicEvent("{0} concluded", functionName);
}                                       // end of DTSTest_TestingBackgroundWorkerUpdateProgress()
//----------------------------------------------------------------------------
// DTSTest_TestingBaudRate1200RadioSelected
//
// Handles the selection of the 1200 baud radio button
//
// Called by:   DTSTest_TestingControlsSetUpWindow
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_TestingBaudRate1200RadioSelected(
    Object          ^sender,
    EventArgs       ^evt)
{
    String          ^functionName = _T("DTSTest_TestingBaudRate1200RadioSelected");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0} called", functionName);
    DTSTest_SetDisplayBaudRate(1200);
    RecordBasicEvent("{0} concluded", functionName);
}                                       // end of DTSTest_TestingBaudRate1200RadioSelected()
//----------------------------------------------------------------------------
// DTSTest_TestingBaudRate2400RadioSelected
//
// Handles the selection of the 2400 baud radio button
//
// Called by:   DTSTest_TestingControlsSetUpWindow
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_TestingBaudRate2400RadioSelected(
    Object          ^sender,
    EventArgs       ^evt)
{
    String          ^functionName = _T("DTSTest_TestingBaudRate2400RadioSelected");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0} called", functionName);
    DTSTest_SetDisplayBaudRate(2400);
    RecordBasicEvent("{0} concluded", functionName);
}                                       // end of DTSTest_TestingBaudRate2400RadioSelected()
//----------------------------------------------------------------------------
// DTSTest_TestingBaudRate4800RadioSelected
//
// Handles the selection of the 4800 baud radio button
//
// Called by:   DTSTest_TestingControlsSetUpWindow
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_TestingBaudRate4800RadioSelected(
    Object          ^sender,
    EventArgs       ^evt)
{
    String          ^functionName = _T("DTSTest_TestingBaudRate4800RadioSelected");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0} called", functionName);
    DTSTest_SetDisplayBaudRate(4800);
    RecordBasicEvent("{0} concluded", functionName);
}                                       // end of DTSTest_TestingBaudRate4800RadioSelected()
//----------------------------------------------------------------------------
// DTSTest_TestingBaudRate600RadioSelected
//
// Handles the selection of the 600 baud radio button
//
// Called by:   DTSTest_TestingControlsSetUpWindow
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_TestingBaudRate600RadioSelected(
    Object          ^sender,
    EventArgs       ^evt)
{
    String          ^functionName = _T("DTSTest_TestingBaudRate600RadioSelected");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0} called", functionName);
    DTSTest_SetDisplayBaudRate(600);
    RecordBasicEvent("{0} concluded", functionName);
}                                       // end of DTSTest_TestingBaudRate600RadioSelected()
//----------------------------------------------------------------------------
// DTSTest_TestingCalculateCRCsClicked
//
// Handles the click of the CRC On label
//
// Called by:   DTSTest_TestingControlsSetUpWindow
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_TestingCalculateCRCsClicked(
    Object          ^sender,
    EventArgs       ^evt)
{
    String          ^functionName = _T("DTSTest_TestingCalculateCRCsClicked");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0} called", functionName);
    DTSTest_ToggleCalculateCRCs();
    RecordBasicEvent("{0} concluded", functionName);
}                                       // end of DTSTest_TestingCalculateCRCsClicked()
//----------------------------------------------------------------------------
// DTSTest_TestingNormalizeClicked
//
// Handles the click of the Normalize Measurements label
//
// Called by:   DTSTest_TestingControlsSetUpWindow
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_TestingNormalizeClicked(
    Object          ^sender,
    EventArgs       ^evt)
{
    String          ^functionName = _T("DTSTest_TestingNormalizeClicked");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0} called", functionName);
    DTSTest_ToggleNormalizeMeasurements();
    RecordBasicEvent("{0} concluded", functionName);
}                                       // end of DTSTest_TestingNormalizeClicked()
//----------------------------------------------------------------------------
// DTSTest_TestingCheckForAsynchronousPause
//
// Checks whether the testing paused flag is set, then loops and yields until
// the flag clears
//
// Called by:   DTSTest_TestingControlsSetUpWindow
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_TestingCheckForAsynchronousPause(void)
{
    while (DTSTest_TestingPaused)
    {
        Thread::Sleep(100);
        Yield();
    }
}                                       // end of DTSTest_TestingCheckForAsynchronousPause()
//----------------------------------------------------------------------------
// DTSTest_TestingControlsClosingWindow
//
// Handles the closing of the Testing Controls window by the red X
//
// Called by:   DTSTest_TestingControlsSetUpWindow
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_TestingControlsClosingWindow(
    Object          ^sender,
    FormClosingEventArgs
                    ^evt)
{
    //------------------------------------------------------------------------
    evt->Cancel = GUI_YES;              // cancel the closing of the window
    RecordBasicEvent("Testing Controls window closing");
    if (testingControlsWindow)
    {
        testingControlsWindow->Hide();
    }
}                                       // end of DTSTest_TestingControlsClosingWindow()
//----------------------------------------------------------------------------
// DTSTest_TestingControlsHideWindow
//
// Event that hides the Testing Controls display window
//
// Called by:   DTSTest_TestingControlsSetUpWindow
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_TestingControlsHideWindow(
    Object          ^sender,
    EventArgs       ^evt)
{
    //------------------------------------------------------------------------
    RecordBasicEvent("Testing Controls window hidden");
    if (testingControlsWindow)
    {
        testingControlsWindow->Hide();
    }
}                                       // end of DTSTest_TestingControlsHideWindow()
//----------------------------------------------------------------------------
// DTSTest_TestingControlsSetUpWindow
//
// Displays Testing controls in a new window
//
// Called by:   DTSTest_InstallUtilities
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_TestingControlsSetUpWindow(void)
{
    SensorInfo      ^sensor = nullptr;
    PDGICInfo       ^pgInfo = DTSTest_GeneralInfo->pgInfo;
    String          ^functionName = _T("DTSTest_TestingControlsSetUpWindow");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0} called", functionName);
    if (DTSTest_GeneralInfo)
    {
        //--------------------------------------------------------------------
        // Create a new window form each time this is called, due to the
        // dynamic nature of the program values
        //--------------------------------------------------------------------
        testingControlsWindow = gcnew Form;
        testingControlsWindow->SuspendLayout();
        //--------------------------------------------------------------------
        // Set its properties
        //--------------------------------------------------------------------
        testingControlsWindow->MaximizeBox = GUI_NO;
        testingControlsWindow->HelpButton = GUI_NO;
        //--------------------------------------------------------------------
        // Set its icon
        //--------------------------------------------------------------------
        testingControlsWindow->Icon = DTSTest_SoftwareIcon;
        //--------------------------------------------------------------------
        // Set the background image
        //--------------------------------------------------------------------
        testingControlsWindow->BackgroundImage = whiteSandBackground;
        //--------------------------------------------------------------------
        // Set the title and border style
        //--------------------------------------------------------------------
        testingControlsWindow->Text = _T("DTSTest Testing Interface");
        testingControlsWindow->FormBorderStyle = ::FormBorderStyle::Fixed3D;
        //--------------------------------------------------------------------
        // Set the dimensions of the Testing Controls window
        //--------------------------------------------------------------------
        testingControlsWindow->Size = Drawing::Size(
            GUI_TESTING_CONTROLS_WINDOW_WIDTH,
            GUI_TESTING_CONTROLS_WINDOW_HEIGHT);
        //--------------------------------------------------------------------
        // Run / Stop button
        //--------------------------------------------------------------------
        testingRunStopButton = gcnew Button;
        testingRunStopButton->Font = gcnew Drawing::Font(
            FontFamily::GenericSansSerif,
            10.0F,
            FontStyle::Bold);
        testingRunStopButton->Text = _T("Run");
        testingRunStopButton->Location = Point(10, 24);
        testingRunStopButton->Size = Drawing::Size(90, GUI_REGULAR_BUTTON_HEIGHT);
        GUI_SetButtonInterfaceProperties(testingRunStopButton);
        testingRunStopButton->Click +=
            gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_TestingRunStopButtonClicked);
        testingControlsWindow->Controls->Add(testingRunStopButton);
        //--------------------------------------------------------------------
        // Run / Stop button tool tip
        //--------------------------------------------------------------------
        ToolTip ^testingRunStopButtonToolTip = gcnew ToolTip;
        testingRunStopButtonToolTip->ShowAlways = GUI_YES;
        testingRunStopButtonToolTip->AutoPopDelay = 10000;   // let stand for ten seconds
        testingRunStopButtonToolTip->ToolTipTitle =
            _T("Run / Stop");
        String ^testingRunStopButtonToolTipText = String::Concat(
            "Starts the round of selected testing from the", Environment::NewLine,
            "beginning if the testing is stopped; stops the", Environment::NewLine,
            "round of testing if it is running");
        testingRunStopButtonToolTip->SetToolTip(testingRunStopButton, testingRunStopButtonToolTipText);
        delete testingRunStopButtonToolTipText;
        //--------------------------------------------------------------------
        // Pause / Resume button
        //--------------------------------------------------------------------
        testingPauseResumeButton = gcnew Button;
        testingPauseResumeButton->Font = gcnew Drawing::Font(
            FontFamily::GenericSansSerif,
            10.0F,
            FontStyle::Bold);
        testingPauseResumeButton->Text = _T("Pause");
        testingPauseResumeButton->Location = Point(
            testingRunStopButton->Right + 15,
            testingRunStopButton->Top);
        testingPauseResumeButton->Size = testingRunStopButton->Size;
        GUI_SetButtonInterfaceProperties(testingPauseResumeButton);
        testingPauseResumeButton->Click +=
            gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_TestingPauseResumeButtonClicked);
        testingControlsWindow->Controls->Add(testingPauseResumeButton);
        testingPauseResumeButton->Enabled = GUI_NO;
        //--------------------------------------------------------------------
        // Pause / Resume button tool tip
        //--------------------------------------------------------------------
        ToolTip ^testingPauseResumeButtonToolTip = gcnew ToolTip;
        testingPauseResumeButtonToolTip->ShowAlways = GUI_YES;
        testingPauseResumeButtonToolTip->AutoPopDelay = 10000;   // let stand for ten seconds
        testingPauseResumeButtonToolTip->ToolTipTitle =
            _T("Pause / Resume");
        String ^testingPauseResumeButtonToolTipText = String::Concat(
            "Pauses the current round of", Environment::NewLine,
            "testing if it is running; resumes", Environment::NewLine,
            "the testing if it is paused");
        testingPauseResumeButtonToolTip->SetToolTip(testingPauseResumeButton, testingPauseResumeButtonToolTipText);
        delete testingPauseResumeButtonToolTipText;
        //--------------------------------------------------------------------
        // Loop check box
        //--------------------------------------------------------------------
        CheckBox ^testingLoopCheck = gcnew CheckBox;
        testingLoopCheck->Font = gcnew Drawing::Font(
            FontFamily::GenericSansSerif,
            10.0F,
            FontStyle::Bold);
        testingLoopCheck->Text = _T("Loop");
        testingLoopCheck->Location = Point(
            testingPauseResumeButton->Right + 15,
            testingPauseResumeButton->Top - 7);
        testingLoopCheck->Size = Drawing::Size(56, 20);
        testingLoopCheck->TextAlign = Drawing::ContentAlignment::TopLeft;
        GUI_SetObjectInterfaceProperties(testingLoopCheck);
        testingLoopCheck->Click +=
            gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_TestingSetResetLoopChecked);
        testingControlsWindow->Controls->Add(testingLoopCheck);
        //--------------------------------------------------------------------
        // Loops Completed label
        //--------------------------------------------------------------------
        testingLoopsCompletedLabel = gcnew Label;
        testingLoopsCompletedLabel->Font = gcnew Drawing::Font(
            FontFamily::GenericSansSerif,
            10.0F,
            FontStyle::Bold);
        testingLoopsCompletedLabel->Text = String::Concat(
            _T("Loops completed: "),
            DTSTest_TestingLoopsCompleted);
        GUI_PositionBelow(testingLoopsCompletedLabel, testingLoopCheck, 4);
        testingLoopsCompletedLabel->Size = Drawing::Size(190, GUI_INFO_LABEL_HEIGHT);
        testingLoopsCompletedLabel->TextAlign = Drawing::ContentAlignment::TopLeft;
        testingLoopsCompletedLabel->Visible = GUI_NO;
        testingControlsWindow->Controls->Add(testingLoopsCompletedLabel);
        //--------------------------------------------------------------------
        // Loop area tool tip
        //--------------------------------------------------------------------
        ToolTip ^testingLoopAreaToolTip = gcnew ToolTip;
        testingLoopAreaToolTip->ShowAlways = GUI_YES;
        testingLoopAreaToolTip->AutoPopDelay = 10000;     // let stand for ten seconds
        testingLoopAreaToolTip->ToolTipTitle =
            _T("Loop");
        String ^testingLoopAreaToolTipText = String::Concat(
            "Flags the selected testing to run in a", Environment::NewLine,
            "loop forever, once the testing starts");
        testingLoopAreaToolTip->SetToolTip(testingLoopCheck, testingLoopAreaToolTipText);
        testingLoopAreaToolTip->SetToolTip(testingLoopsCompletedLabel, testingLoopAreaToolTipText);
        delete testingLoopAreaToolTipText;
        //--------------------------------------------------------------------
        // CRC LED label (image)
        //--------------------------------------------------------------------
        testingCRCLEDLabel = gcnew Label;
        testingCRCLEDLabel->Location = Point(
            testingLoopsCompletedLabel->Right + 15,
            testingRunStopButton->Top - 6);
        testingCRCLEDLabel->Size = Drawing::Size(16, 16);
        testingCRCLEDLabel->Image = DTSTest_CalculateCRCs ? greenDotOnImage : greenDotOffImage;
        GUI_SetObjectInterfaceProperties(testingCRCLEDLabel);
        testingCRCLEDLabel->Click +=
            gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_TestingCalculateCRCsClicked);
        testingControlsWindow->Controls->Add(testingCRCLEDLabel);
        //--------------------------------------------------------------------
        // CRC label
        //--------------------------------------------------------------------
        Label ^testingCRCLabel = gcnew Label;
        testingCRCLabel->Font = gcnew Drawing::Font(
            FontFamily::GenericSansSerif,
            10.0F,
            FontStyle::Bold);
        testingCRCLabel->Text = _T(" CRC On");
        testingCRCLabel->Location = Point(
            testingCRCLEDLabel->Right + 2,
            testingCRCLEDLabel->Top);
        testingCRCLabel->Size = Drawing::Size(74, GUI_INFO_LABEL_HEIGHT);
        testingCRCLabel->TextAlign = Drawing::ContentAlignment::TopLeft;
        GUI_SetObjectInterfaceProperties(testingCRCLabel);
        testingCRCLabel->Click +=
            gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_TestingCalculateCRCsClicked);
        testingControlsWindow->Controls->Add(testingCRCLabel);
        //--------------------------------------------------------------------
        // CRC LED area tool tip
        //--------------------------------------------------------------------
        ToolTip ^testingCRCLEDAreaToolTip = gcnew ToolTip;
        testingCRCLEDAreaToolTip->ShowAlways = GUI_YES;
        testingCRCLEDAreaToolTip->AutoPopDelay = 10000;   // let stand for ten seconds
        testingCRCLEDAreaToolTip->ToolTipTitle =
            _T("CRC On");
        String ^testingCRCLEDAreaToolTipText = String::Concat(
            "ON = software will calculate CRCs for script commands", Environment::NewLine,
            "OFF = software will NOT calculate CRCs for script commands");
        testingCRCLEDAreaToolTip->SetToolTip(testingCRCLEDLabel, testingCRCLEDAreaToolTipText);
        testingCRCLEDAreaToolTip->SetToolTip(testingCRCLabel, testingCRCLEDAreaToolTipText);
        delete testingCRCLEDAreaToolTipText;
        //--------------------------------------------------------------------
        // Normalize LED label (image)
        //--------------------------------------------------------------------
        testingNormalizeLEDLabel = gcnew Label;
        testingNormalizeLEDLabel->Location = Point(
            testingCRCLEDLabel->Left,
            testingCRCLEDLabel->Bottom + 6);
        testingNormalizeLEDLabel->Size = testingCRCLEDLabel->Size;
        testingNormalizeLEDLabel->Image = DTSTest_NormalizeReadings ? greenDotOnImage : greenDotOffImage;
        GUI_SetObjectInterfaceProperties(testingNormalizeLEDLabel);
        testingNormalizeLEDLabel->Click +=
            gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_TestingNormalizeClicked);
        testingControlsWindow->Controls->Add(testingNormalizeLEDLabel);
        //--------------------------------------------------------------------
        // Normalize label
        //--------------------------------------------------------------------
        Label ^testingNormalizeLabel = gcnew Label;
        testingNormalizeLabel->Font = gcnew Drawing::Font(
            FontFamily::GenericSansSerif,
            10.0F,
            FontStyle::Bold);
        testingNormalizeLabel->Text = _T(" Normalize");
        testingNormalizeLabel->Location = Point(
            testingNormalizeLEDLabel->Right + 2,
            testingNormalizeLEDLabel->Top);
        testingNormalizeLabel->Size = testingCRCLabel->Size;
        testingNormalizeLabel->TextAlign = Drawing::ContentAlignment::TopLeft;
        GUI_SetObjectInterfaceProperties(testingNormalizeLabel);
        testingNormalizeLabel->Click +=
            gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_TestingNormalizeClicked);
        testingControlsWindow->Controls->Add(testingNormalizeLabel);
        //--------------------------------------------------------------------
        // Normalize LED area tool tip
        //--------------------------------------------------------------------
        ToolTip ^testingNormalizeLEDAreaToolTip = gcnew ToolTip;
        testingNormalizeLEDAreaToolTip->ShowAlways = GUI_YES;
        testingNormalizeLEDAreaToolTip->AutoPopDelay = 10000;   // let stand for ten seconds
        testingNormalizeLEDAreaToolTip->ToolTipTitle =
            _T("Normalize");
        String ^testingNormalizeLEDAreaToolTipText = String::Concat(
            "ON = normalize measurements", Environment::NewLine,
            "    (apply a bias to pressure and temperature readings)", Environment::NewLine,
            "OFF = do NOT normalize measurements", Environment::NewLine,
            "    (display actual readings)");
        testingNormalizeLEDAreaToolTip->SetToolTip(testingNormalizeLEDLabel, testingNormalizeLEDAreaToolTipText);
        testingNormalizeLEDAreaToolTip->SetToolTip(testingNormalizeLabel, testingNormalizeLEDAreaToolTipText);
        delete testingNormalizeLEDAreaToolTipText;
        //--------------------------------------------------------------------
        // Delay textbox
        //--------------------------------------------------------------------
        testingDelayBox = gcnew TextBox;
        testingDelayBox->Font = gcnew Drawing::Font(
            FontFamily::GenericSansSerif,
            8.0F,
            FontStyle::Bold);
        testingDelayBox->Text = String::Concat(DTSTest_TestingDelay);
        testingDelayBox->Location = Point(
            testingCRCLabel->Right + 20,
            testingCRCLabel->Top - 1);
        testingDelayBox->Size = Drawing::Size(
            50, GUI_REGULAR_TEXT_BOX_HEIGHT);
        testingDelayBox->Multiline = GUI_NO;
        testingDelayBox->AcceptsReturn = GUI_NO;
        testingDelayBox->AcceptsTab = GUI_NO;
        testingDelayBox->WordWrap = GUI_NO;
        testingDelayBox->TextAlign = HorizontalAlignment::Right;
        testingDelayBox->BackColor = Color::White;
        testingDelayBox->Validating +=
            gcnew CancelEventHandler(this, &DTSTest_GUIClass::DTSTest_ValidateTestingDelayValue);
        testingControlsWindow->Controls->Add(testingDelayBox);
        //--------------------------------------------------------------------
        // Delay label
        //--------------------------------------------------------------------
        Label ^testingDelayLabel = gcnew Label;
        testingDelayLabel->Font = gcnew Drawing::Font(
            FontFamily::GenericSansSerif,
            10.0F,
            FontStyle::Bold);
        testingDelayLabel->Text = _T("ms P/T delay");
        testingDelayLabel->Location = Point(
            testingDelayBox->Right + 2,
            testingDelayBox->Top + 1);
        testingDelayLabel->Size = Drawing::Size(90, GUI_INFO_LABEL_HEIGHT);
        testingDelayLabel->TextAlign = Drawing::ContentAlignment::TopLeft;
        testingDelayLabel->BackColor = Color::Transparent;
        testingControlsWindow->Controls->Add(testingDelayLabel);
        //--------------------------------------------------------------------
        // Delay area tool tip
        //--------------------------------------------------------------------
        ToolTip ^testingDelayBoxToolTip = gcnew ToolTip;
        testingDelayBoxToolTip->ShowAlways = GUI_YES;
        testingDelayBoxToolTip->AutoPopDelay = 10000;   // let stand for ten seconds
        testingDelayBoxToolTip->ToolTipTitle =
            _T("Delay");
        String ^testingDelayBoxToolTipText = String::Concat(
            "The number of milliseconds to delay prior to", Environment::NewLine,
            "sending each non-script command to the target", Environment::NewLine,
            "device");
        testingDelayBoxToolTip->SetToolTip(testingDelayBox, testingDelayBoxToolTipText);
        testingDelayBoxToolTip->SetToolTip(testingDelayLabel, testingDelayBoxToolTipText);
        delete testingDelayBoxToolTipText;
        //--------------------------------------------------------------------
        // Sync LED label (image)
        //--------------------------------------------------------------------
        testingSyncLEDLabel = gcnew Label;
        testingSyncLEDLabel->Location = Point(
            testingDelayBox->Left - 2,
            testingDelayBox->Bottom + 4);
        testingSyncLEDLabel->Size = testingCRCLEDLabel->Size;
        testingSyncLEDLabel->Image = greenDotOffImage;
        GUI_SetObjectInterfaceProperties(testingSyncLEDLabel);
        testingSyncLEDLabel->Click +=
            gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_TestingSyncClicked);
        testingControlsWindow->Controls->Add(testingSyncLEDLabel);
        //--------------------------------------------------------------------
        // Sync label
        //--------------------------------------------------------------------
        Label ^testingSyncLabel = gcnew Label;
        testingSyncLabel->Font = gcnew Drawing::Font(
            FontFamily::GenericSansSerif,
            10.0F,
            FontStyle::Bold);
        testingSyncLabel->Text = _T(" Sync On");
        testingSyncLabel->Location = Point(
            testingSyncLEDLabel->Right + 2,
            testingSyncLEDLabel->Top);
        testingSyncLabel->Size = testingCRCLabel->Size;
        testingSyncLabel->TextAlign = Drawing::ContentAlignment::TopLeft;
        GUI_SetObjectInterfaceProperties(testingSyncLabel);
        testingSyncLabel->Click +=
            gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_TestingSyncClicked);
        testingControlsWindow->Controls->Add(testingSyncLabel);
        //--------------------------------------------------------------------
        // Sync LED area tool tip
        //--------------------------------------------------------------------
        ToolTip ^testingSyncLEDAreaToolTip = gcnew ToolTip;
        testingSyncLEDAreaToolTip->ShowAlways = GUI_YES;
        testingSyncLEDAreaToolTip->AutoPopDelay = 10000;   // let stand for ten seconds
        testingSyncLEDAreaToolTip->ToolTipTitle =
            _T("Sync On");
        String ^testingSyncLEDAreaToolTipText = String::Concat(
            "ON = sync is enabled", Environment::NewLine,
            "OFF = sync is NOT enabled");
        testingSyncLEDAreaToolTip->SetToolTip(testingSyncLEDLabel, testingSyncLEDAreaToolTipText);
        testingSyncLEDAreaToolTip->SetToolTip(testingSyncLabel, testingSyncLEDAreaToolTipText);
        delete testingSyncLEDAreaToolTipText;
        //--------------------------------------------------------------------
        // Baud Rate group box
        //--------------------------------------------------------------------
        testingBaudRateGroupBox = gcnew GroupBox;
        testingBaudRateGroupBox->Text = _T("Baud Rate");
        testingBaudRateGroupBox->Location = Point(
            testingControlsWindow->Right - 220,
            testingRunStopButton->Top - 14);
        testingBaudRateGroupBox->BackColor = Color::Transparent;
        testingBaudRateGroupBox->Size = Drawing::Size(124, 54);
        testingControlsWindow->Controls->Add(testingBaudRateGroupBox);
        //--------------------------------------------------------------------
        // Baud Rate radio buttons
        //--------------------------------------------------------------------
        testingBaudRate1200Radio = gcnew RadioButton;
        testingBaudRate1200Radio->Text = _T("1200");
        testingBaudRate1200Radio->Location = Point(5, 16);
        testingBaudRate1200Radio->Size = Drawing::Size(
            50, GUI_REGULAR_RADIO_BUTTON_HEIGHT);
        GUI_SetObjectInterfaceProperties(testingBaudRate1200Radio);
        testingBaudRate1200Radio->Click +=
            gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_TestingBaudRate1200RadioSelected);
        testingBaudRateGroupBox->Controls->Add(testingBaudRate1200Radio);
        testingBaudRate2400Radio = gcnew RadioButton;
        testingBaudRate2400Radio->Text = _T("2400");
        GUI_PositionAndSizeBelow(
            testingBaudRate2400Radio,
            testingBaudRate1200Radio,
            2);
        GUI_SetObjectInterfaceProperties(testingBaudRate2400Radio);
        testingBaudRate2400Radio->Click +=
            gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_TestingBaudRate2400RadioSelected);
        testingBaudRateGroupBox->Controls->Add(testingBaudRate2400Radio);
        testingBaudRate600Radio = gcnew RadioButton;
        testingBaudRate600Radio->Text = _T("600");
        testingBaudRate600Radio->Location = Point(
            testingBaudRate1200Radio->Right + 15,
            testingBaudRate1200Radio->Top);
        testingBaudRate600Radio->Size = testingBaudRate1200Radio->Size;
        if (DTSTest_BaudRateSetTo2400)
            testingBaudRate2400Radio->Checked = GUI_YES;
        else
            testingBaudRate1200Radio->Checked = GUI_YES;
        GUI_SetObjectInterfaceProperties(testingBaudRate600Radio);
        testingBaudRate600Radio->Click +=
            gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_TestingBaudRate600RadioSelected);
//        testingBaudRate600Radio->Enabled = GUI_NO;
        testingBaudRateGroupBox->Controls->Add(testingBaudRate600Radio);
        testingBaudRate4800Radio = gcnew RadioButton;
        testingBaudRate4800Radio->Text = _T("4800");
        GUI_PositionAndSizeBelow(
            testingBaudRate4800Radio,
            testingBaudRate600Radio,
            2);
        GUI_SetObjectInterfaceProperties(testingBaudRate4800Radio);
        testingBaudRate4800Radio->Click +=
            gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_TestingBaudRate4800RadioSelected);
//        testingBaudRate4800Radio->Enabled = GUI_NO;
        testingBaudRateGroupBox->Controls->Add(testingBaudRate4800Radio);
        //--------------------------------------------------------------------
        // Baud Rate area tool tip
        //--------------------------------------------------------------------
        ToolTip ^testingBaudRateAreaToolTip = gcnew ToolTip;
        testingBaudRateAreaToolTip->ShowAlways = GUI_YES;
        testingBaudRateAreaToolTip->AutoPopDelay = 10000;   // let stand for ten seconds
        testingBaudRateAreaToolTip->ToolTipTitle =
            _T("Baud Rate");
        String ^testingBaudRateAreaToolTipText = String::Concat(
            "Displays the current system baud rate setting.", Environment::NewLine,
            "Select one to switch to that baud rate.");
        testingBaudRateAreaToolTip->SetToolTip(testingBaudRateGroupBox, testingBaudRateAreaToolTipText);
        testingBaudRateAreaToolTip->SetToolTip(testingBaudRate1200Radio, testingBaudRateAreaToolTipText);
        testingBaudRateAreaToolTip->SetToolTip(testingBaudRate2400Radio, testingBaudRateAreaToolTipText);
        testingBaudRateAreaToolTip->SetToolTip(testingBaudRate600Radio, testingBaudRateAreaToolTipText);
        testingBaudRateAreaToolTip->SetToolTip(testingBaudRate4800Radio, testingBaudRateAreaToolTipText);
        delete testingBaudRateAreaToolTipText;
        //--------------------------------------------------------------------
        // Running / Stopped LED button
        //--------------------------------------------------------------------
        testingLEDButton = gcnew Button;
        testingLEDButton->Location = Point(
            testingControlsWindow->Right - 50,
            testingRunStopButton->Top);
        testingLEDButton->Size = Drawing::Size(30, 30);
        testingLEDButton->BackgroundImage = yellowLEDOffImage;
        testingLEDButton->BackgroundImageLayout = ImageLayout::Center;
        GUI_SetObjectInterfaceProperties(testingLEDButton);
        testingLEDButton->Click +=
            gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_TestingRunStopButtonClicked);
        testingControlsWindow->Controls->Add(testingLEDButton);
        //--------------------------------------------------------------------
        // Running / Stooped LED button tool tip
        //--------------------------------------------------------------------
        ToolTip ^testingLEDButtonToolTip = gcnew ToolTip;
        testingLEDButtonToolTip->ShowAlways = GUI_YES;
        testingLEDButtonToolTip->AutoPopDelay = 10000;   // let stand for ten seconds
        testingLEDButtonToolTip->ToolTipTitle =
            _T("Running / Stopped");
        String ^testingLEDButtonToolTipText = String::Concat(
            "Displays ON if the tests are currently running or", Environment::NewLine,
            "OFF if they are not. Click to start the round of", Environment::NewLine,
            "selected testing if it is stopped; click to stop", Environment::NewLine,
            "the round if it is running. (Same function as the", Environment::NewLine,
            "\"Run / Stop\" button.)");
        testingLEDButtonToolTip->SetToolTip(testingLEDButton, testingLEDButtonToolTipText);
        delete testingLEDButtonToolTipText;
        //--------------------------------------------------------------------
        // Selection checkmark label
        //--------------------------------------------------------------------
        Label ^testingCheckmarkLabel = gcnew Label;
        testingCheckmarkLabel->Font = gcnew Drawing::Font(
            FontFamily::GenericSansSerif,
            10.0F,
            FontStyle::Bold);
        testingCheckmarkLabel->Text = _T("√");
        testingCheckmarkLabel->Location = Point(
            48, testingRunStopButton->Bottom + 26);
        testingCheckmarkLabel->Size = Drawing::Size(30, GUI_INFO_LABEL_HEIGHT);
        testingCheckmarkLabel->BackColor = Color::Transparent;
        testingControlsWindow->Controls->Add(testingCheckmarkLabel);
        //--------------------------------------------------------------------
        // Selection checkmark label tool tip
        //--------------------------------------------------------------------
        ToolTip ^testingCheckmarkLabelToolTip = gcnew ToolTip;
        testingCheckmarkLabelToolTip->ShowAlways = GUI_YES;
        testingCheckmarkLabelToolTip->AutoPopDelay = 10000;   // let stand for ten seconds
        testingCheckmarkLabelToolTip->ToolTipTitle =
            _T("Selected Entry");
        String ^testingCheckmarkLabelToolTipText = String::Concat(
            "When checked, selects the test entry line", Environment::NewLine,
            "for inclusion into the round of testing", Environment::NewLine,
            "when testing is started");
        testingCheckmarkLabelToolTip->SetToolTip(testingCheckmarkLabel, testingCheckmarkLabelToolTipText);
        //--------------------------------------------------------------------
        // Placeholder labels
        //--------------------------------------------------------------------
        Label ^testingPlaceholder1Label = gcnew Label;
        testingPlaceholder1Label->Font = gcnew Drawing::Font(
            FontFamily::GenericSansSerif,
            10.0F,
            FontStyle::Bold);
        testingPlaceholder1Label->Text = String::Concat(
            DTSTEST_STRING_DOLLAR, _T("1"));
        testingPlaceholder1Label->Location = Point(
            testingCheckmarkLabel->Right + 24,
            testingCheckmarkLabel->Top);
        testingPlaceholder1Label->Size = Drawing::Size(30, GUI_INFO_LABEL_HEIGHT);
        testingPlaceholder1Label->BackColor = Color::Transparent;
        testingControlsWindow->Controls->Add(testingPlaceholder1Label);
        Label ^testingPlaceholder2Label = gcnew Label;
        testingPlaceholder2Label->Font = gcnew Drawing::Font(
            FontFamily::GenericSansSerif,
            10.0F,
            FontStyle::Bold);
        testingPlaceholder2Label->Text = String::Concat(
            DTSTEST_STRING_DOLLAR, _T("2"));
        testingPlaceholder2Label->Location = Point(
            testingPlaceholder1Label->Right + 8,
            testingPlaceholder1Label->Top);
        testingPlaceholder2Label->Size = testingPlaceholder1Label->Size;
        testingPlaceholder2Label->BackColor = Color::Transparent;
        testingControlsWindow->Controls->Add(testingPlaceholder2Label);
        Label ^testingPlaceholder3Label = gcnew Label;
        testingPlaceholder3Label->Font = gcnew Drawing::Font(
            FontFamily::GenericSansSerif,
            10.0F,
            FontStyle::Bold);
        testingPlaceholder3Label->Text = String::Concat(
            DTSTEST_STRING_DOLLAR, _T("3"));
        testingPlaceholder3Label->Location = Point(
            testingPlaceholder2Label->Right + 8,
            testingPlaceholder2Label->Top);
        testingPlaceholder3Label->Size = testingPlaceholder2Label->Size;
        testingPlaceholder3Label->BackColor = Color::Transparent;
        testingControlsWindow->Controls->Add(testingPlaceholder3Label);
        //--------------------------------------------------------------------
        // Placeholder labels tool tip
        //--------------------------------------------------------------------
        ToolTip ^testingPlaceholderLabelToolTip = gcnew ToolTip;
        testingPlaceholderLabelToolTip->ShowAlways = GUI_YES;
        testingPlaceholderLabelToolTip->AutoPopDelay = 10000;   // let stand for ten seconds
        testingPlaceholderLabelToolTip->ToolTipTitle =
            _T("Address Placeholder");
        String ^testingPlaceholderLabelToolTipText = String::Concat(
            "This placeholder identifies a MODBUS address", Environment::NewLine,
            "that is substituted in the script where the", Environment::NewLine,
            "placeholder is located");
        testingPlaceholderLabelToolTip->SetToolTip(testingPlaceholder1Label, testingPlaceholderLabelToolTipText);
        testingPlaceholderLabelToolTip->SetToolTip(testingPlaceholder2Label, testingPlaceholderLabelToolTipText);
        testingPlaceholderLabelToolTip->SetToolTip(testingPlaceholder3Label, testingPlaceholderLabelToolTipText);
        //--------------------------------------------------------------------
        // Device Type label
        //--------------------------------------------------------------------
        Label ^testingPrimaryDeviceTypeLabel = gcnew Label;
        testingPrimaryDeviceTypeLabel->Font = gcnew Drawing::Font(
            FontFamily::GenericSansSerif,
            10.0F,
            FontStyle::Bold);
        testingPrimaryDeviceTypeLabel->Text = _T("Type");
        testingPrimaryDeviceTypeLabel->Location = Point(
            testingPlaceholder3Label->Right + 15,
            testingPlaceholder3Label->Top);
        testingPrimaryDeviceTypeLabel->Size = Drawing::Size(50, GUI_INFO_LABEL_HEIGHT);
        testingPrimaryDeviceTypeLabel->BackColor = Color::Transparent;
        testingPrimaryDeviceTypeLabel->TextAlign = Drawing::ContentAlignment::TopLeft;
        testingControlsWindow->Controls->Add(testingPrimaryDeviceTypeLabel);
        //--------------------------------------------------------------------
        // Device Type label tool tip
        //--------------------------------------------------------------------
        ToolTip ^testingPrimaryDeviceTypeLabelToolTip = gcnew ToolTip;
        testingPrimaryDeviceTypeLabelToolTip->ShowAlways = GUI_YES;
        testingPrimaryDeviceTypeLabelToolTip->AutoPopDelay = 10000;   // let stand for ten seconds
        testingPrimaryDeviceTypeLabelToolTip->ToolTipTitle =
            _T("Primary Device Type");
        String ^testingPrimaryDeviceTypeLabelToolTipText = String::Concat(
            "The device type of the primary ($1) device,", Environment::NewLine,
            "either DTS, DPS, or ROC-X");
        testingPrimaryDeviceTypeLabelToolTip->SetToolTip(testingPrimaryDeviceTypeLabel, testingPrimaryDeviceTypeLabelToolTipText);
        //--------------------------------------------------------------------
        // Script / Command label
        //--------------------------------------------------------------------
        Label ^testingScriptCommandLabel = gcnew Label;
        testingScriptCommandLabel->Font = gcnew Drawing::Font(
            FontFamily::GenericSansSerif,
            10.0F,
            FontStyle::Bold);
        testingScriptCommandLabel->Text = _T("Command or Script");
        testingScriptCommandLabel->Location = Point(
            testingPrimaryDeviceTypeLabel->Right + 9,
            testingPrimaryDeviceTypeLabel->Top);
        testingScriptCommandLabel->Size = Drawing::Size(200, GUI_INFO_LABEL_HEIGHT);
        testingScriptCommandLabel->BackColor = Color::Transparent;
        testingScriptCommandLabel->TextAlign = Drawing::ContentAlignment::TopCenter;
        testingControlsWindow->Controls->Add(testingScriptCommandLabel);
        //--------------------------------------------------------------------
        // Script / Command label tool tip
        //--------------------------------------------------------------------
        ToolTip ^testingScriptCommandLabelToolTip = gcnew ToolTip;
        testingScriptCommandLabelToolTip->ShowAlways = GUI_YES;
        testingScriptCommandLabelToolTip->AutoPopDelay = 10000;   // let stand for ten seconds
        testingScriptCommandLabelToolTip->ToolTipTitle =
            _T("Script / Command");
        String ^testingScriptCommandLabelToolTipText = String::Concat(
            "Contains either the filename of a DTSTest script", Environment::NewLine,
            "file or a discrete command in hex bytes, such as", Environment::NewLine,
            "15 04 00 02 00 02 or $1 4 0 2 0 2, for example.", Environment::NewLine,
            Environment::NewLine,
            "The following shortcut commands are also recognized", Environment::NewLine,
            "and require only the MODBUS address of the target", Environment::NewLine,
            "device where appropriate, with the CRC included in", Environment::NewLine,
            "the shortcut:", Environment::NewLine,
            Environment::NewLine,
            "    $1 pres\tread pressure", Environment::NewLine,
            "    $1 temp\tread temperature", Environment::NewLine,
            "    $1 pnt\t\tread pressure and temperature", Environment::NewLine,
            "    $1 tnp\t\tread pressure and temperature", Environment::NewLine,
            "    $1 status\tread status", Environment::NewLine,
            "    $1 chip\tread chip ID", Environment::NewLine,
            "    $1 adc\t\tread ADC registers", Environment::NewLine,
            "    $1 all\t\tread all registers", Environment::NewLine,
            "    $1 otp\t\tread the OTP (DTS / DPS)", Environment::NewLine,
            "    $1 type\tread the gauge type (ROC-X)", Environment::NewLine,
            "    $1 ver\t\tread the gauge version (ROC-X)", Environment::NewLine,
            "    $1 hold\tread the holding registers (ROC-X)", Environment::NewLine,
            "    $1 flag\t\tread the flag register (ROC-X)", Environment::NewLine,
            "    $1 vend\tread the Vendor ID (ROC-X)", Environment::NewLine,
            "    baud [XX]\tchange baud rate [to XX baud]", Environment::NewLine,
            "    sync\t\tsend the Sync command");
        testingScriptCommandLabelToolTip->SetToolTip(testingScriptCommandLabel, testingScriptCommandLabelToolTipText);
        //--------------------------------------------------------------------
        // Progress % label
        //--------------------------------------------------------------------
        Label ^testingProgressPercentageLabel = gcnew Label;
        testingProgressPercentageLabel->Font = gcnew Drawing::Font(
            FontFamily::GenericSansSerif,
            10.0F,
            FontStyle::Bold);
        testingProgressPercentageLabel->Text = _T("%");
        testingProgressPercentageLabel->Location = Point(
            testingScriptCommandLabel->Right + 120,
            testingScriptCommandLabel->Top);
        testingProgressPercentageLabel->Size = Drawing::Size(90, GUI_INFO_LABEL_HEIGHT);
        testingProgressPercentageLabel->BackColor = Color::Transparent;
        testingProgressPercentageLabel->TextAlign = Drawing::ContentAlignment::TopCenter;
        testingControlsWindow->Controls->Add(testingProgressPercentageLabel);
        //--------------------------------------------------------------------
        // Progress % tool tip
        //--------------------------------------------------------------------
        ToolTip ^testingProgressPercentageLabelToolTip = gcnew ToolTip;
        testingProgressPercentageLabelToolTip->ShowAlways = GUI_YES;
        testingProgressPercentageLabelToolTip->AutoPopDelay = 10000;   // let stand for ten seconds
        testingProgressPercentageLabelToolTip->ToolTipTitle =
            _T("Script Progress");
        String ^testingProgressPercentageLabelToolTipText = String::Concat(
            "Displays the script execution", Environment::NewLine,
            "progress percentage");
        testingProgressPercentageLabelToolTip->SetToolTip(testingProgressPercentageLabel, testingProgressPercentageLabelToolTipText);
        //--------------------------------------------------------------------
        // Pressure psi label
        //--------------------------------------------------------------------
        Label ^testingPressurePSILabel = gcnew Label;
        testingPressurePSILabel->Font = gcnew Drawing::Font(
            FontFamily::GenericSansSerif,
            10.0F,
            FontStyle::Bold);
        testingPressurePSILabel->Text = _T("psi");
        testingPressurePSILabel->Location = Point(
            testingProgressPercentageLabel->Right + 15,
            testingScriptCommandLabel->Top);
        testingPressurePSILabel->Size = Drawing::Size(82, GUI_INFO_LABEL_HEIGHT);
        testingPressurePSILabel->BackColor = Color::Transparent;
        testingPressurePSILabel->TextAlign = Drawing::ContentAlignment::TopCenter;
        testingControlsWindow->Controls->Add(testingPressurePSILabel);
        //--------------------------------------------------------------------
        // Pressure psi label tool tip
        //--------------------------------------------------------------------
        ToolTip ^testingPressurePSILabelToolTip = gcnew ToolTip;
        testingPressurePSILabelToolTip->ShowAlways = GUI_YES;
        testingPressurePSILabelToolTip->AutoPopDelay = 10000;   // let stand for ten seconds
        testingPressurePSILabelToolTip->ToolTipTitle =
            _T("Pressure Reading");
        String ^testingPressurePSILabelToolTipText = String::Concat(
            "Displays the most recent pressure", Environment::NewLine,
            "reading for this entry");
        testingPressurePSILabelToolTip->SetToolTip(testingPressurePSILabel, testingPressurePSILabelToolTipText);
        //--------------------------------------------------------------------
        // Temperature Celsius label
        //--------------------------------------------------------------------
        Label ^testingTemperatureCelsiusLabel = gcnew Label;
        testingTemperatureCelsiusLabel->Font = gcnew Drawing::Font(
            FontFamily::GenericSansSerif,
            10.0F,
            FontStyle::Bold);
        testingTemperatureCelsiusLabel->Text = _T("°C");
        testingTemperatureCelsiusLabel->Location = Point(
            testingPressurePSILabel->Right + 15,
            testingPressurePSILabel->Top);
        testingTemperatureCelsiusLabel->Size = testingPressurePSILabel->Size;
        testingTemperatureCelsiusLabel->BackColor = Color::Transparent;
        testingTemperatureCelsiusLabel->TextAlign = Drawing::ContentAlignment::TopCenter;
        testingControlsWindow->Controls->Add(testingTemperatureCelsiusLabel);
        //--------------------------------------------------------------------
        // Temperature Celsius label tool tip
        //--------------------------------------------------------------------
        ToolTip ^testingTemperatureCelsiusLabelToolTip = gcnew ToolTip;
        testingTemperatureCelsiusLabelToolTip->ShowAlways = GUI_YES;
        testingTemperatureCelsiusLabelToolTip->AutoPopDelay = 10000;   // let stand for ten seconds
        testingTemperatureCelsiusLabelToolTip->ToolTipTitle =
            _T("Temperature Reading");
        String ^testingTemperatureCelsiusLabelToolTipText = String::Concat(
            "Displays the most recent temperature", Environment::NewLine,
            "reading for this entry");
        testingTemperatureCelsiusLabelToolTip->SetToolTip(testingTemperatureCelsiusLabel, testingTemperatureCelsiusLabelToolTipText);
        //--------------------------------------------------------------------
        // Load / Erase label
        //--------------------------------------------------------------------
        Label ^testingLoadEraseLabel = gcnew Label;
        testingLoadEraseLabel->Font = gcnew Drawing::Font(
            FontFamily::GenericSansSerif,
            10.0F,
            FontStyle::Bold);
        testingLoadEraseLabel->Text = _T("Load / Erase");
        testingLoadEraseLabel->Location = Point(
            testingTemperatureCelsiusLabel->Right + 15,
            testingTemperatureCelsiusLabel->Top);
        testingLoadEraseLabel->Size = Drawing::Size(90, GUI_INFO_LABEL_HEIGHT);
        testingLoadEraseLabel->BackColor = Color::Transparent;
        testingLoadEraseLabel->TextAlign = Drawing::ContentAlignment::TopCenter;
        testingControlsWindow->Controls->Add(testingLoadEraseLabel);
        //--------------------------------------------------------------------
        // Load / Erase label tool tip
        //--------------------------------------------------------------------
        ToolTip ^testingLoadEraseLabelToolTip = gcnew ToolTip;
        testingLoadEraseLabelToolTip->ShowAlways = GUI_YES;
        testingLoadEraseLabelToolTip->AutoPopDelay = 10000;   // let stand for ten seconds
        testingLoadEraseLabelToolTip->ToolTipTitle =
            _T("Load / Erase / Default");
        String ^testingLoadEraseLabelToolTipText = String::Concat(
            "Allows you to browse for a coefficient data (.hex)", Environment::NewLine,
            "file to load for the sensor identified by the primary", Environment::NewLine,
            "($1) placeholder, or to erase the coefficient data", Environment::NewLine,
            "that has already been loaded, whose filename is", Environment::NewLine,
            "displayed on the button. 'Default' is displayed if", Environment::NewLine,
            "the default coefficient data file is loaded.");
        testingLoadEraseLabelToolTip->SetToolTip(testingLoadEraseLabel, testingLoadEraseLabelToolTipText);
        //--------------------------------------------------------------------
        // Test entry objects
        //--------------------------------------------------------------------
        int topOfLastLabel = 0;
        for (int testEntryNumber = 0; testEntryNumber < DTSTEST_MAXIMUM_NUMBER_OF_TEST_ENTRIES; testEntryNumber++)
        {
            int index = testEntryNumber + 1;
            TestEntry ^testEntry = DTSTest_TestEntryArray[testEntryNumber];
            SensorInfo ^sensor = pgInfo->sensorInfoArray[testEntry->placeholder1Value];
            //----------------------------------------------------------------
            // Entry Number label
            //----------------------------------------------------------------
            Label ^testingEntryNumberLabel = gcnew Label;
            testingEntryNumberLabel->Text = String::Concat(index);
            testingEntryNumberLabel->Font = gcnew Drawing::Font(
                FontFamily::GenericSansSerif,
                10.0F,
                FontStyle::Bold);
            topOfLastLabel = (testEntryNumber * 36) + 104;
            testingEntryNumberLabel->Location = Point(
                14, topOfLastLabel);
            testingEntryNumberLabel->Size = Drawing::Size(22, GUI_INFO_LABEL_HEIGHT);
            testingEntryNumberLabel->BackColor = Color::Transparent;
            testingEntryNumberLabel->TextAlign = Drawing::ContentAlignment::TopCenter;
            testingControlsWindow->Controls->Add(testingEntryNumberLabel);
            //----------------------------------------------------------------
            // Test Entry Number label tool tip
            //----------------------------------------------------------------
            ToolTip ^testingEntryNumberLabelToolTip = gcnew ToolTip;
            testingEntryNumberLabelToolTip->ShowAlways = GUI_YES;
            testingEntryNumberLabelToolTip->AutoPopDelay = 10000;   // let stand for ten seconds
            testingEntryNumberLabelToolTip->ToolTipTitle =
                _T("Test Entry (Line) Number");
            String ^testingEntryNumberLabelToolTipText = String::Concat(
                "Line number for this test entry, its", Environment::NewLine,
                "placeholders, device type, command,", Environment::NewLine,
                "test script progress, and readings");
            testingEntryNumberLabelToolTip->SetToolTip(testingEntryNumberLabel, testingEntryNumberLabelToolTipText);
            delete testingEntryNumberLabelToolTipText;
            //----------------------------------------------------------------
            // Selected Entry check box
            //----------------------------------------------------------------
            testEntry->entrySelectedCheck = gcnew CheckBox;
            testEntry->entrySelectedCheck->Tag = index;
            testEntry->entrySelectedCheck->Location = Point(
                testingEntryNumberLabel->Right + 10,
                testingEntryNumberLabel->Top + 1);
            testEntry->entrySelectedCheck->Size = Drawing::Size(20, GUI_REGULAR_CHECK_BOX_HEIGHT);
            GUI_SetObjectInterfaceProperties(testEntry->entrySelectedCheck);
            testEntry->entrySelectedCheck->Click +=
                gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_TestingEntrySelectedChecked);
            if (testEntry->entrySelectedForTesting)
                testEntry->entrySelectedCheck->Checked = GUI_YES;
            testingControlsWindow->Controls->Add(testEntry->entrySelectedCheck);
            //----------------------------------------------------------------
            // Selected Entry check box tool tip
            //----------------------------------------------------------------
            ToolTip ^testingSelectedEntryCheckToolTip = gcnew ToolTip;
            testingSelectedEntryCheckToolTip->ShowAlways = GUI_YES;
            testingSelectedEntryCheckToolTip->AutoPopDelay = 10000;     // let stand for ten seconds
            testingSelectedEntryCheckToolTip->ToolTipTitle =
                testingCheckmarkLabelToolTip->ToolTipTitle;
            testingSelectedEntryCheckToolTip->SetToolTip(testEntry->entrySelectedCheck, testingCheckmarkLabelToolTipText);
            //----------------------------------------------------------------
            // Test Entry Status LED label
            //----------------------------------------------------------------
            testEntry->entryStatusLEDLabel = gcnew Label;
            testEntry->entryStatusLEDLabel->Location = Point(
                testEntry->entrySelectedCheck->Right + 4,
                testEntry->entrySelectedCheck->Top - 1);
            testEntry->entryStatusLEDLabel->Size = Drawing::Size(16, 16);
            testEntry->entryStatusLEDLabel->Image = blueDotOffImage;
            GUI_SetObjectInterfaceProperties(testEntry->entryStatusLEDLabel);
            testingControlsWindow->Controls->Add(testEntry->entryStatusLEDLabel);
            //----------------------------------------------------------------
            // Test Entry Status label tool tip
            //----------------------------------------------------------------
            ToolTip ^entryStatusLEDLabelToolTip = gcnew ToolTip;
            entryStatusLEDLabelToolTip->ShowAlways = GUI_YES;
            entryStatusLEDLabelToolTip->AutoPopDelay = 10000;   // let stand for ten seconds
            entryStatusLEDLabelToolTip->ToolTipTitle =
                _T("Test Entry (Line) Status");
            String ^entryStatusLEDLabelToolTipText = String::Concat(
                "Blue : tests are currently running", Environment::NewLine,
                "Green : all the tests that ran also passed", Environment::NewLine,
                "Red : at least one of the tests failed", Environment::NewLine,
                "Off : some or all the tests have not completed");
            entryStatusLEDLabelToolTip->SetToolTip(testEntry->entryStatusLEDLabel, entryStatusLEDLabelToolTipText);
            delete entryStatusLEDLabelToolTipText;
            //----------------------------------------------------------------
            // Placeholder 1 textbox
            //----------------------------------------------------------------
            testEntry->placeholder1Box = gcnew TextBox;
            testEntry->placeholder1Box->Tag = index | 0x100;
            testEntry->placeholder1Box->Font = gcnew Drawing::Font(
                FontFamily::GenericSansSerif,
                8.0F,
                FontStyle::Bold);
            testEntry->placeholder1Box->Text = String::Format(
                "{0:X2}", testEntry->placeholder1Value);
            testEntry->placeholder1Box->Location = Point(
                testEntry->entryStatusLEDLabel->Right + 12,
                testEntry->entrySelectedCheck->Top - 3);
            testEntry->placeholder1Box->Size = Drawing::Size(
                28, GUI_REGULAR_TEXT_BOX_HEIGHT);
            testEntry->placeholder1Box->Multiline = GUI_NO;
            testEntry->placeholder1Box->AcceptsReturn = GUI_NO;
            testEntry->placeholder1Box->AcceptsTab = GUI_NO;
            testEntry->placeholder1Box->WordWrap = GUI_NO;
            testEntry->placeholder1Box->TextAlign = HorizontalAlignment::Center;
            testEntry->placeholder1Box->BackColor = Color::White;
            testEntry->placeholder1Box->CharacterCasing = CharacterCasing::Upper;
            testEntry->placeholder1Box->Validating +=
                gcnew CancelEventHandler(this, &DTSTest_GUIClass::DTSTest_ValidateTestingEntryPlaceholderValue);
            testingControlsWindow->Controls->Add(testEntry->placeholder1Box);
            //----------------------------------------------------------------
            // Placeholder 2 textbox
            //----------------------------------------------------------------
            testEntry->placeholder2Box = gcnew TextBox;
            testEntry->placeholder2Box->Tag = index | 0x200;
            testEntry->placeholder2Box->Font = gcnew Drawing::Font(
                FontFamily::GenericSansSerif,
                8.0F,
                FontStyle::Bold);
            testEntry->placeholder2Box->Text = String::Format(
                "{0:X2}", testEntry->placeholder2Value);
            testEntry->placeholder2Box->Location = Point(
                testEntry->placeholder1Box->Right + 10,
                testEntry->placeholder1Box->Top);
            testEntry->placeholder2Box->Size = testEntry->placeholder1Box->Size;
            testEntry->placeholder2Box->Multiline = GUI_NO;
            testEntry->placeholder2Box->AcceptsReturn = GUI_NO;
            testEntry->placeholder2Box->AcceptsTab = GUI_NO;
            testEntry->placeholder2Box->WordWrap = GUI_NO;
            testEntry->placeholder2Box->TextAlign = HorizontalAlignment::Center;
            testEntry->placeholder2Box->BackColor = Color::White;
            testEntry->placeholder2Box->CharacterCasing = CharacterCasing::Upper;
            testEntry->placeholder2Box->Validating +=
                gcnew CancelEventHandler(this, &DTSTest_GUIClass::DTSTest_ValidateTestingEntryPlaceholderValue);
            testingControlsWindow->Controls->Add(testEntry->placeholder2Box);
            //----------------------------------------------------------------
            // Placeholder 3 textbox
            //----------------------------------------------------------------
            testEntry->placeholder3Box = gcnew TextBox;
            testEntry->placeholder3Box->Tag = index | 0x300;
            testEntry->placeholder3Box->Font = gcnew Drawing::Font(
                FontFamily::GenericSansSerif,
                8.0F,
                FontStyle::Bold);
            testEntry->placeholder3Box->Text = String::Format(
                "{0:X2}", testEntry->placeholder3Value);
            testEntry->placeholder3Box->Location = Point(
                testEntry->placeholder2Box->Right + 10,
                testEntry->placeholder2Box->Top);
            testEntry->placeholder3Box->Size = testEntry->placeholder2Box->Size;
            testEntry->placeholder3Box->Multiline = GUI_NO;
            testEntry->placeholder3Box->AcceptsReturn = GUI_NO;
            testEntry->placeholder3Box->AcceptsTab = GUI_NO;
            testEntry->placeholder3Box->WordWrap = GUI_NO;
            testEntry->placeholder3Box->TextAlign = HorizontalAlignment::Center;
            testEntry->placeholder3Box->BackColor = Color::White;
            testEntry->placeholder3Box->CharacterCasing = CharacterCasing::Upper;
            testEntry->placeholder3Box->Validating +=
                gcnew CancelEventHandler(this, &DTSTest_GUIClass::DTSTest_ValidateTestingEntryPlaceholderValue);
            testingControlsWindow->Controls->Add(testEntry->placeholder3Box);
            //----------------------------------------------------------------
            // Placeholder textboxes tool tip
            //----------------------------------------------------------------
            ToolTip ^testingPlaceholderBoxToolTip = gcnew ToolTip;
            testingPlaceholderBoxToolTip->ShowAlways = GUI_YES;
            testingPlaceholderBoxToolTip->AutoPopDelay = 10000;   // let stand for ten seconds
            testingPlaceholderBoxToolTip->ToolTipTitle =
                testingPlaceholderLabelToolTip->ToolTipTitle;
            testingPlaceholderBoxToolTip->SetToolTip(testEntry->placeholder1Box, testingPlaceholderLabelToolTipText);
            testingPlaceholderBoxToolTip->SetToolTip(testEntry->placeholder2Box, testingPlaceholderLabelToolTipText);
            testingPlaceholderBoxToolTip->SetToolTip(testEntry->placeholder3Box, testingPlaceholderLabelToolTipText);
            //----------------------------------------------------------------
            // Device Type label
            //----------------------------------------------------------------
            testEntry->primaryDeviceTypeLabel = gcnew Label;
            testEntry->primaryDeviceTypeLabel->Font = gcnew Drawing::Font(
                FontFamily::GenericSansSerif,
                10.0F,
                FontStyle::Bold);
            testEntry->primaryDeviceTypeLabel->Location = Point(
                testEntry->placeholder3Box->Right + 15,
                testEntry->placeholder3Box->Top + 1);
            testEntry->primaryDeviceTypeLabel->Size = Drawing::Size(
                50, GUI_INFO_LABEL_HEIGHT);
            testEntry->primaryDeviceTypeLabel->BackColor = Color::Transparent;
            testEntry->primaryDeviceTypeLabel->TextAlign = Drawing::ContentAlignment::TopCenter;
            testingControlsWindow->Controls->Add(testEntry->primaryDeviceTypeLabel);
            if (sensor->sensorType == DTSTEST_SENSOR_TYPE_UNKNOWN)
                testEntry->primaryDeviceTypeLabel->Text = _T("?");
            else
                testEntry->primaryDeviceTypeLabel->Text = sensor->hardwareIDString;
            //----------------------------------------------------------------
            // Device Type label tool tip
            //----------------------------------------------------------------
            ToolTip ^testingDeviceTypeLabelToolTip = gcnew ToolTip;
            testingDeviceTypeLabelToolTip->ShowAlways = GUI_YES;
            testingDeviceTypeLabelToolTip->AutoPopDelay = 10000;   // let stand for ten seconds
            testingDeviceTypeLabelToolTip->ToolTipTitle =
                testingPrimaryDeviceTypeLabelToolTip->ToolTipTitle;
            testingDeviceTypeLabelToolTip->SetToolTip(testEntry->primaryDeviceTypeLabel, testingPrimaryDeviceTypeLabelToolTipText);
            //----------------------------------------------------------------
            // Script / Command textbox
            //----------------------------------------------------------------
            testEntry->entryScriptCommandBox = gcnew TextBox;
            testEntry->entryScriptCommandBox->Tag = index;
            testEntry->entryScriptCommandBox->Font = gcnew Drawing::Font(
                FontFamily::GenericSansSerif,
                8.0F,
                FontStyle::Bold);
            if (StringSet(testEntry->entryControlScriptFile))
                testEntry->entryScriptCommandBox->Text = testEntry->entryControlScriptFile;
            else
                if (StringSet(testEntry->entryCommandString))
                    testEntry->entryScriptCommandBox->Text = testEntry->entryCommandString;
                else
                    testEntry->entryScriptCommandBox->Text = DTSTEST_TESTING_EMPTY_COMMAND_BOX;
            testEntry->entryScriptCommandBox->Location = Point(
                testEntry->primaryDeviceTypeLabel->Right + 15,
                testEntry->placeholder3Box->Top);
            testEntry->entryScriptCommandBox->Size = Drawing::Size(
                200, GUI_REGULAR_TEXT_BOX_HEIGHT);
            testEntry->entryScriptCommandBox->Multiline = GUI_NO;
            testEntry->entryScriptCommandBox->AcceptsReturn = GUI_NO;
            testEntry->entryScriptCommandBox->AcceptsTab = GUI_NO;
            testEntry->entryScriptCommandBox->WordWrap = GUI_NO;
            testEntry->entryScriptCommandBox->TextAlign = HorizontalAlignment::Left;
            if ((StringICompare(testEntry->entryScriptCommandBox->Text, DTSTEST_TESTING_EMPTY_COMMAND_BOX) == 0) ||
                !StringSet(testEntry->entryScriptCommandBox->Text))
                testEntry->entryScriptCommandBox->ForeColor = Color::Gray;
            testEntry->entryScriptCommandBox->BackColor = Color::White;
            testEntry->entryScriptCommandBox->Click +=
                gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_TestingEntryScriptCommandClicked);
            testEntry->entryScriptCommandBox->Validating +=
                gcnew CancelEventHandler(this, &DTSTest_GUIClass::DTSTest_ValidateTestingEntryScriptCommand);
            testingControlsWindow->Controls->Add(testEntry->entryScriptCommandBox);
            //----------------------------------------------------------------
            // Script / Command textbox tool tip
            //----------------------------------------------------------------
            ToolTip ^testingScriptCommandBoxToolTip = gcnew ToolTip;
            testingScriptCommandBoxToolTip->ShowAlways = GUI_YES;
            testingScriptCommandBoxToolTip->AutoPopDelay = 20000;   // let stand for twenty seconds
            testingScriptCommandBoxToolTip->ToolTipTitle =
                testingScriptCommandLabelToolTip->ToolTipTitle;
            testingScriptCommandBoxToolTip->SetToolTip(testEntry->entryScriptCommandBox, testingScriptCommandLabelToolTipText);
            //----------------------------------------------------------------
            // Script button
            //----------------------------------------------------------------
            testEntry->entryScriptPathButton = gcnew Button;
            testEntry->entryScriptPathButton->Tag = index;
            testEntry->entryScriptPathButton->Font = gcnew Drawing::Font(
                FontFamily::GenericSansSerif,
                10.0F,
                FontStyle::Bold);
            testEntry->entryScriptPathButton->Text = _T("Browse...");
            testEntry->entryScriptPathButton->Location = Point(
                testEntry->entryScriptCommandBox->Right + 15,
                testEntry->entryScriptCommandBox->Top);
            testEntry->entryScriptPathButton->Size = Drawing::Size(90, 20);
            GUI_SetButtonInterfaceProperties(testEntry->entryScriptPathButton);
            testEntry->entryScriptPathButton->Click +=
                gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_TestingEntryScriptPathButtonClicked);
            testingControlsWindow->Controls->Add(testEntry->entryScriptPathButton);
            //----------------------------------------------------------------
            // Script button tool tip
            //----------------------------------------------------------------
            ToolTip ^testingScriptPathButtonToolTip = gcnew ToolTip;
            testingScriptPathButtonToolTip->ShowAlways = GUI_YES;
            testingScriptPathButtonToolTip->AutoPopDelay = 10000;   // let stand for ten seconds
            testingScriptPathButtonToolTip->ToolTipTitle =
                _T("Browse");
            String ^testingScriptPathButtonToolTipText = String::Concat(
                "Allows you to browse for a file to run", Environment::NewLine,
                "as a DTSTest script");
            testingScriptPathButtonToolTip->SetToolTip(testEntry->entryScriptPathButton, testingScriptPathButtonToolTipText);
            delete testingScriptPathButtonToolTipText;
            //----------------------------------------------------------------
            // Test Entry progress bar
            //----------------------------------------------------------------
            testEntry->entryProgressBar = gcnew ProgressBar;
            testEntry->entryProgressBar->Location = Point(
                testEntry->entryScriptPathButton->Right + 15,
                testEntry->entrySelectedCheck->Top - 1);
            testEntry->entryProgressBar->Size = Drawing::Size(90, 17);
            testEntry->entryProgressBar->BackgroundImageLayout = ImageLayout::Center;
            testEntry->entryProgressBar->Minimum = 0;
            testEntry->entryProgressBar->Maximum = 100;
            testEntry->entryProgressBar->Style = ProgressBarStyle::Continuous;
            testingControlsWindow->Controls->Add(testEntry->entryProgressBar);
            testEntry->percentGraphics = testEntry->entryProgressBar->CreateGraphics();
            //----------------------------------------------------------------
            // Test Entry progress bar tool tip
            //----------------------------------------------------------------
            ToolTip ^entryProgressBarToolTip = gcnew ToolTip;
            entryProgressBarToolTip->ShowAlways = GUI_YES;
            entryProgressBarToolTip->AutoPopDelay = 10000;   // let stand for ten seconds
            entryProgressBarToolTip->ToolTipTitle =
                testingProgressPercentageLabelToolTip->ToolTipTitle;
            entryProgressBarToolTip->SetToolTip(testEntry->entryProgressBar, testingProgressPercentageLabelToolTipText);
            //----------------------------------------------------------------
            // Pressure label
            //----------------------------------------------------------------
            testEntry->entryPressureLabel = gcnew Label;
            testEntry->entryPressureLabel->Text = _T("--  --  --  --");
            testEntry->entryPressureLabel->Location = Point(
                testEntry->entryProgressBar->Right + 15,
                testEntry->entryProgressBar->Top);
            testEntry->entryPressureLabel->Size = Drawing::Size(
                82, GUI_INFO_LABEL_HEIGHT);
            testEntry->entryPressureLabel->BackColor = Color::Transparent;
            testEntry->entryPressureLabel->Font = gcnew Drawing::Font(
                FontFamily::GenericSansSerif,
                10.0F,
                FontStyle::Bold);
            testEntry->entryPressureLabel->TextAlign = Drawing::ContentAlignment::MiddleCenter;
            testingControlsWindow->Controls->Add(testEntry->entryPressureLabel);
            //----------------------------------------------------------------
            // Pressure label tool tip
            //----------------------------------------------------------------
            ToolTip ^entryPressureLabelToolTip = gcnew ToolTip;
            entryPressureLabelToolTip->ShowAlways = GUI_YES;
            entryPressureLabelToolTip->AutoPopDelay = 10000;   // let stand for ten seconds
            entryPressureLabelToolTip->ToolTipTitle =
                testingPressurePSILabelToolTip->ToolTipTitle;
            entryPressureLabelToolTip->SetToolTip(testEntry->entryPressureLabel, testingPressurePSILabelToolTipText);
            //----------------------------------------------------------------
            // Temperature label
            //----------------------------------------------------------------
            testEntry->entryTemperatureLabel = gcnew Label;
            testEntry->entryTemperatureLabel->Text = _T("--  --  --  --");
            testEntry->entryTemperatureLabel->Location = Point(
                testEntry->entryPressureLabel->Right + 15,
                testEntry->entryPressureLabel->Top);
            testEntry->entryTemperatureLabel->Size = testEntry->entryPressureLabel->Size;
            testEntry->entryTemperatureLabel->BackColor = Color::Transparent;
            testEntry->entryTemperatureLabel->Font = gcnew Drawing::Font(
                FontFamily::GenericSansSerif,
                10.0F,
                FontStyle::Bold);
            testEntry->entryTemperatureLabel->TextAlign = Drawing::ContentAlignment::MiddleCenter;
            testingControlsWindow->Controls->Add(testEntry->entryTemperatureLabel);
            //----------------------------------------------------------------
            // Temperature label tool tip
            //----------------------------------------------------------------
            ToolTip ^entryTemperatureLabelToolTip = gcnew ToolTip;
            entryTemperatureLabelToolTip->ShowAlways = GUI_YES;
            entryTemperatureLabelToolTip->AutoPopDelay = 10000;   // let stand for ten seconds
            entryTemperatureLabelToolTip->ToolTipTitle =
                testingTemperatureCelsiusLabelToolTip->ToolTipTitle;
            entryTemperatureLabelToolTip->SetToolTip(testEntry->entryTemperatureLabel, testingTemperatureCelsiusLabelToolTipText);
            //----------------------------------------------------------------
            // Load / Erase button
            //----------------------------------------------------------------
            testEntry->entryLoadEraseButton = gcnew Button;
            testEntry->entryLoadEraseButton->Tag = index;
            testEntry->entryLoadEraseButton->Font = gcnew Drawing::Font(
                FontFamily::GenericSansSerif,
                10.0F,
                FontStyle::Bold);
            if (testEntry->coefficientDataLoaded)
            {
                if (StringICompare(sensor->coefficientInfo->hexFilePath, GUI_DEFAULT_COEFFICIENT_HEX_FILE) == 0)
                    testEntry->entryLoadEraseButton->Text = _T("Default");
                else
                    testEntry->entryLoadEraseButton->Text = Path::GetFileNameWithoutExtension(
                        sensor->coefficientInfo->hexFilePath);
            }
            else
                testEntry->entryLoadEraseButton->Text = _T("Load");
            testEntry->entryLoadEraseButton->Location = Point(
                testEntry->entryTemperatureLabel->Right + 15,
                testEntry->entryScriptPathButton->Top);
            testEntry->entryLoadEraseButton->Size = Drawing::Size(90, 20);
            GUI_SetButtonInterfaceProperties(testEntry->entryLoadEraseButton);
            testEntry->entryLoadEraseButton->Click +=
                gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_TestingEntryLoadEraseButtonClicked);
            testingControlsWindow->Controls->Add(testEntry->entryLoadEraseButton);
            //----------------------------------------------------------------
            // Load / Erase button tool tip
            //----------------------------------------------------------------
            ToolTip ^entryLoadEraseButtonToolTip = gcnew ToolTip;
            entryLoadEraseButtonToolTip->ShowAlways = GUI_YES;
            entryLoadEraseButtonToolTip->AutoPopDelay = 10000;   // let stand for ten seconds
            entryLoadEraseButtonToolTip->ToolTipTitle =
                testingLoadEraseLabelToolTip->ToolTipTitle;
            entryLoadEraseButtonToolTip->SetToolTip(testEntry->entryLoadEraseButton, testingLoadEraseLabelToolTipText);
        }                               // end of for (int testEntry = 0; ...)
        //--------------------------------------------------------------------
        // Clear Command Dialogue button
        //--------------------------------------------------------------------
        testingClearCommandDialogueButton = gcnew Button;
        testingClearCommandDialogueButton->Font = gcnew Drawing::Font(
            FontFamily::GenericSansSerif,
            10.0F,
            FontStyle::Bold);
        testingClearCommandDialogueButton->Text = _T("Clear");
        testingClearCommandDialogueButton->Location = Point(
            testingRunStopButton->Left,
            topOfLastLabel + 36);
        testingClearCommandDialogueButton->Size = Drawing::Size(
            GUI_CLOSE_BUTTON_WIDTH,
            GUI_REGULAR_BUTTON_HEIGHT);
        GUI_SetButtonInterfaceProperties(testingClearCommandDialogueButton);
        testingClearCommandDialogueButton->Click +=
            gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_HomeClearCommandDialogueButtonClicked);
        testingControlsWindow->Controls->Add(testingClearCommandDialogueButton);
        if (StringSet(generalCSVFileString) || StringSet(homeCommandDialogueBox->Text))
            testingClearCommandDialogueButton->Enabled = GUI_YES;
        else
            testingClearCommandDialogueButton->Enabled = GUI_NO;
        //--------------------------------------------------------------------
        // Clear Command Dialogue button tool tip
        //--------------------------------------------------------------------
        ToolTip ^testingClearCommandDialogueButtonToolTip = gcnew ToolTip;
        testingClearCommandDialogueButtonToolTip->ShowAlways = GUI_YES;
        testingClearCommandDialogueButtonToolTip->AutoPopDelay = 10000;     // let stand for ten seconds
        testingClearCommandDialogueButtonToolTip->ToolTipTitle =
            _T("Clear Command Dialogue");
        String ^testingClearCommandDialogueButtonToolTipText = String::Concat(
            "Clears the command dialogue box and all", Environment::NewLine,
            "current test results that have not been", Environment::NewLine,
            "saved, but does not save either one");
        testingClearCommandDialogueButtonToolTip->SetToolTip(testingClearCommandDialogueButton, testingClearCommandDialogueButtonToolTipText);
        delete testingClearCommandDialogueButtonToolTipText;
        //--------------------------------------------------------------------
        // Save Test Results button
        //--------------------------------------------------------------------
        Button ^testingSaveTestResultsButton = gcnew Button;
        testingSaveTestResultsButton->Font = gcnew Drawing::Font(
            FontFamily::GenericSansSerif,
            10.0F,
            FontStyle::Bold);
        testingSaveTestResultsButton->Text = _T("Save");
        testingSaveTestResultsButton->Location = Point(
            testingClearCommandDialogueButton->Right + 15,
            testingClearCommandDialogueButton->Top);
        testingSaveTestResultsButton->Size = testingClearCommandDialogueButton->Size;
        GUI_SetButtonInterfaceProperties(testingSaveTestResultsButton);
        testingSaveTestResultsButton->Click +=
            gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_HomeSaveCommandDialogueButtonClicked);
        testingControlsWindow->Controls->Add(testingSaveTestResultsButton);
        //--------------------------------------------------------------------
        // Save Test Results button tool tip
        //--------------------------------------------------------------------
        ToolTip ^testingSaveTestResultsButtonToolTip = gcnew ToolTip;
        testingSaveTestResultsButtonToolTip->ShowAlways = GUI_YES;
        testingSaveTestResultsButtonToolTip->AutoPopDelay = 10000;     // let stand for ten seconds
        testingSaveTestResultsButtonToolTip->ToolTipTitle =
            _T("Save Test Results");
        String ^testingSaveTestResultsButtonToolTipText = String::Concat(
            "Prompts for a file in which to save the test", Environment::NewLine,
            "results, with the CSV file being saved in", Environment::NewLine,
            "the same directory");
        testingSaveTestResultsButtonToolTip->SetToolTip(testingSaveTestResultsButton, testingSaveTestResultsButtonToolTipText);
        delete testingSaveTestResultsButtonToolTipText;
        //--------------------------------------------------------------------
        // Results Log Path label
        //--------------------------------------------------------------------
        testingResultsLogPathLabel = gcnew Label;
        testingResultsLogPathLabel->Font = gcnew Drawing::Font(
            FontFamily::GenericSansSerif,
            10.0F,
            FontStyle::Bold);
        testingResultsLogPathLabel->Text = String::Concat(
            _T("Test results: "),
            DTSTest_GeneralInfo->mainScript->resultsLogFilePath);
        testingResultsLogPathLabel->Location = Point(
            testingSaveTestResultsButton->Right + 10,
            testingSaveTestResultsButton->Top + 4);
        testingResultsLogPathLabel->Size = Drawing::Size(
            810, GUI_INFO_LABEL_HEIGHT);
        testingResultsLogPathLabel->BackColor = Color::Transparent;
        testingResultsLogPathLabel->TextAlign = Drawing::ContentAlignment::MiddleLeft;
        testingControlsWindow->Controls->Add(testingResultsLogPathLabel);
        //--------------------------------------------------------------------
        // Results Log Path label tool tip
        //--------------------------------------------------------------------
        ToolTip ^testingResultsLogPathLabelToolTip = gcnew ToolTip;
        testingResultsLogPathLabelToolTip->ShowAlways = GUI_YES;
        testingResultsLogPathLabelToolTip->AutoPopDelay = 10000;     // let stand for ten seconds
        testingResultsLogPathLabelToolTip->ToolTipTitle =
            _T("Test Results Path");
        String ^testingResultsLogPathLabelToolTipText = String::Concat(
            "The path and filename of the", Environment::NewLine,
            "test results log file");
        testingResultsLogPathLabelToolTip->SetToolTip(testingResultsLogPathLabel, testingResultsLogPathLabelToolTipText);
        delete testingResultsLogPathLabelToolTipText;
        //--------------------------------------------------------------------
        // Auto Load Coefficient Data check box
        //--------------------------------------------------------------------
        CheckBox ^testingAutoLoadCFDataCheck = gcnew CheckBox;
        testingAutoLoadCFDataCheck->Text = _T("Automatically load coefficient data");
        testingAutoLoadCFDataCheck->Location = Point(
            20, testingControlsWindow->Bottom - 65);
        testingAutoLoadCFDataCheck->Size = Drawing::Size(200, GUI_REGULAR_CHECK_BOX_HEIGHT);
        GUI_SetObjectInterfaceProperties(testingAutoLoadCFDataCheck);
        testingAutoLoadCFDataCheck->Click +=
            gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_TestingAutoLoadCFDataChecked);
        testingControlsWindow->Controls->Add(testingAutoLoadCFDataCheck);
        testingAutoLoadCFDataCheck->Checked = DTSTest_TestingAutoLoadCoefficientData;
        //--------------------------------------------------------------------
        // Auto Load Coefficient Data check box tool tip
        //--------------------------------------------------------------------
        ToolTip ^testingAutoLoadCFDataCheckToolTip = gcnew ToolTip;
        testingAutoLoadCFDataCheckToolTip->ShowAlways = GUI_YES;
        testingAutoLoadCFDataCheckToolTip->AutoPopDelay = 10000;     // let stand for ten seconds
        testingAutoLoadCFDataCheckToolTip->ToolTipTitle =
            _T("Auto Load Coefficient Data");
        String ^testingAutoLoadCFDataCheckToolTipText = String::Concat(
            "When checked, the software will automatically", Environment::NewLine,
            "load the appropriate coefficient data for the", Environment::NewLine,
            "sensor whose address is added to the", Environment::NewLine,
            "placeholder list");
        testingAutoLoadCFDataCheckToolTip->SetToolTip(testingAutoLoadCFDataCheck, testingAutoLoadCFDataCheckToolTipText);
        delete testingAutoLoadCFDataCheckToolTipText;
        //--------------------------------------------------------------------
        // Display Dialogue check box
        //--------------------------------------------------------------------
        CheckBox ^testingDisplayDialogueCheck = gcnew CheckBox;
        testingDisplayDialogueCheck->Text = _T("Display in main dialogue");
        testingDisplayDialogueCheck->Location = Point(
            testingScriptCommandLabel->Left,
            testingAutoLoadCFDataCheck->Top);
        testingDisplayDialogueCheck->Size = Drawing::Size(
            146, GUI_REGULAR_CHECK_BOX_HEIGHT);
        GUI_SetObjectInterfaceProperties(testingDisplayDialogueCheck);
        testingDisplayDialogueCheck->Click +=
            gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_TestingDisplayDialogueChecked);
        testingControlsWindow->Controls->Add(testingDisplayDialogueCheck);
        testingDisplayDialogueCheck->Checked = DTSTest_TestingDisplayInCommandDialogue;
        //--------------------------------------------------------------------
        // Display Dialogue check box tool tip
        //--------------------------------------------------------------------
        ToolTip ^testingDisplayDialogueCheckToolTip = gcnew ToolTip;
        testingDisplayDialogueCheckToolTip->ShowAlways = GUI_YES;
        testingDisplayDialogueCheckToolTip->AutoPopDelay = 10000;     // let stand for ten seconds
        testingDisplayDialogueCheckToolTip->ToolTipTitle =
            _T("Display in Main Dialogue");
        String ^testingDisplayDialogueCheckToolTipText = String::Concat(
            "When checked, the software will display", Environment::NewLine,
            "the commands and responses in the large", Environment::NewLine,
            "dialogue box on the main (front) window");
        testingDisplayDialogueCheckToolTip->SetToolTip(testingDisplayDialogueCheck, testingDisplayDialogueCheckToolTipText);
        delete testingDisplayDialogueCheckToolTipText;
        //--------------------------------------------------------------------
        // Demo Mode check box
        //--------------------------------------------------------------------
        testingDemoModeCheck = gcnew CheckBox;
        testingDemoModeCheck->Text = _T("Demo mode only");
        testingDemoModeCheck->Location = Point(
            testingDisplayDialogueCheck->Right + 15,
            testingDisplayDialogueCheck->Top);
        testingDemoModeCheck->Size = Drawing::Size(
            110, GUI_REGULAR_CHECK_BOX_HEIGHT);
        GUI_SetObjectInterfaceProperties(testingDemoModeCheck);
        testingDemoModeCheck->Click +=
            gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_HomeDemoModeChecked);
        if (DTSTest_DemoModeEnabled)
            testingDemoModeCheck->Checked = GUI_YES;
        testingControlsWindow->Controls->Add(testingDemoModeCheck);
        //--------------------------------------------------------------------
        // Demo Mode check box tool tip
        //--------------------------------------------------------------------
        ToolTip ^testingDemoModeCheckToolTip = gcnew ToolTip;
        testingDemoModeCheckToolTip->ShowAlways = GUI_YES;
        testingDemoModeCheckToolTip->AutoPopDelay = 10000;     // let stand for ten seconds
        testingDemoModeCheckToolTip->ToolTipTitle =
            _T("Demo Mode");
        String ^testingDemoModeCheckToolTipText = String::Concat(
            "When checked, the software will run in", Environment::NewLine,
            "Demo Mode, meaning that none of the", Environment::NewLine,
            "commands will actually be sent to the", Environment::NewLine,
            "PDGIC");
        testingDemoModeCheckToolTip->SetToolTip(testingDemoModeCheck, testingDemoModeCheckToolTipText);
        delete testingDemoModeCheckToolTipText;
        //--------------------------------------------------------------------
        // Hide button
        //--------------------------------------------------------------------
        Button ^testingHideButton = gcnew Button;
        testingHideButton->Font = gcnew Drawing::Font(
            FontFamily::GenericSansSerif,
            10.0F,
            FontStyle::Bold);
        testingHideButton->Text = _T("Hide");
        testingHideButton->Location = Point(
            testingControlsWindow->Right - 100,
            testingControlsWindow->Bottom - 70);
        testingHideButton->Size = Drawing::Size(
            GUI_CLOSE_BUTTON_WIDTH,
            GUI_REGULAR_BUTTON_HEIGHT);
        GUI_SetButtonInterfaceProperties(testingHideButton);
        testingHideButton->DialogResult = System::Windows::Forms::DialogResult::OK;
        testingHideButton->Click +=
            gcnew EventHandler(this, &DTSTest_GUIClass::DTSTest_TestingControlsHideWindow);
        testingControlsWindow->Controls->Add(testingHideButton);
        //--------------------------------------------------------------------
        // Hide button tool tip
        //--------------------------------------------------------------------
        ToolTip ^testingHideButtonToolTip = gcnew ToolTip;
        testingHideButtonToolTip->ShowAlways = GUI_YES;
        testingHideButtonToolTip->AutoPopDelay = 10000;   // let stand for ten seconds
        testingHideButtonToolTip->ToolTipTitle =
            _T("Hide");
        String ^testingHideButtonToolTipText = String::Concat(
            "Hides (not minimizes) the Testing window,", Environment::NewLine,
            "which preserves the settings and allows the", Environment::NewLine,
            "tests to continue running");
        testingHideButtonToolTip->SetToolTip(testingHideButton, testingHideButtonToolTipText);
        delete testingHideButtonToolTipText;
        //------------------------------------------------------------------------
        // Handle the closing of the window by any other way
        //------------------------------------------------------------------------
        testingControlsWindow->FormClosing +=
            gcnew FormClosingEventHandler(this, &DTSTest_GUIClass::DTSTest_TestingControlsClosingWindow);
        //--------------------------------------------------------------------
        // Set the remaining window properties
        //--------------------------------------------------------------------
        testingControlsWindow->AcceptButton = testingHideButton;
        testingControlsWindow->CancelButton = testingHideButton;
        //--------------------------------------------------------------------
        // Finally, hide the new window
        //--------------------------------------------------------------------
        testingControlsWindow->ResumeLayout();
        testingControlsWindow->Hide();
    }                                   // end of if (DTSTest_GeneralInfo)
    RecordBasicEvent("{0} concluded", functionName);
}                                       // end of DTSTest_TestingControlsSetUpWindow()
//----------------------------------------------------------------------------
// DTSTest_TestingDisplayDialogueChecked
//
// Handles the check of the Display Dialogue box
//
// Called by:   DTSTest_TestingControlsSetUpWindow
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_TestingDisplayDialogueChecked(
    Object          ^sender,
    EventArgs       ^evt)
{
    String          ^functionName = _T("DTSTest_TestingDisplayDialogueChecked");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0} called", functionName);
    DTSTest_TestingDisplayInCommandDialogue = DTSTest_TestingDisplayInCommandDialogue ? GUI_NO : GUI_YES;
    RecordBasicEvent("{0} concluded", functionName);
}                                       // end of DTSTest_TestingDisplayDialogueChecked()
//----------------------------------------------------------------------------
// DTSTest_TestingEntryScriptCommandClicked
//
// Handles the click of the testing entry Script Command box
//
// Called by:   DTSTest_TestingControlsSetUpWindow
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_TestingEntryScriptCommandClicked(
    Object          ^sender,
    EventArgs       ^evt)
{
    int             index = (int) (dynamic_cast <TextBox ^> (sender))->Tag;
    int             testEntryNumber = index - 1;
    String          ^functionName = _T("DTSTest_TestingEntryScriptCommandClicked");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0} called", functionName);
    if (index)
    {
        TestEntry ^testEntry = DTSTest_TestEntryArray[testEntryNumber];
        if (StringICompare(testEntry->entryScriptCommandBox->Text, DTSTEST_TESTING_EMPTY_COMMAND_BOX) == 0)
            testEntry->entryScriptCommandBox->Clear();
        testEntry->entryScriptCommandBox->ForeColor = Color::Black;
    }                                   // end of if (index)
    RecordBasicEvent("{0} concluded", functionName);
}                                       // end of DTSTest_TestingEntryScriptCommandClicked()
//----------------------------------------------------------------------------
// DTSTest_TestingEntryLoadEraseButtonClicked
//
// Handles the click of the testing entry Load / Erase button
//
// Called by:   DTSTest_TestingControlsSetUpWindow
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_TestingEntryLoadEraseButtonClicked(
    Object          ^sender,
    EventArgs       ^evt)
{
    bool            fileLocated = GUI_NO;
    bool            promptResult = GUI_ACCEPT;
    int             index = (int) (dynamic_cast <Button ^> (sender))->Tag;
    int             testEntryNumber = index - 1;
    String          ^functionName = _T("DTSTest_TestingEntryLoadEraseButtonClicked");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0} called", functionName);
    if (index)
    {
        TestEntry ^testEntry = DTSTest_TestEntryArray[testEntryNumber];
        PDGICInfo ^pgInfo = DTSTest_GeneralInfo->pgInfo;
        if (pgInfo)
        {
            SensorInfo ^sensor = pgInfo->sensorInfoArray[testEntry->placeholder1Value];
            if (testEntry->coefficientDataLoaded)
            {
                //------------------------------------------------------------
                // Erase the coefficient data, and update the appropriate objects
                //------------------------------------------------------------
                BYTE *coefficientData = (LPBYTE) sensor->coefficientInfo->coefficientData;
                ClearBuffer(coefficientData, sizeof(CoefficientDataFormat));
                sensor->coefficientInfo->coefficientDataLoaded = GUI_NO;
                testEntry->coefficientDataLoaded = GUI_NO;
                testEntry->entryLoadEraseButton->Text = _T("Load");
                RecordBasicEvent("    Coefficient data for user sensor {0:X2} erased",
                    sensor->nodeAddress);
            }
            else
            {
                //------------------------------------------------------------
                // Load the coefficient data, and update the appropriate objects
                //------------------------------------------------------------
                bool fileLocated = GUI_NO;
                bool promptResult = GUI_ACCEPT;
                String ^filePathString = String::Empty;
                int nodeAddress = testEntry->placeholder1Value;
                if (StringSet(DTSTest_GeneralInfo->searchString))
                    filePathString = DTSTest_GeneralInfo->searchString;
                else
                    filePathString = Environment::GetFolderPath(Environment::SpecialFolder::Recent);
                do
                {
                    StringBuilder ^filePathBuilder = gcnew StringBuilder(
                        filePathString,
                        DTSTEST_MAXIMUM_FILE_PATH_LENGTH);
                    promptResult = DTSTest_PromptForReadFile(
                        _T("Select Coefficient Data File"),
                        filePathBuilder,
                        String::Empty,
                        GUI_FILE_TYPE_HEX);
                    filePathString = filePathBuilder->ToString();
                    delete filePathBuilder;
                    if (promptResult == GUI_ACCEPT)
                    {
                        DTSTest_GeneralInfo->searchString = filePathString;
                        if (File::Exists(filePathString))
                            fileLocated = GUI_YES;
                    }
                }
                while (!fileLocated && (promptResult == GUI_ACCEPT));
                if (fileLocated)
                {
                    char *filePath = (char *) malloc(DTSTEST_MAXIMUM_FILE_PATH_LENGTH);
                    if (filePath)
                    {
                        DTSTest_ConvertString(
                            filePathString,
                            filePath,
                            DTSTEST_MAXIMUM_FILE_PATH_LENGTH);
                        BYTE *coefficientData = (LPBYTE) sensor->coefficientInfo->coefficientData;
                        DWORD status = QD_ReadCoefficientDataFromHexFile(
                            (LPBYTE) filePath,
                            (LPBYTE) coefficientData);
                        if (status == QD_SUCCESS)
                        {
                            RecordBasicEvent("    Coefficient data for {0:X2} loaded from {1}",
                                pgInfo->nodeAddress,
                                filePathString);
                            sensor->coefficientInfo->hexFilePath = filePathString;
                            sensor->coefficientInfo->coefficientDataLoaded = GUI_YES;
                            testEntry->coefficientDataLoaded = GUI_YES;
                            if (StringICompare(sensor->coefficientInfo->hexFilePath, GUI_DEFAULT_COEFFICIENT_HEX_FILE) == 0)
                                testEntry->entryLoadEraseButton->Text = _T("Default");
                            else
                                testEntry->entryLoadEraseButton->Text = Path::GetFileNameWithoutExtension(
                                    sensor->coefficientInfo->hexFilePath);
                            status = DTSTest_SensorCalibrateReadings(sensor);
                        }
                        else
                        {
                            DTSTest_RecordAndModalErrorEvent(
                                "QD_ReadCoefficientDataFromHexFile returned status 0x{0:X8} while analyzing file\n{1}",
                                status, filePathString);
                        }
                        free((void *) filePath);
                    }                   // end of if (filePath)
                }                       // end of if (fileLocated)
            }
        }                               // end of if (pgInfo)
    }                                   // end of if (index)
    RecordBasicEvent("{0} concluded", functionName);
}                                       // end of DTSTest_TestingEntryLoadEraseButtonClicked()
//----------------------------------------------------------------------------
// DTSTest_TestingEntryProcessControlScriptFile
//
// Processes the control script file for the specified test entry
//
// Called by:   DTSTest_TestingProcessTestEntry
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_TestingEntryProcessControlScriptFile(
    BackgroundWorker
                    ^workerThread,
    int             testEntryNumber)
{
    String          ^functionName = _T("DTSTest_TestingEntryProcessControlScriptFile");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0} called", functionName);
    TestEntry ^testEntry = DTSTest_TestEntryArray[testEntryNumber];
    if (StringSet(testEntry->entryControlScriptPath))
    {
        String ^scriptFilePathString = testEntry->entryControlScriptPath;
        if (File::Exists(scriptFilePathString))
        {
            StreamReader ^textReader = File::OpenText(scriptFilePathString);
            if (textReader)
            {
                String ^controlScriptString = textReader->ReadToEnd();
                textReader->Close();
                bool originalCalculateCRCsState = DTSTest_CalculateCRCs;
                DTSTest_ControlScriptRunning = GUI_YES;
                DTSTest_TestingRunControlScript(
                    workerThread,
                    testEntryNumber,
                    controlScriptString);
                DTSTest_ControlScriptRunning = GUI_NO;
                DTSTest_SetCalculateCRCs(originalCalculateCRCsState);
                if (testEntry->entryTestResults != DTSTEST_TEST_RESULT_PASSED)
                    testEntry->entryTestResults = DTSTEST_TEST_RESULT_FAILED;
            }                           // end of if (textReader)
        }                               // end of if (File::Exists(scriptFilePathString))
    }                                   // end of if (StringSet(testEntry->entryControlScriptPath))
    RecordBasicEvent("{0} concluded", functionName);
}                                       // end of DTSTest_TestingEntryProcessControlScriptFile()
//----------------------------------------------------------------------------
// DTSTest_TestingEntryScriptPathButtonClicked
//
// Handles the click of the testing entry Script Path button
//
// Called by:   DTSTest_TestingControlsSetUpWindow
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_TestingEntryScriptPathButtonClicked(
    Object          ^sender,
    EventArgs       ^evt)
{
    bool            fileLocated = GUI_NO;
    bool            promptResult = GUI_ACCEPT;
    int             index = (int) (dynamic_cast <Button ^> (sender))->Tag;
    int             testEntryNumber = index - 1;
    String          ^functionName = _T("DTSTest_TestingEntryScriptPathButtonClicked");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0} called", functionName);
    if (index)
    {
        TestEntry ^testEntry = DTSTest_TestEntryArray[testEntryNumber];
        String ^scriptFilePathString = testEntry->entryControlScriptPath;
        if (!StringSet(scriptFilePathString))
        {
            String ^testingAnotherPath = String::Empty;
            for (int testEntryNumber = 0; testEntryNumber < DTSTEST_MAXIMUM_NUMBER_OF_TEST_ENTRIES; testEntryNumber++)
            {
                TestEntry ^otherTestEntry = DTSTest_TestEntryArray[testEntryNumber];
                if (StringSet(otherTestEntry->entryControlScriptPath))
                    testingAnotherPath = otherTestEntry->entryControlScriptPath;
            }
            if (StringSet(testingAnotherPath))
                scriptFilePathString = testingAnotherPath;
            else
                scriptFilePathString = Environment::GetFolderPath(Environment::SpecialFolder::Recent);
        }                               // end of if (!StringSet(scriptFilePathString))
        do
        {
            StringBuilder ^scriptFilePathBuilder = gcnew StringBuilder(
                scriptFilePathString,
                DTSTEST_MAXIMUM_FILE_PATH_LENGTH);
            promptResult = DTSTest_PromptForReadFile(
                _T("Select Script File"),
                scriptFilePathBuilder,
                scriptFilePathString,
                GUI_FILE_TYPE_UNKNOWN);
            scriptFilePathString = scriptFilePathBuilder->ToString();
            delete scriptFilePathBuilder;
            if (promptResult == GUI_ACCEPT)
            {
                fileLocated = GUI_YES;
                testEntry->entryControlScriptPath = scriptFilePathString;
                testEntry->entryControlScriptFile = Path::GetFileName(testEntry->entryControlScriptPath);
                testEntry->entryScriptCommandBox->ForeColor = Color::Black;
                testEntry->entryScriptCommandBox->Text = testEntry->entryControlScriptFile;
//if (StringSet(testEntry->entryControlScriptPath))
//Modal("NP X : {0}", testEntry->entryControlScriptPath);
            }
        }
        while (!fileLocated && (promptResult == GUI_ACCEPT));
        String ^controlScript = String::Empty;
        if (fileLocated)
        {
            if (StringSet(scriptFilePathString))
            {
                if (File::Exists(scriptFilePathString))
                {
                    StreamReader ^textReader = File::OpenText(scriptFilePathString);
                    if (textReader)
                    {
                        controlScript = textReader->ReadToEnd();
                        textReader->Close();
                    }                   // end of if (textReader)
                }                       // end of if (File::Exists(scriptFilePathString))
                else
                {
                    RecordErrorEvent("    {0} : {1} is not found",
                        functionName, scriptFilePathString);
                }
            }                           // end of if (StringSet(scriptFilePathString))
        }                               // end of if (fileLocated)
    }                                   // end of if (index)
    RecordBasicEvent("{0} concluded", functionName);
}                                       // end of DTSTest_TestingEntryScriptPathButtonClicked()
//----------------------------------------------------------------------------
// DTSTest_TestingEntrySelectedChecked
//
// Handles the check of the Selected Entry box
//
// Called by:   DTSTest_TestingControlsSetUpWindow
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_TestingEntrySelectedChecked(
    Object          ^sender,
    EventArgs       ^evt)
{
    int             index = (int) (dynamic_cast <CheckBox ^> (sender))->Tag;
    String          ^functionName = _T("DTSTest_TestingEntrySelectedChecked");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0} called", functionName);
    if (index)
    {
        TestEntry ^testEntry = DTSTest_TestEntryArray[index - 1];
        testEntry->entrySelectedForTesting = testEntry->entrySelectedForTesting ? GUI_NO : GUI_YES;
        //--------------------------------------------------------------------
        // If tests are still running, disable the changing of the
        // placeholders if this entry is selected to run
        //--------------------------------------------------------------------
        if (DTSTest_TestingRunning)
        {
            if (testEntry->entrySelectedForTesting)
            {
                testingBaudRateGroupBox->Enabled = GUI_NO;
                testEntry->placeholder1Box->Enabled = GUI_NO;
                testEntry->placeholder2Box->Enabled = GUI_NO;
                testEntry->placeholder3Box->Enabled = GUI_NO;
                testEntry->entryScriptCommandBox->Enabled = GUI_NO;
                testEntry->entryScriptPathButton->Enabled = GUI_NO;
                testEntry->entryLoadEraseButton->Enabled = GUI_NO;
            }
            else
            {
                //------------------------------------------------------------
                // If tests are still running, but no entries are selected to
                // run, stop running the tests
                //------------------------------------------------------------
                bool atLeastOneEntryIsSelected = GUI_NO;
                for (int testEntryNumber = 0; testEntryNumber < DTSTEST_MAXIMUM_NUMBER_OF_TEST_ENTRIES; testEntryNumber++)
                {
                    TestEntry ^otherTestEntry = DTSTest_TestEntryArray[testEntryNumber];
                    if (otherTestEntry->entrySelectedForTesting)
                        atLeastOneEntryIsSelected = GUI_YES;
                }
                if (!atLeastOneEntryIsSelected)
                    DTSTest_TestingStopActivities(GUI_NO);
            }
        }                               // end of if (DTSTest_TestingRunning)
        else
        {
            testingBaudRateGroupBox->Enabled = GUI_YES;
            testEntry->placeholder1Box->Enabled = GUI_YES;
            testEntry->placeholder2Box->Enabled = GUI_YES;
            testEntry->placeholder3Box->Enabled = GUI_YES;
            testEntry->entryScriptCommandBox->Enabled = GUI_YES;
            testEntry->entryScriptPathButton->Enabled = GUI_YES;
            testEntry->entryLoadEraseButton->Enabled = GUI_YES;
        }
    }                                   // end of if (index)
    RecordBasicEvent("{0} concluded", functionName);
}                                       // end of DTSTest_TestingEntrySelectedChecked()
//----------------------------------------------------------------------------
// DTSTest_TestingPauseResumeButtonClicked
//
// Handles the click of the testing Loop / Stop button
//
// Called by:   DTSTest_TestingControlsSetUpWindow
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_TestingPauseResumeButtonClicked(
    Object          ^sender,
    EventArgs       ^evt)
{
    String          ^functionName = _T("DTSTest_TestingPauseResumeButtonClicked");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0} called", functionName);
    if (DTSTest_TestingRunning)
    {
        testingRunStopButton->Text = _T("Stop");
        if (DTSTest_TestingPaused)
        {
            testingPauseResumeButton->Text = _T("Pause");
            testingLEDButton->BackgroundImage = yellowLEDOnImage;
        }
        else
        {
            testingPauseResumeButton->Text = _T("Resume");
        }
        testingControlsWindow->Update();
        DTSTest_TestingPaused = DTSTest_TestingPaused ? GUI_NO : GUI_YES;
    }                                   // end of if (DTSTest_TestingRunning)
    RecordBasicEvent("{0} concluded", functionName);
}                                       // end of DTSTest_TestingPauseResumeButtonClicked()
//----------------------------------------------------------------------------
// DTSTest_TestingProcessTestEntry
//
// Processes the tasks involved with the specified test entry
//
// Called by:   DTSTest_TestingRunTestEntries
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_TestingProcessTestEntry(
    BackgroundWorker
                    ^workerThread,
    int             testEntryNumber)
{
    String          ^functionName = _T("DTSTest_TestingProcessTestEntry");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0}({1:D}) called", functionName, testEntryNumber);
    if (testEntryNumber < DTSTEST_MAXIMUM_NUMBER_OF_TEST_ENTRIES)
    {
        DTSTest_CurrentEntryNumber = testEntryNumber;
        int index = testEntryNumber + 1;
        TestEntry ^testEntry = DTSTest_TestEntryArray[testEntryNumber];
        testEntry->allTestsCompleted = GUI_NO;
        testEntry->entryStatusLEDLabel->Image = blueDotOnImage;
//        DTSTest_CurrentTestPassed = GUI_YES;
        testingControlsWindow->Update();
        //--------------------------------------------------------------------
        // Clear the previous completion percentage, if any
        //--------------------------------------------------------------------
        workerThread->ReportProgress(testEntryNumber << 8);
        if (DTSTest_TestingRunning)
        {
            testEntry->entryTestResults = DTSTEST_TEST_RESULT_UNKNOWN;
            if (DTSTest_DemoModeEnabled)
            {
                //------------------------------------------------------------
                // Demo Mode
                //------------------------------------------------------------
                for (int progressPercent = 0; (progressPercent < 100) && DTSTest_TestingRunning; progressPercent++)
                {
                    Thread::Sleep(3);
                    DTSTest_TestingCheckForAsynchronousPause();
                    workerThread->ReportProgress(progressPercent | (testEntryNumber << 8));
                }
                if (index % 3)
                    testEntry->entryTestResults = DTSTEST_TEST_RESULT_FAILED;
                else
                    testEntry->entryTestResults = DTSTEST_TEST_RESULT_PASSED;
            }
            else
            {
                //------------------------------------------------------------
                // Perform the actual work of the testing
                //------------------------------------------------------------
                if (StringSet(testEntry->entryCommandReplacedString))
                {
                    Thread::Sleep(DTSTest_TestingDelay);
                    String ^commandDialogueString = String::Empty;
                    if (StringICompare(testEntry->entryCommandReplacedString, testEntry->entryCommandString) == 0)
                    {
                        commandDialogueString = String::Concat(
//                            Environment::NewLine,
                            testEntry->entryCommandReplacedString,
                            Environment::NewLine);
                    }
                    else
                    {
                        commandDialogueString = String::Concat(
//                            Environment::NewLine,
                            testEntry->entryCommandString,
                            _T(" => "),
                            testEntry->entryCommandReplacedString,
                            Environment::NewLine);
                    }
                    bool testingContext = GUI_YES;
                    DTSTest_CommandDialogueAppendLine(commandDialogueString);
                    testEntry->entryCommandReplacedString = DTSTest_ScriptParseLineForCommandString(
                        testEntry->entryCommandReplacedString,
                        DTSTest_TestingDelay,
                        testingContext);
                    String ^interpretationString = DTSTest_ReturnScriptCommandInterpretationString(
                        testEntry->entryCommandReplacedString,
                        testingContext);
//                    generalCSVEntry->loggedCSVDelayString = String::Concat(DTSTest_TestingDelay);
                    generalCSVEntry->loggedCSVCommandString = testEntry->entryCommandReplacedString;
                    if (StringSet(testEntry->entryCommandReplacedString))
                        DTSTest_FileCreateCSVEntry(generalCSVEntry, GUI_CSV_REGULAR_ENTRY);
                    if (StringSet(interpretationString))
                        interpretationString += Environment::NewLine;
                    if (StringSet(testEntry->entryCommandReplacedString))
                    {
                        bool originalDateAndTimeState = DTSTest_PrependDateAndTime;
                        DTSTest_PrependDateAndTime = GUI_NO;
                        DTSTest_CommandDialogueAppendLine(interpretationString);
                        DTSTest_PrependDateAndTime = originalDateAndTimeState;
                    }
                }
                else
                {
                    //--------------------------------------------------------
                    // Process the entry as a control script file
                    //--------------------------------------------------------
                    DTSTest_TestingEntryProcessControlScriptFile(
                        workerThread,
                        testEntryNumber);
                }                       // end of else of if (StringSet(testEntry->entryCommandReplacedString))
            }                           // end of else of if (DTSTest_DemoModeEnabled)
            //----------------------------------------------------------------
            // Report the actual result and progress completion percentage
            //----------------------------------------------------------------
            if (testEntry->entryTestResults == DTSTEST_TEST_RESULT_PASSED)
                testEntry->allTestsPassed = GUI_YES;
            else
                testEntry->allTestsPassed = GUI_NO;
        }                               // end of if (DTSTest_TestingRunning)
        if (DTSTest_TestingRunning)
        {
            workerThread->ReportProgress(100 | (testEntryNumber << 8));
            if (testEntry->allTestsPassed)
                testEntry->entryStatusLEDLabel->Image = greenDotOnImage;
            else
                testEntry->entryStatusLEDLabel->Image = redDotOnImage;
        }
        else
            testEntry->entryStatusLEDLabel->Image = blueDotOffImage;
        testEntry->allTestsCompleted = GUI_YES;
        testingControlsWindow->Update();
    }
    RecordBasicEvent("{0} concluded", functionName);
}                                       // end of DTSTest_TestingProcessTestEntry()
//----------------------------------------------------------------------------
// DTSTest_TestingRunControlScript
//
// Processes all the lines of the control script specified by the context
//
// Called by:   DTSTest_TestingEntryProcessControlScriptFile
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_TestingRunControlScript(
    BackgroundWorker
                    ^workerThread,
    int             testEntryNumber,
    String          ^controlScriptString)
{
    String          ^border = GUI_TEXT_FILE_BORDER;
    String          ^halfBorder = GUI_TEXT_FILE_HALF_BORDER;
    String          ^functionName = _T("DTSTest_TestingRunControlScript");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0} called", functionName);
    if (DTSTest_ControlScriptRunning && StringSet(controlScriptString))
    {
        this->Cursor = Cursors::WaitCursor;
        TestEntry ^testEntry = DTSTest_TestEntryArray[testEntryNumber];
//        if (!DTSTest_ControlScriptLooping)
//            DTSTest_DetermineResultsLog();
        DTSTest_GeneralInfo->mainScript->scriptNumberOfPasses = 0;
        DTSTest_GeneralInfo->mainScript->scriptNumberOfFailures = 0;
        //--------------------------------------------------------------------
        // Remove all commas, in anticipation of populating the CSV file
        //--------------------------------------------------------------------
        if (controlScriptString->Contains(DTSTEST_STRING_COMMA))
            controlScriptString = controlScriptString->Replace(DTSTEST_STRING_COMMA, String::Empty);
        array <Char> ^lineDelimiters = gcnew array <Char> {DTSTEST_CHAR_CR, DTSTEST_CHAR_LF};
        array <String ^> ^scriptLines = controlScriptString->Split(
            lineDelimiters,
            StringSplitOptions::RemoveEmptyEntries);
//        PDGICInfo ^pgInfo = DTSTest_GeneralInfo->pgInfo;
//        bool originalPrependState = DTSTest_PrependDateAndTime;
//        DTSTest_PrependDateAndTime = GUI_NO;
//        String ^scriptHeader = String::Concat(
//            border, Environment::NewLine,
//            "# Results Log: ", DTSTest_GeneralInfo->resultsLogFilePath, Environment::NewLine,
//            "# DTSTest v", DTSTEST_PROGRAM_VERSION_STRING,
//            "-", DTSTest_BuildNumber, Environment::NewLine,
//            "# Operator: ", DTSTest_GeneralInfo->operatorName, Environment::NewLine,
//            "# Serial Number: ",
//            (StringSet(DTSTest_GeneralInfo->dieSerialNumber) ? DTSTest_GeneralInfo->dieSerialNumber : "None"),
//            Environment::NewLine,
//            "# Computer: ", Environment::MachineName, Environment::NewLine,
//            border, Environment::NewLine);
//        DTSTest_PrependDateAndTime = originalPrependState;
//        scriptHeader = String::Concat(
//            "Start of script ",
//            testEntry->entryControlScriptPath,
//            Environment::NewLine);
//        if (!DTSTest_PrependDateAndTime)
//        {
//            DateTime dateTime = DateTime::Now;
//            scriptHeader += String::Concat(
//                String::Format(
//                    " [ {0:D2}-{1:D2}-{2:D4} {3:D2}:{4:D2}:{5:D2} ]",
//                    dateTime.Month,
//                    dateTime.Day,
//                    dateTime.Year,
//                    dateTime.Hour,
//                    dateTime.Minute,
//                    dateTime.Second),
//                    Environment::NewLine);
//        }
//        generalCSVFileString = String::Empty;
//        if (DTSTest_GeneralInfo->flags & DTSTEST_GENERAL_CREATE_CSV_LOG_FILE)
//        {
//            DTSTest_FileInitializeCSVHeader(generalCSVFileString);
//        }
//        do
//        {
            DWORD controlScriptAmountCompleted = 0;
            for each (String ^scriptLineString in scriptLines)
            {
                controlScriptAmountCompleted += scriptLineString->Length;
                DTSTest_ScriptProcessLine(
                    scriptLineString,
                    GUI_YES);
                while (DTSTest_ControlScriptPaused)
                {
                    Thread::Sleep(100);
                }
                if (DTSTest_ControlScriptRunning)
                    Thread::Sleep(10);
                else
                    break;
                int progressPercent = ((controlScriptAmountCompleted * 100) / controlScriptString->Length);
                workerThread->ReportProgress(progressPercent | (testEntryNumber << 8));
            }
//            if (DTSTest_ControlScriptRunning)
//            {
                String ^scriptTrailer = String::Concat(
                    "End of script ",
                    testEntry->entryControlScriptPath,
                    Environment::NewLine);
                if (!DTSTest_PrependDateAndTime)
                {
                    DateTime dateTime = DateTime::Now;
                    scriptTrailer += String::Concat(
                        String::Format(
                            " [ {0:D2}-{1:D2}-{2:D4} {3:D2}:{4:D2}:{5:D2} ]",
                            dateTime.Month,
                            dateTime.Day,
                            dateTime.Year,
                            dateTime.Hour,
                            dateTime.Minute,
                            dateTime.Second),
                            Environment::NewLine);
                }
                DTSTest_CommandDialogueAppendLine(scriptTrailer);
                scriptTrailer = String::Concat(
                    "Tests passed = ",
                    DTSTest_GeneralInfo->mainScript->scriptNumberOfPasses, Environment::NewLine,
                    "Tests failed = ",
                    DTSTest_GeneralInfo->mainScript->scriptNumberOfFailures, Environment::NewLine,
//                    border, Environment::NewLine,
//                    "# End of results log ", DTSTest_GeneralInfo->resultsLogFilePath, Environment::NewLine,
                    border, Environment::NewLine);
                bool originalPrependState = DTSTest_PrependDateAndTime;
                DTSTest_PrependDateAndTime = GUI_NO;
                DTSTest_CommandDialogueAppendLine(scriptTrailer);
                DTSTest_PrependDateAndTime = originalPrependState;
                //------------------------------------------------------------
                // Save the results log to file
                //------------------------------------------------------------
//                DTSTest_AppendLineToDataLog(homeCommandDialogueBox->Text);
                if (DTSTest_GeneralInfo->flags & DTSTEST_GENERAL_CREATE_CSV_LOG_FILE)
                {
                    DTSTest_AppendLineToCSVLog(generalCSVFileString);
                }
//            }
//        }
//        while (DTSTest_ControlScriptLooping && DTSTest_ControlScriptRunning);
        delete [] scriptLines;
        delete [] lineDelimiters;
        this->Cursor = Cursors::Default;
    }                                   // end of if (DTSTest_ControlScriptRunning && StringSet(controlScript))
    RecordBasicEvent("{0} concluded", functionName);
}                                       // end of DTSTest_TestingRunControlScript()
//----------------------------------------------------------------------------
// DTSTest_TestingRunStopButtonClicked
//
// Handles the click of the testing Run / Stop button
//
// Called by:   DTSTest_TestingControlsSetUpWindow
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_TestingRunStopButtonClicked(
    Object          ^sender,
    EventArgs       ^evt)
{
    String          ^functionName = _T("DTSTest_TestingRunStopButtonClicked");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0} called", functionName);
    if (DTSTest_TestingRunning)
        DTSTest_TestingStopActivities(GUI_NO);
    else
        DTSTest_TestingStartRunActivities();
    RecordBasicEvent("{0} concluded", functionName);
}                                       // end of DTSTest_TestingRunStopButtonClicked()
//----------------------------------------------------------------------------
// DTSTest_TestingRunTestEntries
//
// Runs all the selected test entries forever, until flagged to stop
//
// Returns: 0       = Success
//          nonzero = Test Canceled or Failure
//
// Called by:   DTSTest_TestingBackgroundRunTestEntry
//----------------------------------------------------------------------------
    DWORD DTSTest_GUIClass::
DTSTest_TestingRunTestEntries(
    BackgroundWorker
                    ^workerThread)
{
    DWORD           status = DTSTEST_SUCCESS;
    String          ^functionName = _T("DTSTest_TestingRunTestEntries");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0} called", functionName);
    if (DTSTest_TestingLooping)
    {
        testingLoopsCompletedLabel->Text = String::Concat(
            _T("Loops completed: "),
            DTSTest_TestingLoopsCompleted);
    }
    bool testsAreRunning = DTSTest_TestingRunning;
    while (testsAreRunning)
    {
        //--------------------------------------------------------------------
        // Clear the results
        //--------------------------------------------------------------------
        for (int testEntryNumber = 0; testEntryNumber < DTSTEST_MAXIMUM_NUMBER_OF_TEST_ENTRIES; testEntryNumber++)
            testingEntryBackground->ReportProgress(testEntryNumber << 8);
        //--------------------------------------------------------------------
        // Begin running through one round of testing selected entries
        //--------------------------------------------------------------------
        for (int testEntryNumber = 0; (testEntryNumber < DTSTEST_MAXIMUM_NUMBER_OF_TEST_ENTRIES) && DTSTest_TestingRunning; testEntryNumber++)
        {
            int index = testEntryNumber + 1;
            TestEntry ^testEntry = DTSTest_TestEntryArray[testEntryNumber];
            if (testEntry->entrySelectedForTesting)
            {
                DTSTest_TestingCheckForAsynchronousPause();
                if (DTSTest_TestingRunning)
                {
                    DTSTest_TestingProcessTestEntry(
                        workerThread,
                        testEntryNumber);
                }
                if (!DTSTest_TestingRunning)
                {
                    status = DTSTEST_ERROR_TEST_CANCELED;                       // 0x000000F8
                    testsAreRunning = GUI_NO;
                }
            }                           // end of if (testEntry->entrySelectedForTesting)
        }                               // end of for (int testEntryNumber = 0; ...)
        if (DTSTest_TestingLooping)
        {
            if (testsAreRunning)
                testingLoopsCompletedLabel->Text = String::Concat(
                    _T("Loops completed: "),
                    ++DTSTest_TestingLoopsCompleted);
        }
        else
            testsAreRunning = GUI_NO;
    }                                   // end of while (testsAreRunning)
    RecordBasicEvent("{0} concluded, returning 0x{1:X8}", functionName, status);
    return status;
}                                       // end of DTSTest_TestingRunTestEntries()
//----------------------------------------------------------------------------
// DTSTest_TestingSetResetLoopChecked
//
// Handles the check of the Loop box
//
// Called by:   DTSTest_TestingControlsSetUpWindow
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_TestingSetResetLoopChecked(
    Object          ^sender,
    EventArgs       ^evt)
{
    String          ^functionName = _T("DTSTest_TestingSetResetLoopChecked");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0} called", functionName);
    DTSTest_TestingLooping = DTSTest_TestingLooping ? GUI_NO : GUI_YES;
    if (DTSTest_TestingLooping)
        testingLoopsCompletedLabel->Visible = GUI_YES;
    else
        testingLoopsCompletedLabel->Visible = GUI_NO;
    RecordBasicEvent("{0} concluded", functionName);
}                                       // end of DTSTest_TestingSetResetLoopChecked()
//----------------------------------------------------------------------------
// DTSTest_TestingStartLogging
//
// Starts logging both the regular results log and the CSV log
//
// Called by:   DTSTest_TestingStartRunActivities
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_TestingStartLogging(void)
{
    String          ^border = GUI_TEXT_FILE_BORDER;
    String          ^functionName = _T("DTSTest_TestingStartLogging");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0} called", functionName);
    DTSTest_DetermineResultsLog();
        generalLogFileString = String::Empty;
        DateTime dateTime = DateTime::Now;
        String ^testingDateString = String::Format(
            "{0:D2}-{1:D2}-{2:D4} {3:D2}:{4:D2}:{5:D2}",
            dateTime.Month,
            dateTime.Day,
            dateTime.Year,
            dateTime.Hour,
            dateTime.Minute,
            dateTime.Second);
        String ^logHeader = String::Concat(
            border, Environment::NewLine,
            "# Results Log: ", DTSTest_GeneralInfo->mainScript->resultsLogFilePath, Environment::NewLine,
            "# DTSTest v", DTSTEST_PROGRAM_VERSION_STRING,
            "-", DTSTest_BuildNumber, Environment::NewLine,
            "# Operator: ", DTSTest_GeneralInfo->operatorName, Environment::NewLine,
            "# Serial Number: ",
            (StringSet(DTSTest_GeneralInfo->dieSerialNumber) ? DTSTest_GeneralInfo->dieSerialNumber : "None"),
            Environment::NewLine,
            "# Computer: ", Environment::MachineName, Environment::NewLine,
            "# Started: ", testingDateString, Environment::NewLine,
            border, Environment::NewLine);
        bool originalPrependState = DTSTest_PrependDateAndTime;
        DTSTest_PrependDateAndTime = GUI_NO;
        DTSTest_CommandDialogueAppendLine(logHeader);
        DTSTest_PrependDateAndTime = originalPrependState;
        homeClearCommandDialogueButton->Enabled = GUI_YES;
        testingClearCommandDialogueButton->Enabled = GUI_YES;
//        scriptHeader = String::Concat(
//            "Start of script ",
//            testEntry->entryControlScriptPath,
//            Environment::NewLine);
//        if (!DTSTest_PrependDateAndTime)
//        {
//        }
//                //------------------------------------------------------------
//                // Save the log file header
//                //------------------------------------------------------------
//                DTSTest_AppendLineToDataLog(logHeader);
        if (DTSTest_GeneralInfo->flags & DTSTEST_GENERAL_CREATE_CSV_LOG_FILE)
        {
            DTSTest_FileInitializeCSVHeader(generalCSVEntry);
        }
    RecordBasicEvent("{0} concluded", functionName);
}                                       // end of DTSTest_TestingStartLogging()
//----------------------------------------------------------------------------
// DTSTest_TestingStartRunActivities
//
// Starts all the testing activities necessary to start a round of testing
//
// Called by:   DTSTest_TestingRunStopButtonClicked
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_TestingStartRunActivities(void)
{
    bool            ateastOneEntryIsSelected = GUI_NO;
    String          ^functionName = _T("DTSTest_TestingStartRunActivities");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0} called", functionName);
    for (int testEntryNumber = 0; testEntryNumber < DTSTEST_MAXIMUM_NUMBER_OF_TEST_ENTRIES; testEntryNumber++)
    {
        TestEntry ^testEntry = DTSTest_TestEntryArray[testEntryNumber];
        if (testEntry->entrySelectedForTesting)
        {
            ateastOneEntryIsSelected = GUI_YES;
            testingBaudRateGroupBox->Enabled = GUI_NO;
            testEntry->placeholder1Box->Enabled = GUI_NO;
            testEntry->placeholder2Box->Enabled = GUI_NO;
            testEntry->placeholder3Box->Enabled = GUI_NO;
            testEntry->entryScriptCommandBox->Enabled = GUI_NO;
            testEntry->entryScriptPathButton->Enabled = GUI_NO;
            testEntry->entryLoadEraseButton->Enabled = GUI_NO;
        }
    }
    if (ateastOneEntryIsSelected)
    {
        DTSTest_TestingRunning = GUI_YES;
        DTSTest_TestingLoopsCompleted = 0;
        testingLEDButton->BackgroundImage = yellowLEDOnImage;
        testingRunStopButton->Text = _T("Stop");
        testingPauseResumeButton->Text = _T("Pause");
        testingPauseResumeButton->Enabled = GUI_YES;
        testingControlsWindow->Update();
        homeLoadControlScriptButton->Enabled = GUI_NO;
        homeSingleCommandBox->Enabled = GUI_NO;
        homeSwitchBaudRateButton->Enabled = GUI_NO;
        homeSingleCommandBox->BackColor = Color::LightGray;
        homeSingleCommandBox->Enabled = GUI_NO;
        DTSTest_TestingStartLogging();
        DTSTest_PDGICOpenPersistentPort(DTSTest_GeneralInfo->pgInfo);
        //--------------------------------------------------------------------
        // Start the background process that runs the tests forever
        //--------------------------------------------------------------------
        testingEntryBackground->RunWorkerAsync();
    }                                   // end of if (ateastOneEntryIsSelected)
    else
    {
        GUI_DisplayMandatoryError(
            _T("No Test Entries Selected"),
            "Select at least one test entry to include\n"
            "in the testing, then click Run");
    }
    RecordBasicEvent("{0} concluded", functionName);
}                                       // end of DTSTest_TestingStartRunActivities()
//----------------------------------------------------------------------------
// DTSTest_TestingStopActivities
//
// Stops all the testing activities necessary to start a round of testing
//
// Called by:   DTSTest_TestingRunStopButtonClicked
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_TestingStopActivities(
    bool            runCanceled)
{
    String          ^functionName = _T("DTSTest_TestingStopActivities");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0} called", functionName);
    if (runCanceled)
        testingEntryBackground->CancelAsync();
    for (int testEntryNumber = 0; testEntryNumber < DTSTEST_MAXIMUM_NUMBER_OF_TEST_ENTRIES; testEntryNumber++)
    {
        TestEntry ^testEntry = DTSTest_TestEntryArray[testEntryNumber];
        if (testEntry->entrySelectedForTesting)
        {
            testingBaudRateGroupBox->Enabled = GUI_YES;
            testEntry->placeholder1Box->Enabled = GUI_YES;
            testEntry->placeholder2Box->Enabled = GUI_YES;
            testEntry->placeholder3Box->Enabled = GUI_YES;
            testEntry->entryScriptCommandBox->Enabled = GUI_YES;
            testEntry->entryScriptPathButton->Enabled = GUI_YES;
            testEntry->entryLoadEraseButton->Enabled = GUI_YES;
            if (!testEntry->allTestsCompleted)
                testEntry->entryStatusLEDLabel->Image = blueDotOffImage;
        }
    }
    DTSTest_PDGICClosePersistentPort(DTSTest_GeneralInfo->pgInfo);
    DTSTest_TestingStopLogging();
    testingRunStopButton->Text = _T("Run");
    testingPauseResumeButton->Text = _T("Pause");
    testingPauseResumeButton->Enabled = GUI_NO;
    DTSTest_TestingPaused = GUI_NO;
    testingLEDButton->BackgroundImage = yellowLEDOffImage;
    testingControlsWindow->Update();
    homeLoadControlScriptButton->Enabled = GUI_YES;
    homeSingleCommandBox->Enabled = GUI_YES;
    homeSwitchBaudRateButton->Enabled = GUI_YES;
    homeSingleCommandBox->BackColor = Color::Lavender;
    homeSingleCommandBox->Enabled = GUI_YES;
    DTSTest_TestingRunning = GUI_NO;
    RecordBasicEvent("{0} concluded", functionName);
}                                       // end of DTSTest_TestingStopActivities()
//----------------------------------------------------------------------------
// DTSTest_TestingStopLogging
//
// Terminates logging both the regular results log and the CSV log
//
// Called by:   DTSTest_TestingStopActivities
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_TestingStopLogging(void)
{
    String          ^border = GUI_TEXT_FILE_BORDER;
//    String          ^halfBorder = GUI_TEXT_FILE_HALF_BORDER;
    String          ^functionName = _T("DTSTest_TestingStopLogging");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0} called", functionName);
//                if (!DTSTest_PrependDateAndTime)
//                {
//                    DateTime dateTime = DateTime::Now;
//                    scriptTrailer += String::Concat(
//                        String::Format(
//                            " [ {0:D2}-{1:D2}-{2:D4} {3:D2}:{4:D2}:{5:D2} ]",
//                            dateTime.Month,
//                            dateTime.Day,
//                            dateTime.Year,
//                            dateTime.Hour,
//                            dateTime.Minute,
//                            dateTime.Second),
//                            Environment::NewLine);
//                }
                String ^logTrailer = String::Concat(
                    border, Environment::NewLine,
                    "# End of results log ", DTSTest_GeneralInfo->mainScript->resultsLogFilePath, Environment::NewLine,
                    border, Environment::NewLine);
                bool originalPrependState = DTSTest_PrependDateAndTime;
                DTSTest_PrependDateAndTime = GUI_NO;
                //------------------------------------------------------------
                // Save the results log to file
                //------------------------------------------------------------
                DTSTest_CommandDialogueAppendLine(logTrailer);
                DTSTest_PrependDateAndTime = originalPrependState;
                if (DTSTest_GeneralInfo->flags & DTSTEST_GENERAL_CREATE_CSV_LOG_FILE)
                {
                    DTSTest_AppendLineToCSVLog(generalCSVFileString);
                }
    RecordBasicEvent("{0} concluded", functionName);
}                                       // end of DTSTest_TestingStopLogging()
//----------------------------------------------------------------------------
// DTSTest_TestingSyncClicked
//
// Handles the click of the Sync On label
//
// Called by:   DTSTest_TestingControlsSetUpWindow
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_TestingSyncClicked(
    Object          ^sender,
    EventArgs       ^evt)
{
    String          ^functionName = _T("DTSTest_TestingSyncClicked");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0} called", functionName);
    DTSTest_ToggleSync();
    RecordBasicEvent("{0} concluded", functionName);
}                                       // end of DTSTest_TestingSyncClicked()
//----------------------------------------------------------------------------
// DTSTest_ValidateTestingDelayValue
//
// Handles changes of the testing delay field
//
// Called by:   DTSTest_TestingControlsSetUpWindow
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_ValidateTestingDelayValue(
    Object          ^sender,
    CancelEventArgs ^evt)
{
    bool            revertToOriginalValue = GUI_YES;
    String          ^valueString = (String ^) (dynamic_cast <TextBox ^> (sender))->Text;
    String          ^originalString = valueString;
    DWORD           status = DTSTEST_SUCCESS;
    String          ^functionName = _T("DTSTest_ValidateTestingDelayValue");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0} called", functionName);
    if (StringSet(valueString))
    {
        int newValue = 0;
        bool isCorrectFormat = DTSTest_ParseAndConvertStringToInteger(
            valueString,
            &newValue);
        if (isCorrectFormat)
            DTSTest_TestingDelay = newValue;
        evt->Cancel = GUI_NO;
        RecordBasicEvent("{0} concluded: Accept {1:D}",
            functionName, newValue);
        revertToOriginalValue = GUI_NO;
        return;
    }                                   // end of if (StringSet(valueString))
    else
    {
        //--------------------------------------------------------------------
        // The tester cleared the text box, so set the delay to zero
        //--------------------------------------------------------------------
        testingDelayBox->Text = _T("0");
    }
    if (revertToOriginalValue)
    {
        if (testingDelayBox)
            testingDelayBox->Text = originalString;
    }
    evt->Cancel = GUI_YES;
    RecordBasicEvent("{0} concluded: Cancel", functionName);
}                                       // end of DTSTest_ValidateTestingDelayValue()
//----------------------------------------------------------------------------
// DTSTest_ValidateTestingEntryPlaceholderValue
//
// Handles changes of the testing placeholder value field
//
// Called by:   DTSTest_TestingControlsSetUpWindow
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_ValidateTestingEntryPlaceholderValue(
    Object          ^sender,
    CancelEventArgs ^evt)
{
    bool            revertToOriginalValue = GUI_YES;
    BYTE            newValue;
    PDGICInfo       ^pgInfo = DTSTest_GeneralInfo->pgInfo;
    int             tag = (int) (dynamic_cast <TextBox ^> (sender))->Tag;
    BYTE            placeholderIndex = (BYTE) ((tag >> 8) & 0x0F);
    int             offset = ((tag & 0xFF) > 0) ? ((tag & 0xFF) - 1) : 0;
    BYTE            originalValue = 0;
    BYTE            placeholderValue = 0;
    TestEntry       ^testEntry = DTSTest_TestEntryArray[offset];
    TextBox         ^placeholderBox = nullptr;
    String          ^valueString = (String ^) (dynamic_cast <TextBox ^> (sender))->Text;
    DWORD           status = DTSTEST_SUCCESS;
    String          ^functionName = _T("DTSTest_ValidateTestingEntryPlaceholderValue");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0}(entry {1:D}, ${2:D}) called", functionName, (offset + 1), (placeholderIndex + 1));
    switch (placeholderIndex)
    {
        case 1 :
            placeholderBox = testEntry->placeholder1Box;
            placeholderValue = testEntry->placeholder1Value;
            break;
        case 2 :
            placeholderBox = testEntry->placeholder2Box;
            placeholderValue = testEntry->placeholder2Value;
            break;
        case 3 :
            placeholderBox = testEntry->placeholder3Box;
            placeholderValue = testEntry->placeholder3Value;
            break;
        default :
            break;
    }
    originalValue = placeholderValue;
    if (!StringSet(valueString) || (StringICompare(valueString, DTSTEST_STRING_0) == 0))
    {
        valueString = _T("00");
        if (placeholderBox)
            placeholderBox->Text = valueString;
        testEntry->coefficientDataLoaded = GUI_NO;
        testEntry->entryLoadEraseButton->Text = _T("Load");
    }
    if (StringSet(valueString) && (valueString->Length < 3))
    {
        bool isCorrectFormat = DTSTest_ParseAndConvertHexStringToByte(
            valueString,
            &newValue);
        if (isCorrectFormat)
        {
            valueString = String::Format("{0:X2}", newValue);
            if (newValue < 255)
            {
                if (newValue != placeholderValue)
                {
                    RecordBasicEvent(
                        "    The script placeholder ${0:D} MODBUS address changed from {1:X2} to {2:X2}",
                        placeholderIndex,
                        placeholderValue,
                        newValue);
                    placeholderValue = newValue;
                    switch (placeholderIndex)
                    {
                        case 1 :
                            DTSTest_TestEntryArray[offset]->placeholder1Value = newValue;
                            break;
                        case 2 :
                            DTSTest_TestEntryArray[offset]->placeholder2Value = newValue;
                            break;
                        case 3 :
                            DTSTest_TestEntryArray[offset]->placeholder3Value = newValue;
                            break;
                        default :
                            break;
                    }
                    placeholderBox->Text = String::Format(
                        "{0:X2}", placeholderValue);
                    if (placeholderValue)
                    {
                        testEntry->entryStatusLEDLabel->Image = blueDotOffImage;
                        SensorInfo ^sensor = pgInfo->sensorInfoArray[newValue];
                        if (placeholderIndex == 1)
                        {
                            //------------------------------------------------
                            // Only display the device type for $1
                            //------------------------------------------------
                            status = DTSTest_SensorRetrieveType(sensor);
                            if (status == DTSTEST_SUCCESS)
                            {
                                if (sensor->sensorType == DTSTEST_SENSOR_TYPE_GAUGE)
                                    status = DTSTest_SensorRetrieveGaugeInformation(sensor);
                                else
                                    status = DTSTest_SensorRetrieveBargeInformation(sensor);
                            }
                            if (sensor->sensorType == DTSTEST_SENSOR_TYPE_UNKNOWN)
                                testEntry->primaryDeviceTypeLabel->Text = _T("?");
                            else
                                testEntry->primaryDeviceTypeLabel->Text = sensor->hardwareIDString;
                        }
                        if (status == DTSTEST_SUCCESS)
                        {
                            if (DTSTest_TestingAutoLoadCoefficientData)
                            {
                                status = DTSTest_SensorCalibrateReadings(sensor);
                                if (status == DTSTEST_SUCCESS)
                                {
                                    testEntry->coefficientDataLoaded = GUI_YES;
                                    if (StringICompare(sensor->coefficientInfo->hexFilePath, GUI_DEFAULT_COEFFICIENT_HEX_FILE) == 0)
                                        testEntry->entryLoadEraseButton->Text = _T("Default");
                                    else
                                        testEntry->entryLoadEraseButton->Text = Path::GetFileNameWithoutExtension(
                                            sensor->coefficientInfo->hexFilePath);
                                }
                            }           // end of if (DTSTest_ScriptAutoLoadCoefficientData)
                        }               // end of if (status == DTSTEST_SUCCESS)
                    }                   // end of if (placeholder->placeholderValue)
                    else
                    {
                        testEntry->primaryDeviceTypeLabel->Text = String::Empty;
                    }
                }                       // end of if (newValue != placeholder->placeholderValue)
                evt->Cancel = GUI_NO;
                RecordBasicEvent("{0} concluded: Accept {1:X2} => {2:X2}",
                    functionName, originalValue, newValue);
                revertToOriginalValue = GUI_NO;
                return;
            }                           // end of if (newValue < 255)
            else
            {
                DTSTest_PromptOKModal(
                    "Invalid MODBUS Address",
                    "Valid values are 01 through FE, inclusive");
                RecordErrorEvent(
                    "    Attempted to set script placeholder ${0:D} MODBUS address to '{1:X2}'",
                    placeholderIndex, newValue);
            }
        }                               // end of if (isCorrectFormat)
        else
        {
            DTSTest_PromptOKModal(
                "Invalid Characters",
                "The entry contains invalid characters;\n"
                "enter only hex digits");
            RecordErrorEvent(
                "    Attempted to set script placeholder ${0:X2} MODBUS address to '{1}'",
                placeholderIndex, valueString);
        }
    }                                   // end of if (StringSet(valueString) && (valueString->Length < 3))
    if (revertToOriginalValue)
    {
        if (placeholderBox)
            placeholderBox->Text = String::Format(
                "{0:X2}", placeholderValue);
    }
    evt->Cancel = GUI_YES;
    RecordBasicEvent("{0} concluded: Cancel", functionName);
}                                       // end of DTSTest_ValidateTestingEntryPlaceholderValue()
//----------------------------------------------------------------------------
// DTSTest_ValidateTestingEntryScriptCommand
//
// Handles changes of the testing script / command field
//
// Called by:   DTSTest_TestingControlsSetUpWindow
//----------------------------------------------------------------------------
    void DTSTest_GUIClass::
DTSTest_ValidateTestingEntryScriptCommand(
    Object          ^sender,
    CancelEventArgs ^evt)
{
    bool            revertToOriginalValue = GUI_YES;
    PDGICInfo       ^pgInfo = DTSTest_GeneralInfo->pgInfo;
    int             index = (int) (dynamic_cast <TextBox ^> (sender))->Tag;
    int             offset = (index > 0) ? (index - 1) : 0;
    TestEntry       ^testEntry = DTSTest_TestEntryArray[offset];
    String          ^newString = (String ^) (dynamic_cast <TextBox ^> (sender))->Text;
    DWORD           status = DTSTEST_SUCCESS;
    String          ^functionName = _T("DTSTest_ValidateTestingEntryScriptCommand");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0} called", functionName);
    String ^originalString = DTSTEST_TESTING_EMPTY_COMMAND_BOX;
    if (StringSet(newString))
    {
        if (StringICompare(newString, testEntry->entryControlScriptFile) == 0)
            originalString = testEntry->entryControlScriptFile;
        else
            if (StringICompare(newString, testEntry->entryCommandString) == 0)
                originalString = testEntry->entryCommandString;
        if ((StringICompare(newString, DTSTEST_TESTING_EMPTY_COMMAND_BOX) == 0) ||
            !StringSet(newString))
            testEntry->entryScriptCommandBox->ForeColor = Color::Gray;
        else
            testEntry->entryScriptCommandBox->ForeColor = Color::Black;
        //--------------------------------------------------------------------
        // Test for data type: if the box contains a period, it is probably a
        // file name, but if it contains a $ or space, it is probably a
        // command, but those are by no means certain
        //--------------------------------------------------------------------
        if (newString->Contains(DTSTEST_STRING_PERIOD))
        {
            testEntry->entryControlScriptFile = newString;
            String ^controlScriptDirectory = String::Empty;
            if (StringSet(testEntry->entryControlScriptPath))
            {
                controlScriptDirectory = Path::GetDirectoryName(testEntry->entryControlScriptPath);
            }
            else
            {
                for (int testEntryOffset = 0; testEntryOffset < DTSTEST_MAXIMUM_NUMBER_OF_TEST_ENTRIES; testEntryOffset++)
                {
                    if (StringSet(DTSTest_TestEntryArray[testEntryOffset]->entryControlScriptPath))
                    {
                        controlScriptDirectory = Path::GetDirectoryName(DTSTest_TestEntryArray[testEntryOffset]->entryControlScriptPath);
                        break;
                    }
                }
            }
            if (!StringSet(controlScriptDirectory))
                controlScriptDirectory = DTSTest_GeneralInfo->searchString;
            if (!StringSet(controlScriptDirectory))
                controlScriptDirectory = DTSTest_GeneralInfo->logDirectory;
            testEntry->entryControlScriptPath = String::Concat(
                controlScriptDirectory,
                DTSTEST_STRING_BACKSLASH,
                testEntry->entryControlScriptFile);
            if (!File::Exists(testEntry->entryControlScriptPath))
                DTSTest_PromptOKModal(
                    "Script File Not Found",
                    "Unable to locate file\n\n{0}",
                    testEntry->entryControlScriptPath);
        }
        else
        {
            if (StringICompare(newString, DTSTEST_TESTING_EMPTY_COMMAND_BOX))
            {
                testEntry->entryCommandString = newString;
                if (newString->Contains(DTSTEST_STRING_DOLLAR) || newString->Contains(DTSTEST_STRING_SPACE))
                {
                    if (newString->Contains(DTSTEST_STRING_DOLLAR))
                    {
                        String ^replacedString = String::Empty;
                        replacedString = newString->Replace(
                            "$1", String::Format("{0:X2}", testEntry->placeholder1Value));
                        replacedString = replacedString->Replace(
                            "$2", String::Format("{0:X2}", testEntry->placeholder2Value));
                        replacedString = replacedString->Replace(
                            "$3", String::Format("{0:X2}", testEntry->placeholder3Value));
                        testEntry->entryCommandReplacedString = replacedString;
                    }
                    else
                        testEntry->entryCommandReplacedString = newString;
                }
                else
                    testEntry->entryCommandReplacedString = newString;
            }
        }
        evt->Cancel = GUI_NO;
        RecordBasicEvent("{0} concluded: Accept {1:X2} => {2:X2}",
            functionName, originalString, newString);
        revertToOriginalValue = GUI_NO;
        return;
    }                                   // end of if (StringSet(newString))
    else
    {
        //--------------------------------------------------------------------
        // The tester cleared the text box, which means to clear all the strings
        //--------------------------------------------------------------------
        testEntry->entryScriptCommandBox->ForeColor = Color::Gray;
        testEntry->entryCommandString = String::Empty;
        testEntry->entryCommandReplacedString = String::Empty;
        testEntry->entryControlScriptPath = String::Empty;
        testEntry->entryControlScriptFile = String::Empty;
    }
    if (revertToOriginalValue)
    {
        if (testEntry->entryScriptCommandBox)
            testEntry->entryScriptCommandBox->Text = originalString;
    }
    evt->Cancel = GUI_YES;
    RecordBasicEvent("{0} concluded: Cancel", functionName);
}                                       // end of DTSTest_ValidateTestingEntryScriptCommand()
//----------------------------------------------------------------------------
#endif      // TESTING_CPP
//============================================================================
// End of Testing.cpp
//============================================================================
