<?php
//============================================================================
// //qdlamp/var/www/trunk/public/DTSTest/DTSTest-Help.php
//
// General online help for DTSTest
//
// Copyright (C) 2014 - 2015 Quartzdyne, Inc.  All rights reserved.
//
// No part of this source code may be reproduced or transmitted in any form or
// by any means, electronic or mechanical, including photocopying, recording,
// or any information storage and retrieval system, without express written
// permission from Quartzdyne, Inc.  Further, no use of this source code is
// permitted in any form or means without a valid, written license agreement
// with Quartzdyne, Inc.  While every reasonable precaution has been taken in
// the preparation of this source code, Quartzdyne, Inc., assumes no
// responsibility for errors, omissions, or damages from the use of the source
// code contained herein.
//
// NEITHER QUARTZDYNE, INC., ANY MEMBER OF QUARTZDYNE, INC., NOR ANY PERSON OR
// ORGANIZATION ACTING ON BEHALF OF THEM MAKES ANY WARRANTY OR REPRESENTATION
// WHATSOEVER, EXPRESS OR IMPLIED, INCLUDING ANY WARRANTY OF MERCHANTABILITY
// OR FITNESS FOR ANY PURPOSE WITH RESPECT TO THE SOURCE CODE OR ASSUMES ANY
// LIABILITY WHATSOEVER WITH RESPECT TO ANY USE OF THE SOURCE CODE OR ANY
// PORTION THEREOF OR WITH RESPECT TO ANY DAMAGES THAT MAY RESULT FROM SUCH
// USE.
//
// Noji Ratzlaff
//
// See DTSTest.log for a complete history of all updates, changes, and revisions
// of this source and other files and policies regarding DTSTest software.  Also,
// a detailed revision history of this file is included at the bottom of this
// source.
//============================================================================
    header('Cache-Control: no-cache, must-revalidate');
    header('Expires: -1');
    header('Pragma: no-cache');
    define('displayVersion', '0.0.1');
    define('updatedDate', '2014-12-16');
    define('sourceVersion', displayVersion . '.' . updatedDate);
    include('/var/www/trunk/script/server/MainDefs.php');
    //------------------------------------------------------------------------
    // DTSTest-specific websites
    //------------------------------------------------------------------------
    define('DTSTest_PublicDir', QD_PublicDir . 'DTSTest/');
    define('DTSTest_PkgDir', DTSTest_PublicDir . 'pkg/');
    define('DTSTest_HelpSite', DTSTest_PublicDir . 'DTSTest-Help.php');
    define('DTSTest_ArchiveSite', DTSTest_PublicDir . 'DTSTest-Archive.php');
    define('DTSTest_DownloadSite', DTSTest_PublicDir . 'DTSTest-Download.php');
    //------------------------------------------------------------------------
    // Packages
    //------------------------------------------------------------------------
    define('releaseVersion', '0.0.3');
    define('DTSTest_Software', DTSTest_PkgDir . 'DTSTest-Setup-' . releaseVersion . '.exe');
    //------------------------------------------------------------------------
    // Support
    //------------------------------------------------------------------------
    define('emailSubject' , 'DTSTest Help (Version ' . sourceVersion . ')');
    define('reportIssues',
        'Please communicate problems and suggestions to <a href="' . mailSite . '?emailSubject=' .
        emailSubject . '&dest=support" target="_blank">Quartzdyne Support</a>');
    //------------------------------------------------------------------------
    include('/script/server/compresshtml.php');
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html lang="en-US">
    <head>
        <title>DTSTest Help</title>
        <meta http-equiv="content-type" content="text/html; charset=UTF-8" />
        <meta name="description" content="This page displays the DTSTest help" />
        <meta name="keywords" content="quartzdyne, quartz, pressure, temperature, sensor, transducer, help, DTSTest" />
        <meta name="distribution" content="global" />
        <meta name="author" content="Noji Ratzlaff" />
        <link href="/image/quartzdyne.ico" rel="shortcut icon" type="image/x-icon" />
        <link href="/style/qdprogstd.css" rel="stylesheet" type="text/css" />
        <link href="/style/reset1.css" rel="stylesheet" type="text/css" />
        <link href="/style/table1.css" rel="stylesheet" type="text/css" />
        <style type="text/css">
            body
            {
                background-image: url('/image/white_sand.jpg');
                font: 12px verdana,sans-serif;
                margin-left: 16px;
                margin-right: 16px;
                margin-top: 8px;
            }
            div.footer
            {
                color: black;
                font-size: 80%;
                font-weight: normal;
                margin-top: 10px;
                margin-bottom: 10px;
            }
        </style>
        <?  //----------------------------------------------------------------
            // Invoke the javascript page header functions
            //----------------------------------------------------------------
        ?>
        <script src="<?=clientScriptDir ?>PageHeader.js" type="text/javascript"></script>
        <script src="<?=clientScriptDir ?>ExpandCollapse.js" type="text/javascript"></script>
        <?  //----------------------------------------------------------------
            // Define local javascript functions
            //----------------------------------------------------------------
        ?>
        <script type="text/javascript">
<!--
            //----------------------------------------------------------------
            // display_pic
            //
            // Displays the specified picture, depending on picture type,
            // Windows version, and size
            //----------------------------------------------------------------
            function display_pic(pic, picType, os, size)
            {
                var     fileType;
                var     fullPic;
                //------------------------------------------------------------
                switch (os)
                {
                    case 'W7' :
                    case 'W8' :
                    case '08R2' :
                        fileType = 'png';
                        break;
                    case 'Vista' :
                        fileType = 'jpg';
                        break;
                    default :
                        fileType = 'bmp';
                        break;
                }
                switch (picType)
                {
                    case 'Window' :
                        fullPic = os + '/' + pic + '-' + os + '.' + fileType;
                        if (size == null)
                            size = '500';
                        document.write(
                             '<img src="image/' + fullPic + '" style="text-align:center; width:' + size + 'px;" />');
                        break;
                    case 'Hardware' :
                    case 'Manual' :
                        fullPic = picType + '/' + pic + '.' + fileType;
                        if (size == null)
                            size = '500';
                        document.write(
                             '<img src="image/' + fullPic + '" style="text-align:center; width:' + size + 'px;" />');
                        break;
                    default :
                        var     sizeSpec = '';
                        fullPic = os + '/' + pic + '-' + picType + '-' + os + '.' + fileType;
                        if (size != null)
                        {
                            switch (size)
                            {
                                case '1' :
                                    sizeSpec = ' width:72px; height:22px;';
                                    break;
                                case '2' :
                                    sizeSpec = ' width:86px; height:20px;';
                                    break;
                                default:
                                    sizeSpec = ' width:' + size + 'px;';
                                    break;
                            }
                        }
                        document.write(
                             '<img src="image/' + fullPic + '" style="vertical-align:middle;' + sizeSpec + '" />');
                        break;
                }
            }                           // end of display_pic()
            //----------------------------------------------------------------
            // display_ie_pic
            //
            // Displays the specified picture, depending on picture type,
            // browser version, and Windows version; meant specifically for
            // images that have browser-dependent appearances
            //----------------------------------------------------------------
            function display_ie_pic(pic, picType)
            {
                switch (picType)
                {
                    case 'Button' :
                    case 'Label' :
                    case 'Pulldown' :
                        if (browserFlag == 'IE 9')
                            pic = 'Vista/' + pic + '-' + picType + '-IE9-Vista.jpg';
                        else
                            pic = 'XP/' + pic + '-' + picType + '-XP.bmp';
                        document.write(
                             '<img src="image/' + pic + '" style="vertical-align:middle;" />');
                        break;
                    case 'Window' :
                    default :
                        if (browserFlag == 'IE 9')
                            pic = 'Vista/' + pic + '-IE9-Vista.jpg';
                        else
                            pic = 'XP/' + pic + '-XP.bmp';
                        document.write(
                             '<img src="image/' + pic + '" style="text-align:center; width:500px;" />');
                        break;
                }
            }                           // end of display_ie_pic()
            //----------------------------------------------------------------
            // jump_within_doc
            //
            // Expands the text of the specified category and topic, then
            // jumps to the specified tag whose text is displayed as a link
            //----------------------------------------------------------------
            function jump_within_doc(text, linkTag, topic, category)
            {
                //------------------------------------------------------------
                if (category == null)
                    category = 'Software_Man';
                document.write(
                    '<a href="#' + linkTag + '" onclick="expand_sub(\'' + category +
                    '\');expand_sub(\'' + topic + '\')"><b>' + text + '</b></a>');
            }                           // end of jump_within_doc()
            //----------------------------------------------------------------
            // display_footer
            //
            // Displays a footer
            //----------------------------------------------------------------
            function display_footer()
            {
                //------------------------------------------------------------
                document.write(
                    '<div class="footer" id="footer"><?=reportIssues ?><br /><br />' +
                    '<a href="#doc_top">Return to the top of the page</a></div>');
            }                           // end of display_footer()
//-->
        </script>
    </head>
    <body onselectstart="event.returnValue=false;">
        <div id="qd_div" lang="QD"></div>
        <div style="margin:auto; text-align:center; width:1000px;" id="MainHeader">
            <?  //------------------------------------------------------------
                // Display the company logo and a button to print the page
                //------------------------------------------------------------
            ?>
            <a href="<?=QD_HomeDir ?>" target="_blank" name="doc_top">
                <img src="/image/QDDoverLogo.png" style="float:left; width:150px; margin-bottom:10px;" alt="Quartzdyne" />
            </a>
            <div style="margin-left:20px; margin-bottom:10px; text-align:center; float:left;">
                <div style="color:black; font-weight:bold; font-size:200%;">
                    <span style="color:orange; font-style:italic; font-weight:extra-bold; font-family:Arial,sans;">
                        <acronym title="Quartzdyne DTSTest">
                            DTSTest
                        </acronym>
                    </span>
                    Help Center
                </div>
                <span style="font-size:120%; margin-top:5px;">
                    <?=date('D d M Y h:i:s a'); ?>
                </span>
                <span>
                    <form style="margin-top:10px;">
                        <input
                            type="button"
                            onClick="window.print()"
                            value=" Print This Help Page "
                            style="color:blue;" />
                    </form>
                </span>
            </div>
        </div>                          <? // end of MainHeader ?>
        <div style="clear:both;" id="MainBody">
            <?  //------------------------------------------------------------
                // Display the header of the help text
                //------------------------------------------------------------
            ?>
            <div style="margin-top:5px; margin-bottom:10px;">
                <a href="<?=DTSTest_DownloadSite ?>" target="_blank">Download</a> and install
                <a href="<?=DTSTest_DownloadSite ?>" target="_blank">
                    <img src="image/DTSTest-Logo.png" style="height:40px; width:60px; vertical-align:middle;" alt="DTSTest" />
                </a>
                software and related tools
                <br />
                <div style="color:blue; margin-bottom:10px; cursor:pointer;" id="ExpandAll"
                    onclick="expand_collapse_all()"
                    ondblclick="expand_collapse_all()"
                    onmouseover="this.style.color = 'green';"
                    onmouseout="this.style.color = 'blue';">
                    <img src="/image/Red-Dot.gif" class="centerDot" />
                    Expand the entire help text
                </div>
                <?=reportIssues ?>
            </div>
            <?  //------------------------------------------------------------
                // Display the actual help text
                //------------------------------------------------------------
            ?>
            <hr class="redLine" />
            <div style="margin-top:10px" id="Help_Section">
                <div style="font-size:180%; color:blue; font-weight:bold; cursor:default;">DTSTest Help</div>
                <?  //------------------------------------------------------------
                    // Overview
                    //------------------------------------------------------------
                ?>
                <div class="category" id="Overview"
                    onclick="expand_collapse('Overview_Topics')"
                    ondblclick="expand_collapse('Overview_Topics')"
                    onmouseover="this.style.color = 'green';"
                    onmouseout="this.style.color = 'blue';">
                    <img src="/image/SpinStar.gif" class="spinStar" />
                    Overview
                </div>
                <div class="invisible" id="Overview_Topics" lang="QD">
                    <div class="topic"
                        onclick="expand_collapse('Overview_What')"
                        ondblclick="expand_collapse('Overview_What')"
                        onmouseover="this.style.color = 'darkgoldenrod';"
                        onmouseout="this.style.color = 'purple';">
                        What Is DTSTest?<a name="About_DTSTest"></a>
                    </div>
                    <div class="subtopic" id="Overview_What" lang="QD">
                        The DTSTest&trade;, or the Quartzdyne<sup>&reg;</sup> New Software,
                        is a combination program and source code designed to provide a
                        template for creating new GUI software, complete with support
                        web pages.
                        <br />
                    </div>
                </div>                  <? // end of Overview_Topics ?>
                <?  //------------------------------------------------------------
                    // Installation
                    //------------------------------------------------------------
                ?>
                <div class="category" id="Installation" name="install_top"
                    onclick="expand_collapse('Installation_Topics')"
                    ondblclick="expand_collapse('Installation_Topics')"
                    onmouseover="this.style.color = 'green';"
                    onmouseout="this.style.color = 'blue';">
                    <img src="/image/SpinStar.gif" class="spinStar" />
                    Installation
                </div>
                <div class="invisible" id="Installation_Topics" lang="QD">
                    <div class="topic"
                        onclick="expand_collapse('Install_Software')"
                        ondblclick="expand_collapse('Install_Software')"
                        onmouseover="this.style.color = 'darkgoldenrod';"
                        onmouseout="this.style.color = 'purple';">
                        Software Download and Installation<a name="Software_Installation"></a>
                    </div>
                    <div class="subtopic" id="Install_Software" lang="QD">
                        <div style="margin-top:10px; margin-bottom:10px;" lang="QD">
                            Follow these instructions to install the software on your computer. <b>You need
                            administrator privileges to install the software.</b>
                        </div>
                        <a href="<?=DTSTest_Software ?>">Download</a> the software directly from the <a href="<?=DTSTest_DownloadSite ?>" target="_blank">DTSTest Download Center</a>.
                        <br />
                    </div>
                </div>                  <? // end of Installation_Topics ?>
                <?  //------------------------------------------------------------
                    // Software Manual
                    //------------------------------------------------------------
                ?>
                <div class="category" id="Software_Manual"
                    onclick="expand_collapse('Software_Man')"
                    ondblclick="expand_collapse('Software_Man')"
                    onmouseover="this.style.color = 'green';"
                    onmouseout="this.style.color = 'blue';">
                    <img src="/image/SpinStar.gif" class="spinStar" />
                    Software User Guide
                </div>
                <div class="invisible" id="Software_Man" lang="QD">
                    <script type="text/javascript">display_pic('Home-Window', 'Manual', 'W7', '800');</script>
                    <br /><br />
                    <div class="topic"
                        onclick="expand_collapse('Software_Overview')"
                        ondblclick="expand_collapse('Software_Overview')"
                        onmouseover="this.style.color = 'darkgoldenrod';"
                        onmouseout="this.style.color = 'purple';">
                        Software Overview
                    </div>
                    <div class="subtopic" id="Software_Overview" lang="QD">
                        The Quartzdyne<sup>&reg;</sup> DTSTest&trade; software
                        is a template program that allows you to do create
                        ready-made GUI applications with comprehensive built-in
                        utilities in very little time.
                        <br />
                        <script type="text/javascript">display_footer();</script>
                    </div>
                    <div class="topic"
                        onclick="expand_collapse('Software_Startup')"
                        ondblclick="expand_collapse('Software_Startup')"
                        onmouseover="this.style.color = 'darkgoldenrod';"
                        onmouseout="this.style.color = 'purple';">
                        At Startup<a name="At_Startup"></a>
                    </div>
                    <div class="subtopic" id="Software_Startup" lang="QD">
                        When you start the software running, it performs a number of startup tasks, in
                        the following order (not an exhaustive list):
                        <ol>
                            <li style="list-style-type:disc;">
                                Processes any specified command-line parameters
                            </li>
                            <li style="list-style-type:disc;">
                                Checks to make sure the DTSTest software is not already running
                            </li>
                            <li style="list-style-type:disc;">
                                Allocates and initializes internal structures and other data elements
                            </li>
                            <li style="list-style-type:disc;">
                                Creates the error log, and the event log if you have selected to do so
                            </li>
                            <li style="list-style-type:disc;">
                                Determines the Windows version of your computer
                            </li>
                            <li style="list-style-type:disc;">
                                Retrieves the config data save from the previous run of the software
                            </li>
                            <li style="list-style-type:disc;">
                                Sets the foundation for the GUI by installing icons, images, and sounds, then
                                initializes the program GUI components and the infrastructure for the
                                windows and their contents
                            </li>
                            <li style="list-style-type:disc;">
                                Begins constructing the Opening ('Home') Window, the tool strip, and the status
                                strip
                            </li>
                            <li style="list-style-type:disc;">
                                Checks whether the installed version of the software matches that listed on
                                Quartzdyne's website, and prompts for download and installation of the latest
                                update available online
                            </li>
                        </ol>
                        <script type="text/javascript">display_footer();</script>
                    </div>
                    <div class="topic"
                        onclick="expand_collapse('Software_Home')"
                        ondblclick="expand_collapse('Software_Home')"
                        onmouseover="this.style.color = 'darkgoldenrod';"
                        onmouseout="this.style.color = 'purple';">
                        Opening Window<a name="Opening_Window"></a>
                        <div class="subtopic" id="Software_Home" lang="QD">
                            When the software first appears, it presents you with the program name, software
                            version, the tool strip, an exit button, the status bar, the main progress bar,
                            and the current date-and-time.
                            <br />
                            <script type="text/javascript">display_footer();</script>
                        </div>
                    </div>
                    <div class="topic"
                        onclick="expand_collapse('Software_Expert')"
                        ondblclick="expand_collapse('Software_Expert')"
                        onmouseover="this.style.color = 'darkgoldenrod';"
                        onmouseout="this.style.color = 'purple';">
                        Expert Mode<a name="Expert_Mode"></a>
                    </div>
                    <div class="subtopic" id="Software_Expert" lang="QD">
                        <script type="text/javascript">display_pic('Expert-Mode', 'Manual', 'W7', '800');</script>
                        <br /><br />
                        An <b>Expert Mode</b> (advanced) interface is provided for testers who feel comfortable
                        enough with the DTSTest software to understand details beyond that of a regular tester.
                        The software displays the Expert Mode tools when you click the Functions pull-down
                        on the tool strip, then select <b>Enable Expert Mode</b>.
                        <br /><br />
                        Effects of Expert Mode on the rest of the software<br />
                            <div style="margin-left:40px;">Exposes functions not normally available</div>
                            <div style="margin-left:40px;">Save and delete files without warning</div>
                        <br />
                        Click <b><i>Program Information</i></b> to display much of what the software knows about
                        the state of the hardware and software at the moment you clicked the button.
                        <br /><br />
                        Program Modal Messages
                        <br /><br />
                        Event Log Recording
                        <br />
                        <script type="text/javascript">display_footer();</script>
                    </div>
                    <div class="topic"
                        onclick="expand_collapse('Software_CommandLine')"
                        ondblclick="expand_collapse('Software_CommandLine')"
                        onmouseover="this.style.color = 'darkgoldenrod';"
                        onmouseout="this.style.color = 'purple';">
                        Command Line<a name="Command_Line"></a>
                    </div>
                    <div class="subtopic" id="Software_CommandLine" lang="QD">
                        DTSTest has an optional command-line interface available for those who want to
                        start the software in the Command Prompt window. An advantage to starting the
                        software this way is that you have the ability to specify a limited set of
                        command-line parameters to the program, which can affect or control software
                        operations before the GUI begins running, or without displaying the GUI at all,
                        depending on the parameters.
                        <br /><br />
                        <div style="margin-left:40px;">
                            Accepted command-line parameters (switches prefixed by '/' can also be prefixed
                            by '-' instead)
                            <br /><br />
                            <div style="margin-left:40px;">/mb : Enables 'basic' modal messages (/mb- disables)</div><br />
                            <div style="margin-left:40px;">/me : Enables 'error' modal messages (/me- disables)</div><br />
                            <div style="margin-left:40px;">/ms : Enables stack traces on errors (/ms- disables)</div><br />
                            <div style="margin-left:40px;">/mv : Enables 'verbose' modal messages (/mv- disables)</div><br />
                            <div style="margin-left:40px;">/md : Enables 'detailed' modal messages (/md- disables)</div><br />
                            <div style="margin-left:40px;">/mx : Enables 'experimental' modal messages (/mx- disables)</div><br />
                            <div style="margin-left:40px;">/m0 : Disables all modal messages</div><br />
                            <div style="margin-left:40px;">/evt : Starts logging events in the event log</div><br />
                            <div style="margin-left:40px;">/evtv : Starts logging verbose events in the event log</div><br />
                            <div style="margin-left:40px;">/cfg : Load config information on startup (/cfg- prevents)</div><br />
                            <div style="margin-left:40px;">/gui : Display the graphical user interface (/gui- for command-line only)</div><br />
                            <div style="margin-left:40px;">/x : Starts the software in Expert Mode (/x- disables)</div><br />
                            <div style="margin-left:40px;">/h : Displays the command-line usage and the online help</div><br />
                            <div style="margin-left:40px;">/? : Displays the usage window only</div><br />
                        </div>
                        <script type="text/javascript">display_footer();</script>
                    </div>
                    <div class="topic"
                        onclick="expand_collapse('Software_Errors')"
                        ondblclick="expand_collapse('Software_Errors')"
                        onmouseover="this.style.color = 'darkgoldenrod';"
                        onmouseout="this.style.color = 'purple';">
                        Errors<a name="Errors"></a>
                    </div>
                    <div class="subtopic" id="Software_Errors" lang="QD">
                        Description of Errors<br />
                        <div style="margin-left:40px;">
                            Software Errors<br />
                        </div>
                        <div style="margin-left:40px;">
                            The Error Log<br />
                        </div>
                        <div style="margin-left:40px;">
                            Error Codes<br />
                        </div>
                        <script type="text/javascript">display_footer();</script>
                    </div>
                </div>                  <? // end of Software_Man ?>
            </div>                      <? // end of Help_Section ?>
        </div>                          <? // end of MainBody ?>
        <hr class="redLine" />
        <div class="page_bottom" id="MainFooter">
            <i class="flush_left">Copyright &copy; <?=date('Y'); ?> <a href="<?=QD_HomeDir ?>" target="_blank">Quartzdyne, Inc.</a>, a <a href="<?=DoverDir ?>" target="_blank">Dover</a><sup>&reg;</sup> company</i>
            <span class="flush_right" style="font-size:80%;">(Version <?=sourceVersion ?> [<script type="text/javascript">document.write(browserFlag);</script>])</span>
        </div>                          <? // end of MainFooter ?>
    </body>
</html>
<?php
//============================================================================
// DTSTest-Help.php Revision History (defined as sourceVersion in this source)
//
//  16 Dec 2014     0.0.1       1.  Initial public release
//
// End of DTSTest-Help.php
//============================================================================
?>
