<?php
//============================================================================
// //qdlamp/var/www/trunk/public/DTSTest/DTSTest-Archive.php
//
// Download page for DTSTest archived software
//
// Copyright (C) 2014 - 2015 Quartzdyne, Inc.  All rights reserved.
//
// No part of this source code may be reproduced or transmitted in any form or
// by any means, electronic or mechanical, including photocopying, recording,
// or any information storage and retrieval system, without express written
// permission from Quartzdyne, Inc.  Further, no use of this source code is
// permitted in any form or means without a valid, written license agreement
// with Quartzdyne, Inc.  While every reasonable precaution has been taken in
// the preparation of this source code, Quartzdyne, Inc., assumes no
// responsibility for errors, omissions, or damages from the use of the source
// code contained herein.
//
// NEITHER QUARTZDYNE, INC., ANY MEMBER OF QUARTZDYNE, INC., NOR ANY PERSON OR
// ORGANIZATION ACTING ON BEHALF OF THEM MAKES ANY WARRANTY OR REPRESENTATION
// WHATSOEVER, EXPRESS OR IMPLIED, INCLUDING ANY WARRANTY OF MERCHANTABILITY
// OR FITNESS FOR ANY PURPOSE WITH RESPECT TO THE SOURCE CODE OR ASSUMES ANY
// LIABILITY WHATSOEVER WITH RESPECT TO ANY USE OF THE SOURCE CODE OR ANY
// PORTION THEREOF OR WITH RESPECT TO ANY DAMAGES THAT MAY RESULT FROM SUCH
// USE.
//
// Noji Ratzlaff
//
// See DTSTest.log for a complete history of all updates, changes, and revisions
// of this source and other files and policies regarding DTSTest software.  Also,
// a detailed revision history of this file is included at the bottom of this
// source.
//============================================================================
    header('Cache-Control: no-cache, must-revalidate');
    header('Expires: -1');
    header('Pragma: no-cache');
    define('displayVersion', '0.0.1');
    define('updatedDate', '2014-12-16');
    define('sourceVersion', displayVersion . '.' . updatedDate);
    include('/var/www/trunk/script/server/MainDefs.php');
    //------------------------------------------------------------------------
    // DTSTest-specific websites
    //------------------------------------------------------------------------
    define('DTSTest_PublicDir', QD_PublicDir . 'DTSTest/');
    define('DTSTest_PkgDir', DTSTest_PublicDir . 'pkg/');
    define('DTSTest_HelpSite', DTSTest_PublicDir . 'DTSTest-Help.php');
    define('DTSTest_DownloadSite', DTSTest_PublicDir . 'DTSTest-Download.php');
    //------------------------------------------------------------------------
    // Packages
    //------------------------------------------------------------------------
    define('DTSTest_SW_Version_0_0_2', '0.0.2');
    define('DTSTest_SW_0_0_2', 'DTSTest-Setup-' . DTSTest_SW_Version_0_0_2 . '.zip');
    define('DTSTest_SW_Date_0_0_2', '03-28-2012');
    define('DTSTest_SW_Version_0_0_1', '0.0.1');
    define('DTSTest_SW_0_0_1', 'DTSTest-Setup-' . DTSTest_SW_Version_0_0_1 . '.zip');
    define('DTSTest_SW_Date_0_0_1', '02-29-2012');
    //------------------------------------------------------------------------
    // Support
    //------------------------------------------------------------------------
    define('emailSubject' , 'DTSTest Archives (Version ' . sourceVersion . ')');
    define('reportIssues',
        'Please communicate problems and suggestions to <a href="' . mailSite . '?emailSubject=' .
        emailSubject . '&dest=support">Quartzdyne Support</a>');
    //------------------------------------------------------------------------
    include('/script/server/compresshtml.php');
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html lang="en-US">
    <head>
        <title>DTSTest Archives</title>
        <meta http-equiv="content-type" content="text/html; charset=UTF-8" />
        <meta name="description" content="This page displays the DTSTest software archives site" />
        <meta name="keywords" content="quartzdyne, quartz, pressure, temperature, sensor, transducer, archive, DTSTest" />
        <meta name="distribution" content="global" />
        <meta name="author" content="Noji Ratzlaff" />
        <link href="/image/quartzdyne.ico" rel="shortcut icon" type="image/x-icon" />
        <link href="/style/qdprogstd.css" rel="stylesheet" type="text/css" />
        <link href="/style/reset1.css" rel="stylesheet" type="text/css" />
        <link href="/style/table1.css" rel="stylesheet" type="text/css" />
        <style type="text/css">
            body
            {
                background-image: url('/image/white_sand.jpg');
                font: 100% verdana,sans-serif;
                margin-left: 16px;
                margin-right: 16px;
                margin-top: 8px;
            }
            @media print
            {
                table
                {
                    font-size: 140%;
                }
            }
        </style>
        <?  //----------------------------------------------------------------
            // Invoke the javascript page header functions
            //----------------------------------------------------------------
        ?>
        <script src="<?=clientScriptDir ?>PageHeader.js" type="text/javascript"></script>
        <script src="<?=clientScriptDir ?>ExpandCollapse.js" type="text/javascript"></script>
        <?  //----------------------------------------------------------------
            // Define local javascript functions
            //----------------------------------------------------------------
        ?>
        <script type="text/javascript">
<!--
//-->
        </script>
    </head>
    <body onselectstart="event.returnValue=false;">
        <div id="qd_div" lang="QD"></div>
        <?  //----------------------------------------------------------------
            // Display the company logo and prompt the user to print the page
            //----------------------------------------------------------------
        ?>
        <div style="margin:auto; text-align:center; width:1000px;" id="MainHeader">
            <a href="http://www.quartzdyne.com" target="_blank" name="doc_top">
                <img src="/image/QDDoverLogo.png" style="float:left; width:150px;" alt="Quartzdyne" />
            </a>
            <div style="margin-left:20px; margin-bottom:10px; text-align:center; float:left;">
                <div style="color:black; font-weight:bold; font-size:160%;">
                    <span style="color:orange; font-style:italic; font-weight:extra-bold; font-family:Arial,sans;">
                        <acronym title="Quartzdyne DTSTest Software">
                            DTSTest
                        </acronym>
                    </span>
                    Software Archives
                </div>
                <span style="font-size:120%; margin-top:5px;">
                    <?=date('D d M Y h:i:s a'); ?>
                </span>
                <span>
                    <form style="margin-top:10px;">
                        <input
                            type="button"
                            onClick="window.print()"
                            value=" Print This Page "
                            style="color:blue;" />
                    </form>
                </span>
            </div>
        </div>                          <? // end of MainHeader ?>
        <div style="clear:both;" id="MainBody">
            <a href="<?=DTSTest_DownloadSite ?>">Return</a> to the DTSTest Download Center
            <br /><br />
            <a href="<?=DTSTest_HelpSite ?>">Return</a> to the DTSTest Help Center
            <br /><br />
            <?=reportIssues ?>
            <hr class="redLine" />
            <div class="archive_category" id="ProductionSW"
                onclick="expand_collapse('ProductionSW_Body')"
                ondblclick="expand_collapse('ProductionSW_Body')"
                onmouseover="this.style.color = 'green';"
                onmouseout="this.style.color = 'blue';">
                <img src="/image/Purple-Dot.gif" class="centerDot" />
                DTSTest Production Software
            </div>
            <div class="archive_invisible" id="ProductionSW_Body" lang="QD">
                Version <a href="archive/<?=DTSTest_SW_0_0_2 ?>"><?=DTSTest_SW_Version_0_0_2 ?></a> (<?=DTSTest_SW_Date_0_0_2 ?>)
                <br /><br />
                Version <a href="archive/<?=DTSTest_SW_0_0_1 ?>"><?=DTSTest_SW_Version_0_0_1 ?></a> (<?=DTSTest_SW_Date_0_0_1 ?>)
            </div>
        </div>                          <? // end of MainBody ?>
        <hr class="redLine" />
        <div class="page_bottom" id="MainFooter">
            <i class="flush_left">Copyright &copy; <?=date('Y'); ?> <a href="<?=QD_HomeDir ?>" target="_blank">Quartzdyne, Inc.</a>, a <a href="<?=DoverDir ?>" target="_blank">Dover</a><sup>&reg;</sup> company</i>
            <span class="flush_right" style="font-size:80%;">(Version <?=sourceVersion ?> [<script type="text/javascript">document.write(browserFlag);</script>])</span>
        </div>                          <? // end of MainFooter ?>
    </body>
</html>
<?php
//============================================================================
// DTSTest-Archive.php Revision History (defined as sourceVersion in this source)
//
//  16 Dec 2014     0.0.1       1.  Initial public release
//
// End of DTSTest-Archive.php
//============================================================================
?>
