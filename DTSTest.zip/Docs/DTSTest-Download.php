<?php
//============================================================================
// //qdlamp/var/www/trunk/public/DTSTest/DTSTest-Download.php
//
// Download page for DTSTest and associated entities
//
// Copyright (C) 2014 - 2015 Quartzdyne, Inc.  All rights reserved.
//
// No part of this source code may be reproduced or transmitted in any form or
// by any means, electronic or mechanical, including photocopying, recording,
// or any information storage and retrieval system, without express written
// permission from Quartzdyne, Inc.  Further, no use of this source code is
// permitted in any form or means without a valid, written license agreement
// with Quartzdyne, Inc.  While every reasonable precaution has been taken in
// the preparation of this source code, Quartzdyne, Inc., assumes no
// responsibility for errors, omissions, or damages from the use of the source
// code contained herein.
//
// NEITHER QUARTZDYNE, INC., ANY MEMBER OF QUARTZDYNE, INC., NOR ANY PERSON OR
// ORGANIZATION ACTING ON BEHALF OF THEM MAKES ANY WARRANTY OR REPRESENTATION
// WHATSOEVER, EXPRESS OR IMPLIED, INCLUDING ANY WARRANTY OF MERCHANTABILITY
// OR FITNESS FOR ANY PURPOSE WITH RESPECT TO THE SOURCE CODE OR ASSUMES ANY
// LIABILITY WHATSOEVER WITH RESPECT TO ANY USE OF THE SOURCE CODE OR ANY
// PORTION THEREOF OR WITH RESPECT TO ANY DAMAGES THAT MAY RESULT FROM SUCH
// USE.
//
// Noji Ratzlaff
//
// See DTSTest.log for a complete history of all updates, changes, and revisions
// of this source and other files and policies regarding DTSTest software.  Also,
// a detailed revision history of this file is included at the bottom of this
// source.
//============================================================================
    header('Cache-Control: no-cache, must-revalidate');
    header('Expires: -1');
    header('Pragma: no-cache');
    define('displayVersion', '0.0.1');
    define('updatedDate', '2014-12-16');
    define('sourceVersion', displayVersion . '.' . updatedDate);
    include('/var/www/trunk/script/server/MainDefs.php');
    //------------------------------------------------------------------------
    // DTSTest-specific websites
    //------------------------------------------------------------------------
    define('DTSTest_PublicDir', QD_PublicDir . 'DTSTest/');
    define('DTSTest_PkgDir', DTSTest_PublicDir . 'pkg/');
    define('DTSTest_HelpSite', DTSTest_PublicDir . 'DTSTest-Help.php');
    define('DTSTest_ArchiveSite', DTSTest_PublicDir . 'DTSTest-Archive.php');
    //------------------------------------------------------------------------
    // Packages
    //------------------------------------------------------------------------
    define('releaseVersion', '0.0.3');
    define('releaseDate', '06-12-2012');
    define('DTSTest_Release', DTSTest_PkgDir . 'DTSTest-Setup-' . releaseVersion . '.exe');
    //------------------------------------------------------------------------
    // Support
    //------------------------------------------------------------------------
    define('emailSubject' , 'DTSTest Download (Version ' . sourceVersion . ')');
    define('reportIssues',
        'Please communicate problems and suggestions to <a href="' . mailSite . '?emailSubject=' .
        emailSubject . '&dest=support">Quartzdyne Support</a>');
    //------------------------------------------------------------------------
    include('/script/server/compresshtml.php');
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html lang="en-US">
    <head>
        <title>DTSTest Download</title>
        <meta http-equiv="content-type" content="text/html; charset=UTF-8" />
        <meta name="description" content="This page displays the DTSTest download site" />
        <meta name="keywords" content="quartzdyne, quartz, pressure, temperature, sensor, transducer, download, DTSTest " />
        <meta name="distribution" content="global" />
        <meta name="author" content="Noji Ratzlaff" />
        <link href="/image/quartzdyne.ico" rel="shortcut icon" type="image/x-icon" />
        <link href="/style/qdprogstd.css" rel="stylesheet" type="text/css" />
        <link href="/style/reset1.css" rel="stylesheet" type="text/css" />
        <link href="/style/table1.css" rel="stylesheet" type="text/css" />
        <style type="text/css">
            body
            {
                background-image: url('/image/white_sand.jpg');
                font: 100% verdana,sans-serif;
                margin-left: 16px;
                margin-right: 16px;
                margin-top: 8px;
            }
            @media print
            {
                table
                {
                    font-size: 140%;
                }
            }
        </style>
        <?  //----------------------------------------------------------------
            // Invoke the javascript page header functions
            //----------------------------------------------------------------
        ?>
        <script src="<?=clientScriptDir ?>PageHeader.js" type="text/javascript"></script>
        <script src="<?=clientScriptDir ?>ExpandCollapse.js" type="text/javascript"></script>
        <?  //----------------------------------------------------------------
            // Define local javascript functions
            //----------------------------------------------------------------
        ?>
        <script type="text/javascript">
<!--
//-->
        </script>
    </head>
    <body onselectstart="event.returnValue=false;">
        <div id="qd_div" lang="QD"></div>
        <?  //----------------------------------------------------------------
            // Display the company logo and prompt the user to print the page
            //----------------------------------------------------------------
        ?>
        <div style="margin:auto; text-align:center; width:1000px;" id="MainHeader">
            <a href="<?=QD_HomeDir ?>" target="_blank" name="doc_top">
                <img src="/image/QDDoverLogo.png" style="float:left; width:150px;" alt="Quartzdyne" />
            </a>
            <div style="margin-left:20px; margin-bottom:10px; text-align:center; float:left;">
                <div style="color:black; font-weight:bold; font-size:160%;">
                    <span style="color:orange; font-style:italic; font-weight:extra-bold; font-family:Arial,sans;">
                        <acronym title="Quartzdyne DTSTest Software">
                            DTSTest
                        </acronym>
                    </span>
                    Download Center
                </div>
                <span style="font-size:120%; margin-top:5px;">
                    <?=date('D d M Y h:i:s a'); ?>
                </span>
                <span>
                    <form style="margin-top:10px;">
                        <input
                            type="button"
                            onClick="window.print()"
                            value=" Print This Page "
                            style="color:blue;" />
                    </form>
                </span>
            </div>
        </div>                          <? // end of MainHeader ?>
        <div style="clear:both;" id="MainBody">
            <a href="<?=DTSTest_HelpSite ?>">Return</a> to the DTSTest Help Center<br />
            <br />
            <?=reportIssues ?>
            <hr class="redLine" />
            <a href="<?=DTSTest_Release ?>">
                <img src="/image/Download-Button.gif" style="width:110px; vertical-align:middle; margin-bottom:8px;" alt="Download" />
            </a>
            and install the <b>released</b>
            <a href="<?=DTSTest_Release ?>">
                <img src="image/DTSTest-Logo.png" style="height:40px; width:60px; vertical-align:middle;" alt="DTSTest" />
            </a>
            software (version <?=releaseVersion?> on <?=releaseDate ?>)
            <div class="download_category" id="SWChangeHistory"
                onclick="expand_collapse('SWChangeHistoryBody')"
                ondblclick="expand_collapse('SWChangeHistoryBody')"
                onmouseover="this.style.color = 'green';"
                onmouseout="this.style.color = 'blue';">
                History of Changes Made to the Released Software
            </div>
            <div class="invisible" id="SWChangeHistoryBody" lang="QD">
                <div class="download_topic"
                    onclick="expand_collapse('SW003ChangeHistory')"
                    ondblclick="expand_collapse('SW003ChangeHistory')"
                    onmouseover="this.style.color = 'darkgoldenrod';"
                    onmouseout="this.style.color = 'purple';">
                    Version 0.0.3
                </div>
                <div class="download_subtopic" id="SW003ChangeHistory" lang="QD">
                    <li style="list-style-type:decimal;">
                        Moved most of the functions into the main class as methods, to accommodate
                        a more seamless way of updating the software online
                    </li>
                    <li style="list-style-type:decimal;">
                        Now saves the command line, the name of the config file, and the program
                        flags as-is, to record the flags as they were during run-time
                    </li>
                    <li style="list-style-type:decimal;">
                        Added hand pointers to all active objects when they are moused over
                    </li>
                </div>
                <div class="download_topic"
                    onclick="expand_collapse('SW002ChangeHistory')"
                    ondblclick="expand_collapse('SW002ChangeHistory')"
                    onmouseover="this.style.color = 'darkgoldenrod';"
                    onmouseout="this.style.color = 'purple';">
                    Version 0.0.2
                </div>
                <div class="download_subtopic" id="SW002ChangeHistory" lang="QD">
                    <li style="list-style-type:decimal;">
                        Can display stack traces on encountering errors
                    </li>
                    <li style="list-style-type:decimal;">
                        Can send emails and/or text messages upon encountering errors
                    </li>
                    <li style="list-style-type:decimal;">
                        Added the ability to update itself (with user prompts) to a newer
                        version, if one is available online
                    </li>
                </div>
                <div class="download_topic"
                    onclick="expand_collapse('SW001ChangeHistory')"
                    ondblclick="expand_collapse('SW001ChangeHistory')"
                    onmouseover="this.style.color = 'darkgoldenrod';"
                    onmouseout="this.style.color = 'purple';">
                    Version 0.0.1
                </div>
                <div class="download_subtopic" id="SW001ChangeHistory" lang="QD">
                    <li style="list-style-type:decimal;">
                        Initial internal release
                    </li>
                    <li style="list-style-type:decimal;">
                        DTSTest software template, which includes many standard features,
                        including both GUI and command-line control, error logs, event
                        logging, and comprehensive online help
                    </li>
                </div>
            </div>                  <? // end of SWChangeHistoryBody ?>
            <b>Visit the <a href="<?=DTSTest_ArchiveSite ?>">archives</a> to download older versions of DTSTest-related software</b>
            <br />
        </div>                          <? // end of MainBody ?>
        <hr class="redLine" />
        <div class="page_bottom" id="MainFooter">
            <i class="flush_left">Copyright &copy; <?=date('Y'); ?> <a href="<?=QD_HomeDir ?>" target="_blank">Quartzdyne, Inc.</a>, a <a href="<?=DoverDir ?>" target="_blank">Dover</a><sup>&reg;</sup> company</i>
            <span class="flush_right" style="font-size:80%;">(Version <?=sourceVersion ?> [<script type="text/javascript">document.write(browserFlag);</script>])</span>
        </div>                          <? // end of MainFooter ?>
    </body>
</html>
<?php
//============================================================================
// DTSTest-Download.php Revision History (defined as sourceVersion in this source)
//
//  16 Dec 2014     0.0.1       1.  Initial public release
//
// End of DTSTest-Download.php
//============================================================================
?>
