<?php
//============================================================================
// //qdlamp/var/www/trunk/public/DTSTest/index.php
//
// Default page for DTSTest
//
// Copyright (C) 2014 - 2014 Quartzdyne, Inc.  All rights reserved.
//
// No part of this source code may be reproduced or transmitted in any form or
// by any means, electronic or mechanical, including photocopying, recording,
// or any information storage and retrieval system, without express written
// permission from Quartzdyne, Inc.  Further, no use of this source code is
// permitted in any form or means without a valid, written license agreement
// with Quartzdyne, Inc.  While every reasonable precaution has been taken in
// the preparation of this source code, Quartzdyne, Inc., assumes no
// responsibility for errors, omissions, or damages from the use of the source
// code contained herein.
//
// NEITHER QUARTZDYNE, INC., ANY MEMBER OF QUARTZDYNE, INC., NOR ANY PERSON OR
// ORGANIZATION ACTING ON BEHALF OF THEM MAKES ANY WARRANTY OR REPRESENTATION
// WHATSOEVER, EXPRESS OR IMPLIED, INCLUDING ANY WARRANTY OF MERCHANTABILITY
// OR FITNESS FOR ANY PURPOSE WITH RESPECT TO THE SOURCE CODE OR ASSUMES ANY
// LIABILITY WHATSOEVER WITH RESPECT TO ANY USE OF THE SOURCE CODE OR ANY
// PORTION THEREOF OR WITH RESPECT TO ANY DAMAGES THAT MAY RESULT FROM SUCH
// USE.
//
// Noji Ratzlaff
//
// A detailed revision history of this file is included at the bottom of this
// source.
//
// Updated 12-16-2014
//============================================================================
    header('Cache-Control: no-cache, must-revalidate');
    header('Expires: -1');
    header('Pragma: no-cache');
    header('Location: http://qd.quartzdyne.com/public/DTSTest/DTSTest-Help.php');
    define('displayVersion', '0.0.1');
    define('sourceVersion', displayVersion . '.2014-12-16');
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html lang="eng">
    <head>
        <title>Quartzdyne DTSTest</title>
        <meta name="keywords" content="quartzdyne,DTSTest,quartz,pressure,temperature,sensor,transducer" />
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
        <meta http-equiv="Pragma" content="no-cache" />
        <meta name="author" content="Noji Ratzlaff" />
        <link href="/image/quartzdyne.ico" rel="shortcut icon" type="image/x-icon" />
    </head>
    <body>
    </body>
</html>
<?php
//============================================================================
// index.php Revision History (defined as sourceVersion in this source)
//
//  16 Dec 2014     0.0.1       1.  Initial pubilc release
//
// End of index.php
//============================================================================
?>
